import { PrismaClient } from "@prisma/client"
const db = new PrismaClient()

async function main() {
  const admin = await db.user.findFirst({ where: { roles: { contains: "admin" } } })
  if (!admin) { console.log("no admin"); return }

  const existing = await db.stickerPack.count({ where: { isOfficial: true } })
  if (existing > 0) { console.log("official stickers already seeded"); return }

  const pack = await db.stickerPack.create({
    data: {
      name: "اموجی‌های کارول",
      ownerId: admin.id,
      isOfficial: true,
      coverUrl: "/stickers/like.png",
    },
  })

  const stickers = [
    { url: "/stickers/like.png", name: "لایک", category: "احساسات" },
    { url: "/stickers/laugh.png", name: "خنده", category: "احساسات" },
    { url: "/stickers/love.png", name: "عشق", category: "احساسات" },
    { url: "/stickers/sad.png", name: "غمگین", category: "احساسات" },
    { url: "/stickers/angry.png", name: "عصبانی", category: "احساسات" },
  ]
  for (const s of stickers) {
    await db.sticker.create({ data: { packId: pack.id, ...s, kind: "sticker" } })
  }
  console.log("Official stickers seeded:", stickers.length)
}

main().catch(e => { console.error(e); process.exit(1) }).finally(() => db.$disconnect())
