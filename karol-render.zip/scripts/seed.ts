import { PrismaClient } from "@prisma/client"
import bcrypt from "bcryptjs"
import { CONFIG } from "../src/lib/config"

const db = new PrismaClient()

async function main() {
  const adminExists = await db.user.findFirst({ where: { roles: { contains: "admin" } } })
  if (!adminExists) {
    const hash = await bcrypt.hash("admin123", 10)
    await db.user.create({
      data: {
        username: "admin",
        passwordHash: hash,
        displayName: "مدیر کارول",
        roles: "admin",
        coins: 1000000,
        isVip: true,
        vipExpiresAt: new Date(Date.now() + 365 * 86400000),
        dailyUploadLimitBytes: 2n * 1024n * 1024n * 1024n,
      },
    })
    console.log("Admin user created: admin / admin123")
  } else {
    console.log("Admin already exists")
  }

  for (const [k, v] of Object.entries(CONFIG.defaultSettings)) {
    await db.setting.upsert({ where: { key: k }, update: {}, create: { key: k, value: v } })
  }
  console.log("Default settings seeded")

  const roomsCount = await db.chatRoom.count()
  if (roomsCount === 0) {
    const admin = await db.user.findFirst({ where: { roles: { contains: "admin" } } })
    if (admin) {
      await db.chatRoom.createMany({
        data: [
          { name: "گفتگوی عمومی", description: "چت‌روم عمومی کارول", type: "public", ownerId: admin.id, order: 0 },
          { name: "موسیقی", description: "بحث و اشتراک موسیقی", type: "public", ownerId: admin.id, order: 1 },
          { name: "فیلم و ویدیو", description: "معرفی ویدیو و ریلز", type: "public", ownerId: admin.id, order: 2 },
          { name: "VIP کارول", description: "مخصوص اعضای وی‌آی‌پی", type: "vip", ownerId: admin.id, order: 3 },
        ],
      })
      console.log("Default chat rooms created")
    }
  }

  const shopCount = await db.shopItem.count()
  if (shopCount === 0) {
    await db.shopItem.createMany({
      data: [
        { title: "۱۰٬۰۰۰ کارول‌کوین", description: "شارژ کیف پول", price: 50000, kind: "coins", payload: "10000", active: true },
        { title: "۵۰٬۰۰۰ کارول‌کوین", description: "شارژ کیف پول + ۵٪ پاداش", price: 230000, kind: "coins", payload: "52500", active: true },
        { title: "۱۰۰٬۰۰۰ کارول‌کوین", description: "شارژ کیف پول + ۱۰٪ پاداش", price: 450000, kind: "coins", payload: "110000", active: true },
        { title: "اشتراک VIP یک‌ماهه", description: "دسترسی به بخش وی‌آی‌پی و آپلود نامحدود", price: 30000, kind: "vip", payload: "30", active: true },
      ],
    })
    console.log("Default shop items created")
  }

  const cfgCount = await db.configPackage.count()
  if (cfgCount === 0) {
    const pkgs = [
      { name: "۱۰ مگابایت", volumeBytes: 10n * 1024n * 1024n, priceCoins: 500, durationDays: 30 },
      { name: "۱۰۰ مگابایت", volumeBytes: 100n * 1024n * 1024n, priceCoins: 2000, durationDays: 30 },
      { name: "۵۰۰ مگابایت", volumeBytes: 500n * 1024n * 1024n, priceCoins: 6000, durationDays: 30 },
      { name: "۱ گیگابایت", volumeBytes: 1n * 1024n * 1024n * 1024n, priceCoins: 10000, durationDays: 30 },
      { name: "۲ گیگابایت", volumeBytes: 2n * 1024n * 1024n * 1024n, priceCoins: 18000, durationDays: 30 },
      { name: "۵ گیگابایت", volumeBytes: 5n * 1024n * 1024n * 1024n, priceCoins: 40000, durationDays: 30 },
    ]
    for (const p of pkgs) {
      await db.configPackage.create({ data: { ...p, active: true } })
    }
    console.log("Config packages seeded")
  }

  // sample v2ray config stock for testing
  const stockCount = await db.configStock.count()
  if (stockCount === 0) {
    const pkg = await db.configPackage.findFirst({ where: { name: "۱۰ مگابایت" } })
    if (pkg) {
      for (let i = 0; i < 5; i++) {
        await db.configStock.create({ data: { packageId: pkg.id, configText: `vless://demo-${i}@example.com:443?type=tcp&security=tls#Karol-Demo-${i}` } })
      }
      console.log("Sample config stock seeded")
    }
  }
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(() => db.$disconnect())
