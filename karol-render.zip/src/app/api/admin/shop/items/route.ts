import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET() {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const items = await db.shopItem.findMany({
    orderBy: [{ active: "desc" }, { kind: "asc" }, { price: "asc" }],
    select: {
      id: true, title: true, description: true, price: true, kind: true,
      payload: true, imageUrl: true, active: true, createdAt: true,
      _count: { select: { orders: true } },
    },
  })
  return NextResponse.json({ items })
}
