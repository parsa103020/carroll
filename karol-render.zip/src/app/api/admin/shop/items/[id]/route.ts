import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"
import { deleteObject, objectPathFromUrl } from "@/lib/storage"

export const runtime = "nodejs"

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  const { id } = await ctx.params
  const body = await req.json().catch(() => ({}))

  const data: any = {}
  if (typeof body.title === "string" && body.title.trim()) data.title = body.title.trim().slice(0, 200)
  if (typeof body.description === "string") data.description = body.description.trim().slice(0, 1000) || null
  if (body.price !== undefined) {
    const p = parseInt(body.price, 10)
    if (!Number.isFinite(p) || p < 0) return NextResponse.json({ error: "قیمت نامعتبر" }, { status: 400 })
    data.price = p
  }
  if (["coins", "vip", "custom"].includes(body.kind)) data.kind = body.kind
  if (typeof body.payload === "string") data.payload = body.payload
  if (typeof body.imageUrl === "string") data.imageUrl = body.imageUrl || null
  if (typeof body.active === "boolean") data.active = body.active

  if (Object.keys(data).length === 0)
    return NextResponse.json({ error: "چیزی برای به‌روزرسانی نیست" }, { status: 400 })

  const item = await db.shopItem.update({ where: { id }, data })
  return NextResponse.json({ item })
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  const { id } = await ctx.params
  const item = await db.shopItem.findUnique({ where: { id }, select: { id: true, imageUrl: true } })
  if (!item) return NextResponse.json({ error: "not found" }, { status: 404 })

  if (item.imageUrl) {
    const p = objectPathFromUrl(item.imageUrl)
    if (p) await deleteObject(p).catch(() => {})
  }
  await db.shopItem.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
