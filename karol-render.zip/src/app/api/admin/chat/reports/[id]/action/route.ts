import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"
import { deleteObject, objectPathFromUrl } from "@/lib/storage"
import { audit, getClientInfo } from "@/lib/audit"

export const runtime = "nodejs"

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  const { id } = await ctx.params
  const body = await req.json().catch(() => ({}))
  const action = body.action

  const report = await db.chatReport.findUnique({
    where: { id },
    include: { message: { select: { id: true, mediaUrl: true, userId: true } } },
  })
  if (!report) return NextResponse.json({ error: "not found" }, { status: 404 })

  const info = getClientInfo(req)
  const auditCtx = { actorId: session.user!.id, actorName: session.user!.username, ip: info.ip, userAgent: info.userAgent }

  if (action === "dismiss") {
    const updated = await db.chatReport.update({
      where: { id },
      data: { status: "dismissed" },
    })
    await audit(auditCtx, "chat.report_action", {
      targetType: "chat_report",
      targetId: id,
      description: `رد گزارش چت (dismiss)`,
      severity: "info",
      metadata: { reportId: id, action: "dismiss" },
    })
    return NextResponse.json({ report: updated })
  }

  if (action === "delete_message") {
    if (report.message) {
      if (report.message.mediaUrl) {
        const p = objectPathFromUrl(report.message.mediaUrl)
        if (p) await deleteObject(p).catch(() => {})
      }
      await db.chatMessage.update({
        where: { id: report.message.id },
        data: { deletedAt: new Date(), content: "[حذف توسط ادمین]", mediaUrl: null },
      })
    }
    const updated = await db.chatReport.update({
      where: { id },
      data: { status: "resolved" },
    })
    await audit(auditCtx, "chat.report_action", {
      targetType: "chat_report",
      targetId: id,
      description: `حذف پیام گزارش‌شده و بستن گزارش`,
      severity: "info",
      metadata: { reportId: id, action: "delete_message", messageId: report.message?.id },
    })
    return NextResponse.json({ report: updated })
  }

  if (action === "ban_user") {
    if (report.reportedUserId) {
      const reason = String(body.reason || "رفتار نامناسب در چت").slice(0, 500)
      await db.user.update({
        where: { id: report.reportedUserId },
        data: { banned: true, banReason: reason },
      })
      await db.session.deleteMany({ where: { userId: report.reportedUserId } }).catch(() => {})
    }
    const updated = await db.chatReport.update({
      where: { id },
      data: { status: "resolved" },
    })
    await audit(auditCtx, "chat.report_action", {
      targetType: "chat_report",
      targetId: id,
      description: `مسدودسازی کاربر گزارش‌شده و بستن گزارش`,
      severity: "info",
      metadata: { reportId: id, action: "ban_user", reportedUserId: report.reportedUserId },
    })
    return NextResponse.json({ report: updated })
  }

  return NextResponse.json({ error: "invalid action" }, { status: 400 })
}
