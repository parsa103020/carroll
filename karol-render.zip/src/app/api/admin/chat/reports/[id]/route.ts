import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"
import { deleteObject, objectPathFromUrl } from "@/lib/storage"

export const runtime = "nodejs"

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  const { id } = await ctx.params
  const body = await req.json().catch(() => ({}))

  const report = await db.chatReport.findUnique({
    where: { id },
    include: { message: { select: { id: true, mediaUrl: true, userId: true } } },
  })
  if (!report) return NextResponse.json({ error: "not found" }, { status: 404 })

  if (body.action) {
    const action = body.action

    if (action === "dismiss") {
      const updated = await db.chatReport.update({
        where: { id },
        data: { status: "dismissed" },
      })
      return NextResponse.json({ report: updated })
    }

    if (action === "delete_message") {
      if (report.message) {
        if (report.message.mediaUrl) {
          const p = objectPathFromUrl(report.message.mediaUrl)
          if (p) await deleteObject(p).catch(() => {})
        }
        await db.chatMessage.update({
          where: { id: report.message.id },
          data: { deletedAt: new Date(), content: "[حذف توسط ادمین]", mediaUrl: null },
        })
      }
      const updated = await db.chatReport.update({
        where: { id },
        data: { status: "resolved" },
      })
      return NextResponse.json({ report: updated })
    }

    if (action === "ban_user") {
      if (report.reportedUserId) {
        const reason = String(body.reason || "رفتار نامناسب در چت").slice(0, 500)
        await db.user.update({
          where: { id: report.reportedUserId },
          data: { banned: true, banReason: reason },
        })
        await db.session.deleteMany({ where: { userId: report.reportedUserId } }).catch(() => {})
      }
      const updated = await db.chatReport.update({
        where: { id },
        data: { status: "resolved" },
      })
      return NextResponse.json({ report: updated })
    }

    return NextResponse.json({ error: "invalid action" }, { status: 400 })
  }

  if (body.status && ["open", "dismissed", "resolved"].includes(body.status)) {
    const updated = await db.chatReport.update({
      where: { id },
      data: { status: body.status },
    })
    return NextResponse.json({ report: updated })
  }

  return NextResponse.json({ error: "invalid" }, { status: 400 })
}
