import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"
import { deleteObject, objectPathFromUrl } from "@/lib/storage"
import { audit, getClientInfo } from "@/lib/audit"

export const runtime = "nodejs"

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const { id } = await ctx.params
  const body = await req.json().catch(() => ({}))

  const existing = await db.chatMessage.findUnique({ where: { id } })
  if (!existing) return NextResponse.json({ error: "not found" }, { status: 404 })

  if (body.restore === true || body.deletedAt === null) {
    const updated = await db.chatMessage.update({
      where: { id },
      data: { deletedAt: null },
    })
    const info = getClientInfo(req)
    await audit(
      { actorId: session.user!.id, actorName: session.user!.username, ip: info.ip, userAgent: info.userAgent },
      "chat.message_restore",
      {
        targetType: "chat_message",
        targetId: id,
        description: `بازگردانی پیام حذف‌شده در روم ${existing.roomId}`,
        severity: "info",
        metadata: { messageId: id, roomId: existing.roomId },
      },
    )
    return NextResponse.json({ message: updated })
  }

  return NextResponse.json({ error: "invalid" }, { status: 400 })
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const { id } = await ctx.params
  const existing = await db.chatMessage.findUnique({ where: { id } })
  if (!existing) return NextResponse.json({ error: "not found" }, { status: 404 })

  if (existing.mediaUrl) {
    const p = objectPathFromUrl(existing.mediaUrl)
    if (p) await deleteObject(p).catch(() => {})
  }

  const updated = await db.chatMessage.update({
    where: { id },
    data: {
      deletedAt: new Date(),
      mediaUrl: null,
    },
  })

  const info = getClientInfo(req)
  await audit(
    { actorId: session.user!.id, actorName: session.user!.username, ip: info.ip, userAgent: info.userAgent },
    "chat.message_delete",
    {
      targetType: "chat_message",
      targetId: id,
      description: `حذف پیام در روم ${existing.roomId}`,
      severity: "warning",
      metadata: { messageId: id, roomId: existing.roomId, content: existing.content?.slice(0, 200) },
    },
  )

  return NextResponse.json({ message: updated })
}
