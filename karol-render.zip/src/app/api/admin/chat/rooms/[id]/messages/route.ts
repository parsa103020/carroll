import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const { id } = await ctx.params
  const url = new URL(req.url)
  const q = url.searchParams.get("q")?.trim() || ""
  const onlyDeleted = url.searchParams.get("deleted") === "true"
  const page = Math.max(1, parseInt(url.searchParams.get("page") || "1", 10))
  const pageSize = Math.min(100, parseInt(url.searchParams.get("pageSize") || "50", 10))

  const where: any = { roomId: id }
  if (onlyDeleted) where.deletedAt = { not: null }
  if (q) {
    where.OR = [
      { content: { contains: q } },
      { username: { contains: q } },
    ]
  }

  const [total, messages] = await Promise.all([
    db.chatMessage.count({ where }),
    db.chatMessage.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        user: { select: { id: true, username: true, displayName: true, avatarUrl: true, banned: true } },
      },
    }),
  ])

  return NextResponse.json({
    messages: messages.map((m) => ({
      id: m.id,
      roomId: m.roomId,
      userId: m.userId,
      username: m.username,
      content: m.content,
      type: m.type,
      mediaUrl: m.mediaUrl,
      mediaMeta: m.mediaMeta,
      replyToId: m.replyToId,
      createdAt: m.createdAt,
      deletedAt: m.deletedAt,
      user: m.user,
    })),
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  })
}
