import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET() {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const fiveMinAgo = new Date(Date.now() - 5 * 60 * 1000)

  const [
    totalUsers,
    onlineUsers,
    vipMembers,
    openTickets,
    pendingOrders,
    totalFiles,
    totalReels,
    totalVideos,
    totalPosts,
    totalCoinsAgg,
    recentUsers,
    recentOrders,
    recentTickets,
    recentReports,
  ] = await Promise.all([
    db.user.count(),
    db.session.count({ where: { expiresAt: { gt: fiveMinAgo } } }),
    db.user.count({ where: { isVip: true } }),
    db.ticket.count({ where: { status: { in: ["open", "pending"] } } }),
    db.order.count({ where: { status: "pending" } }),
    db.file.count(),
    db.reel.count(),
    db.video.count(),
    db.feedPost.count(),
    db.user.aggregate({ _sum: { coins: true } }),
    db.user.findMany({
      orderBy: { createdAt: "desc" },
      take: 10,
      select: {
        id: true, username: true, displayName: true, avatarUrl: true,
        isVip: true, banned: true, roles: true, createdAt: true, coins: true,
      },
    }),
    db.order.findMany({
      where: { status: "pending" },
      orderBy: { createdAt: "desc" },
      take: 10,
      include: {
        user: { select: { id: true, username: true, displayName: true, avatarUrl: true } },
        shopItem: { select: { id: true, title: true, kind: true, price: true } },
      },
    }),
    db.ticket.findMany({
      where: { status: { in: ["open", "pending"] } },
      orderBy: { updatedAt: "desc" },
      take: 10,
      include: {
        user: { select: { id: true, username: true, displayName: true, avatarUrl: true } },
        _count: { select: { messages: true } },
      },
    }),
    db.chatReport.findMany({
      where: { status: "open" },
      orderBy: { createdAt: "desc" },
      take: 10,
      include: {
        message: { select: { id: true, content: true, type: true, mediaUrl: true, createdAt: true, deletedAt: true } },
        reporter: { select: { id: true, username: true, displayName: true } },
        reportedUser: { select: { id: true, username: true, displayName: true } },
      },
    }),
  ])

  const totalCoins = totalCoinsAgg._sum.coins ?? 0
  const pendingOrdersCount = pendingOrders

  return NextResponse.json({
    stats: {
      totalUsers,
      onlineUsers,
      vipMembers,
      openTickets,
      pendingOrders: pendingOrdersCount,
      totalFiles,
      totalReels,
      totalVideos,
      totalPosts,
      totalCoins,
    },
    recent: {
      users: recentUsers,
      orders: recentOrders,
      tickets: recentTickets.map((t) => ({
        id: t.id, subject: t.subject, status: t.status, priority: t.priority,
        category: t.category, createdAt: t.createdAt, updatedAt: t.updatedAt,
        messagesCount: t._count.messages,
        owner: t.user,
      })),
      reports: recentReports,
    },
  })
}
