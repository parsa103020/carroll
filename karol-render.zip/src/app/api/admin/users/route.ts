import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

const USER_FIELDS = {
  id: true, username: true, displayName: true, avatarUrl: true, bio: true,
  coins: true, isVip: true, vipExpiresAt: true,
  dailyUploadLimitBytes: true, usedUploadBytesToday: true,
  roles: true, banned: true, banReason: true,
  createdAt: true, lastLoginAt: true,
} as const

function serialize(u: any) {
  return {
    ...u,
    dailyUploadLimitBytes: u.dailyUploadLimitBytes?.toString() ?? "0",
    usedUploadBytesToday: u.usedUploadBytesToday?.toString() ?? "0",
  }
}

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const url = new URL(req.url)
  const q = url.searchParams.get("q")?.trim() || ""
  const role = url.searchParams.get("role") || ""
  const vip = url.searchParams.get("vip")
  const banned = url.searchParams.get("banned")
  const page = Math.max(1, parseInt(url.searchParams.get("page") || "1", 10))
  const pageSize = Math.min(100, parseInt(url.searchParams.get("pageSize") || "30", 10))

  const where: any = {}
  if (q) {
    where.OR = [
      { username: { contains: q } },
      { displayName: { contains: q } },
    ]
  }
  if (role === "vip") where.isVip = true
  else if (role === "banned") where.banned = true
  else if (role === "admin") where.roles = { contains: "admin" }
  else if (role === "moderator") where.OR = [
    { roles: { contains: "moderator" } },
    { roles: { contains: "_mod" } },
  ]
  if (vip === "true") where.isVip = true
  if (vip === "false") where.isVip = false
  if (banned === "true") where.banned = true
  if (banned === "false") where.banned = false

  const [total, users] = await Promise.all([
    db.user.count({ where }),
    db.user.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
      select: USER_FIELDS,
    }),
  ])

  return NextResponse.json({
    users: users.map(serialize),
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  })
}
