import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"
import { audit, getClientInfo } from "@/lib/audit"

export const runtime = "nodejs"

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  const actor = session.user!
  const { id } = await ctx.params
  const body = await req.json().catch(() => ({}))
  const action = body.action

  const report = await db.userReport.findUnique({
    where: { id },
    include: {
      reportedUser: { select: { id: true, username: true, banned: true } },
    },
  })
  if (!report) return NextResponse.json({ error: "not found" }, { status: 404 })

  if (action === "dismiss") {
    const updated = await db.userReport.update({
      where: { id },
      data: { status: "dismissed" },
    })
    const client = getClientInfo(req)
    await audit(
      {
        actorId: actor.id,
        actorName: actor.username,
        ip: client.ip,
        userAgent: client.userAgent,
      },
      "user.report.dismiss",
      {
        targetType: "user_report",
        targetId: id,
        description: `رد گزارش کاربر @${report.reportedUser?.username || "نامشخص"}`,
        severity: "info",
      },
    )
    return NextResponse.json({ report: updated })
  }

  if (action === "ban_user") {
    if (!report.reportedUser) {
      return NextResponse.json({ error: "کاربر گزارش‌شده وجود ندارد" }, { status: 400 })
    }
    if (report.reportedUser.banned) {
      return NextResponse.json({ error: "کاربر از قبل مسدود شده است" }, { status: 400 })
    }
    const reason = String(body.reason || "گزارش رفتار نامناسب").slice(0, 500)
    await db.user.update({
      where: { id: report.reportedUserId },
      data: { banned: true, banReason: reason },
    })
    await db.session
      .deleteMany({ where: { userId: report.reportedUserId } })
      .catch(() => {})
    const updated = await db.userReport.update({
      where: { id },
      data: { status: "resolved" },
    })
    const client = getClientInfo(req)
    await audit(
      {
        actorId: actor.id,
        actorName: actor.username,
        ip: client.ip,
        userAgent: client.userAgent,
      },
      "user.ban",
      {
        targetType: "user",
        targetId: report.reportedUserId,
        description: `مسدود کردن @${report.reportedUser.username} به دلیل گزارش (${report.reason})${reason ? ` — ${reason}` : ""}`,
        severity: "danger",
        metadata: { reportId: id, banReason: reason },
      },
    )
    return NextResponse.json({ report: updated })
  }

  return NextResponse.json({ error: "invalid action" }, { status: 400 })
}
