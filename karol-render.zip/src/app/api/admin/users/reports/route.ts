import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const url = new URL(req.url)
  const status = url.searchParams.get("status") || "open"

  const where: any = {}
  if (status && ["open", "dismissed", "resolved", "all"].includes(status)) {
    if (status !== "all") where.status = status
  }

  const reports = await db.userReport.findMany({
    where,
    orderBy: { createdAt: "desc" },
    take: 200,
    include: {
      reporter: {
        select: { id: true, username: true, displayName: true, avatarUrl: true },
      },
      reportedUser: {
        select: {
          id: true,
          username: true,
          displayName: true,
          avatarUrl: true,
          banned: true,
          roles: true,
        },
      },
    },
  })

  return NextResponse.json({ reports })
}
