import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"
import { creditCoins, spendCoins } from "@/lib/coins"
import { CONFIG } from "@/lib/config"
import { audit, getClientInfo } from "@/lib/audit"

export const runtime = "nodejs"

const USER_FIELDS = {
  id: true, username: true, displayName: true, avatarUrl: true, bio: true,
  coins: true, isVip: true, vipExpiresAt: true,
  dailyUploadLimitBytes: true, usedUploadBytesToday: true,
  roles: true, banned: true, banReason: true,
  createdAt: true, lastLoginAt: true,
} as const

function serialize(u: any) {
  return {
    ...u,
    dailyUploadLimitBytes: u.dailyUploadLimitBytes?.toString() ?? "0",
    usedUploadBytesToday: u.usedUploadBytesToday?.toString() ?? "0",
  }
}

const VALID_ROLES = new Set([
  "user", "admin", "moderator",
  "chat_mod", "video_mod", "reel_mod", "feed_mod", "drive_mod", "shop_mod", "ticket_mod",
])

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  const { id } = await ctx.params
  const u = await db.user.findUnique({ where: { id }, select: USER_FIELDS })
  if (!u) return NextResponse.json({ error: "not found" }, { status: 404 })
  return NextResponse.json({ user: serialize(u) })
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  const { id } = await ctx.params
  const actor = session.user!
  const info = getClientInfo(req)
  const auditCtx = { actorId: actor.id, actorName: actor.username, ip: info.ip, userAgent: info.userAgent }
  const body = await req.json().catch(() => ({}))

  const target = await db.user.findUnique({ where: { id } })
  if (!target) return NextResponse.json({ error: "not found" }, { status: 404 })

  const data: any = {}
  const meta: { coinAdjust?: number; coinReason?: string; coinNewBalance?: number } = {}
  const auditActions: Promise<void>[] = []

  if (typeof body.displayName === "string") {
    const dn = body.displayName.trim()
    if (dn.length > 60) return NextResponse.json({ error: "نام نمایشی خیلی طولانی است" }, { status: 400 })
    data.displayName = dn || null
  }

  if (Array.isArray(body.roles)) {
    const clean = Array.from(new Set(body.roles.map((r: any) => String(r)).filter((r: string) => VALID_ROLES.has(r))))
    if (!clean.includes("user")) clean.push("user")
    data.roles = clean.join(",")
    auditActions.push(
      audit(auditCtx, "user.update", {
        targetType: "user",
        targetId: id,
        description: `به‌روزرسانی نقش‌های کاربر @${target.username} به ${clean.join(", ")}`,
        severity: "warning",
        metadata: { previousRoles: target.roles, newRoles: data.roles },
      }),
    )
  }

  if (body.dailyUploadLimitBytes !== undefined) {
    const mb = parseFloat(body.dailyUploadLimitBytes)
    if (!Number.isFinite(mb) || mb < 0)
      return NextResponse.json({ error: "سهمیه نامعتبر است" }, { status: 400 })
    data.dailyUploadLimitBytes = BigInt(Math.round(mb * 1024 * 1024))
  }

  if (typeof body.banned === "boolean") {
    data.banned = body.banned
    data.banReason = body.banned ? String(body.banReason || "").slice(0, 500) || null : null
    if (body.banned) {
      await db.session.deleteMany({ where: { userId: id } }).catch(() => {})
      auditActions.push(
        audit(auditCtx, "user.ban", {
          targetType: "user",
          targetId: id,
          description: `مسدودسازی کاربر @${target.username}${data.banReason ? ` — دلیل: ${data.banReason}` : ""}`,
          severity: "danger",
          metadata: { username: target.username, reason: data.banReason },
        }),
      )
    } else {
      auditActions.push(
        audit(auditCtx, "user.unban", {
          targetType: "user",
          targetId: id,
          description: `رفع مسدودیت کاربر @${target.username}`,
          severity: "warning",
          metadata: { username: target.username },
        }),
      )
    }
  } else if (typeof body.banReason === "string" && body.banReason !== undefined) {
    data.banReason = body.banReason || null
  }

  if (typeof body.isVip === "boolean") {
    if (body.isVip) {
      const days = Math.max(1, parseInt(body.vipDays, 10) || 30)
      const now = new Date()
      const startFrom = target.vipExpiresAt && target.vipExpiresAt > now ? target.vipExpiresAt : now
      data.vipExpiresAt = new Date(startFrom.getTime() + days * 86400000)
      const bonus = BigInt(CONFIG.storage.limits.drive)
      data.dailyUploadLimitBytes = (target.dailyUploadLimitBytes ?? BigInt(0)) + bonus
      data.isVip = true
      auditActions.push(
        audit(auditCtx, "user.vip_grant", {
          targetType: "user",
          targetId: id,
          description: `اعطای VIP به @${target.username} برای ${days} روز`,
          severity: "warning",
          metadata: { username: target.username, days, expiresAt: data.vipExpiresAt },
        }),
      )
    } else {
      data.isVip = false
      data.vipExpiresAt = null
    }
  }

  if (body.coinAdjust !== undefined && body.coinAdjust !== 0) {
    const adj = parseInt(body.coinAdjust, 10)
    if (!Number.isFinite(adj) || adj === 0)
      return NextResponse.json({ error: "تعداد سکه نامعتبر است" }, { status: 400 })
    const reason = String(body.coinReason || "").trim().slice(0, 200)
    const desc = `توسط ادمین @${actor.username}${reason ? ` — ${reason}` : ""}`
    let newBalance: number
    if (adj > 0) {
      newBalance = await creditCoins(id, adj, "admin_adjust", desc)
    } else {
      try {
        newBalance = await spendCoins(id, Math.abs(adj), desc)
      } catch {
        return NextResponse.json({ error: "سکه کافی نیست" }, { status: 400 })
      }
    }
    meta.coinAdjust = adj
    meta.coinReason = reason
    meta.coinNewBalance = newBalance
    auditActions.push(
      audit(auditCtx, "user.coin_adjust", {
        targetType: "user",
        targetId: id,
        description: `تنظیم سکه ${adj > 0 ? "+" : ""}${adj} برای @${target.username}${reason ? ` — ${reason}` : ""}`,
        severity: "warning",
        metadata: { username: target.username, adjust: adj, reason, newBalance },
      }),
    )
  }

  if (Object.keys(data).length === 0 && Object.keys(meta).length === 0)
    return NextResponse.json({ error: "چیزی برای به‌روزرسانی نیست" }, { status: 400 })

  if (Object.keys(data).length > 0) {
    await db.user.update({ where: { id }, data })
  }
  await Promise.all(auditActions)
  const fresh = await db.user.findUnique({ where: { id }, select: USER_FIELDS })
  return NextResponse.json({ user: serialize(fresh), ...meta })
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  const { id } = await ctx.params
  if (id === session.user!.id)
    return NextResponse.json({ error: "نمی‌توانید حساب خودتان را حذف کنید" }, { status: 400 })

  const target = await db.user.findUnique({ where: { id }, select: { id: true, username: true, avatarUrl: true } })
  if (!target) return NextResponse.json({ error: "not found" }, { status: 404 })

  await db.user.delete({ where: { id } })
  const info = getClientInfo(req)
  await audit(
    { actorId: session.user!.id, actorName: session.user!.username, ip: info.ip, userAgent: info.userAgent },
    "user.delete",
    {
      targetType: "user",
      targetId: id,
      description: `حذف کاربر @${target.username}`,
      severity: "danger",
      metadata: { username: target.username },
    },
  )
  return NextResponse.json({ ok: true })
}
