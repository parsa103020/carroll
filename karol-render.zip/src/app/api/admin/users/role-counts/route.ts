import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET() {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const users = await db.user.findMany({ select: { roles: true } })
  const counts: Record<string, number> = {}
  for (const u of users) {
    for (const r of u.roles.split(",").map((x) => x.trim()).filter(Boolean)) {
      counts[r] = (counts[r] || 0) + 1
    }
  }
  return NextResponse.json({ counts })
}
