import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const url = new URL(req.url)
  const severity = url.searchParams.get("severity") || ""
  const action = url.searchParams.get("action")?.trim() || ""
  const actor = url.searchParams.get("actor")?.trim() || ""
  const from = url.searchParams.get("from")
  const to = url.searchParams.get("to")
  const page = Math.max(1, parseInt(url.searchParams.get("page") || "1", 10))
  const pageSize = Math.min(100, parseInt(url.searchParams.get("pageSize") || "50", 10))

  const where: any = {}
  if (severity && ["info", "warning", "danger"].includes(severity)) where.severity = severity
  if (action) where.action = { contains: action }
  if (actor) where.actorName = { contains: actor }
  if (from) {
    const d = new Date(from)
    if (!isNaN(d.getTime())) where.createdAt = { ...(where.createdAt || {}), gte: d }
  }
  if (to) {
    const d = new Date(to)
    if (!isNaN(d.getTime())) {
      d.setHours(23, 59, 59, 999)
      where.createdAt = { ...(where.createdAt || {}), lte: d }
    }
  }

  const [total, logs] = await Promise.all([
    db.auditLog.count({ where }),
    db.auditLog.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        actor: { select: { id: true, username: true, avatarUrl: true } },
      },
    }),
  ])

  return NextResponse.json({
    logs: logs.map((l) => ({
      id: l.id,
      actorId: l.actorId,
      actorName: l.actorName,
      actor: l.actor,
      action: l.action,
      targetType: l.targetType,
      targetId: l.targetId,
      description: l.description,
      severity: l.severity,
      ip: l.ip,
      userAgent: l.userAgent,
      metadata: l.metadata,
      createdAt: l.createdAt,
    })),
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  })
}
