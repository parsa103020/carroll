import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const url = new URL(req.url)
  const q = url.searchParams.get("q")?.trim() || ""
  const category = url.searchParams.get("category") || ""
  const page = Math.max(1, parseInt(url.searchParams.get("page") || "1", 10))
  const pageSize = Math.min(200, parseInt(url.searchParams.get("pageSize") || "50", 10))

  const where: any = {}
  if (q) {
    where.OR = [
      { name: { contains: q } },
      { owner: { username: { contains: q } } },
      { owner: { displayName: { contains: q } } },
    ]
  }
  if (category && ["image", "video", "audio", "gif", "file"].includes(category)) {
    where.category = category
  }

  const [total, files] = await Promise.all([
    db.file.count({ where }),
    db.file.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        owner: { select: { id: true, username: true, displayName: true } },
      },
    }),
  ])

  return NextResponse.json({
    files: files.map((f) => ({
      id: f.id,
      name: f.name,
      url: f.url,
      size: f.size.toString(),
      mime: f.mime,
      category: f.category,
      isPublic: f.isPublic,
      createdAt: f.createdAt,
      ownerId: f.ownerId,
      owner: f.owner,
    })),
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  })
}
