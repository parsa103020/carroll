import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"
import { deleteObject, objectPathFromUrl } from "@/lib/storage"
import { audit, getClientInfo } from "@/lib/audit"

export const runtime = "nodejs"

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  const { id } = await ctx.params
  const body = await req.json().catch(() => ({}))
  if (typeof body.isPublic !== "boolean")
    return NextResponse.json({ error: "isPublic required" }, { status: 400 })

  const file = await db.file.update({
    where: { id },
    data: { isPublic: body.isPublic },
    select: { id: true, isPublic: true, ownerId: true, name: true },
  })
  const info = getClientInfo(req)
  await audit(
    { actorId: session.user!.id, actorName: session.user!.username, ip: info.ip, userAgent: info.userAgent },
    "file.update",
    {
      targetType: "file",
      targetId: id,
      description: `تغییر وضعیت فایل «${file.name || id}» به ${body.isPublic ? "عمومی" : "خصوصی"}`,
      severity: "info",
      metadata: { fileId: id, isPublic: body.isPublic, ownerId: file.ownerId },
    },
  )
  return NextResponse.json(file)
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  const { id } = await ctx.params
  const file = await db.file.findUnique({ where: { id }, select: { id: true, url: true, name: true, ownerId: true } })
  if (!file) return NextResponse.json({ error: "not found" }, { status: 404 })

  const p = objectPathFromUrl(file.url)
  if (p) await deleteObject(p).catch(() => {})
  await db.file.delete({ where: { id } })

  const info = getClientInfo(req)
  await audit(
    { actorId: session.user!.id, actorName: session.user!.username, ip: info.ip, userAgent: info.userAgent },
    "file.delete",
    {
      targetType: "file",
      targetId: id,
      description: `حذف فایل «${file.name || id}»`,
      severity: "warning",
      metadata: { fileId: id, ownerId: file.ownerId, name: file.name },
    },
  )
  return NextResponse.json({ ok: true })
}
