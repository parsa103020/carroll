import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const url = new URL(req.url)
  const q = url.searchParams.get("q")?.trim() || ""
  const page = Math.max(1, parseInt(url.searchParams.get("page") || "1", 10))
  const pageSize = Math.min(100, parseInt(url.searchParams.get("pageSize") || "30", 10))

  const where: any = {}
  if (q) {
    where.OR = [
      { content: { contains: q } },
      { owner: { username: { contains: q } } },
      { owner: { displayName: { contains: q } } },
    ]
  }

  const [total, posts] = await Promise.all([
    db.feedPost.count({ where }),
    db.feedPost.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        owner: { select: { id: true, username: true, displayName: true, avatarUrl: true, isVip: true } },
        _count: { select: { likes: true, comments: true } },
      },
    }),
  ])

  return NextResponse.json({
    posts: posts.map((p) => ({
      id: p.id,
      content: p.content,
      mediaUrls: p.mediaUrls ? p.mediaUrls.split("|").filter(Boolean) : [],
      createdAt: p.createdAt,
      ownerId: p.ownerId,
      owner: p.owner,
      likes: p._count.likes,
      comments: p._count.comments,
    })),
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  })
}
