import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"
import { deleteObject, objectPathFromUrl } from "@/lib/storage"
import { audit, getClientInfo } from "@/lib/audit"

export const runtime = "nodejs"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const url = new URL(req.url)
  const q = url.searchParams.get("q")?.trim() || ""
  const page = Math.max(1, parseInt(url.searchParams.get("page") || "1", 10))
  const pageSize = Math.min(100, parseInt(url.searchParams.get("pageSize") || "30", 10))

  const where: any = {}
  if (q) {
    where.OR = [
      { content: { contains: q } },
      { owner: { username: { contains: q } } },
      { owner: { displayName: { contains: q } } },
    ]
  }

  const [total, posts] = await Promise.all([
    db.feedPost.count({ where }),
    db.feedPost.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        owner: { select: { id: true, username: true, displayName: true, avatarUrl: true, isVip: true } },
        _count: { select: { likes: true, comments: true } },
      },
    }),
  ])

  return NextResponse.json({
    posts: posts.map((p) => ({
      id: p.id,
      content: p.content,
      mediaUrls: p.mediaUrls ? p.mediaUrls.split("|").filter(Boolean) : [],
      createdAt: p.createdAt,
      ownerId: p.ownerId,
      owner: p.owner,
      likes: p._count.likes,
      comments: p._count.comments,
    })),
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  })
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  const { id } = await ctx.params

  const post = await db.feedPost.findUnique({ where: { id }, select: { id: true, mediaUrls: true, content: true, ownerId: true } })
  if (!post) return NextResponse.json({ error: "not found" }, { status: 404 })

  if (post.mediaUrls) {
    for (const u of post.mediaUrls.split("|").filter(Boolean)) {
      const p = objectPathFromUrl(u)
      if (p) await deleteObject(p).catch(() => {})
    }
  }
  await db.feedPost.delete({ where: { id } })
  const info = getClientInfo(req)
  await audit(
    { actorId: session.user!.id, actorName: session.user!.username, ip: info.ip, userAgent: info.userAgent },
    "content.feed_delete",
    {
      targetType: "feed_post",
      targetId: id,
      description: `حذف پست فیید${post.content ? ` «${post.content.slice(0, 60)}»` : ""}`,
      severity: "warning",
      metadata: { postId: id, ownerId: post.ownerId },
    },
  )
  return NextResponse.json({ ok: true })
}
