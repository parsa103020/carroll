import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"
import { deleteObject, objectPathFromUrl } from "@/lib/storage"
import { audit, getClientInfo } from "@/lib/audit"

export const runtime = "nodejs"

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  const { id } = await ctx.params
  const video = await db.video.findUnique({
    where: { id },
    select: { id: true, videoUrl: true, thumbnailUrl: true, title: true, ownerId: true },
  })
  if (!video) return NextResponse.json({ error: "not found" }, { status: 404 })

  const vp = objectPathFromUrl(video.videoUrl)
  if (vp) await deleteObject(vp).catch(() => {})
  if (video.thumbnailUrl) {
    const tp = objectPathFromUrl(video.thumbnailUrl)
    if (tp) await deleteObject(tp).catch(() => {})
  }
  await db.video.delete({ where: { id } })
  const info = getClientInfo(req)
  await audit(
    { actorId: session.user!.id, actorName: session.user!.username, ip: info.ip, userAgent: info.userAgent },
    "content.video_delete",
    {
      targetType: "video",
      targetId: id,
      description: `حذف ویدیو${video.title ? ` «${video.title.slice(0, 60)}»` : ""}`,
      severity: "warning",
      metadata: { videoId: id, ownerId: video.ownerId },
    },
  )
  return NextResponse.json({ ok: true })
}
