import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const url = new URL(req.url)
  const q = url.searchParams.get("q")?.trim() || ""
  const page = Math.max(1, parseInt(url.searchParams.get("page") || "1", 10))
  const pageSize = Math.min(100, parseInt(url.searchParams.get("pageSize") || "30", 10))

  const where: any = {}
  if (q) {
    where.OR = [
      { caption: { contains: q } },
      { musicTitle: { contains: q } },
      { owner: { username: { contains: q } } },
      { owner: { displayName: { contains: q } } },
    ]
  }

  const [total, reels] = await Promise.all([
    db.reel.count({ where }),
    db.reel.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        owner: { select: { id: true, username: true, displayName: true, avatarUrl: true, isVip: true } },
        _count: { select: { likes: true, comments: true } },
      },
    }),
  ])

  return NextResponse.json({
    reels: reels.map((r) => ({
      id: r.id,
      videoUrl: r.videoUrl,
      posterUrl: r.posterUrl,
      caption: r.caption,
      musicTitle: r.musicTitle,
      views: r.views,
      createdAt: r.createdAt,
      ownerId: r.ownerId,
      owner: r.owner,
      likes: r._count.likes,
      comments: r._count.comments,
    })),
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  })
}
