import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"
import { deleteObject, objectPathFromUrl } from "@/lib/storage"
import { audit, getClientInfo } from "@/lib/audit"

export const runtime = "nodejs"

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  const { id } = await ctx.params
  const reel = await db.reel.findUnique({ where: { id }, select: { id: true, videoUrl: true, posterUrl: true, caption: true, ownerId: true } })
  if (!reel) return NextResponse.json({ error: "not found" }, { status: 404 })

  const vp = objectPathFromUrl(reel.videoUrl)
  if (vp) await deleteObject(vp).catch(() => {})
  if (reel.posterUrl) {
    const pp = objectPathFromUrl(reel.posterUrl)
    if (pp) await deleteObject(pp).catch(() => {})
  }
  await db.reel.delete({ where: { id } })
  const info = getClientInfo(req)
  await audit(
    { actorId: session.user!.id, actorName: session.user!.username, ip: info.ip, userAgent: info.userAgent },
    "content.reel_delete",
    {
      targetType: "reel",
      targetId: id,
      description: `حذف ریلز${reel.caption ? ` «${reel.caption.slice(0, 60)}»` : ""}`,
      severity: "warning",
      metadata: { reelId: id, ownerId: reel.ownerId },
    },
  )
  return NextResponse.json({ ok: true })
}
