import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const url = new URL(req.url)
  const status = url.searchParams.get("status") || ""
  const page = Math.max(1, parseInt(url.searchParams.get("page") || "1", 10))
  const pageSize = Math.min(100, parseInt(url.searchParams.get("pageSize") || "50", 10))

  const where: any = {}
  if (["active", "expired"].includes(status)) {
    const now = new Date()
    where.expiresAt = status === "active" ? { gt: now } : { lte: now }
  }

  const [total, items] = await Promise.all([
    db.configPurchase.count({ where }),
    db.configPurchase.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        user: { select: { id: true, username: true, displayName: true } },
        package: { select: { id: true, name: true, volumeBytes: true } },
      },
    }),
  ])

  return NextResponse.json({
    purchases: items.map((p) => ({
      id: p.id,
      userId: p.userId,
      packageId: p.packageId,
      configId: p.configId,
      configText: p.configText,
      pricePaid: p.pricePaid,
      volumeBytes: p.volumeBytes.toString(),
      expiresAt: p.expiresAt,
      createdAt: p.createdAt,
      user: p.user,
      package: p.package ? {
        ...p.package,
        volumeBytes: p.package.volumeBytes.toString(),
      } : null,
    })),
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  })
}
