import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"
import { audit, getClientInfo } from "@/lib/audit"

export const runtime = "nodejs"

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const { id } = await ctx.params
  const body = await req.json().catch(() => ({}))

  const existing = await db.configPackage.findUnique({ where: { id } })
  if (!existing) return NextResponse.json({ error: "not found" }, { status: 404 })

  const data: any = {}
  if (typeof body.name === "string" && body.name.trim()) data.name = body.name.trim()
  if (body.volumeBytes !== undefined) {
    try { data.volumeBytes = BigInt(String(body.volumeBytes)) }
    catch { return NextResponse.json({ error: "حجم نامعتبر" }, { status: 400 }) }
  }
  if (body.priceCoins !== undefined) data.priceCoins = Math.max(0, parseInt(body.priceCoins, 10) || 0)
  if (body.durationDays !== undefined) data.durationDays = Math.max(1, parseInt(body.durationDays, 10) || 30)
  if (typeof body.active === "boolean") data.active = body.active

  const updated = await db.configPackage.update({ where: { id }, data })
  const info = getClientInfo(req)
  await audit(
    { actorId: session.user!.id, actorName: session.user!.username, ip: info.ip, userAgent: info.userAgent },
    "config.package_update",
    {
      targetType: "config_package",
      targetId: id,
      description: `ویرایش بسته کانفیگ «${updated.name}»`,
      severity: "warning",
      metadata: { packageId: id, changes: data },
    },
  )
  return NextResponse.json({
    package: { ...updated, volumeBytes: updated.volumeBytes.toString() },
  })
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const { id } = await ctx.params

  const purchases = await db.configPurchase.count({ where: { packageId: id } })
  if (purchases > 0) {
    return NextResponse.json(
      { error: "این بسته خرید دارد و قابل حذف نیست" },
      { status: 400 },
    )
  }

  const existing = await db.configPackage.findUnique({ where: { id }, select: { name: true } }).catch(() => null)
  await db.configStock.deleteMany({ where: { packageId: id } }).catch(() => {})
  await db.configPackage.delete({ where: { id } }).catch(() => {})

  const info = getClientInfo(req)
  await audit(
    { actorId: session.user!.id, actorName: session.user!.username, ip: info.ip, userAgent: info.userAgent },
    "config.package_delete",
    {
      targetType: "config_package",
      targetId: id,
      description: `حذف بسته کانفیگ «${existing?.name || id}»`,
      severity: "warning",
      metadata: { packageId: id, name: existing?.name },
    },
  )

  return NextResponse.json({ ok: true })
}
