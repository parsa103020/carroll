import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"
import { audit, getClientInfo } from "@/lib/audit"

export const runtime = "nodejs"

function serializePkg(p: any) {
  return {
    ...p,
    volumeBytes: p.volumeBytes?.toString() ?? "0",
  }
}

export async function GET() {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const packages = await db.configPackage.findMany({
    orderBy: { priceCoins: "asc" },
    include: {
      _count: {
        select: {
          stock: { where: { purchase: { is: null } } },
          purchases: true,
        },
      },
    },
  })

  return NextResponse.json({
    packages: packages.map((p) => ({
      id: p.id,
      name: p.name,
      volumeBytes: p.volumeBytes.toString(),
      priceCoins: p.priceCoins,
      durationDays: p.durationDays,
      active: p.active,
      createdAt: p.createdAt,
      unassignedStock: (p._count.stock as unknown as number) ?? 0,
      purchasesCount: p._count.purchases,
    })),
  })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const body = await req.json().catch(() => ({}))
  const name = String(body.name || "").trim()
  if (!name) return NextResponse.json({ error: "نام بسته الزامی است" }, { status: 400 })

  let volumeBytes: bigint
  try {
    volumeBytes = BigInt(String(body.volumeBytes || "0"))
  } catch {
    return NextResponse.json({ error: "حجم نامعتبر" }, { status: 400 })
  }
  const priceCoins = Math.max(0, parseInt(body.priceCoins, 10) || 0)
  const durationDays = Math.max(1, parseInt(body.durationDays, 10) || 30)

  const pkg = await db.configPackage.create({
    data: { name, volumeBytes, priceCoins, durationDays, active: !!body.active },
  })

  const info = getClientInfo(req)
  await audit(
    { actorId: session.user!.id, actorName: session.user!.username, ip: info.ip, userAgent: info.userAgent },
    "config.package_create",
    {
      targetType: "config_package",
      targetId: pkg.id,
      description: `ایجاد بسته کانفیگ «${name}» (${priceCoins} سکه)`,
      severity: "warning",
      metadata: { packageId: pkg.id, name, priceCoins, durationDays },
    },
  )

  return NextResponse.json({ package: serializePkg(pkg) })
}
