import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"
import { audit, getClientInfo } from "@/lib/audit"

export const runtime = "nodejs"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const url = new URL(req.url)
  const packageId = url.searchParams.get("packageId") || ""
  const assigned = url.searchParams.get("assigned")
  const page = Math.max(1, parseInt(url.searchParams.get("page") || "1", 10))
  const pageSize = Math.min(200, parseInt(url.searchParams.get("pageSize") || "50", 10))

  const where: any = {}
  if (packageId) where.packageId = packageId
  if (assigned === "true") where.purchase = { isNot: null }
  if (assigned === "false") where.purchase = { is: null }

  const [total, items] = await Promise.all([
    db.configStock.count({ where }),
    db.configStock.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        package: { select: { id: true, name: true, priceCoins: true, volumeBytes: true } },
        purchase: {
          select: {
            id: true,
            userId: true,
            expiresAt: true,
            createdAt: true,
            user: { select: { id: true, username: true, displayName: true } },
          },
        },
      },
    }),
  ])

  return NextResponse.json({
    stock: items.map((s) => ({
      id: s.id,
      packageId: s.packageId,
      configText: s.configText,
      assignedToId: s.assignedToId,
      assignedAt: s.assignedAt,
      createdAt: s.createdAt,
      package: s.package ? {
        ...s.package,
        volumeBytes: s.package.volumeBytes.toString(),
      } : null,
      assignedTo: s.purchase?.user || null,
      assignedAt: s.purchase?.createdAt || s.assignedAt,
      expiresAt: s.purchase?.expiresAt || null,
    })),
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const body = await req.json().catch(() => ({}))
  const packageId = String(body.packageId || "")
  const raw = String(body.configs || "")

  if (!packageId) return NextResponse.json({ error: "بسته انتخاب نشده" }, { status: 400 })

  const pkg = await db.configPackage.findUnique({ where: { id: packageId } })
  if (!pkg) return NextResponse.json({ error: "بسته یافت نشد" }, { status: 404 })

  const lines = raw
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean)

  if (lines.length === 0)
    return NextResponse.json({ error: "حداقل یک کانفیگ وارد کنید" }, { status: 400 })

  if (lines.length > 500)
    return NextResponse.json({ error: "حداکثر ۵۰۰ کانفیگ در هر بار" }, { status: 400 })

  await db.configStock.createMany({
    data: lines.map((text) => ({ packageId, configText: text })),
  })

  const count = await db.configStock.count({
    where: { packageId, purchase: { is: null } },
  })

  const info = getClientInfo(req)
  await audit(
    { actorId: session.user!.id, actorName: session.user!.username, ip: info.ip, userAgent: info.userAgent },
    "config.stock_add",
    {
      targetType: "config_package",
      targetId: packageId,
      description: `افزودن ${lines.length} کانفیگ به بسته «${pkg.name}»`,
      severity: "warning",
      metadata: { packageId, packageName: pkg.name, added: lines.length },
    },
  )

  return NextResponse.json({ added: lines.length, unassigned: count })
}
