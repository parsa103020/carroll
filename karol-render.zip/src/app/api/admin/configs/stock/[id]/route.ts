import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"
import { audit, getClientInfo } from "@/lib/audit"

export const runtime = "nodejs"

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const { id } = await ctx.params
  const existing = await db.configStock.findUnique({
    where: { id },
    include: { purchase: { select: { id: true } }, package: { select: { name: true } } },
  })
  if (!existing) return NextResponse.json({ error: "not found" }, { status: 404 })

  if (existing.purchase) {
    return NextResponse.json(
      { error: "این کانفیگ قبلاً فروخته شده و قابل حذف نیست" },
      { status: 400 },
    )
  }

  await db.configStock.delete({ where: { id } })
  const info = getClientInfo(req)
  await audit(
    { actorId: session.user!.id, actorName: session.user!.username, ip: info.ip, userAgent: info.userAgent },
    "config.stock_delete",
    {
      targetType: "config_stock",
      targetId: id,
      description: `حذف کانفیگ از بسته «${existing.package?.name || "—"}»`,
      severity: "warning",
      metadata: { stockId: id, packageId: existing.packageId },
    },
  )
  return NextResponse.json({ ok: true })
}
