import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

const PAGE = 50

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const url = new URL(req.url)
  const cursor = url.searchParams.get("cursor")
  const limit = Math.min(PAGE, Math.max(1, parseInt(url.searchParams.get("limit") || String(PAGE), 10) || PAGE))

  const rows = await db.coinTransaction.findMany({
    where: { userId: session.user!.id },
    orderBy: { createdAt: "desc" },
    take: limit + 1,
    ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
    select: {
      id: true,
      amount: true,
      balanceAfter: true,
      type: true,
      description: true,
      referenceId: true,
      createdAt: true,
    },
  })

  const hasNext = rows.length > limit
  const list = rows.slice(0, limit)
  return NextResponse.json({
    transactions: list,
    nextCursor: hasNext ? list[list.length - 1]?.id || null : null,
  })
}
