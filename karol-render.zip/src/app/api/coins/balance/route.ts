import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const u = await db.user.findUnique({
    where: { id: session.user!.id },
    select: { coins: true, isVip: true, vipExpiresAt: true },
  })
  if (!u) return NextResponse.json({ error: "not_found" }, { status: 404 })
  return NextResponse.json({
    coins: u.coins,
    isVip: u.isVip,
    vipExpiresAt: u.vipExpiresAt,
  })
}
