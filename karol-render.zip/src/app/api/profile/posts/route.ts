import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const url = new URL(req.url)
  const cursor = url.searchParams.get("cursor")
  const take = 12

  const posts = await db.feedPost.findMany({
    where: { ownerId: session.user!.id },
    orderBy: { createdAt: "desc" },
    take: take + 1,
    ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
    include: { _count: { select: { likes: true, comments: true } } },
  })

  const hasNext = posts.length > take
  const list = posts.slice(0, take).map((p) => ({
    id: p.id,
    content: p.content,
    mediaUrls: p.mediaUrls ? p.mediaUrls.split("|").filter(Boolean) : [],
    createdAt: p.createdAt,
    likes: p._count.likes,
    comments: p._count.comments,
  }))

  return NextResponse.json({
    posts: list,
    nextCursor: hasNext ? list[list.length - 1]?.id ?? null : null,
  })
}
