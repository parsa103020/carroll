import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const url = new URL(req.url)
  const cursor = url.searchParams.get("cursor")
  const take = 12

  const reels = await db.reel.findMany({
    where: { ownerId: session.user!.id },
    orderBy: { createdAt: "desc" },
    take: take + 1,
    ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
    include: { _count: { select: { likes: true, comments: true } } },
  })

  const hasNext = reels.length > take
  const list = reels.slice(0, take).map((r) => ({
    id: r.id,
    videoUrl: r.videoUrl,
    posterUrl: r.posterUrl,
    caption: r.caption,
    musicTitle: r.musicTitle,
    views: r.views,
    createdAt: r.createdAt,
    likes: r._count.likes,
    comments: r._count.comments,
  }))

  return NextResponse.json({
    reels: list,
    nextCursor: hasNext ? list[list.length - 1]?.id ?? null : null,
  })
}
