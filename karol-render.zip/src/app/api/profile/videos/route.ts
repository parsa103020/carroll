import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const url = new URL(req.url)
  const cursor = url.searchParams.get("cursor")
  const take = 12

  const videos = await db.video.findMany({
    where: { ownerId: session.user!.id },
    orderBy: { createdAt: "desc" },
    take: take + 1,
    ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
    include: { _count: { select: { likes: true, comments: true } } },
  })

  const hasNext = videos.length > take
  const list = videos.slice(0, take).map((v) => ({
    id: v.id,
    title: v.title,
    description: v.description,
    videoUrl: v.videoUrl,
    thumbnailUrl: v.thumbnailUrl,
    category: v.category,
    duration: v.duration,
    views: v.views,
    createdAt: v.createdAt,
    likes: v._count.likes,
    comments: v._count.comments,
  }))

  return NextResponse.json({
    videos: list,
    nextCursor: hasNext ? list[list.length - 1]?.id ?? null : null,
  })
}
