import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const url = new URL(req.url)
  const cursor = url.searchParams.get("cursor")
  const take = 24

  const files = await db.file.findMany({
    where: { ownerId: session.user!.id },
    orderBy: { createdAt: "desc" },
    take: take + 1,
    ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
  })

  const hasNext = files.length > take
  const list = files.slice(0, take).map((f) => ({
    id: f.id,
    name: f.name,
    url: f.url,
    size: f.size.toString(),
    mime: f.mime,
    category: f.category,
    isPublic: f.isPublic,
    createdAt: f.createdAt,
  }))

  return NextResponse.json({
    files: list,
    nextCursor: hasNext ? list[list.length - 1]?.id ?? null : null,
  })
}
