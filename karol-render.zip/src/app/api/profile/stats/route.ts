import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"
import { resetDailyUploadIfNeeded } from "@/lib/coins"

export const runtime = "nodejs"

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })

  const user = await resetDailyUploadIfNeeded(session.user!)

  const [files, posts, reels, videos] = await Promise.all([
    db.file.count({ where: { ownerId: user.id } }),
    db.feedPost.count({ where: { ownerId: user.id } }),
    db.reel.count({ where: { ownerId: user.id } }),
    db.video.count({ where: { ownerId: user.id } }),
  ])

  return NextResponse.json({
    counts: { files, posts, reels, videos },
    quota: {
      used: user.usedUploadBytesToday.toString(),
      limit: user.dailyUploadLimitBytes.toString(),
      resetAt: user.uploadResetAt,
    },
  })
}
