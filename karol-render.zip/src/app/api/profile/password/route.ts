import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hashPassword, verifyPassword } from "@/lib/auth"
import { CONFIG } from "@/lib/config"

export const runtime = "nodejs"

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const body = await req.json().catch(() => ({}))
  const current = String(body.current || "")
  const next = String(body.new || "")
  const confirm = String(body.confirm || "")

  if (!current || !next || !confirm) {
    return NextResponse.json({ error: "تمام فیلدها را پر کنید" }, { status: 400 })
  }
  if (next.length < CONFIG.auth.minPasswordLength) {
    return NextResponse.json(
      { error: `رمز عبور حداقل ${CONFIG.auth.minPasswordLength} نویسه باشد` },
      { status: 400 },
    )
  }
  if (next !== confirm) {
    return NextResponse.json({ error: "رمز جدید و تکرار آن یکسان نیستند" }, { status: 400 })
  }

  const user = await db.user.findUnique({ where: { id: session.user!.id } })
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 })

  const ok = await verifyPassword(current, user.passwordHash)
  if (!ok) {
    return NextResponse.json({ error: "رمز عبور فعلی نادرست است" }, { status: 400 })
  }

  const hash = await hashPassword(next)
  await db.user.update({ where: { id: user.id }, data: { passwordHash: hash } })

  return NextResponse.json({ ok: true })
}
