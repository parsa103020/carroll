import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

const PROFILE_EFFECTS = ["none", "rgb", "rainbow", "pulse", "gold"] as const
type ProfileEffect = (typeof PROFILE_EFFECTS)[number]

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const u = session.user!
  return NextResponse.json({
    user: {
      id: u.id,
      username: u.username,
      displayName: u.displayName,
      bio: u.bio,
      avatarUrl: u.avatarUrl,
      animatedAvatarUrl: u.animatedAvatarUrl,
      profileEffect: u.profileEffect,
      nameColor: u.nameColor,
      coins: u.coins,
      isVip: u.isVip,
      vipExpiresAt: u.vipExpiresAt,
      roles: u.roles.split(","),
      dailyUploadLimitBytes: u.dailyUploadLimitBytes.toString(),
      usedUploadBytesToday: u.usedUploadBytesToday.toString(),
      banned: u.banned,
      createdAt: u.createdAt,
      lastLoginAt: u.lastLoginAt,
    },
  })
}

export async function PATCH(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const body = await req.json().catch(() => ({}))
  const data: Record<string, string | null> = {}

  if (typeof body.displayName === "string") {
    const v = body.displayName.trim().slice(0, 60)
    data.displayName = v || null
  }
  if (typeof body.bio === "string") {
    const v = body.bio.trim().slice(0, 500)
    data.bio = v || null
  }
  if (typeof body.avatarUrl === "string") {
    const v = body.avatarUrl.trim()
    data.avatarUrl = v || null
  }

  if (typeof body.animatedAvatarUrl === "string") {
    const v = body.animatedAvatarUrl.trim()
    data.animatedAvatarUrl = v || null
  }

  if (typeof body.profileEffect === "string") {
    const v = body.profileEffect.trim()
    if (!PROFILE_EFFECTS.includes(v as ProfileEffect)) {
      return NextResponse.json({ error: "افکت پروفایل نامعتبر است" }, { status: 400 })
    }
    data.profileEffect = v
  }

  if (typeof body.nameColor === "string") {
    const v = body.nameColor.trim()
    if (!v) {
      data.nameColor = null
    } else if (!/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(v)) {
      return NextResponse.json({ error: "رنگ نامعتبر است (مثال: #2dd4bf)" }, { status: 400 })
    } else {
      data.nameColor = v
    }
  }

  if (Object.keys(data).length === 0) {
    return NextResponse.json({ error: "چیزی برای ذخیره نیست" }, { status: 400 })
  }

  const updated = await db.user.update({
    where: { id: session.user!.id },
    data,
    select: {
      id: true,
      username: true,
      displayName: true,
      bio: true,
      avatarUrl: true,
      animatedAvatarUrl: true,
      profileEffect: true,
      nameColor: true,
      coins: true,
      isVip: true,
      vipExpiresAt: true,
      roles: true,
      dailyUploadLimitBytes: true,
      usedUploadBytesToday: true,
      banned: true,
      createdAt: true,
      lastLoginAt: true,
    },
  })

  return NextResponse.json({
    user: {
      ...updated,
      roles: updated.roles.split(","),
      dailyUploadLimitBytes: updated.dailyUploadLimitBytes.toString(),
      usedUploadBytesToday: updated.usedUploadBytesToday.toString(),
    },
  })
}
