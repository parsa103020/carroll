import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { getSetting, asBigInt } from "@/lib/settings"
import { CONFIG } from "@/lib/config"

export const runtime = "nodejs"

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const u = session.user!
  const bonusBytes = asBigInt(
    await getSetting("vip.bonusUploadBytes"),
    BigInt(CONFIG.storage.limits.drive),
  )
  return NextResponse.json({
    isVip: u.isVip,
    vipExpiresAt: u.vipExpiresAt,
    bonusUploadBytes: bonusBytes.toString(),
    dailyUploadLimitBytes: u.dailyUploadLimitBytes.toString(),
    pricePerMonth: await getSetting("vip.pricePerMonth"),
  })
}
