import { NextRequest, NextResponse } from "next/server"
import { getSettings, setSettings } from "@/lib/settings"
import { getSession, hasRole } from "@/lib/auth"
import { audit, getClientInfo } from "@/lib/audit"

export const runtime = "nodejs"

const PUBLIC_KEYS = new Set([
  "general.siteName",
  "general.maintenance",
  "general.signupOpen",
  "shop.cardNumber",
  "shop.cardHolder",
  "vip.pricePerMonth",
  "chat.allowVoice",
  "chat.allowStickers",
  "chat.allowGifs",
  "chat.allowImages",
  "chat.allowVideos",
])

export async function GET() {
  const all = await getSettings()
  const session = await getSession()
  const isAdmin = session && hasRole(session.user!.roles, "admin")
  const filtered: Record<string, string> = {}
  for (const [k, v] of Object.entries(all)) {
    if (isAdmin || PUBLIC_KEYS.has(k) || k.startsWith("chat.") || k.startsWith("upload.") || k.startsWith("reel.") || k.startsWith("video.") || k.startsWith("feed.")) {
      filtered[k] = v
    }
  }
  return NextResponse.json(filtered)
}

export async function PUT(req: NextRequest) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  const body = await req.json().catch(() => ({}))
  await setSettings(body)
  const info = getClientInfo(req)
  await audit(
    { actorId: session.user!.id, actorName: session.user!.username, ip: info.ip, userAgent: info.userAgent },
    "settings.update",
    {
      targetType: "settings",
      targetId: "global",
      description: `به‌روزرسانی تنظیمات (${Object.keys(body).length} کلید)`,
      severity: "info",
      metadata: { keys: Object.keys(body) },
    },
  )
  return NextResponse.json({ ok: true })
}
