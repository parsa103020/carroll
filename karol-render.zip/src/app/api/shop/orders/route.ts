import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"
import { getSetting } from "@/lib/settings"

export const runtime = "nodejs"

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  if (!hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const orders = await db.order.findMany({
    orderBy: { createdAt: "desc" },
    take: 200,
    include: {
      user: { select: { id: true, username: true, displayName: true, avatarUrl: true } },
      shopItem: { select: { id: true, title: true, kind: true, payload: true, price: true } },
    },
  })
  return NextResponse.json({ orders })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const user = session.user!

  const body = await req.json().catch(() => ({}))
  const shopItemId = body.shopItemId ? String(body.shopItemId) : null
  const receiptUrl = body.receiptUrl ? String(body.receiptUrl) : null
  const note = body.note ? String(body.note).trim().slice(0, 500) : null

  let item: Awaited<ReturnType<typeof db.shopItem.findUnique>> = null
  let amount = 0
  let coins = 0

  if (shopItemId) {
    item = await db.shopItem.findUnique({ where: { id: shopItemId } })
    if (!item || !item.active)
      return NextResponse.json({ error: "محصول یافت نشد" }, { status: 404 })
    amount = item.price
    if (item.kind === "coins") {
      const parsed = parseInt(item.payload, 10)
      if (Number.isFinite(parsed) && parsed > 0) coins = parsed
    }
  } else {
    amount = parseInt(body.amount, 10)
    if (!Number.isFinite(amount) || amount <= 0)
      return NextResponse.json({ error: "مبلغ نامعتبر است" }, { status: 400 })
  }

  if (!receiptUrl)
    return NextResponse.json({ error: "تصویر رسید الزامی است" }, { status: 400 })

  const cardNumber = await getSetting("shop.cardNumber")

  const order = await db.order.create({
    data: {
      userId: user.id,
      shopItemId: item?.id ?? null,
      amount,
      coins,
      status: "pending",
      receiptUrl,
      note,
      cardNumber,
    },
    include: {
      shopItem: { select: { id: true, title: true, kind: true, payload: true, price: true } },
    },
  })
  return NextResponse.json({ order })
}
