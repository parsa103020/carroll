import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const url = new URL(req.url)
  const cursor = url.searchParams.get("cursor")
  const limit = Math.min(50, Math.max(1, parseInt(url.searchParams.get("limit") || "50", 10) || 50))

  const rows = await db.order.findMany({
    where: { userId: session.user!.id },
    orderBy: { createdAt: "desc" },
    take: limit + 1,
    ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
    include: {
      shopItem: { select: { id: true, title: true, kind: true, payload: true, price: true } },
    },
  })
  const hasNext = rows.length > limit
  const list = rows.slice(0, limit)
  return NextResponse.json({
    orders: list.map((o) => ({
      id: o.id,
      amount: o.amount,
      coins: o.coins,
      status: o.status,
      receiptUrl: o.receiptUrl,
      note: o.note,
      cardNumber: o.cardNumber,
      createdAt: o.createdAt,
      reviewedAt: o.reviewedAt,
      shopItem: o.shopItem
        ? {
            id: o.shopItem.id,
            title: o.shopItem.title,
            kind: o.shopItem.kind,
            payload: o.shopItem.payload,
            price: o.shopItem.price,
          }
        : null,
    })),
    nextCursor: hasNext ? list[list.length - 1]?.id || null : null,
  })
}
