import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"
import { creditCoins } from "@/lib/coins"
import { getSetting, asBigInt } from "@/lib/settings"
import { CONFIG } from "@/lib/config"
import { audit, getClientInfo } from "@/lib/audit"

export const runtime = "nodejs"

function parseVipPayload(payload: string): number {
  const days = parseInt(payload, 10)
  if (Number.isFinite(days) && days > 0) return days
  return 30
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  if (!hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const { id } = await ctx.params
  const body = await req.json().catch(() => ({}))
  const action = body.action === "reject" ? "rejected" : "confirmed"

  const order = await db.order.findUnique({
    where: { id },
    include: { shopItem: true },
  })
  if (!order) return NextResponse.json({ error: "سفارش یافت نشد" }, { status: 404 })
  if (order.status !== "pending")
    return NextResponse.json({ error: "این سفارش قبلاً بررسی شده است" }, { status: 400 })

  const info = getClientInfo(req)
  const auditCtx = { actorId: session.user!.id, actorName: session.user!.username, ip: info.ip, userAgent: info.userAgent }
  const itemTitle = order.shopItem?.title || "سفارش"

  if (action === "confirmed") {
    const item = order.shopItem
    if (item?.kind === "coins") {
      const parsed = parseInt(item.payload, 10)
      const amount = Number.isFinite(parsed) && parsed > 0 ? parsed : 0
      if (amount > 0) {
        await creditCoins(order.userId, amount, "purchase", "خرید کوین", order.id)
      }
    } else if (item?.kind === "vip") {
      const days = parseVipPayload(item.payload)
      const now = new Date()
      const fresh = await db.user.findUnique({ where: { id: order.userId } })
      const startFrom =
        fresh?.vipExpiresAt && fresh.vipExpiresAt > now ? fresh.vipExpiresAt : now
      const expiresAt = new Date(startFrom.getTime() + days * 86400000)
      const bonusBytes = asBigInt(
        await getSetting("vip.bonusUploadBytes"),
        BigInt(CONFIG.storage.limits.drive),
      )
      const newLimit = (fresh?.dailyUploadLimitBytes ?? BigInt(CONFIG.storage.limits.drive)) + bonusBytes
      await db.user.update({
        where: { id: order.userId },
        data: {
          isVip: true,
          vipExpiresAt: expiresAt,
          dailyUploadLimitBytes: newLimit,
        },
      })
    }

    const updated = await db.order.update({
      where: { id },
      data: {
        status: "confirmed",
        reviewedAt: new Date(),
        reviewerId: session.user!.id,
      },
      include: {
        user: { select: { id: true, username: true, displayName: true } },
        shopItem: { select: { id: true, title: true, kind: true, payload: true, price: true } },
      },
    })
    await audit(auditCtx, "shop.order_confirm", {
      targetType: "order",
      targetId: id,
      description: `تأیید سفارش «${itemTitle}» برای ${updated.user?.displayName || updated.user?.username || "کاربر"}`,
      severity: "warning",
      metadata: { orderId: id, userId: order.userId, amount: order.amount, itemKind: order.shopItem?.kind },
    })
    return NextResponse.json({ order: updated })
  } else {
    const updated = await db.order.update({
      where: { id },
      data: {
        status: "rejected",
        reviewedAt: new Date(),
        reviewerId: session.user!.id,
      },
      include: {
        user: { select: { id: true, username: true, displayName: true } },
        shopItem: { select: { id: true, title: true, kind: true, payload: true, price: true } },
      },
    })
    await audit(auditCtx, "shop.order_reject", {
      targetType: "order",
      targetId: id,
      description: `رد سفارش «${itemTitle}» برای ${updated.user?.displayName || updated.user?.username || "کاربر"}`,
      severity: "warning",
      metadata: { orderId: id, userId: order.userId, amount: order.amount },
    })
    return NextResponse.json({ order: updated })
  }
}
