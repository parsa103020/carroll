import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const items = await db.shopItem.findMany({
    where: { active: true },
    orderBy: [{ kind: "asc" }, { price: "asc" }],
    select: {
      id: true,
      title: true,
      description: true,
      price: true,
      kind: true,
      payload: true,
      imageUrl: true,
      active: true,
      createdAt: true,
    },
  })
  return NextResponse.json({ items })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session || !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const body = await req.json().catch(() => ({}))
  const title = String(body.title || "").trim()
  const description = body.description ? String(body.description).trim() : null
  const price = parseInt(body.price, 10)
  const kind = ["coins", "vip", "custom"].includes(body.kind) ? body.kind : "coins"
  const payload = body.payload ? String(body.payload) : ""
  const imageUrl = body.imageUrl ? String(body.imageUrl) : null
  const active = body.active !== false

  if (!title) return NextResponse.json({ error: "عنوان الزامی است" }, { status: 400 })
  if (!Number.isFinite(price) || price < 0)
    return NextResponse.json({ error: "قیمت نامعتبر است" }, { status: 400 })

  const item = await db.shopItem.create({
    data: { title, description, price, kind, payload, imageUrl, active },
  })
  return NextResponse.json({ item })
}
