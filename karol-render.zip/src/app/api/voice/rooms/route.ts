import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"
import { getSetting, asInt } from "@/lib/settings"

export const runtime = "nodejs"

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const user = session.user!
  const maxRoomUsers = asInt(await getSetting("voice.maxRoomUsers"), 8)

  const rooms = await db.voiceRoom.findMany({
    orderBy: { createdAt: "asc" },
    include: { owner: { select: { id: true, username: true, displayName: true } } },
  })

  const list = rooms.map((r) => ({
    id: r.id,
    name: r.name,
    description: r.description,
    type: r.type,
    ownerId: r.ownerId,
    ownerName: r.owner?.displayName || r.owner?.username || "کاربر",
    maxUsers: r.maxUsers,
    createdAt: r.createdAt,
    isOwner: r.ownerId === user.id,
    canManage: r.ownerId === user.id || hasRole(user.roles, "admin"),
  }))

  return NextResponse.json({ rooms: list, maxRoomUsers })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const user = session.user!
  const body = await req.json().catch(() => ({}))
  const name = String(body.name || "").trim()
  const description = body.description ? String(body.description).trim().slice(0, 200) : null
  const type = ["public", "vip"].includes(body.type) ? body.type : "public"
  const maxDefault = asInt(await getSetting("voice.maxRoomUsers"), 8)
  const maxUsers = Number.isFinite(Number(body.maxUsers)) && Number(body.maxUsers) > 0
    ? Math.min(Math.max(2, Number(body.maxUsers)), 24)
    : maxDefault
  if (!name) return NextResponse.json({ error: "نام روم الزامی است" }, { status: 400 })

  const room = await db.voiceRoom.create({
    data: { name, description, type, ownerId: user.id, maxUsers },
  })

  return NextResponse.json({ room })
}
