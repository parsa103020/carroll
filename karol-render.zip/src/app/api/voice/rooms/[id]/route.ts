import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const room = await db.voiceRoom.findUnique({ where: { id } })
  if (!room) return NextResponse.json({ error: "not found" }, { status: 404 })
  if (room.ownerId !== session.user!.id && !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  await db.voiceRoom.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
