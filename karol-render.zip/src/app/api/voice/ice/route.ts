import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { getSetting } from "@/lib/settings"

export const runtime = "nodejs"

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })

  const stunUrl = await getSetting("voice.stunUrl")
  const turnUrl = await getSetting("voice.turnUrl")
  const turnUser = await getSetting("voice.turnUser")
  const turnPass = await getSetting("voice.turnPass")
  const maxRoomUsers = Number(await getSetting("voice.maxRoomUsers")) || 8

  const iceServers: RTCIceServer[] = []
  if (stunUrl) iceServers.push({ urls: stunUrl })
  if (turnUrl) {
    iceServers.push({
      urls: turnUrl,
      username: turnUser || undefined,
      credential: turnPass || undefined,
    })
  }

  return NextResponse.json({ iceServers, maxRoomUsers })
}
