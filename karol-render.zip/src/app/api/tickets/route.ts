import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

const VALID_CATEGORIES = ["tech", "report", "payment", "vip", "other", "general"]
const VALID_PRIORITIES = ["low", "normal", "high"]
const VALID_STATUSES = ["open", "pending", "closed"]

const OWNER_SELECT = {
  id: true,
  username: true,
  displayName: true,
  avatarUrl: true,
  isVip: true,
} as const

function serializeTicket(t: any) {
  return {
    id: t.id,
    subject: t.subject,
    category: t.category,
    status: t.status,
    priority: t.priority,
    assignedTo: t.assignedTo,
    userId: t.userId,
    createdAt: t.createdAt,
    updatedAt: t.updatedAt,
    closedAt: t.closedAt,
    owner: t.owner ?? null,
    messagesCount: t._count?.messages ?? 0,
    lastMessage: t.messages?.[0]
      ? {
          id: t.messages[0].id,
          content: t.messages[0].content,
          isAdmin: t.messages[0].isAdmin,
          createdAt: t.messages[0].createdAt,
          userId: t.messages[0].userId,
        }
      : null,
  }
}

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const url = new URL(req.url)
  const status = url.searchParams.get("status")
  const category = url.searchParams.get("category")
  const userId = url.searchParams.get("userId")
  const q = url.searchParams.get("q")?.trim() || ""
  const admin = hasRole(session.user!.roles, "admin")

  const where: any = {}
  if (!admin) {
    where.userId = session.user!.id
  } else if (userId) {
    where.userId = userId
  }
  if (status && VALID_STATUSES.includes(status)) where.status = status
  if (category && VALID_CATEGORIES.includes(category)) where.category = category
  if (q) {
    where.OR = [
      { subject: { contains: q } },
      { user: { username: { contains: q } } },
      { user: { displayName: { contains: q } } },
    ]
  }

  const tickets = await db.ticket.findMany({
    where,
    orderBy: { updatedAt: "desc" },
    take: 200,
    include: {
      ...(admin ? { user: { select: OWNER_SELECT } } : {}),
      _count: { select: { messages: true } },
      messages: {
        orderBy: { createdAt: "desc" },
        take: 1,
        select: {
          id: true,
          content: true,
          isAdmin: true,
          createdAt: true,
          userId: true,
        },
      },
    },
  })

  return NextResponse.json({
    tickets: tickets.map((t) => serializeTicket({ ...t, owner: (t as any).user })),
    isAdmin: admin,
  })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const body = await req.json().catch(() => ({}))
  const subject = String(body.subject || "").trim()
  const message = String(body.message || "").trim()
  const category = VALID_CATEGORIES.includes(body.category) ? body.category : "general"
  const priority = VALID_PRIORITIES.includes(body.priority) ? body.priority : "normal"

  if (subject.length < 3 || subject.length > 200)
    return NextResponse.json({ error: "موضوع باید بین ۳ تا ۲۰۰ نویسه باشد" }, { status: 400 })
  if (message.length < 1 || message.length > 5000)
    return NextResponse.json({ error: "پیام اولیه الزامی است" }, { status: 400 })

  const ticket = await db.ticket.create({
    data: {
      userId: session.user!.id,
      subject,
      category,
      priority,
      messages: {
        create: {
          userId: session.user!.id,
          content: message,
          isAdmin: false,
        },
      },
    },
    include: {
      messages: { take: 1, orderBy: { createdAt: "asc" } },
      _count: { select: { messages: true } },
    },
  })

  // Notify admins
  const admins = await db.user.findMany({
    where: { roles: { contains: "admin" } },
    select: { id: true },
  })
  if (admins.length > 0) {
    await db.notification.createMany({
      data: admins.map((a) => ({
        userId: a.id,
        type: "ticket",
        title: "تیکت جدید",
        body: subject,
        link: `tickets:${ticket.id}`,
      })),
    })
  }

  return NextResponse.json({
    ticket: serializeTicket({
      ...ticket,
      owner: null,
      messages: ticket.messages,
    }),
  })
}
