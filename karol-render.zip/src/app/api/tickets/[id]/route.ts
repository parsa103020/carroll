import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

const VALID_CATEGORIES = ["tech", "report", "payment", "vip", "other", "general"]
const VALID_PRIORITIES = ["low", "normal", "high"]
const VALID_STATUSES = ["open", "pending", "closed"]

const USER_SELECT = {
  id: true,
  username: true,
  displayName: true,
  avatarUrl: true,
  isVip: true,
} as const

function parseAttachments(raw: string | null | undefined): string[] {
  if (!raw) return []
  try {
    const v = JSON.parse(raw)
    return Array.isArray(v) ? v.filter((x) => typeof x === "string") : []
  } catch {
    return raw.split("|").filter(Boolean)
  }
}

function serializeTicketFull(t: any) {
  return {
    id: t.id,
    subject: t.subject,
    category: t.category,
    status: t.status,
    priority: t.priority,
    assignedTo: t.assignedTo,
    userId: t.userId,
    createdAt: t.createdAt,
    updatedAt: t.updatedAt,
    closedAt: t.closedAt,
    owner: t.user
      ? {
          id: t.user.id,
          username: t.user.username,
          displayName: t.user.displayName,
          avatarUrl: t.user.avatarUrl,
          isVip: t.user.isVip,
          roles: t.user.roles,
        }
      : null,
    messages: (t.messages || []).map((m: any) => ({
      id: m.id,
      content: m.content,
      isAdmin: m.isAdmin,
      attachments: parseAttachments(m.attachments),
      createdAt: m.createdAt,
      userId: m.userId,
      user: m.user
        ? {
            id: m.user.id,
            username: m.user.username,
            displayName: m.user.displayName,
            avatarUrl: m.user.avatarUrl,
            isVip: m.user.isVip,
          }
        : null,
    })),
  }
}

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const admin = hasRole(session.user!.roles, "admin")

  const ticket = await db.ticket.findUnique({
    where: { id },
    include: {
      user: { select: { ...USER_SELECT, roles: true } },
      messages: {
        orderBy: { createdAt: "asc" },
        include: { user: { select: USER_SELECT } },
      },
    },
  })
  if (!ticket) return NextResponse.json({ error: "not found" }, { status: 404 })
  if (!admin && ticket.userId !== session.user!.id)
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  return NextResponse.json({ ticket: serializeTicketFull(ticket), isAdmin: admin })
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const admin = hasRole(session.user!.roles, "admin")
  if (!admin) return NextResponse.json({ error: "forbidden" }, { status: 403 })
  const { id } = await params
  const body = await req.json().catch(() => ({}))

  const data: any = {}
  if (body.status && VALID_STATUSES.includes(body.status)) {
    data.status = body.status
    if (body.status === "closed") data.closedAt = new Date()
    else data.closedAt = null
  }
  if (body.priority && VALID_PRIORITIES.includes(body.priority)) data.priority = body.priority
  if (body.assignedTo !== undefined) data.assignedTo = body.assignedTo ? String(body.assignedTo) : null
  // admin can also reassign category
  if (body.category && VALID_CATEGORIES.includes(body.category)) data.category = body.category

  if (Object.keys(data).length === 0)
    return NextResponse.json({ error: "nothing to update" }, { status: 400 })

  const ticket = await db.ticket.update({
    where: { id },
    data,
    include: {
      user: { select: { ...USER_SELECT, roles: true } },
      messages: {
        orderBy: { createdAt: "asc" },
        include: { user: { select: USER_SELECT } },
      },
    },
  })

  return NextResponse.json({ ticket: serializeTicketFull(ticket) })
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const admin = hasRole(session.user!.roles, "admin")
  const { id } = await params

  const ticket = await db.ticket.findUnique({
    where: { id },
    select: { id: true, userId: true, status: true },
  })
  if (!ticket) return NextResponse.json({ error: "not found" }, { status: 404 })
  if (!admin && ticket.userId !== session.user!.id)
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  // Close the ticket (soft). Admin can hard-delete via admin panel if needed.
  await db.ticket.update({
    where: { id },
    data: { status: "closed", closedAt: new Date() },
  })

  return NextResponse.json({ ok: true })
}
