import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

const USER_SELECT = {
  id: true,
  username: true,
  displayName: true,
  avatarUrl: true,
  isVip: true,
} as const

function parseAttachments(raw: string | null | undefined): string[] {
  if (!raw) return []
  try {
    const v = JSON.parse(raw)
    return Array.isArray(v) ? v.filter((x) => typeof x === "string") : []
  } catch {
    return raw.split("|").filter(Boolean)
  }
}

function serializeMessage(m: any) {
  return {
    id: m.id,
    content: m.content,
    isAdmin: m.isAdmin,
    attachments: parseAttachments(m.attachments),
    createdAt: m.createdAt,
    userId: m.userId,
    user: m.user
      ? {
          id: m.user.id,
          username: m.user.username,
          displayName: m.user.displayName,
          avatarUrl: m.user.avatarUrl,
          isVip: m.user.isVip,
        }
      : null,
  }
}

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const admin = hasRole(session.user!.roles, "admin")

  const ticket = await db.ticket.findUnique({
    where: { id },
    select: { id: true, userId: true },
  })
  if (!ticket) return NextResponse.json({ error: "not found" }, { status: 404 })
  if (!admin && ticket.userId !== session.user!.id)
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const url = new URL(req.url)
  const since = url.searchParams.get("since")
  const sinceDate = since ? new Date(since) : null

  const messages = await db.ticketMessage.findMany({
    where: {
      ticketId: id,
      ...(sinceDate && !isNaN(sinceDate.getTime()) ? { createdAt: { gt: sinceDate } } : {}),
    },
    orderBy: { createdAt: "asc" },
    take: 500,
    include: { user: { select: USER_SELECT } },
  })

  return NextResponse.json({
    messages: messages.map(serializeMessage),
  })
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const admin = hasRole(session.user!.roles, "admin")

  const ticket = await db.ticket.findUnique({
    where: { id },
    select: { id: true, userId: true, status: true, subject: true },
  })
  if (!ticket) return NextResponse.json({ error: "not found" }, { status: 404 })
  if (!admin && ticket.userId !== session.user!.id)
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  if (ticket.status === "closed" && !admin)
    return NextResponse.json({ error: "این تیکت بسته شده است" }, { status: 400 })

  const body = await req.json().catch(() => ({}))
  const content = String(body.content || "").trim()
  if (!content) return NextResponse.json({ error: "پیام خالی است" }, { status: 400 })
  if (content.length > 5000)
    return NextResponse.json({ error: "پیام خیلی طولانی است" }, { status: 400 })

  let attachmentsRaw = ""
  const att = body.attachments
  if (Array.isArray(att) && att.length > 0) {
    const clean = att.filter((x: any) => typeof x === "string").slice(0, 10)
    if (clean.length > 0) attachmentsRaw = JSON.stringify(clean)
  }

  const msg = await db.ticketMessage.create({
    data: {
      ticketId: id,
      userId: session.user!.id,
      content,
      isAdmin: admin,
      attachments: attachmentsRaw,
    },
    include: { user: { select: USER_SELECT } },
  })

  // Touch ticket.updatedAt (re-open if closed and admin replies)
  await db.ticket.update({
    where: { id },
    data: {
      updatedAt: new Date(),
      ...(ticket.status === "closed" && admin ? { status: "pending", closedAt: null } : {}),
    },
  })

  // Notify the other party
  if (admin) {
    await db.notification.create({
      data: {
        userId: ticket.userId,
        type: "ticket",
        title: "پاسخ پشتیبانی",
        body: content.slice(0, 120),
        link: `tickets:${id}`,
      },
    })
  } else {
    const admins = await db.user.findMany({
      where: { roles: { contains: "admin" } },
      select: { id: true },
    })
    if (admins.length > 0) {
      await db.notification.createMany({
        data: admins.map((a) => ({
          userId: a.id,
          type: "ticket",
          title: "پیام جدید در تیکت",
          body: content.slice(0, 120),
          link: `tickets:${id}`,
        })),
      })
    }
  }

  return NextResponse.json({ message: serializeMessage(msg) })
}
