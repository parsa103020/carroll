import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { resetDailyUploadIfNeeded } from "@/lib/coins"

export const runtime = "nodejs"

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })

  const user = await resetDailyUploadIfNeeded(session.user!)

  const used = user.usedUploadBytesToday
  const limit = user.dailyUploadLimitBytes
  const remaining = used > limit ? 0n : limit - used

  return NextResponse.json({
    used: used.toString(),
    limit: limit.toString(),
    remaining: remaining.toString(),
    resetAt: user.uploadResetAt.toISOString(),
  })
}
