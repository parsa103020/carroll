import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { db } from "@/lib/db"

export const runtime = "nodejs"

const PAGE_SIZE = 40

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const category = searchParams.get("category") || undefined
  const q = searchParams.get("q")?.trim() || undefined
  const cursor = searchParams.get("cursor") || undefined

  const where: any = { ownerId: session.user!.id }
  if (category && category !== "all") {
    where.category = category
  }
  if (q) {
    where.name = { contains: q }
  }

  const items = await db.file.findMany({
    where,
    orderBy: { createdAt: "desc" },
    take: PAGE_SIZE + 1,
    ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
    select: {
      id: true,
      name: true,
      url: true,
      size: true,
      mime: true,
      category: true,
      isPublic: true,
      createdAt: true,
    },
  })

  let nextCursor: string | null = null
  if (items.length > PAGE_SIZE) {
    const next = items.pop()!
    nextCursor = next.id
  }

  return NextResponse.json({
    files: items.map((f) => ({
      ...f,
      size: f.size.toString(),
    })),
    nextCursor,
  })
}
