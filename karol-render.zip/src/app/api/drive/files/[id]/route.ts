import { NextRequest, NextResponse } from "next/server"
import { getSession, hasRole } from "@/lib/auth"
import { db } from "@/lib/db"
import { deleteObject, objectPathFromUrl } from "@/lib/storage"

export const runtime = "nodejs"

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })

  const { id } = await ctx.params
  const file = await db.file.findUnique({ where: { id } })
  if (!file) return NextResponse.json({ error: "not found" }, { status: 404 })

  const isOwner = file.ownerId === session.user!.id
  const isAdmin = hasRole(session.user!.roles, "admin")
  if (!isOwner && !isAdmin) {
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  }

  const body = await req.json().catch(() => ({}))
  const isPublic = !!body.isPublic

  const updated = await db.file.update({
    where: { id },
    data: { isPublic },
    select: { id: true, isPublic: true },
  })

  return NextResponse.json(updated)
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })

  const { id } = await ctx.params
  const file = await db.file.findUnique({ where: { id } })
  if (!file) return NextResponse.json({ error: "not found" }, { status: 404 })

  const isOwner = file.ownerId === session.user!.id
  const isAdmin = hasRole(session.user!.roles, "admin")
  if (!isOwner && !isAdmin) {
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  }

  const objPath = objectPathFromUrl(file.url)
  if (objPath) await deleteObject(objPath)
  await db.file.delete({ where: { id } })

  return NextResponse.json({ ok: true })
}
