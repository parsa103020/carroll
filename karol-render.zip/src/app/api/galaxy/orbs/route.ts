import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

interface Orb {
  id: string
  type: "post" | "reel" | "video" | "music" | "user"
  refId: string
  title: string
  subtitle: string
  avatar?: string | null
  poster?: string | null
  glow: number
  metric: number
  seed: number
  href: string
}

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })

  const [posts, reels, videos, tracks, vips] = await Promise.all([
    db.feedPost.findMany({
      take: 14,
      orderBy: { createdAt: "desc" },
      include: { owner: { select: { id: true, username: true, displayName: true, avatarUrl: true, isVip: true } }, _count: { select: { likes: true, comments: true } } },
    }),
    db.reel.findMany({
      take: 10,
      orderBy: { views: "desc" },
      include: { owner: { select: { id: true, username: true, displayName: true, avatarUrl: true, isVip: true } }, _count: { select: { likes: true, comments: true } } },
    }),
    db.video.findMany({
      take: 10,
      orderBy: { views: "desc" },
      include: { owner: { select: { id: true, username: true, displayName: true, avatarUrl: true, isVip: true } }, _count: { select: { likes: true, comments: true } } },
    }),
    db.musicTrack.findMany({
      take: 10,
      orderBy: { plays: "desc" },
    }),
    db.user.findMany({
      take: 8,
      where: { isVip: true },
      select: { id: true, username: true, displayName: true, avatarUrl: true, isVip: true, coins: true },
    }),
  ])

  const orbs: Orb[] = []

  posts.forEach((p, i) => {
    const glow = Math.min(1, (p._count.likes + p._count.comments) / 20)
    orbs.push({
      id: `post-${p.id}`,
      type: "post",
      refId: p.id,
      title: p.content?.slice(0, 60) || "پست کارول",
      subtitle: `@${p.owner.username}`,
      avatar: p.owner.avatarUrl,
      glow,
      metric: p._count.likes,
      seed: (parseInt(p.id.slice(-6), 36) + i) % 1000,
      href: "feed",
    })
  })

  reels.forEach((r, i) => {
    const glow = Math.min(1, (r.views + r._count.likes * 5) / 500)
    orbs.push({
      id: `reel-${r.id}`,
      type: "reel",
      refId: r.id,
      title: r.caption?.slice(0, 50) || "ریلز",
      subtitle: `@${r.owner.username}`,
      avatar: r.owner.avatarUrl,
      glow,
      metric: r.views,
      seed: (parseInt(r.id.slice(-6), 36) + i) % 1000,
      poster: r.posterUrl || undefined,
      href: "reels",
    })
  })

  videos.forEach((v, i) => {
    const glow = Math.min(1, (v.views + v._count.likes * 3) / 800)
    orbs.push({
      id: `video-${v.id}`,
      type: "video",
      refId: v.id,
      title: v.title,
      subtitle: `@${v.owner.username}`,
      avatar: v.owner.avatarUrl,
      glow,
      metric: v.views,
      seed: (parseInt(v.id.slice(-6), 36) + i) % 1000,
      poster: v.thumbnailUrl || undefined,
      href: "videos",
    })
  })

  tracks.forEach((t, i) => {
    const glow = Math.min(1, t.plays / 200)
    orbs.push({
      id: `track-${t.id}`,
      type: "music",
      refId: t.id,
      title: t.title,
      subtitle: t.artist,
      avatar: t.coverUrl || undefined,
      glow,
      metric: t.plays,
      seed: (parseInt(t.id.slice(-6), 36) + i) % 1000,
      href: "music",
    })
  })

  vips.forEach((u, i) => {
    const glow = Math.min(1, u.coins / 100000)
    orbs.push({
      id: `user-${u.id}`,
      type: "user",
      refId: u.id,
      title: u.displayName || u.username,
      subtitle: `@${u.username}`,
      avatar: u.avatarUrl,
      glow,
      metric: u.coins,
      seed: (parseInt(u.id.slice(-6), 36) + i) % 1000,
      href: "profile",
    })
  })

  orbs.sort((a, b) => b.glow - a.glow)

  const stats = {
    totalOrbs: orbs.length,
    posts: posts.length,
    reels: reels.length,
    videos: videos.length,
    tracks: tracks.length,
    vips: vips.length,
    brightest: orbs[0] || null,
  }

  return NextResponse.json({ orbs, stats })
}
