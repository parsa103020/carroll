import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"
import { getSetting, asInt } from "@/lib/settings"

export const runtime = "nodejs"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const url = new URL(req.url)
  const cursor = url.searchParams.get("cursor")
  const take = 20
  const posts = await db.feedPost.findMany({
    where: { ownerId: { not: undefined } },
    orderBy: { createdAt: "desc" },
    take: take + 1,
    ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
    include: {
      owner: {
        select: {
          id: true,
          username: true,
          displayName: true,
          avatarUrl: true,
          animatedAvatarUrl: true,
          isVip: true,
          profileEffect: true,
          nameColor: true,
        },
      },
      likes: { where: { userId: session.user!.id }, select: { id: true } },
      _count: { select: { likes: true, comments: true } },
    },
  })
  const hasNext = posts.length > take
  const list = posts.slice(0, take).map((p) => ({
    id: p.id,
    content: p.content,
    mediaUrls: p.mediaUrls ? p.mediaUrls.split("|").filter(Boolean) : [],
    createdAt: p.createdAt,
    likes: p._count.likes,
    comments: p._count.comments,
    liked: p.likes.length > 0,
    owner: p.owner,
  }))
  return NextResponse.json({ posts: list, nextCursor: hasNext ? list[list.length - 1]?.id : null })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const body = await req.json().catch(() => ({}))
  const content = String(body.content || "").trim()
  const mediaUrls: string[] = Array.isArray(body.mediaUrls) ? body.mediaUrls : []
  if (!content && mediaUrls.length === 0)
    return NextResponse.json({ error: "خالی است" }, { status: 400 })
  if (content.length > 2000)
    return NextResponse.json({ error: "متن خیلی طولانی است" }, { status: 400 })
  const maxMedia = asInt(await getSetting("feed.maxMedia"), 4)
  if (mediaUrls.length > maxMedia)
    return NextResponse.json({ error: `حداکثر ${maxMedia} تصویر` }, { status: 400 })
  const post = await db.feedPost.create({
    data: {
      ownerId: session.user!.id,
      content: content || null,
      mediaUrls: mediaUrls.join("|"),
    },
    include: {
      owner: {
        select: {
          id: true,
          username: true,
          displayName: true,
          avatarUrl: true,
          animatedAvatarUrl: true,
          isVip: true,
          profileEffect: true,
          nameColor: true,
        },
      },
    },
  })
  return NextResponse.json({
    post: {
      id: post.id,
      content: post.content,
      mediaUrls: mediaUrls,
      createdAt: post.createdAt,
      likes: 0,
      comments: 0,
      liked: false,
      owner: post.owner,
    },
  })
}
