import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { getSetting, asBigInt } from "@/lib/settings"
import { storeObject } from "@/lib/storage"
import { consumeUploadQuota, resetDailyUploadIfNeeded } from "@/lib/coins"
import { db } from "@/lib/db"
import { CONFIG } from "@/lib/config"

export const runtime = "nodejs"
export const maxDuration = 120

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const user = await resetDailyUploadIfNeeded(session.user!)

  const form = await req.formData()
  const file = form.get("file") as File | null
  if (!file) return NextResponse.json({ error: "no file" }, { status: 400 })

  const limit = asBigInt(
    await getSetting("chat.voiceMaxBytes"),
    BigInt(CONFIG.storage.limits.chatVoice),
  )
  if (BigInt(file.size) > limit) {
    return NextResponse.json(
      { error: `حجم فایل صوتی بیش از حد مجاز است (${(Number(limit) / 1024 / 1024).toFixed(1)} مگابایت)` },
      { status: 413 },
    )
  }

  const buf = Buffer.from(await file.arrayBuffer())
  const mime = file.type || "audio/webm"
  const obj = await storeObject("chat", buf, mime, file.name || `voice-${Date.now()}.webm`)

  try {
    await consumeUploadQuota(user.id, BigInt(file.size))
  } catch (e: any) {
    return NextResponse.json(
      { error: e.message === "UPLOAD_QUOTA_EXCEEDED" ? "سهمیه آپلود روزانه شما پر شده است" : e.message },
      { status: 400 },
    )
  }

  await db.file.create({
    data: {
      ownerId: user.id,
      name: file.name || "voice",
      url: obj.url,
      size: BigInt(file.size),
      mime,
      category: "audio",
      isPublic: false,
    },
  })

  return NextResponse.json({
    ok: true,
    url: obj.url,
    size: file.size,
    mime,
    category: "audio",
  })
}
