import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasAnyRole } from "@/lib/auth"

export const runtime = "nodejs"

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string; msgId: string }> }) {
  const { id, msgId } = await ctx.params
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const user = session.user!

  const msg = await db.chatMessage.findUnique({
    where: { id: msgId },
    select: { roomId: true, userId: true },
  })
  if (!msg || msg.roomId !== id)
    return NextResponse.json({ error: "message not found" }, { status: 404 })

  const canDelete =
    msg.userId === user.id || hasAnyRole(user.roles, "admin", "chat_mod")
  if (!canDelete) return NextResponse.json({ error: "forbidden" }, { status: 403 })

  await db.chatMessage.update({
    where: { id: msgId },
    data: { deletedAt: new Date(), content: null, mediaUrl: null, mediaMeta: null },
  })

  return NextResponse.json({ ok: true, messageId: msgId })
}
