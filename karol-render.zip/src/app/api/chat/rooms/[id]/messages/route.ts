import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole, hasAnyRole } from "@/lib/auth"
import { getSetting, asInt, asBool } from "@/lib/settings"
import { CONFIG } from "@/lib/config"

export const runtime = "nodejs"

const PAGE_SIZE = CONFIG.chat.historyPageSize

function canAccess(room: { type: string }, user: { isVip: boolean; roles: string }) {
  if (room.type === "vip") return user.isVip || hasRole(user.roles, "admin")
  return true
}

function mapMessage(m: any) {
  return {
    id: m.id,
    roomId: m.roomId,
    userId: m.userId,
    username: m.username,
    content: m.content,
    type: m.type,
    mediaUrl: m.mediaUrl,
    mediaMeta: m.mediaMeta,
    replyToId: m.replyToId,
    forwardedFromId: m.forwardedFromId,
    forwardedFromName: m.forwardedFromName,
    createdAt: m.createdAt,
    deletedAt: m.deletedAt,
    user: m.user
      ? {
          id: m.user.id,
          username: m.user.username,
          displayName: m.user.displayName,
          avatarUrl: m.user.avatarUrl,
          animatedAvatarUrl: m.user.animatedAvatarUrl,
          isVip: m.user.isVip,
          isAdmin: hasRole(m.user.roles, "admin"),
          profileEffect: m.user.profileEffect,
          nameColor: m.user.nameColor,
        }
      : null,
  }
}

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const user = session.user!

  const room = await db.chatRoom.findUnique({ where: { id }, select: { type: true } })
  if (!room) return NextResponse.json({ error: "room not found" }, { status: 404 })
  if (!canAccess(room, user))
    return NextResponse.json({ error: "برای ورود به این روم VIP لازم است" }, { status: 403 })

  const url = new URL(req.url)
  const cursor = url.searchParams.get("cursor")
  const limit = Math.min(asInt(url.searchParams.get("limit") || "", PAGE_SIZE), 100)

  const messages = await db.chatMessage.findMany({
    where: { roomId: id },
    orderBy: { createdAt: "desc" },
    take: limit + 1,
    ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
    include: {
      user: {
        select: {
          id: true,
          username: true,
          displayName: true,
          avatarUrl: true,
          animatedAvatarUrl: true,
          isVip: true,
          roles: true,
          profileEffect: true,
          nameColor: true,
        },
      },
    },
  })

  const hasNext = messages.length > limit
  const list = messages.slice(0, limit).map(mapMessage)

  return NextResponse.json({
    messages: list,
    nextCursor: hasNext ? list[list.length - 1]?.id : null,
  })
}

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const user = session.user!

  const room = await db.chatRoom.findUnique({
    where: { id },
    select: { id: true, type: true, roomKind: true, ownerId: true },
  })
  if (!room) return NextResponse.json({ error: "room not found" }, { status: 404 })
  if (!canAccess(room, user))
    return NextResponse.json({ error: "برای ورود به این روم VIP لازم است" }, { status: 403 })

  const isRoomOwner = room.ownerId === user.id
  const canPostInChannel =
    room.roomKind !== "channel" || isRoomOwner || hasAnyRole(user.roles, "admin", "chat_mod")
  if (!canPostInChannel) {
    return NextResponse.json(
      { error: "فقط سازنده کانال می‌تواند پیام بفرستد" },
      { status: 403 },
    )
  }

  const body = await req.json().catch(() => ({}))
  const type = String(body.type || "text")
  const validTypes = ["text", "image", "video", "voice", "gif", "sticker"]
  if (!validTypes.includes(type))
    return NextResponse.json({ error: "نوع پیام نامعتبر است" }, { status: 400 })

  const forwardedFromId = typeof body.forwardedFromId === "string" ? body.forwardedFromId : null
  let forwardedFromName: string | null =
    typeof body.forwardedFromName === "string" ? body.forwardedFromName : null

  let content = typeof body.content === "string" ? body.content.slice(0, 10000) : null
  let mediaUrl = typeof body.mediaUrl === "string" ? body.mediaUrl : null
  let mediaMeta = body.mediaMeta ? JSON.stringify(body.mediaMeta).slice(0, 2000) : null

  if (forwardedFromId) {
    const src = await db.chatMessage.findUnique({
      where: { id: forwardedFromId },
      select: {
        id: true,
        content: true,
        type: true,
        mediaUrl: true,
        mediaMeta: true,
        username: true,
        userId: true,
        roomId: true,
      },
    })
    if (!src) {
      return NextResponse.json({ error: "پیام مبدأ یافت نشد" }, { status: 404 })
    }
    content = src.content
    mediaUrl = src.mediaUrl
    mediaMeta = src.mediaMeta
    if (!forwardedFromName) {
      forwardedFromName = src.username || null
    }
  }

  const replyToId = typeof body.replyToId === "string" ? body.replyToId : null

  if (type === "text" && (!content || !content.trim()))
    return NextResponse.json({ error: "پیام خالی است" }, { status: 400 })
  if (type !== "text" && !mediaUrl)
    return NextResponse.json({ error: "فایل ضمیمه الزامی است" }, { status: 400 })

  const maxLen = asInt(await getSetting("chat.maxMessageLength"), 2000)
  if (content && content.length > maxLen)
    return NextResponse.json({ error: `حداکثر طول پیام ${maxLen} نویسه است` }, { status: 400 })

  if (type === "voice" && !asBool(await getSetting("chat.allowVoice")))
    return NextResponse.json({ error: "ارسال پیام صوتی غیرفعال است" }, { status: 403 })
  if (type === "sticker" && !asBool(await getSetting("chat.allowStickers")))
    return NextResponse.json({ error: "استیکر غیرفعال است" }, { status: 403 })
  if (type === "gif" && !asBool(await getSetting("chat.allowGifs")))
    return NextResponse.json({ error: "ارسال گیف غیرفعال است" }, { status: 403 })
  if (type === "image" && !asBool(await getSetting("chat.allowImages")))
    return NextResponse.json({ error: "ارسال تصویر غیرفعال است" }, { status: 403 })
  if (type === "video" && !asBool(await getSetting("chat.allowVideos")))
    return NextResponse.json({ error: "ارسال ویدیو غیرفعال است" }, { status: 403 })

  const rateLimitSecs = asInt(await getSetting("chat.rateLimitSeconds"), 1)
  if (rateLimitSecs > 0) {
    const last = await db.chatMessage.findFirst({
      where: { userId: user.id, roomId: id },
      orderBy: { createdAt: "desc" },
      select: { createdAt: true },
    })
    if (last) {
      const elapsed = (Date.now() - last.createdAt.getTime()) / 1000
      if (elapsed < rateLimitSecs)
        return NextResponse.json(
          { error: `لطفاً ${rateLimitSecs} ثانیه صبر کنید` },
          { status: 429 },
        )
    }
  }

  const membership = await db.chatMember.findUnique({
    where: { roomId_userId: { roomId: id, userId: user.id } },
  })
  if (!membership) {
    const role = room.roomKind === "channel" ? (isRoomOwner ? "owner" : "viewer") : "member"
    await db.chatMember.create({
      data: { roomId: id, userId: user.id, role },
    })
  } else if (membership.muted && !hasAnyRole(user.roles, "admin", "chat_mod")) {
    return NextResponse.json({ error: "شما در این روم بی‌صدا شده‌اید" }, { status: 403 })
  }

  if (replyToId) {
    const r = await db.chatMessage.findUnique({ where: { id: replyToId }, select: { roomId: true } })
    if (!r || r.roomId !== id) return NextResponse.json({ error: "invalid reply" }, { status: 400 })
  }

  const message = await db.chatMessage.create({
    data: {
      roomId: id,
      userId: user.id,
      username: user.username,
      content,
      type,
      mediaUrl,
      mediaMeta,
      replyToId,
      forwardedFromId,
      forwardedFromName,
    },
    include: {
      user: {
        select: {
          id: true,
          username: true,
          displayName: true,
          avatarUrl: true,
          animatedAvatarUrl: true,
          isVip: true,
          roles: true,
          profileEffect: true,
          nameColor: true,
        },
      },
    },
  })

  if ((type === "sticker" || type === "gif") && mediaUrl) {
    try {
      await db.sticker.updateMany({
        where: { url: mediaUrl },
        data: { usageCount: { increment: 1 } },
      })
    } catch {
      // ignore — sticker may not exist (external URL)
    }
  }

  return NextResponse.json({ message: mapMessage(message) })
}
