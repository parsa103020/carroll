import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

export async function POST(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const user = session.user!

  const room = await db.chatRoom.findUnique({
    where: { id },
    select: { id: true, type: true, roomKind: true, ownerId: true },
  })
  if (!room) return NextResponse.json({ error: "room not found" }, { status: 404 })

  if (room.type === "vip" && !user.isVip) {
    return NextResponse.json({ error: "این روم مخصوص اعضای VIP است" }, { status: 403 })
  }

  const existing = await db.chatMember.findUnique({
    where: { roomId_userId: { roomId: id, userId: user.id } },
    select: { id: true, role: true },
  })

  if (existing) {
    return NextResponse.json({
      ok: true,
      alreadyMember: true,
      role: existing.role,
    })
  }

  const role = room.roomKind === "channel" ? "viewer" : "member"
  await db.chatMember.create({
    data: { roomId: id, userId: user.id, role },
  })

  return NextResponse.json({ ok: true, alreadyMember: false, role })
}
