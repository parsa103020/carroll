import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const user = session.user!
  const isAdmin = hasRole(user.roles, "admin")

  const room = await db.chatRoom.findUnique({
    where: { id },
    include: {
      members: { where: { userId: user.id }, select: { id: true, role: true } },
      _count: { select: { members: true } },
    },
  })
  if (!room) return NextResponse.json({ error: "room not found" }, { status: 404 })
  const accessible = room.type === "public" || user.isVip || isAdmin
  return NextResponse.json({
    room: {
      id: room.id,
      name: room.name,
      description: room.description,
      type: room.type,
      roomKind: room.roomKind,
      iconUrl: room.iconUrl,
      ownerId: room.ownerId,
      order: room.order,
      memberCount: room._count.members,
      isMember: room.members.length > 0,
      memberRole: room.members[0]?.role || null,
      isOwner: room.ownerId === user.id,
      accessible,
    },
  })
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const user = session.user!

  const room = await db.chatRoom.findUnique({ where: { id }, select: { ownerId: true } })
  if (!room) return NextResponse.json({ error: "room not found" }, { status: 404 })
  const isAdmin = hasRole(user.roles, "admin")
  if (room.ownerId !== user.id && !isAdmin) {
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  }

  const body = await req.json().catch(() => ({}))
  const data: any = {}
  if (typeof body.name === "string" && body.name.trim()) data.name = body.name.trim()
  if (typeof body.description === "string") data.description = body.description || null
  if (["public", "vip"].includes(body.type)) data.type = body.type
  if (typeof body.iconUrl === "string") data.iconUrl = body.iconUrl || null
  if (typeof body.order === "number") data.order = body.order

  const updated = await db.chatRoom.update({ where: { id }, data })
  return NextResponse.json({ room: updated })
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const user = session.user!

  const room = await db.chatRoom.findUnique({ where: { id }, select: { ownerId: true } })
  if (!room) return NextResponse.json({ error: "room not found" }, { status: 404 })
  const isAdmin = hasRole(user.roles, "admin")
  if (room.ownerId !== user.id && !isAdmin) {
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  }

  await db.chatRoom.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
