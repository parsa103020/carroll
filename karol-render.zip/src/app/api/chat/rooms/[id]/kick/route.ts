import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasAnyRole } from "@/lib/auth"
import { audit, getClientInfo } from "@/lib/audit"

export const runtime = "nodejs"

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id: roomId } = await ctx.params
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const actor = session.user!

  const room = await db.chatRoom.findUnique({
    where: { id: roomId },
    select: { id: true, ownerId: true, name: true },
  })
  if (!room) return NextResponse.json({ error: "room not found" }, { status: 404 })

  const isOwner = room.ownerId === actor.id
  const isStaff = hasAnyRole(actor.roles, "admin", "chat_mod")
  if (!isStaff && !isOwner) {
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  }

  const body = await req.json().catch(() => ({}))
  const userId = String(body.userId || "")
  if (!userId) return NextResponse.json({ error: "userId required" }, { status: 400 })
  if (userId === actor.id) {
    return NextResponse.json({ error: "نمی‌توانید خودتان را اخراج کنید" }, { status: 400 })
  }

  const target = await db.user.findUnique({
    where: { id: userId },
    select: { id: true, username: true, roles: true },
  })
  if (!target) return NextResponse.json({ error: "user not found" }, { status: 404 })

  if (hasAnyRole(target.roles, "admin") && !hasAnyRole(actor.roles, "admin")) {
    return NextResponse.json({ error: "نمی‌توانید ادمین را اخراج کنید" }, { status: 403 })
  }

  const reason = typeof body.reason === "string" ? body.reason.slice(0, 500) : null
  let expiresAt: Date | null = null
  if (typeof body.expiresInMinutes === "number" && body.expiresInMinutes > 0) {
    expiresAt = new Date(Date.now() + body.expiresInMinutes * 60_000)
  }

  const membership = await db.chatMember.findUnique({
    where: { roomId_userId: { roomId, userId } },
  })
  if (membership) {
    await db.chatMember.delete({ where: { id: membership.id } })
  }

  const kick = await db.chatKick.create({
    data: {
      roomId,
      userId,
      kickedBy: actor.id,
      reason,
      expiresAt,
    },
  })

  const client = getClientInfo(req)
  await audit(
    {
      actorId: actor.id,
      actorName: actor.username,
      ip: client.ip,
      userAgent: client.userAgent,
    },
    "chat.kick",
    {
      targetType: "user",
      targetId: userId,
      description: `اخراج @${target.username} از روم «${room.name}»${reason ? ` — ${reason}` : ""}`,
      severity: "warning",
      metadata: {
        roomId,
        roomName: room.name,
        kickId: kick.id,
        expiresAt: expiresAt?.toISOString() || null,
      },
    },
  )

  return NextResponse.json({ ok: true, kickId: kick.id })
}
