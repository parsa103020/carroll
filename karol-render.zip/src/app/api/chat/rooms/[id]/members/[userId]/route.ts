import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasAnyRole } from "@/lib/auth"
import { audit, getClientInfo } from "@/lib/audit"

export const runtime = "nodejs"

async function resolveRoomAndPerms(
  req: NextRequest,
  ctx: { params: Promise<{ id: string; userId: string }> },
) {
  const { id: roomId, userId } = await ctx.params
  const session = await getSession()
  if (!session) return { error: NextResponse.json({ error: "unauthorized" }, { status: 401 }) }
  const actor = session.user!

  const room = await db.chatRoom.findUnique({
    where: { id: roomId },
    select: { id: true, ownerId: true, name: true },
  })
  if (!room) return { error: NextResponse.json({ error: "room not found" }, { status: 404 }) }

  const isOwner = room.ownerId === actor.id
  const isStaff = hasAnyRole(actor.roles, "admin", "chat_mod")
  if (!isStaff && !isOwner) {
    return { error: NextResponse.json({ error: "forbidden" }, { status: 403 }) }
  }

  return { roomId, userId, actor, room, client: getClientInfo(req) }
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string; userId: string }> }) {
  const r = await resolveRoomAndPerms(req, ctx)
  if ("error" in r) return r.error
  const { roomId, userId, actor, room, client } = r

  const body = await req.json().catch(() => ({}))

  const membership = await db.chatMember.findUnique({
    where: { roomId_userId: { roomId, userId } },
    include: { user: { select: { id: true, username: true, roles: true } } },
  })
  if (!membership) {
    return NextResponse.json({ error: "member not found" }, { status: 404 })
  }
  if (
    hasAnyRole(membership.user.roles, "admin") &&
    !hasAnyRole(actor.roles, "admin")
  ) {
    return NextResponse.json({ error: "نمی‌توانید ادمین را میوت کنید" }, { status: 403 })
  }

  const updates: { muted?: boolean; role?: string } = {}
  if (typeof body.muted === "boolean") updates.muted = body.muted
  if (typeof body.role === "string") {
    const role = body.role.trim().slice(0, 32)
    if (!["member", "mod"].includes(role)) {
      return NextResponse.json({ error: "نقش نامعتبر" }, { status: 400 })
    }
    updates.role = role
  }

  if (Object.keys(updates).length === 0) {
    return NextResponse.json({ error: "چیزی برای به‌روزرسانی نیست" }, { status: 400 })
  }

  const updated = await db.chatMember.update({
    where: { id: membership.id },
    data: updates,
  })

  if (typeof updates.muted === "boolean") {
    await audit(
      {
        actorId: actor.id,
        actorName: actor.username,
        ip: client.ip,
        userAgent: client.userAgent,
      },
      updates.muted ? "chat.mute" : "chat.unmute",
      {
        targetType: "user",
        targetId: userId,
        description: `${updates.muted ? "بی‌صدا کردن" : "رفع بی‌صدایی"} @${membership.user.username} در روم «${room.name}»`,
        severity: updates.muted ? "warning" : "info",
        metadata: { roomId, roomName: room.name },
      },
    )
  }
  if (typeof updates.role === "string") {
    await audit(
      {
        actorId: actor.id,
        actorName: actor.username,
        ip: client.ip,
        userAgent: client.userAgent,
      },
      "chat.member.role",
      {
        targetType: "user",
        targetId: userId,
        description: `تغییر نقش @${membership.user.username} در روم «${room.name}» به ${updates.role}`,
        severity: "info",
        metadata: { roomId, roomName: room.name, role: updates.role },
      },
    )
  }

  return NextResponse.json({
    ok: true,
    member: {
      id: updated.id,
      role: updated.role,
      muted: updated.muted,
      joinedAt: updated.joinedAt,
      userId,
    },
  })
}
