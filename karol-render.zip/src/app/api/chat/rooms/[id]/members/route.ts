import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole, hasAnyRole } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })

  const members = await db.chatMember.findMany({
    where: { roomId: id },
    orderBy: { joinedAt: "asc" },
    take: 200,
    include: {
      user: {
        select: { id: true, username: true, displayName: true, avatarUrl: true, isVip: true, roles: true },
      },
    },
  })

  const list = members.map((m) => ({
    id: m.id,
    role: m.role,
    muted: m.muted,
    joinedAt: m.joinedAt,
    user: {
      id: m.user.id,
      username: m.user.username,
      displayName: m.user.displayName,
      avatarUrl: m.user.avatarUrl,
      isVip: m.user.isVip,
      isAdmin: hasRole(m.user.roles, "admin"),
    },
  }))

  return NextResponse.json({ members: list })
}

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const user = session.user!

  await db.chatMember.upsert({
    where: { roomId_userId: { roomId: id, userId: user.id } },
    update: {},
    create: { roomId: id, userId: user.id, role: "member" },
  })

  return NextResponse.json({ ok: true })
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  if (!hasAnyRole(session.user!.roles, "admin", "chat_mod"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const body = await req.json().catch(() => ({}))
  const userId = String(body.userId || "")
  if (!userId) return NextResponse.json({ error: "userId required" }, { status: 400 })

  const data: any = {}
  if (typeof body.muted === "boolean") data.muted = body.muted
  if (typeof body.role === "string") data.role = body.role

  await db.chatMember.update({
    where: { roomId_userId: { roomId: id, userId } },
    data,
  })
  return NextResponse.json({ ok: true })
}
