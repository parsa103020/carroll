import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const user = session.user!
  const isAdmin = hasRole(user.roles, "admin")

  const rooms = await db.chatRoom.findMany({
    orderBy: [{ order: "asc" }, { createdAt: "asc" }],
    include: {
      _count: { select: { members: true } },
      members: { where: { userId: user.id }, select: { id: true, role: true } },
    },
  })

  const list = rooms.map((r) => ({
    id: r.id,
    name: r.name,
    description: r.description,
    type: r.type,
    roomKind: r.roomKind,
    iconUrl: r.iconUrl,
    ownerId: r.ownerId,
    order: r.order,
    memberCount: r._count.members,
    isMember: r.members.length > 0,
    memberRole: r.members[0]?.role || null,
    isOwner: r.ownerId === user.id,
    accessible: r.type === "public" || user.isVip || isAdmin,
  }))

  return NextResponse.json({ rooms: list })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const user = session.user!
  const isAdmin = hasRole(user.roles, "admin")

  const body = await req.json().catch(() => ({}))
  const name = String(body.name || "").trim()
  const description = body.description ? String(body.description).trim() : null
  const type = ["public", "vip"].includes(body.type) ? body.type : "public"
  const roomKind = ["room", "channel", "group"].includes(body.roomKind) ? body.roomKind : "room"
  const iconUrl = body.iconUrl ? String(body.iconUrl) : null
  if (!name) return NextResponse.json({ error: "نام الزامی است" }, { status: 400 })

  if (roomKind === "room" && !isAdmin) {
    return NextResponse.json({ error: "ساخت روم عمومی فقط برای مدیران ممکن است" }, { status: 403 })
  }
  if (type === "vip" && !isAdmin) {
    return NextResponse.json({ error: "ساخت روم VIP فقط برای مدیران ممکن است" }, { status: 403 })
  }

  const last = await db.chatRoom.findFirst({ orderBy: { order: "desc" }, select: { order: true } })
  const order = last ? last.order + 1 : 0

  const room = await db.chatRoom.create({
    data: {
      name,
      description,
      type,
      roomKind,
      iconUrl,
      ownerId: user.id,
      order,
    },
  })

  await db.chatMember.create({
    data: {
      roomId: room.id,
      userId: user.id,
      role: roomKind === "channel" ? "owner" : "owner",
    },
  })

  return NextResponse.json({
    room: {
      id: room.id,
      name: room.name,
      description: room.description,
      type: room.type,
      roomKind: room.roomKind,
      iconUrl: room.iconUrl,
      ownerId: room.ownerId,
      order: room.order,
      memberCount: 1,
      isMember: true,
      memberRole: "owner",
      isOwner: true,
      accessible: true,
    },
  })
}
