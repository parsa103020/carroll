import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasAnyRole } from "@/lib/auth"
import { deleteObject, objectPathFromUrl } from "@/lib/storage"

export const runtime = "nodejs"

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const user = session.user!

  const sticker = await db.sticker.findUnique({
    where: { id },
    include: { pack: { select: { ownerId: true, isOfficial: true } } },
  })
  if (!sticker) return NextResponse.json({ error: "sticker not found" }, { status: 404 })

  const isOwner = sticker.pack.ownerId === user.id
  const isAdmin = hasAnyRole(user.roles, "admin", "chat_mod")
  if (!isOwner && !isAdmin) {
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  }

  await db.sticker.delete({ where: { id } })

  if (!sticker.pack.isOfficial) {
    const key = objectPathFromUrl(sticker.url)
    if (key) await deleteObject(key).catch(() => {})
  }

  return NextResponse.json({ ok: true })
}
