import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

function mapSticker(s: any) {
  return {
    id: s.id,
    url: s.url,
    name: s.name,
    kind: s.kind,
    category: s.category,
    usageCount: s.usageCount,
    packId: s.packId,
    isOfficial: s.pack?.isOfficial ?? false,
  }
}

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const user = session.user!

  const url = new URL(req.url)
  const q = url.searchParams.get("q")?.trim() || ""
  const kind = url.searchParams.get("kind")
  const popular = url.searchParams.get("popular") === "true"

  const validKinds = ["sticker", "gif"]
  const kindFilter = kind && validKinds.includes(kind) ? kind : undefined

  if (popular) {
    const stickers = await db.sticker.findMany({
      where: {
        ...(kindFilter ? { kind: kindFilter } : {}),
        ...(q ? { name: { contains: q } } : {}),
      },
      orderBy: { usageCount: "desc" },
      take: 20,
      include: { pack: { select: { isOfficial: true, name: true } } },
    })
    return NextResponse.json({
      packs: [],
      stickers: stickers.map(mapSticker),
    })
  }

  const packs = await db.stickerPack.findMany({
    where: {
      OR: [{ isOfficial: true }, { ownerId: user.id }],
    },
    orderBy: [{ isOfficial: "desc" }, { createdAt: "asc" }],
    include: {
      stickers: {
        where: {
          AND: [
            kindFilter ? { kind: kindFilter } : {},
            q ? { name: { contains: q } } : {},
          ],
        },
        orderBy: [{ usageCount: "desc" }, { createdAt: "asc" }],
      },
    },
  })

  return NextResponse.json({
    packs: packs.map((p) => ({
      id: p.id,
      name: p.name,
      coverUrl: p.coverUrl,
      isOfficial: p.isOfficial,
      stickers: p.stickers.map((s) => ({
        id: s.id,
        url: s.url,
        name: s.name,
        kind: s.kind,
        category: s.category,
        usageCount: s.usageCount,
        packId: s.packId,
        isOfficial: p.isOfficial,
      })),
    })),
    stickers: [],
  })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const user = session.user!

  const body = await req.json().catch(() => ({}))
  const url = String(body.url || "").trim()
  const name = body.name ? String(body.name).trim() : null
  const kind = ["sticker", "gif"].includes(body.kind) ? body.kind : "sticker"
  const category = body.category ? String(body.category).trim() : null
  const packId = body.packId ? String(body.packId) : null
  const packName = body.packName ? String(body.packName).trim() : "استیکرهای من"

  if (!url) return NextResponse.json({ error: "url required" }, { status: 400 })

  let pid = packId
  if (!pid) {
    const existing = await db.stickerPack.findFirst({
      where: { ownerId: user.id, name: packName, isOfficial: false },
      select: { id: true },
    })
    if (existing) {
      pid = existing.id
    } else {
      const pack = await db.stickerPack.create({
        data: { name: packName, ownerId: user.id, isOfficial: false },
      })
      pid = pack.id
    }
  } else {
    const exists = await db.stickerPack.findUnique({ where: { id: pid } })
    if (!exists || exists.ownerId !== user.id || exists.isOfficial)
      return NextResponse.json({ error: "pack not found" }, { status: 404 })
  }

  const sticker = await db.sticker.create({
    data: { packId: pid, url, name, kind, category },
  })

  return NextResponse.json({ sticker: mapSticker({ ...sticker, pack: { isOfficial: false } }) })
}
