import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { hashPassword, verifyPassword, createSession, setSessionCookie, getSession, destroySession, hasRole } from "@/lib/auth"
import { CONFIG } from "@/lib/config"
import { getSetting, asBool } from "@/lib/settings"
import { audit, getClientInfo } from "@/lib/audit"

export const runtime = "nodejs"

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ user: null })
  const u = session.user!
  return NextResponse.json({
    user: {
      id: u.id,
      username: u.username,
      displayName: u.displayName,
      avatarUrl: u.avatarUrl,
      animatedAvatarUrl: u.animatedAvatarUrl,
      profileEffect: u.profileEffect,
      nameColor: u.nameColor,
      bio: u.bio,
      coins: u.coins,
      isVip: u.isVip,
      vipExpiresAt: u.vipExpiresAt,
      roles: u.roles.split(","),
      dailyUploadLimitBytes: u.dailyUploadLimitBytes.toString(),
      usedUploadBytesToday: u.usedUploadBytesToday.toString(),
      banned: u.banned,
      createdAt: u.createdAt,
    },
  })
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}))
  const action = body.action || "login"

  if (action === "register") {
    const signupOpen = asBool(await getSetting("general.signupOpen"))
    if (!signupOpen) return NextResponse.json({ error: "ثبت‌نام موقتاً بسته است" }, { status: 403 })
    const username = String(body.username || "").trim().toLowerCase()
    const password = String(body.password || "")
    if (username.length < CONFIG.auth.minUsernameLength || username.length > CONFIG.auth.maxUsernameLength)
      return NextResponse.json({ error: `نام کاربری باید ${CONFIG.auth.minUsernameLength} تا ${CONFIG.auth.maxUsernameLength} نویسه باشد` }, { status: 400 })
    if (!/^[a-z0-9_.-]+$/.test(username))
      return NextResponse.json({ error: "نام کاربری فقط می‌تواند شامل حروف انگلیسی، عدد، نقطه، خط‌تیره و زیرخط باشد" }, { status: 400 })
    if (password.length < CONFIG.auth.minPasswordLength)
      return NextResponse.json({ error: `رمز عبور حداقل ${CONFIG.auth.minPasswordLength} نویسه باشد` }, { status: 400 })
    const exists = await db.user.findUnique({ where: { username } })
    if (exists) return NextResponse.json({ error: "این نام کاربری قبلاً گرفته شده" }, { status: 409 })
    const hash = await hashPassword(password)
    const user = await db.user.create({
      data: { username, passwordHash: hash, displayName: username },
    })
    const { token, expiresAt } = await createSession(user.id, user.username, user.roles)
    const res = NextResponse.json({ ok: true })
    res.cookies.set(setSessionCookie(token, expiresAt))
    return res
  }

  if (action === "login") {
    const username = String(body.username || "").trim().toLowerCase()
    const password = String(body.password || "")
    const user = await db.user.findUnique({ where: { username } })
    if (!user) return NextResponse.json({ error: "نام کاربری یا رمز عبور نادرست است" }, { status: 401 })
    if (user.banned) return NextResponse.json({ error: "حساب شما مسدود شده است" }, { status: 403 })
    const ok = await verifyPassword(password, user.passwordHash)
    if (!ok) return NextResponse.json({ error: "نام کاربری یا رمز عبور نادرست است" }, { status: 401 })
    await db.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } })
    const { token, expiresAt } = await createSession(user.id, user.username, user.roles)
    if (hasRole(user.roles, "admin")) {
      const info = getClientInfo(req)
      audit(
        { actorId: user.id, actorName: user.username, ip: info.ip, userAgent: info.userAgent },
        "auth.admin_login",
        {
          targetType: "user",
          targetId: user.id,
          description: `ورود ادمین @${user.username} به پنل مدیریت`,
          severity: "info",
          metadata: { username: user.username, ip: info.ip, userAgent: info.userAgent },
        },
      )
    }
    const res = NextResponse.json({ ok: true })
    res.cookies.set(setSessionCookie(token, expiresAt))
    return res
  }

  if (action === "logout") {
    await destroySession()
    const res = NextResponse.json({ ok: true })
    res.cookies.delete(CONFIG.auth.cookieName)
    return res
  }

  return NextResponse.json({ error: "invalid action" }, { status: 400 })
}
