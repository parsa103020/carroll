import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const messages = await db.watchMessage.findMany({
    where: { roomId: id },
    orderBy: { createdAt: "asc" },
    take: 200,
    select: {
      id: true,
      userId: true,
      username: true,
      content: true,
      createdAt: true,
    },
  })
  return NextResponse.json({ messages })
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const user = session.user!
  const { id } = await params
  const room = await db.watchRoom.findUnique({ where: { id: id } })
  if (!room) return NextResponse.json({ error: "not found" }, { status: 404 })
  const body = await req.json().catch(() => ({}))
  const content = String(body.content || "").trim()
  if (!content) return NextResponse.json({ error: "پیام خالی است" }, { status: 400 })
  if (content.length > 500) return NextResponse.json({ error: "پیام طولانی است" }, { status: 400 })

  const msg = await db.watchMessage.create({
    data: {
      roomId: id,
      userId: user.id,
      username: user.displayName || user.username,
      content,
    },
  })

  return NextResponse.json({
    message: {
      id: msg.id,
      userId: msg.userId,
      username: msg.username,
      content: msg.content,
      createdAt: msg.createdAt,
    },
  })
}
