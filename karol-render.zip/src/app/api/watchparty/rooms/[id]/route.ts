import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const room = await db.watchRoom.findUnique({
    where: { id },
    include: {
      owner: { select: { id: true, username: true, displayName: true, avatarUrl: true } },
    },
  })
  if (!room) return NextResponse.json({ error: "not found" }, { status: 404 })

  const messages = await db.watchMessage.findMany({
    where: { roomId: id },
    orderBy: { createdAt: "asc" },
    take: 100,
    select: {
      id: true,
      userId: true,
      username: true,
      content: true,
      createdAt: true,
    },
  })

  return NextResponse.json({
    room: {
      id: room.id,
      name: room.name,
      ownerId: room.ownerId,
      ownerName: room.owner?.displayName || room.owner?.username || "کاربر",
      ownerAvatar: room.owner?.avatarUrl || null,
      videoUrl: room.videoUrl,
      videoTitle: room.videoTitle,
      videoType: room.videoType,
      isPlaying: room.isPlaying,
      currentTime: room.currentTime,
      lastSyncAt: room.lastSyncAt,
      hostControlOnly: room.hostControlOnly,
      createdAt: room.createdAt,
      isOwner: room.ownerId === session.user!.id,
      canManage: room.ownerId === session.user!.id || hasRole(session.user!.roles, "admin"),
    },
    messages,
  })
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const room = await db.watchRoom.findUnique({ where: { id } })
  if (!room) return NextResponse.json({ error: "not found" }, { status: 404 })
  if (room.ownerId !== session.user!.id && !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })

  const body = await req.json().catch(() => ({}))
  const data: Record<string, unknown> = {}

  if (typeof body.hostControlOnly === "boolean") {
    data.hostControlOnly = body.hostControlOnly
  }
  if (typeof body.name === "string") {
    const v = body.name.trim().slice(0, 60)
    if (v) data.name = v
  }
  if (typeof body.videoTitle === "string") {
    data.videoTitle = body.videoTitle.trim().slice(0, 200) || null
  }

  if (Object.keys(data).length === 0) {
    return NextResponse.json({ error: "چیزی برای به‌روزرسانی نیست" }, { status: 400 })
  }

  const updated = await db.watchRoom.update({
    where: { id },
    data,
  })

  return NextResponse.json({
    room: {
      id: updated.id,
      name: updated.name,
      ownerId: updated.ownerId,
      videoUrl: updated.videoUrl,
      videoTitle: updated.videoTitle,
      videoType: updated.videoType,
      isPlaying: updated.isPlaying,
      currentTime: updated.currentTime,
      lastSyncAt: updated.lastSyncAt,
      hostControlOnly: updated.hostControlOnly,
      createdAt: updated.createdAt,
      isOwner: updated.ownerId === session.user!.id,
      canManage: updated.ownerId === session.user!.id || hasRole(session.user!.roles, "admin"),
    },
  })
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const room = await db.watchRoom.findUnique({ where: { id } })
  if (!room) return NextResponse.json({ error: "not found" }, { status: 404 })
  if (room.ownerId !== session.user!.id && !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  await db.watchRoom.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
