import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const user = session.user!

  const rooms = await db.watchRoom.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      owner: { select: { id: true, username: true, displayName: true, avatarUrl: true } },
      _count: { select: { messages: true } },
    },
    take: 60,
  })

  const list = rooms.map((r) => ({
    id: r.id,
    name: r.name,
    ownerId: r.ownerId,
    ownerName: r.owner?.displayName || r.owner?.username || "کاربر",
    ownerAvatar: r.owner?.avatarUrl || null,
    videoUrl: r.videoUrl,
    videoTitle: r.videoTitle,
    videoType: r.videoType,
    isPlaying: r.isPlaying,
    currentTime: r.currentTime,
    hostControlOnly: r.hostControlOnly,
    createdAt: r.createdAt,
    messageCount: r._count.messages,
    isOwner: r.ownerId === user.id,
    canManage: r.ownerId === user.id || hasRole(user.roles, "admin"),
  }))

  return NextResponse.json({ rooms: list })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const user = session.user!
  const body = await req.json().catch(() => ({}))
  const name = String(body.name || "").trim()
  const videoUrl = String(body.videoUrl || "").trim()
  const videoTitle = body.videoTitle ? String(body.videoTitle).trim().slice(0, 200) : null

  if (!name) return NextResponse.json({ error: "نام اتاق الزامی است" }, { status: 400 })
  if (!videoUrl) return NextResponse.json({ error: "آدرس ویدیو الزامی است" }, { status: 400 })

  try {
    const u = new URL(videoUrl)
    if (!/^https?:$/.test(u.protocol)) throw new Error("bad protocol")
  } catch {
    return NextResponse.json({ error: "آدرس ویدیو معتبر نیست" }, { status: 400 })
  }

  const ext = videoUrl.split("?")[0].split("#")[0].split(".").pop()?.toLowerCase() || "mp4"
  const knownTypes = ["mp4", "webm", "m3u8", "ogv", "ogg", "mov", "mkv"]
  const videoType = knownTypes.includes(ext) ? ext : "mp4"

  const hostControlOnly = body.hostControlOnly === false ? false : true

  const room = await db.watchRoom.create({
    data: {
      name,
      ownerId: user.id,
      videoUrl,
      videoTitle,
      videoType,
      isPlaying: false,
      currentTime: 0,
      hostControlOnly,
    },
  })

  return NextResponse.json({ room })
}
