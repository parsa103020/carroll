import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

const VALID_CATEGORIES = [
  "entertainment",
  "education",
  "music",
  "sports",
  "technology",
  "news",
  "other",
  "general",
]

const OWNER_SELECT = {
  id: true,
  username: true,
  displayName: true,
  avatarUrl: true,
  isVip: true,
} as const

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const url = new URL(req.url)
  const category = url.searchParams.get("category") || "all"
  const q = url.searchParams.get("q")?.trim() || ""
  const cursor = url.searchParams.get("cursor")
  const excludeId = url.searchParams.get("exclude")
  const limit = Math.min(40, Math.max(1, Number(url.searchParams.get("limit")) || 20))
  const take = limit

  const where: any = {}
  if (category && category !== "all" && VALID_CATEGORIES.includes(category)) {
    where.category = category
  }
  if (excludeId) {
    where.id = { not: excludeId }
  }
  if (q) {
    where.OR = [
      { title: { contains: q } },
      { description: { contains: q } },
      { owner: { username: { contains: q } } },
      { owner: { displayName: { contains: q } } },
    ]
  }

  const videos = await db.video.findMany({
    where,
    orderBy: { createdAt: "desc" },
    take: take + 1,
    ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
    include: {
      owner: { select: OWNER_SELECT },
      likes: { where: { userId: session.user!.id }, select: { id: true } },
      _count: { select: { likes: true, comments: true } },
    },
  })
  const hasNext = videos.length > take
  const list = videos.slice(0, take).map((v) => ({
    id: v.id,
    title: v.title,
    description: v.description,
    videoUrl: v.videoUrl,
    thumbnailUrl: v.thumbnailUrl,
    category: v.category,
    duration: v.duration,
    views: v.views,
    createdAt: v.createdAt,
    likes: v._count.likes,
    comments: v._count.comments,
    liked: v.likes.length > 0,
    owner: v.owner,
  }))
  return NextResponse.json({
    videos: list,
    nextCursor: hasNext ? list[list.length - 1]?.id ?? null : null,
  })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const body = await req.json().catch(() => ({}))
  const title = String(body.title || "").trim()
  const videoUrl = String(body.videoUrl || "").trim()
  const thumbnailUrl = body.thumbnailUrl ? String(body.thumbnailUrl).trim() : null
  const description = body.description ? String(body.description).trim() : null
  const category = VALID_CATEGORIES.includes(body.category) ? body.category : "general"
  const duration = Number.isFinite(Number(body.duration))
    ? Math.max(0, Math.floor(Number(body.duration)))
    : 0

  if (!title) return NextResponse.json({ error: "عنوان الزامی است" }, { status: 400 })
  if (title.length > 200) return NextResponse.json({ error: "عنوان خیلی طولانی است" }, { status: 400 })
  if (!videoUrl) return NextResponse.json({ error: "ویدیو الزامی است" }, { status: 400 })
  if (description && description.length > 5000)
    return NextResponse.json({ error: "توضیحات خیلی طولانی است" }, { status: 400 })

  const video = await db.video.create({
    data: {
      ownerId: session.user!.id,
      title,
      description,
      videoUrl,
      thumbnailUrl,
      category,
      duration,
    },
    include: {
      owner: { select: OWNER_SELECT },
      _count: { select: { likes: true, comments: true } },
    },
  })

  return NextResponse.json({
    video: {
      id: video.id,
      title: video.title,
      description: video.description,
      videoUrl: video.videoUrl,
      thumbnailUrl: video.thumbnailUrl,
      category: video.category,
      duration: video.duration,
      views: video.views,
      createdAt: video.createdAt,
      likes: video._count.likes,
      comments: video._count.comments,
      liked: false,
      owner: video.owner,
    },
  })
}
