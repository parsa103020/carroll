import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const updated = await db.video
    .update({
      where: { id },
      data: { views: { increment: 1 } },
      select: { views: true },
    })
    .catch(() => null)
  if (!updated) return NextResponse.json({ error: "not found" }, { status: 404 })
  return NextResponse.json({ views: updated.views })
}
