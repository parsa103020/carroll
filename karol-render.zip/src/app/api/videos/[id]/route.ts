import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

const OWNER_SELECT = {
  id: true,
  username: true,
  displayName: true,
  avatarUrl: true,
  isVip: true,
} as const

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const video = await db.video.findUnique({
    where: { id },
    include: {
      owner: { select: OWNER_SELECT },
      likes: { where: { userId: session.user!.id }, select: { id: true } },
      _count: { select: { likes: true, comments: true } },
    },
  })
  if (!video) return NextResponse.json({ error: "not found" }, { status: 404 })
  return NextResponse.json({
    video: {
      id: video.id,
      title: video.title,
      description: video.description,
      videoUrl: video.videoUrl,
      thumbnailUrl: video.thumbnailUrl,
      category: video.category,
      duration: video.duration,
      views: video.views,
      createdAt: video.createdAt,
      likes: video._count.likes,
      comments: video._count.comments,
      liked: video.likes.length > 0,
      owner: video.owner,
    },
  })
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const video = await db.video.findUnique({ where: { id }, select: { ownerId: true } })
  if (!video) return NextResponse.json({ error: "not found" }, { status: 404 })
  if (video.ownerId !== session.user!.id && !hasRole(session.user!.roles, "admin"))
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  await db.video.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
