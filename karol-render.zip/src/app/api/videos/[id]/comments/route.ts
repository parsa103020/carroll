import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

const USER_SELECT = {
  id: true,
  username: true,
  displayName: true,
  avatarUrl: true,
  isVip: true,
} as const

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const url = new URL(req.url)
  const cursor = url.searchParams.get("cursor")
  const take = 20

  const comments = await db.videoComment.findMany({
    where: { videoId: id },
    orderBy: { createdAt: "desc" },
    take: take + 1,
    ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
    include: { user: { select: USER_SELECT } },
  })
  const hasNext = comments.length > take
  const list = comments.slice(0, take).map((c) => ({
    id: c.id,
    content: c.content,
    createdAt: c.createdAt,
    user: c.user,
  }))
  return NextResponse.json({
    comments: list,
    nextCursor: hasNext ? list[list.length - 1]?.id ?? null : null,
  })
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const body = await req.json().catch(() => ({}))
  const content = String(body.content || "").trim()
  if (!content) return NextResponse.json({ error: "کامنت خالی است" }, { status: 400 })
  if (content.length > 2000)
    return NextResponse.json({ error: "کامنت خیلی طولانی است" }, { status: 400 })

  const video = await db.video.findUnique({ where: { id }, select: { id: true } })
  if (!video) return NextResponse.json({ error: "not found" }, { status: 404 })

  const comment = await db.videoComment.create({
    data: { videoId: id, userId: session.user!.id, content },
    include: { user: { select: USER_SELECT } },
  })
  return NextResponse.json({
    comment: {
      id: comment.id,
      content: comment.content,
      createdAt: comment.createdAt,
      user: comment.user,
    },
  })
}
