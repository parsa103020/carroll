import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const exists = await db.video.findUnique({ where: { id }, select: { id: true } })
  if (!exists) return NextResponse.json({ error: "not found" }, { status: 404 })

  const existing = await db.videoLike.findUnique({
    where: { videoId_userId: { videoId: id, userId: session.user!.id } },
  })
  if (existing) {
    await db.videoLike.delete({ where: { id: existing.id } })
    const likes = await db.videoLike.count({ where: { videoId: id } })
    return NextResponse.json({ liked: false, likes })
  }
  await db.videoLike.create({ data: { videoId: id, userId: session.user!.id } })
  const likes = await db.videoLike.count({ where: { videoId: id } })
  return NextResponse.json({ liked: true, likes })
}
