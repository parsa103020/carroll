import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { getSetting, asBool } from "@/lib/settings"

export const runtime = "nodejs"

const CACHE_TTL = 5 * 60 * 1000
const cache = new Map<string, { ts: number; data: { tracks: ExternalTrackT[] } }>()

interface ExternalTrackT {
  id: string
  source: "external"
  externalId: string
  title: string
  artist: string
  album: string | null
  coverUrl: string | null
  audioUrl: string
  duration: number
  genre: string | null
  plays: number
}

interface ITunesResult {
  trackId?: number
  trackName?: string
  artistName?: string
  collectionName?: string
  artworkUrl100?: string
  previewUrl?: string
  trackTimeMillis?: number
  primaryGenreName?: string
}

function mapResult(r: ITunesResult): ExternalTrackT | null {
  if (!r.previewUrl || !r.trackId || !r.trackName || !r.artistName) return null
  const cover = r.artworkUrl100
    ? r.artworkUrl100
        .replace("100x100bb", "600x600bb")
        .replace("100x100", "600x600")
    : null
  return {
    id: `ext-${r.trackId}`,
    source: "external",
    externalId: String(r.trackId),
    title: r.trackName,
    artist: r.artistName,
    album: r.collectionName || null,
    coverUrl: cover,
    audioUrl: r.previewUrl,
    duration: r.trackTimeMillis ? Math.round(r.trackTimeMillis / 1000) : 0,
    genre: r.primaryGenreName || null,
    plays: 0,
  }
}

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })

  const enabled = asBool(await getSetting("music.externalEnabled"))
  if (!enabled) return NextResponse.json({ tracks: [] })

  const url = new URL(req.url)
  const q = (url.searchParams.get("q") || "").trim()
  const limit = Math.min(
    50,
    Math.max(1, parseInt(url.searchParams.get("limit") || "50", 10) || 50),
  )

  if (!q) return NextResponse.json({ tracks: [] })

  const cacheKey = `${q.toLowerCase()}|${limit}`
  const cached = cache.get(cacheKey)
  if (cached && Date.now() - cached.ts < CACHE_TTL) {
    return NextResponse.json(cached.data)
  }

  try {
    const apiUrl = `https://itunes.apple.com/search?term=${encodeURIComponent(q)}&media=music&limit=${limit}&country=US`
    const ctrl = new AbortController()
    const timer = setTimeout(() => ctrl.abort(), 8000)
    const r = await fetch(apiUrl, {
      signal: ctrl.signal,
      headers: { Accept: "application/json", "User-Agent": "Karol/1.0" },
    })
    clearTimeout(timer)
    if (!r.ok) {
      return NextResponse.json({
        tracks: [],
        error: "جستجوی خارجی موقتاً در دسترس نیست",
      })
    }
    const json = (await r.json()) as { results?: ITunesResult[] }
    const tracks = (json.results || [])
      .map(mapResult)
      .filter((t): t is ExternalTrackT => t !== null)
    const data = { tracks }
    cache.set(cacheKey, { ts: Date.now(), data })
    if (cache.size > 200) {
      const oldest = [...cache.entries()].sort((a, b) => a[1].ts - b[1].ts)[0]?.[0]
      if (oldest) cache.delete(oldest)
    }
    return NextResponse.json(data)
  } catch {
    return NextResponse.json({
      tracks: [],
      error: "جستجوی خارجی موقتاً در دسترس نیست",
    })
  }
}
