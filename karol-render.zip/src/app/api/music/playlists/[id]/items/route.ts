import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

async function getOwned(id: string, userId: string) {
  const pl = await db.playlist.findUnique({ where: { id } })
  if (!pl || pl.ownerId !== userId) return null
  return pl
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const pl = await getOwned(id, session.user!.id)
  if (!pl) return NextResponse.json({ error: "پلی‌لیست یافت نشد" }, { status: 404 })
  const body = await req.json().catch(() => ({}))
  const trackId = String(body.trackId || "")
  if (!trackId) return NextResponse.json({ error: "آهنگ مشخص نیست" }, { status: 400 })
  const track = await db.musicTrack.findUnique({ where: { id: trackId } })
  if (!track) return NextResponse.json({ error: "آهنگ یافت نشد" }, { status: 404 })
  const last = await db.playlistItem.findFirst({
    where: { playlistId: id },
    orderBy: { order: "desc" },
    select: { order: true },
  })
  const order = (last?.order || 0) + 1
  const existing = await db.playlistItem.findFirst({ where: { playlistId: id, trackId } })
  if (existing) return NextResponse.json({ ok: true, duplicate: true, itemId: existing.id })
  const item = await db.playlistItem.create({ data: { playlistId: id, trackId, order } })
  return NextResponse.json({ ok: true, itemId: item.id })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const pl = await getOwned(id, session.user!.id)
  if (!pl) return NextResponse.json({ error: "پلی‌لیست یافت نشد" }, { status: 404 })
  const url = new URL(req.url)
  const itemId = url.searchParams.get("itemId")
  const trackId = url.searchParams.get("trackId")
  if (itemId) {
    await db.playlistItem.deleteMany({ where: { id: itemId, playlistId: id } })
  } else if (trackId) {
    await db.playlistItem.deleteMany({ where: { trackId, playlistId: id } })
  } else {
    return NextResponse.json({ error: "itemId یا trackId لازم است" }, { status: 400 })
  }
  return NextResponse.json({ ok: true })
}
