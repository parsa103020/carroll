import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

async function getOwned(id: string, userId: string) {
  const pl = await db.playlist.findUnique({ where: { id } })
  if (!pl) return null
  if (pl.ownerId !== userId) return null
  return pl
}

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const pl = await db.playlist.findUnique({
    where: { id },
    include: {
      items: {
        orderBy: { order: "asc" },
        include: {
          track: true,
        },
      },
    },
  })
  if (!pl) return NextResponse.json({ error: "not found" }, { status: 404 })
  return NextResponse.json({
    playlist: {
      id: pl.id,
      name: pl.name,
      createdAt: pl.createdAt,
      tracks: pl.items.map((it) => ({
        itemId: it.id,
        order: it.order,
        id: it.track.id,
        title: it.track.title,
        artist: it.track.artist,
        album: it.track.album,
        coverUrl: it.track.coverUrl,
        audioUrl: it.track.audioUrl,
        duration: it.track.duration,
        plays: it.track.plays,
      })),
    },
  })
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const pl = await getOwned(id, session.user!.id)
  if (!pl) return NextResponse.json({ error: "پلی‌لیست یافت نشد" }, { status: 404 })
  const body = await req.json().catch(() => ({}))
  const name = String(body.name || "").trim()
  if (!name) return NextResponse.json({ error: "نام الزامی است" }, { status: 400 })
  const updated = await db.playlist.update({ where: { id }, data: { name } })
  return NextResponse.json({ playlist: { id: updated.id, name: updated.name } })
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const pl = await getOwned(id, session.user!.id)
  if (!pl) return NextResponse.json({ error: "پلی‌لیست یافت نشد" }, { status: 404 })
  await db.playlist.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
