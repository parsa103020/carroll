import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const playlists = await db.playlist.findMany({
    where: { ownerId: session.user!.id },
    orderBy: { createdAt: "desc" },
    include: { _count: { select: { items: true } } },
  })
  return NextResponse.json({
    playlists: playlists.map((p) => ({
      id: p.id,
      name: p.name,
      count: p._count.items,
      createdAt: p.createdAt,
    })),
  })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const body = await req.json().catch(() => ({}))
  const name = String(body.name || "").trim()
  if (!name) return NextResponse.json({ error: "نام پلی‌لیست الزامی است" }, { status: 400 })
  if (name.length > 80) return NextResponse.json({ error: "نام خیلی طولانی است" }, { status: 400 })
  const playlist = await db.playlist.create({
    data: { ownerId: session.user!.id, name },
  })
  return NextResponse.json({ playlist: { id: playlist.id, name: playlist.name, count: 0, createdAt: playlist.createdAt } })
}
