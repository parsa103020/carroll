import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const t = await db.musicTrack.findUnique({ where: { id } })
  if (!t) return NextResponse.json({ error: "not found" }, { status: 404 })
  return NextResponse.json({ track: t })
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  // MusicTrack has no ownerId; admin can delete any, others cannot
  if (!hasRole(session.user!.roles, "admin")) {
    return NextResponse.json({ error: "فقط مدیر می‌تواند آهنگ را حذف کند" }, { status: 403 })
  }
  await db.musicTrack.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
