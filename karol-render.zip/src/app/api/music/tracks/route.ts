import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"
import { getSetting, asBool } from "@/lib/settings"

export const runtime = "nodejs"

const PAGE = 40

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const url = new URL(req.url)
  const q = (url.searchParams.get("q") || "").trim()
  const cursor = url.searchParams.get("cursor")
  const sort = url.searchParams.get("sort") === "newest" ? "createdAt" : "popular"
  const onlyMine = url.searchParams.get("mine") === "1"

  const where: any = {}
  if (q) {
    where.OR = [
      { title: { contains: q } },
      { artist: { contains: q } },
      { album: { contains: q } },
    ]
  }
  if (onlyMine) {
    // local tracks created by this user — we don't have ownerId on MusicTrack, so skip
  }

  const rows = await db.musicTrack.findMany({
    where,
    orderBy: sort === "popular" ? { plays: "desc" } : { createdAt: "desc" },
    take: PAGE + 1,
    ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
  })

  const hasNext = rows.length > PAGE
  const list = rows.slice(0, PAGE).map((t) => ({
    id: t.id,
    title: t.title,
    artist: t.artist,
    album: t.album,
    coverUrl: t.coverUrl,
    audioUrl: t.audioUrl,
    duration: t.duration,
    source: t.source,
    plays: t.plays,
    createdAt: t.createdAt,
  }))

  let popular: any[] = []
  if (!q && !cursor) {
    popular = (await db.musicTrack.findMany({
      orderBy: { plays: "desc" },
      take: 12,
      where: { audioUrl: { not: null } },
    })).map((t) => ({
      id: t.id,
      title: t.title,
      artist: t.artist,
      album: t.album,
      coverUrl: t.coverUrl,
      audioUrl: t.audioUrl,
      duration: t.duration,
      plays: t.plays,
    }))
  }

  const externalEnabled = asBool(await getSetting("music.externalSearch"))
  return NextResponse.json({
    tracks: list,
    nextCursor: hasNext ? list[list.length - 1]?.id : null,
    popular,
    externalEnabled,
  })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const body = await req.json().catch(() => ({}))
  const title = String(body.title || "").trim()
  const artist = String(body.artist || "").trim()
  const album = body.album ? String(body.album).trim() : null
  const audioUrl = body.audioUrl ? String(body.audioUrl) : null
  const coverUrl = body.coverUrl ? String(body.coverUrl) : null
  const duration = Math.max(0, parseInt(body.duration, 10) || 0)
  const source = body.source === "external" ? "external" : "local"
  const externalId = body.externalId ? String(body.externalId) : null

  if (!title) return NextResponse.json({ error: "عنوان الزامی است" }, { status: 400 })
  if (!artist) return NextResponse.json({ error: "نام خواننده الزامی است" }, { status: 400 })
  if (!audioUrl) return NextResponse.json({ error: "فایل صوتی الزامی است" }, { status: 400 })

  if (source === "external" && externalId) {
    const existing = await db.musicTrack.findFirst({ where: { externalId } })
    if (existing) {
      return NextResponse.json({
        track: {
          id: existing.id,
          title: existing.title,
          artist: existing.artist,
          album: existing.album,
          coverUrl: existing.coverUrl,
          audioUrl: existing.audioUrl,
          duration: existing.duration,
          source: existing.source,
          plays: existing.plays,
          createdAt: existing.createdAt,
        },
        existed: true,
      })
    }
  }

  const track = await db.musicTrack.create({
    data: {
      title,
      artist,
      album,
      audioUrl,
      coverUrl,
      duration,
      source,
      ...(externalId && source === "external" ? { externalId } : {}),
    },
  })
  return NextResponse.json({ track, existed: false })
}
