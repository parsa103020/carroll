import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const track = await db.musicTrack.findUnique({ where: { id } })
  if (!track) return NextResponse.json({ error: "not found" }, { status: 404 })
  const updated = await db.musicTrack.update({
    where: { id },
    data: { plays: { increment: 1 } },
    select: { plays: true },
  })
  return NextResponse.json({ plays: updated.plays })
}
