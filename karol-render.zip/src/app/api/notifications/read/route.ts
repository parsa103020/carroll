import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const body = await req.json().catch(() => ({}))

  if (body.all === true) {
    await db.notification.updateMany({
      where: { userId: session.user!.id, read: false },
      data: { read: true },
    })
    return NextResponse.json({ ok: true, all: true })
  }

  const id = String(body.id || "")
  if (!id) return NextResponse.json({ error: "id الزامی است" }, { status: 400 })

  const updated = await db.notification.updateMany({
    where: { id, userId: session.user!.id },
    data: { read: true },
  })

  if (updated.count === 0) {
    return NextResponse.json({ error: "اعلان یافت نشد" }, { status: 404 })
  }
  return NextResponse.json({ ok: true })
}
