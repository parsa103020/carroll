import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

const VALID_TYPES = new Set([
  "system",
  "order",
  "vip",
  "ticket",
  "like",
  "mention",
])

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const url = new URL(req.url)
  const cursor = url.searchParams.get("cursor")
  const filter = url.searchParams.get("filter") || "all"
  const take = 30

  const where: any = { userId: session.user!.id }
  if (filter === "unread") where.read = false

  const notifs = await db.notification.findMany({
    where,
    orderBy: { createdAt: "desc" },
    take: take + 1,
    ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
  })

  const hasNext = notifs.length > take
  const list = notifs.slice(0, take).map((n) => ({
    id: n.id,
    type: n.type,
    title: n.title,
    body: n.body,
    link: n.link,
    read: n.read,
    createdAt: n.createdAt,
  }))

  return NextResponse.json({
    notifications: list,
    nextCursor: hasNext ? list[list.length - 1]?.id ?? null : null,
  })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const body = await req.json().catch(() => ({}))

  let targetUserId = session.user!.id
  if (body.userId && typeof body.userId === "string") {
    targetUserId = body.userId
  }

  const type = String(body.type || "system")
  const title = String(body.title || "").trim().slice(0, 200)
  const notifBody = body.body != null ? String(body.body).trim().slice(0, 1000) : null
  const link = body.link != null ? String(body.link).trim().slice(0, 200) : null

  if (!title) return NextResponse.json({ error: "عنوان الزامی است" }, { status: 400 })
  if (!VALID_TYPES.has(type)) return NextResponse.json({ error: "نوع نامعتبر" }, { status: 400 })

  const n = await db.notification.create({
    data: {
      userId: targetUserId,
      type,
      title,
      body: notifBody,
      link,
    },
  })

  return NextResponse.json({
    notification: {
      id: n.id,
      type: n.type,
      title: n.title,
      body: n.body,
      link: n.link,
      read: n.read,
      createdAt: n.createdAt,
    },
  })
}
