import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"
import { audit, getClientInfo } from "@/lib/audit"

export const runtime = "nodejs"

const VALID_REASONS = new Set([
  "spam",
  "insult",
  "inappropriate",
  "fraud",
  "other",
])

const REASON_LABELS: Record<string, string> = {
  spam: "اسپم",
  insult: "توهین",
  inappropriate: "محتوای نامناسب",
  fraud: "کلاهبرداری",
  other: "دیگر",
}

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id: reportedUserId } = await ctx.params
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const reporter = session.user!

  if (reporter.id === reportedUserId) {
    return NextResponse.json({ error: "نمی‌توانید خودتان را گزارش کنید" }, { status: 400 })
  }

  const target = await db.user.findUnique({
    where: { id: reportedUserId },
    select: { id: true, username: true },
  })
  if (!target) return NextResponse.json({ error: "user not found" }, { status: 404 })

  const body = await req.json().catch(() => ({}))
  const reasonRaw = typeof body.reason === "string" ? body.reason.trim() : ""
  if (!VALID_REASONS.has(reasonRaw)) {
    return NextResponse.json(
      { error: "دلیل گزارش نامعتبر است" },
      { status: 400 },
    )
  }
  const description =
    typeof body.description === "string" ? body.description.trim().slice(0, 1000) : null

  const recent = await db.userReport.count({
    where: {
      reporterId: reporter.id,
      createdAt: { gt: new Date(Date.now() - 60_000) },
    },
  })
  if (recent >= 3) {
    return NextResponse.json(
      { error: "تعداد گزارش‌های شما در یک دقیقه اخیر زیاد است. کمی بعد تلاش کنید." },
      { status: 429 },
    )
  }

  const report = await db.userReport.create({
    data: {
      reporterId: reporter.id,
      reportedUserId,
      reason: reasonRaw,
      description,
    },
  })

  const client = getClientInfo(req)
  await audit(
    {
      actorId: reporter.id,
      actorName: reporter.username,
      ip: client.ip,
      userAgent: client.userAgent,
    },
    "user.report",
    {
      targetType: "user",
      targetId: reportedUserId,
      description: `گزارش @${target.username} به دلیل «${REASON_LABELS[reasonRaw]}»${description ? ` — ${description.slice(0, 120)}` : ""}`,
      severity: "warning",
      metadata: {
        reportId: report.id,
        reason: reasonRaw,
      },
    },
  )

  return NextResponse.json({ ok: true, reportId: report.id })
}
