import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"
import { spendCoins } from "@/lib/coins"

export const runtime = "nodejs"

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const user = session.user!

  const body = await req.json().catch(() => ({}))
  const packageId = String(body.packageId || "")
  if (!packageId)
    return NextResponse.json({ error: "بسته انتخاب نشده است" }, { status: 400 })

  const pkg = await db.configPackage.findUnique({ where: { id: packageId } })
  if (!pkg || !pkg.active)
    return NextResponse.json({ error: "بسته یافت نشد" }, { status: 404 })

  const stock = await db.configStock.findFirst({
    where: { packageId: pkg.id, assignedToId: null },
    orderBy: { createdAt: "asc" },
  })
  if (!stock) {
    return NextResponse.json(
      { error: "موجودی کانفیگ تمام شده، بعداً تلاش کنید" },
      { status: 409 },
    )
  }

  const expiresAt = new Date(
    Date.now() + pkg.durationDays * 24 * 60 * 60 * 1000,
  )

  try {
    const result = await db.$transaction(async (tx) => {
      const freshStock = await tx.configStock.findUnique({ where: { id: stock.id } })
      if (!freshStock || freshStock.assignedToId) {
        throw new Error("STOCK_RACE")
      }

      const purchase = await tx.configPurchase.create({
        data: {
          userId: user.id,
          packageId: pkg.id,
          configId: freshStock.id,
          configText: freshStock.configText,
          pricePaid: pkg.priceCoins,
          volumeBytes: pkg.volumeBytes,
          expiresAt,
        },
      })

      await tx.configStock.update({
        where: { id: freshStock.id },
        data: { assignedToId: user.id, assignedAt: new Date() },
      })

      return purchase
    })

    try {
      await spendCoins(
        user.id,
        pkg.priceCoins,
        `خرید کانفیگ ${pkg.name}`,
        result.id,
      )
    } catch (e: any) {
      await db.configPurchase.delete({ where: { id: result.id } }).catch(() => {})
      await db.configStock
        .update({ where: { id: stock.id }, data: { assignedToId: null, assignedAt: null } })
        .catch(() => {})
      if (e?.message === "INSUFFICIENT_BALANCE") {
        return NextResponse.json(
          { error: "کارول‌کوین کافی ندارید" },
          { status: 400 },
        )
      }
      throw e
    }

    return NextResponse.json({
      purchase: {
        id: result.id,
        packageId: result.packageId,
        configId: result.configId,
        pricePaid: result.pricePaid,
        volumeBytes: result.volumeBytes.toString(),
        expiresAt: result.expiresAt,
        createdAt: result.createdAt,
        packageName: pkg.name,
        configText: result.configText,
      },
      configText: result.configText,
    })
  } catch (e: any) {
    if (e?.message === "STOCK_RACE") {
      return NextResponse.json(
        { error: "موجودی کانفیگ تمام شده، بعداً تلاش کنید" },
        { status: 409 },
      )
    }
    return NextResponse.json({ error: "خطا در خرید کانفیگ" }, { status: 500 })
  }
}
