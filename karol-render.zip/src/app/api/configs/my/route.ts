import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })

  const url = new URL(req.url)
  const limit = Math.min(parseInt(url.searchParams.get("limit") || "20", 10) || 20, 100)
  const cursor = url.searchParams.get("cursor") || null

  const purchases = await db.configPurchase.findMany({
    where: { userId: session.user!.id },
    orderBy: { createdAt: "desc" },
    take: limit + 1,
    ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
    include: {
      package: { select: { id: true, name: true, durationDays: true } },
    },
  })

  let nextCursor: string | null = null
  const items = purchases.slice(0, limit)
  if (purchases.length > limit) nextCursor = items[items.length - 1].id

  return NextResponse.json({
    purchases: items.map((p) => ({
      id: p.id,
      packageId: p.packageId,
      configId: p.configId,
      pricePaid: p.pricePaid,
      volumeBytes: p.volumeBytes.toString(),
      expiresAt: p.expiresAt,
      createdAt: p.createdAt,
      packageName: p.package.name,
      durationDays: p.package.durationDays,
    })),
    nextCursor,
  })
}
