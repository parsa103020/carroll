import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })

  const { id } = await params
  const purchase = await db.configPurchase.findUnique({
    where: { id },
    include: {
      package: { select: { id: true, name: true, durationDays: true } },
    },
  })
  if (!purchase || purchase.userId !== session.user!.id) {
    return NextResponse.json({ error: "کانفیگ یافت نشد" }, { status: 404 })
  }

  return NextResponse.json({
    purchase: {
      id: purchase.id,
      packageId: purchase.packageId,
      configId: purchase.configId,
      pricePaid: purchase.pricePaid,
      volumeBytes: purchase.volumeBytes.toString(),
      expiresAt: purchase.expiresAt,
      createdAt: purchase.createdAt,
      packageName: purchase.package.name,
      durationDays: purchase.package.durationDays,
      configText: purchase.configText,
    },
  })
}
