import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })

  const pkgs = await db.configPackage.findMany({
    where: { active: true },
    orderBy: { volumeBytes: "asc" },
    select: {
      id: true,
      name: true,
      volumeBytes: true,
      priceCoins: true,
      durationDays: true,
      _count: { select: { stock: { where: { assignedToId: null } } } },
    },
  })

  const items = pkgs.map((p) => ({
    id: p.id,
    name: p.name,
    volumeBytes: p.volumeBytes.toString(),
    priceCoins: p.priceCoins,
    durationDays: p.durationDays,
    stockAvailable: p._count.stock,
  }))

  return NextResponse.json({ packages: items })
}
