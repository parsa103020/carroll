import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  const { id } = await params
  const reel = await db.reel.findUnique({ where: { id }, select: { id: true } })
  if (!reel) return NextResponse.json({ error: "not found" }, { status: 404 })
  const updated = await db.reel.update({
    where: { id },
    data: { views: { increment: 1 } },
    select: { views: true },
  })
  return NextResponse.json({ views: updated.views, viewedBy: session?.user?.id ?? null })
}
