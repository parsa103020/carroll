import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const existing = await db.reelLike.findUnique({
    where: { reelId_userId: { reelId: id, userId: session.user!.id } },
  })
  if (existing) {
    await db.reelLike.delete({ where: { id: existing.id } })
    return NextResponse.json({ liked: false })
  }
  await db.reelLike.create({ data: { reelId: id, userId: session.user!.id } })
  return NextResponse.json({ liked: true })
}
