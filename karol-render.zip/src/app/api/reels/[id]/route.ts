import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const reel = await db.reel.findUnique({
    where: { id },
    include: {
      owner: { select: { id: true, username: true, displayName: true, avatarUrl: true, isVip: true } },
      likes: { where: { userId: session.user!.id }, select: { id: true } },
      _count: { select: { likes: true, comments: true } },
    },
  })
  if (!reel) return NextResponse.json({ error: "not found" }, { status: 404 })
  return NextResponse.json({
    reel: {
      id: reel.id,
      videoUrl: reel.videoUrl,
      posterUrl: reel.posterUrl,
      caption: reel.caption,
      musicTitle: reel.musicTitle,
      views: reel.views,
      createdAt: reel.createdAt,
      likes: reel._count.likes,
      comments: reel._count.comments,
      liked: reel.likes.length > 0,
      owner: reel.owner,
    },
  })
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const reel = await db.reel.findUnique({ where: { id }, select: { ownerId: true } })
  if (!reel) return NextResponse.json({ error: "not found" }, { status: 404 })
  const isOwner = reel.ownerId === session.user!.id
  const isAdmin = hasRole(session.user!.roles, "admin")
  if (!isOwner && !isAdmin) {
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  }
  await db.reel.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
