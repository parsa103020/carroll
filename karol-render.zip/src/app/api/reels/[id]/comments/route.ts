import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession } from "@/lib/auth"

export const runtime = "nodejs"

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const url = new URL(req.url)
  const cursor = url.searchParams.get("cursor")
  const take = 20
  const comments = await db.reelComment.findMany({
    where: { reelId: id },
    orderBy: { createdAt: "desc" },
    take: take + 1,
    ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
    include: {
      user: { select: { id: true, username: true, displayName: true, avatarUrl: true, isVip: true } },
    },
  })
  const hasNext = comments.length > take
  const list = comments.slice(0, take).map((c) => ({
    id: c.id,
    content: c.content,
    createdAt: c.createdAt,
    user: c.user,
  }))
  return NextResponse.json({
    comments: list,
    nextCursor: hasNext ? list[list.length - 1]?.id ?? null : null,
  })
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const { id } = await params
  const body = await req.json().catch(() => ({}))
  const content = String(body.content || "").trim()
  if (!content) return NextResponse.json({ error: "نظر خالی است" }, { status: 400 })
  if (content.length > 1000) return NextResponse.json({ error: "نظر خیلی طولانی است" }, { status: 400 })
  const reel = await db.reel.findUnique({ where: { id }, select: { id: true } })
  if (!reel) return NextResponse.json({ error: "not found" }, { status: 404 })
  const comment = await db.reelComment.create({
    data: { reelId: id, userId: session.user!.id, content },
    include: {
      user: { select: { id: true, username: true, displayName: true, avatarUrl: true, isVip: true } },
    },
  })
  return NextResponse.json({
    comment: {
      id: comment.id,
      content: comment.content,
      createdAt: comment.createdAt,
      user: comment.user,
    },
  })
}
