import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getSession, hasRole } from "@/lib/auth"
import { getSetting, asInt } from "@/lib/settings"

export const runtime = "nodejs"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const url = new URL(req.url)
  const cursor = url.searchParams.get("cursor")
  const take = asInt(await getSetting("reel.feedSize"), 10)
  const reels = await db.reel.findMany({
    orderBy: { createdAt: "desc" },
    take: take + 1,
    ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
    include: {
      owner: { select: { id: true, username: true, displayName: true, avatarUrl: true, isVip: true } },
      likes: { where: { userId: session.user!.id }, select: { id: true } },
      _count: { select: { likes: true, comments: true } },
    },
  })
  const hasNext = reels.length > take
  const list = reels.slice(0, take).map((r) => ({
    id: r.id,
    videoUrl: r.videoUrl,
    posterUrl: r.posterUrl,
    caption: r.caption,
    musicTitle: r.musicTitle,
    views: r.views,
    createdAt: r.createdAt,
    likes: r._count.likes,
    comments: r._count.comments,
    liked: r.likes.length > 0,
    owner: r.owner,
  }))
  return NextResponse.json({
    reels: list,
    nextCursor: hasNext ? list[list.length - 1]?.id ?? null : null,
  })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  const body = await req.json().catch(() => ({}))
  const videoUrl = String(body.videoUrl || "").trim()
  if (!videoUrl) return NextResponse.json({ error: "ویدیو الزامی است" }, { status: 400 })
  const caption = body.caption != null ? String(body.caption).trim().slice(0, 1000) : null
  const musicTitle = body.musicTitle != null ? String(body.musicTitle).trim().slice(0, 200) : null
  const posterUrl = body.posterUrl != null ? String(body.posterUrl).trim() : null

  const reel = await db.reel.create({
    data: {
      ownerId: session.user!.id,
      videoUrl,
      posterUrl: posterUrl || null,
      caption: caption || null,
      musicTitle: musicTitle || null,
    },
    include: {
      owner: { select: { id: true, username: true, displayName: true, avatarUrl: true, isVip: true } },
      _count: { select: { likes: true, comments: true } },
    },
  })
  return NextResponse.json({
    reel: {
      id: reel.id,
      videoUrl: reel.videoUrl,
      posterUrl: reel.posterUrl,
      caption: reel.caption,
      musicTitle: reel.musicTitle,
      views: reel.views,
      createdAt: reel.createdAt,
      likes: reel._count.likes,
      comments: reel._count.comments,
      liked: false,
      owner: reel.owner,
    },
  })
}
