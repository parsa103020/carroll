import type { Metadata, Viewport } from "next"
import { Vazirmatn } from "next/font/google"
import "./globals.css"
import { Toaster } from "@/components/ui/toaster"
import { Toaster as SonnerToaster } from "@/components/ui/sonner"
import { Providers } from "@/components/providers"

const vazirmatn = Vazirmatn({
  variable: "--font-vazirmatn",
  subsets: ["arabic", "latin"],
  display: "swap",
})

export const metadata: Metadata = {
  title: "کارول — پلتفرم اجتماعی",
  description: "کارول، پلتفرم یکپارچه گفتگو، موسیقی، ویدیو، ریلز و فروشگاه برای دوران قطعی اینترنت",
  keywords: ["کارول", "Karol", "چت", "موسیقی", "ویدیو", "ریلز", "فروشگاه"],
  icons: { icon: "/favicon.svg" },
}

export const viewport: Viewport = {
  themeColor: "#060d11",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
}

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="fa" dir="rtl" data-theme="aurora" suppressHydrationWarning>
      <body className={`${vazirmatn.variable} font-sans antialiased`}>
        <Providers>{children}</Providers>
        <Toaster />
        <SonnerToaster position="top-center" richColors />
      </body>
    </html>
  )
}
