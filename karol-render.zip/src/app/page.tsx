"use client"

import { useEffect } from "react"
import dynamic from "next/dynamic"
import { useApp, isAppAdmin, type SectionId } from "@/lib/store"
import AuthScreen from "@/sections/auth/AuthScreen"
import { AppShell } from "@/components/karol/AppShell"
import { setGlobalToast } from "@/lib/store"
import { toast as sonnerToast } from "sonner"
import { Loader2 } from "lucide-react"

const Feed = dynamic(() => import("@/sections/feed/FeedSection").then((m) => m.default), { ssr: false })
const Galaxy = dynamic(() => import("@/sections/galaxy/GalaxySection").then((m) => m.default), { ssr: false })
const Chat = dynamic(() => import("@/sections/chat/ChatSection").then((m) => m.default), { ssr: false })
const Voice = dynamic(() => import("@/sections/voice/VoiceSection").then((m) => m.default), { ssr: false })
const WatchParty = dynamic(() => import("@/sections/watchparty/WatchPartySection").then((m) => m.default), { ssr: false })
const Music = dynamic(() => import("@/sections/music/MusicSection").then((m) => m.default), { ssr: false })
const Videos = dynamic(() => import("@/sections/videos/VideosSection").then((m) => m.default), { ssr: false })
const Reels = dynamic(() => import("@/sections/reels/ReelsSection").then((m) => m.default), { ssr: false })
const Drive = dynamic(() => import("@/sections/drive/DriveSection").then((m) => m.default), { ssr: false })
const Shop = dynamic(() => import("@/sections/shop/ShopSection").then((m) => m.default), { ssr: false })
const Configs = dynamic(() => import("@/sections/configs/ConfigsSection").then((m) => m.default), { ssr: false })
const Vip = dynamic(() => import("@/sections/vip/VipSection").then((m) => m.default), { ssr: false })
const Wallet = dynamic(() => import("@/sections/wallet/WalletSection").then((m) => m.default), { ssr: false })
const Tickets = dynamic(() => import("@/sections/tickets/TicketsSection").then((m) => m.default), { ssr: false })
const Profile = dynamic(() => import("@/sections/profile/ProfileSection").then((m) => m.default), { ssr: false })
const Admin = dynamic(() => import("@/sections/admin/AdminSection").then((m) => m.default), { ssr: false })
const Notifications = dynamic(() => import("@/sections/notifications/NotificationsSection").then((m) => m.default), { ssr: false })

const SECTION_COMPONENTS: Record<SectionId, React.ComponentType<any>> = {
  feed: Feed,
  galaxy: Galaxy,
  chat: Chat,
  voice: Voice,
  watchparty: WatchParty,
  configs: Configs,
  music: Music,
  videos: Videos,
  reels: Reels,
  drive: Drive,
  shop: Shop,
  vip: Vip,
  wallet: Wallet,
  tickets: Tickets,
  profile: Profile,
  admin: Admin,
  notifications: Notifications,
}

export default function Home() {
  const { user, loadingUser, section, refreshUser } = useApp()

  useEffect(() => {
    setGlobalToast((msg, kind) => {
      if (kind === "success") sonnerToast.success(msg)
      else if (kind === "error") sonnerToast.error(msg)
      else sonnerToast(msg)
    })
    refreshUser()
  }, [refreshUser])

  if (loadingUser) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-base">
        <div className="flex flex-col items-center gap-3">
          <img src="/logo.svg" alt="" className="w-16 h-16 animate-karol-pulse" />
          <Loader2 className="w-5 h-5 animate-spin text-muted-c" />
          <p className="text-sm text-muted-c">در حال بارگذاری کارول…</p>
        </div>
      </div>
    )
  }

  if (!user) return <AuthScreen />

  const Active = SECTION_COMPONENTS[section] || Feed
  const isAdmin = isAppAdmin(user)

  return (
    <AppShell>
      <Active />
      {section === "admin" && !isAdmin && (
        <div className="p-10 text-center text-muted-c">دسترسی غیرمجاز</div>
      )}
    </AppShell>
  )
}
