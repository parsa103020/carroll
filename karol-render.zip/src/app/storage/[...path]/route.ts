import { NextResponse } from "next/server"
import { promises as fs } from "fs"
import path from "path"
import { CONFIG } from "@/lib/config"

const MIME: Record<string, string> = {
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".gif": "image/gif",
  ".webp": "image/webp",
  ".mp3": "audio/mpeg",
  ".ogg": "audio/ogg",
  ".weba": "audio/webm",
  ".aac": "audio/aac",
  ".mp4": "video/mp4",
  ".webm": "video/webm",
  ".mov": "video/quicktime",
  ".pdf": "application/pdf",
  ".zip": "application/zip",
}

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ path: string[] }> },
) {
  const { path: segments } = await params
  const rel = segments.map((s) => decodeURIComponent(s)).join("/")
  if (rel.includes("..")) return new NextResponse("Forbidden", { status: 403 })
  const abs = path.join(CONFIG.storage.local.root, rel)
  try {
    const buf = await fs.readFile(abs)
    const ext = path.extname(abs).toLowerCase()
    const mime = MIME[ext] || "application/octet-stream"
    return new NextResponse(buf, {
      headers: {
        "Content-Type": mime,
        "Cache-Control": "public, max-age=31536000, immutable",
        "Access-Control-Allow-Origin": "*",
      },
    })
  } catch {
    return new NextResponse("Not found", { status: 404 })
  }
}
