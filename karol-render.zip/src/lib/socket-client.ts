export function getSocketUrl(): string {
  if (process.env.NEXT_PUBLIC_SOCKET_URL) {
    return process.env.NEXT_PUBLIC_SOCKET_URL
  }
  if (process.env.NEXT_PUBLIC_SOCKET_PORT) {
    return `/?XTransformPort=${process.env.NEXT_PUBLIC_SOCKET_PORT}`
  }
  if (typeof window !== "undefined") {
    return window.location.origin
  }
  return ""
}
