export function formatBytes(b: number | string | bigint): string {
  const n = typeof b === "bigint" ? Number(b) : typeof b === "string" ? parseInt(b, 10) : b
  if (!n || n < 0) return "۰"
  const units = ["بایت", "کیلوبایت", "مگابایت", "گیگابایت", "ترابایت"]
  let i = 0
  let v = n
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024
    i++
  }
  const fa = v.toLocaleString("fa-IR", { maximumFractionDigits: 1 })
  return `${fa} ${units[i]}`
}

export function formatNumber(n: number | bigint): string {
  const num = typeof n === "bigint" ? Number(n) : n
  return num.toLocaleString("fa-IR")
}

export function faDigits(s: string | number): string {
  return String(s).replace(/[0-9]/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[parseInt(d, 10)])
}

export function timeAgo(date: string | Date): string {
  const d = typeof date === "string" ? new Date(date) : date
  const diff = Date.now() - d.getTime()
  const sec = Math.floor(diff / 1000)
  if (sec < 5) return "هم‌اکنون"
  if (sec < 60) return `${faDigits(sec)} ثانیه پیش`
  const min = Math.floor(sec / 60)
  if (min < 60) return `${faDigits(min)} دقیقه پیش`
  const hr = Math.floor(min / 60)
  if (hr < 24) return `${faDigits(hr)} ساعت پیش`
  const day = Math.floor(hr / 24)
  if (day < 30) return `${faDigits(day)} روز پیش`
  const mo = Math.floor(day / 30)
  if (mo < 12) return `${faDigits(mo)} ماه پیش`
  return `${faDigits(Math.floor(mo / 12))} سال پیش`
}

export function formatTime(date: string | Date): string {
  const d = typeof date === "string" ? new Date(date) : date
  return d.toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" })
}

export function formatDate(date: string | Date): string {
  const d = typeof date === "string" ? new Date(date) : date
  return d.toLocaleDateString("fa-IR", { year: "numeric", month: "long", day: "numeric" })
}

export async function api<T = any>(
  input: string,
  init?: RequestInit & { json?: any },
): Promise<T> {
  const headers: Record<string, string> = { ...(init?.headers as any) }
  let body = init?.body
  if (init?.json !== undefined) {
    headers["Content-Type"] = "application/json"
    body = JSON.stringify(init.json)
  }
  const r = await fetch(input, { ...init, headers, body })
  const ct = r.headers.get("content-type") || ""
  const data = ct.includes("application/json") ? await r.json() : await r.text()
  if (!r.ok) {
    const msg = (data && typeof data === "object" && (data as any).error) || `خطا ${r.status}`
    throw new Error(msg)
  }
  return data as T
}

export function categoryColor(cat: string): string {
  const map: Record<string, string> = {
    image: "text-emerald-500",
    video: "text-rose-500",
    audio: "text-amber-500",
    gif: "text-purple-500",
    file: "text-blue-500",
  }
  return map[cat] || "text-muted-foreground"
}
