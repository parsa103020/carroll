import { db } from "./db"

export interface AuditContext {
  actorId?: string
  actorName: string
  ip?: string
  userAgent?: string
}

export type AuditSeverity = "info" | "warning" | "danger"

export async function audit(
  ctx: AuditContext,
  action: string,
  opts: {
    targetType?: string
    targetId?: string
    description?: string
    severity?: AuditSeverity
    metadata?: Record<string, any>
  } = {},
) {
  try {
    await db.auditLog.create({
      data: {
        actorId: ctx.actorId || null,
        actorName: ctx.actorName,
        action,
        targetType: opts.targetType || "",
        targetId: opts.targetId || "",
        description: opts.description || "",
        severity: opts.severity || "info",
        metadata: opts.metadata ? JSON.stringify(opts.metadata) : null,
      },
    })
  } catch (e) {
    console.error("audit log failed:", e)
  }
}

export function getClientInfo(req: Request): { ip?: string; userAgent?: string } {
  const forwarded = req.headers.get("x-forwarded-for")
  const ip = forwarded?.split(",")[0]?.trim() || req.headers.get("x-real-ip") || undefined
  const userAgent = req.headers.get("user-agent") || undefined
  return { ip, userAgent }
}
