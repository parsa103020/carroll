import { SignJWT, jwtVerify } from "jose"
import { cookies } from "next/headers"
import bcrypt from "bcryptjs"
import { db } from "./db"
import { CONFIG } from "./config"

const secret = new TextEncoder().encode(
  process.env.AUTH_SECRET || "karol-dev-secret-change-me-please-0123456789",
)

export interface SessionPayload {
  sub: string
  username: string
  roles: string
}

export async function createSession(userId: string, username: string, roles: string) {
  const token = await new SignJWT({ username, roles })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(userId)
    .setIssuedAt()
    .setExpirationTime(`${CONFIG.auth.sessionTtlDays}d`)
    .sign(secret)

  const expiresAt = new Date(Date.now() + CONFIG.auth.sessionTtlDays * 86400000)
  await db.session.create({
    data: {
      userId,
      token,
      expiresAt,
    },
  })
  return { token, expiresAt }
}

export async function verifyToken(token: string): Promise<SessionPayload | null> {
  try {
    const { payload } = await jwtVerify(token, secret)
    return {
      sub: payload.sub as string,
      username: payload.username as string,
      roles: payload.roles as string,
    }
  } catch {
    return null
  }
}

export async function getSession(): Promise<{
  user: Awaited<ReturnType<typeof db.user.findUnique>>
  payload: SessionPayload
} | null> {
  const cookieStore = await cookies()
  const token = cookieStore.get(CONFIG.auth.cookieName)?.value
  if (!token) return null
  const payload = await verifyToken(token)
  if (!payload) return null
  const session = await db.session.findUnique({ where: { token } })
  if (!session || session.expiresAt < new Date()) return null
  const user = await db.user.findUnique({ where: { id: payload.sub } })
  if (!user || user.banned) return null
  return { user, payload }
}

export async function requireUser() {
  const s = await getSession()
  if (!s) throw new Error("UNAUTHORIZED")
  return s.user
}

export async function requireAdmin() {
  const user = await requireUser()
  if (!hasRole(user.roles, "admin")) throw new Error("FORBIDDEN")
  return user
}

export function hasRole(roles: string, role: string): boolean {
  return roles.split(",").map((r) => r.trim()).includes(role)
}

export function hasAnyRole(roles: string, ...needles: string[]): boolean {
  const list = roles.split(",").map((r) => r.trim())
  return needles.some((n) => list.includes(n))
}

export async function hashPassword(p: string): Promise<string> {
  return bcrypt.hash(p, 10)
}

export async function verifyPassword(p: string, hash: string): Promise<boolean> {
  return bcrypt.compare(p, hash)
}

export function setSessionCookie(token: string, expiresAt: Date) {
  return {
    name: CONFIG.auth.cookieName,
    value: token,
    httpOnly: true,
    sameSite: "lax" as const,
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: expiresAt,
  }
}

export async function destroySession() {
  const cookieStore = await cookies()
  const token = cookieStore.get(CONFIG.auth.cookieName)?.value
  if (token) {
    await db.session.deleteMany({ where: { token } }).catch(() => {})
  }
}
