"use client"

import { create } from "zustand"
import type { KarolTheme } from "@/components/providers"

export const DEFAULT_THEME: KarolTheme = "aurora"

export interface CurrentUser {
  id: string
  username: string
  displayName: string | null
  avatarUrl: string | null
  animatedAvatarUrl: string | null
  profileEffect: string
  nameColor: string | null
  bio: string | null
  coins: number
  isVip: boolean
  vipExpiresAt: string | null
  roles: string[]
  dailyUploadLimitBytes: string
  usedUploadBytesToday: string
  banned: boolean
  createdAt: string
}

export type SectionId =
  | "feed"
  | "galaxy"
  | "chat"
  | "voice"
  | "watchparty"
  | "music"
  | "videos"
  | "reels"
  | "drive"
  | "shop"
  | "configs"
  | "vip"
  | "wallet"
  | "tickets"
  | "profile"
  | "admin"
  | "notifications"

interface AppState {
  user: CurrentUser | null
  loadingUser: boolean
  section: SectionId
  sectionParams: Record<string, any>
  theme: KarolTheme
  sidebarOpen: boolean
  toast: (msg: string, kind?: "default" | "success" | "error") => void

  setUser: (u: CurrentUser | null) => void
  setLoadingUser: (b: boolean) => void
  setSection: (s: SectionId, params?: Record<string, any>) => void
  setTheme: (t: KarolTheme) => void
  setSidebarOpen: (b: boolean) => void
  refreshUser: () => Promise<void>
}

let toastFn: (msg: string, kind?: "default" | "success" | "error") => void = () => {}

export function setGlobalToast(fn: typeof toastFn) {
  toastFn = fn
}

export const useApp = create<AppState>((set, get) => ({
  user: null,
  loadingUser: true,
  section: "feed",
  sectionParams: {},
  theme: DEFAULT_THEME,
  sidebarOpen: false,
  toast: (msg, kind) => toastFn(msg, kind),

  setUser: (u) => set({ user: u }),
  setLoadingUser: (b) => set({ loadingUser: b }),
  setSection: (s, params = {}) =>
    set({ section: s, sectionParams: params, sidebarOpen: false }),
  setTheme: (t) => {
    set({ theme: t })
    if (typeof window !== "undefined") {
      localStorage.setItem("karol-theme", t)
      document.documentElement.setAttribute("data-theme", t)
    }
  },
  setSidebarOpen: (b) => set({ sidebarOpen: b }),
  refreshUser: async () => {
    try {
      const r = await fetch("/api/auth")
      const d = await r.json()
      set({ user: d.user, loadingUser: false })
    } catch {
      set({ loadingUser: false })
    }
  },
}))

export const isAppAdmin = (u: CurrentUser | null) => !!u && u.roles.includes("admin")
export const isModerator = (u: CurrentUser | null) =>
  !!u && (u.roles.includes("admin") || u.roles.some((r) => r.endsWith("_mod") || r === "moderator"))
