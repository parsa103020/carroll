import { db } from "./db"
import type { User } from "@prisma/client"

export async function creditCoins(userId: string, amount: number, type: string, description: string, referenceId?: string) {
  const user = await db.user.findUnique({ where: { id: userId } })
  if (!user) throw new Error("USER_NOT_FOUND")
  const balanceAfter = user.coins + amount
  await db.user.update({ where: { id: userId }, data: { coins: balanceAfter } })
  await db.coinTransaction.create({
    data: { userId, amount, balanceAfter, type, description, referenceId },
  })
  return balanceAfter
}

export async function spendCoins(userId: string, amount: number, description: string, referenceId?: string) {
  const user = await db.user.findUnique({ where: { id: userId } })
  if (!user) throw new Error("USER_NOT_FOUND")
  if (user.coins < amount) throw new Error("INSUFFICIENT_BALANCE")
  const balanceAfter = user.coins - amount
  await db.user.update({ where: { id: userId }, data: { coins: balanceAfter } })
  await db.coinTransaction.create({
    data: { userId, amount: -amount, balanceAfter, type: "spend", description, referenceId },
  })
  return balanceAfter
}

export async function resetDailyUploadIfNeeded(user: User): Promise<User> {
  const now = new Date()
  const reset = new Date(user.uploadResetAt)
  const needsReset =
    now.getUTCDate() !== reset.getUTCDate() ||
    now.getUTCMonth() !== reset.getUTCMonth() ||
    now.getUTCFullYear() !== reset.getUTCFullYear()
  if (needsReset) {
    const updated = await db.user.update({
      where: { id: user.id },
      data: { usedUploadBytesToday: 0n, uploadResetAt: now },
    })
    return updated
  }
  return user
}

export async function consumeUploadQuota(userId: string, bytes: bigint) {
  const user = await db.user.findUnique({ where: { id: userId } })
  if (!user) throw new Error("USER_NOT_FOUND")
  const fresh = await resetDailyUploadIfNeeded(user)
  if (fresh.usedUploadBytesToday + bytes > fresh.dailyUploadLimitBytes) {
    throw new Error("UPLOAD_QUOTA_EXCEEDED")
  }
  await db.user.update({
    where: { id: userId },
    data: { usedUploadBytesToday: { increment: bytes } },
  })
}
