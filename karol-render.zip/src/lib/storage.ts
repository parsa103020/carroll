import { promises as fs } from "fs"
import path from "path"
import { CONFIG } from "./config"
import { randomUUID } from "crypto"

export interface StoredObject {
  key: string
  url: string
  size: number
  mime: string
}

const CATEGORY_DIRS: Record<string, string> = {
  avatar: "avatars",
  chat: "chat",
  drive: "drive",
  reel: "reels",
  video: "videos",
  music: "music",
  receipt: "receipts",
  sticker: "stickers",
  gif: "chat",
}

function extFromMime(mime: string): string {
  const map: Record<string, string> = {
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/gif": ".gif",
    "image/webp": ".webp",
    "audio/mpeg": ".mp3",
    "audio/mp3": ".mp3",
    "audio/ogg": ".ogg",
    "audio/webm": ".weba",
    "audio/aac": ".aac",
    "video/mp4": ".mp4",
    "video/webm": ".webm",
    "video/quicktime": ".mov",
    "application/pdf": ".pdf",
    "application/zip": ".zip",
  }
  return map[mime] || ""
}

export async function storeObject(
  category: keyof typeof CATEGORY_DIRS,
  data: Buffer | Uint8Array,
  mime: string,
  name?: string,
): Promise<StoredObject> {
  const dir = CATEGORY_DIRS[category] || "drive"
  const ext = extFromMime(mime)
  const id = randomUUID().replace(/-/g, "")
  const filename = `${id}${ext}`
  const relPath = path.join(dir, filename)
  const absPath = path.join(CONFIG.storage.local.root, relPath)

  await fs.mkdir(path.dirname(absPath), { recursive: true })
  await fs.writeFile(absPath, Buffer.from(data))

  const size = data.byteLength
  return {
    key: relPath,
    url: `${CONFIG.storage.local.publicBase}/${relPath}`,
    size,
    mime,
  }
}

export async function readObject(key: string): Promise<Buffer | null> {
  const absPath = path.join(CONFIG.storage.local.root, key)
  try {
    return await fs.readFile(absPath)
  } catch {
    return null
  }
}

export async function deleteObject(key: string): Promise<void> {
  const absPath = path.join(CONFIG.storage.local.root, key)
  try {
    await fs.unlink(absPath)
  } catch {
    // ignore
  }
}

export function objectPathFromUrl(url: string): string | null {
  if (!url.startsWith(CONFIG.storage.local.publicBase + "/")) return null
  return url.slice(CONFIG.storage.local.publicBase.length + 1)
}
