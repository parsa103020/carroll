import { db } from "./db"
import { CONFIG } from "./config"

const cache = new Map<string, { value: string; ts: number }>()
const TTL = 5000

export async function getSetting(key: string): Promise<string> {
  const cached = cache.get(key)
  if (cached && Date.now() - cached.ts < TTL) return cached.value
  const row = await db.setting.findUnique({ where: { key } })
  const value = row?.value ?? CONFIG.defaultSettings[key] ?? ""
  cache.set(key, { value, ts: Date.now() })
  return value
}

export async function getSettings(): Promise<Record<string, string>> {
  const rows = await db.setting.findMany()
  const result: Record<string, string> = { ...CONFIG.defaultSettings }
  for (const r of rows) result[r.key] = r.value
  for (const [k, v] of Object.entries(result)) cache.set(k, { value: v, ts: Date.now() })
  return result
}

export async function setSetting(key: string, value: string): Promise<void> {
  await db.setting.upsert({
    where: { key },
    update: { value },
    create: { key, value },
  })
  cache.set(key, { value, ts: Date.now() })
}

export async function setSettings(map: Record<string, string>): Promise<void> {
  for (const [k, v] of Object.entries(map)) await setSetting(k, v)
}

export function asBool(v: string): boolean {
  return v === "true" || v === "1" || v === "yes"
}

export function asInt(v: string, def = 0): number {
  const n = parseInt(v, 10)
  return Number.isFinite(n) ? n : def
}

export function asBigInt(v: string, def = 0n): bigint {
  try {
    return BigInt(v)
  } catch {
    return def
  }
}
