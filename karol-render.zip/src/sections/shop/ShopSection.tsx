"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import { useApp, isAppAdmin } from "@/lib/store"
import { api, formatNumber, faDigits, timeAgo, formatDate } from "@/lib/format"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import {
  Coins,
  Crown,
  CreditCard,
  Receipt,
  Check,
  X,
  ShoppingBag,
  Upload,
  Copy,
  Loader2,
  Package,
  Clock,
  PackageCheck,
  PackageX,
  ImageIcon,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface ShopItem {
  id: string
  title: string
  description: string | null
  price: number
  kind: "coins" | "vip" | "custom"
  payload: string
  imageUrl: string | null
}

interface MyOrder {
  id: string
  amount: number
  coins: number
  status: "pending" | "confirmed" | "rejected"
  receiptUrl: string | null
  note: string | null
  cardNumber: string | null
  createdAt: string
  reviewedAt: string | null
  shopItem: {
    id: string
    title: string
    kind: string
    payload: string
    price: number
  } | null
}

interface AdminOrder extends MyOrder {
  user: { id: string; username: string; displayName: string | null; avatarUrl: string | null }
}

interface ShopSettings {
  cardNumber?: string
  cardHolder?: string
}

const STATUS_META: Record<
  MyOrder["status"],
  { label: string; icon: React.ComponentType<{ className?: string }>; cls: string }
> = {
  pending: { label: "در انتظار", icon: Clock, cls: "bg-amber-500/15 text-amber-600 border-amber-500/30" },
  confirmed: { label: "تأیید شد", icon: PackageCheck, cls: "bg-emerald-500/15 text-emerald-600 border-emerald-500/30" },
  rejected: { label: "رد شد", icon: PackageX, cls: "bg-rose-500/15 text-rose-600 border-rose-500/30" },
}

function kindBadge(kind: string) {
  if (kind === "vip")
    return (
      <Badge className="bg-gold/15 text-gold border border-gold/30 gap-1">
        <Crown className="w-3 h-3" /> VIP
      </Badge>
    )
  if (kind === "coins")
    return (
      <Badge className="bg-primary/10 text-primary border border-primary/30 gap-1">
        <Coins className="w-3 h-3" /> کوین
      </Badge>
    )
  return (
    <Badge variant="outline" className="gap-1">
      <Package className="w-3 h-3" /> محصول
    </Badge>
  )
}

export default function ShopSection() {
  const { user, toast, setSection, refreshUser } = useApp()
  const admin = isAppAdmin(user)
  const [items, setItems] = useState<ShopItem[]>([])
  const [loadingItems, setLoadingItems] = useState(true)
  const [settings, setSettings] = useState<ShopSettings>({})
  const [activeItem, setActiveItem] = useState<ShopItem | null>(null)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [myOrders, setMyOrders] = useState<MyOrder[]>([])
  const [loadingOrders, setLoadingOrders] = useState(true)
  const [adminOrders, setAdminOrders] = useState<AdminOrder[]>([])
  const [loadingAdmin, setLoadingAdmin] = useState(false)
  const [reviewingId, setReviewingId] = useState<string | null>(null)
  const [tab, setTab] = useState<"items" | "orders">("items")

  const loadItems = useCallback(async () => {
    setLoadingItems(true)
    try {
      const [itemsRes, settingsRes] = await Promise.all([
        api<{ items: ShopItem[] }>("/api/shop/items"),
        api<Record<string, string>>("/api/settings"),
      ])
      setItems(itemsRes.items)
      setSettings({
        cardNumber: settingsRes["shop.cardNumber"],
        cardHolder: settingsRes["shop.cardHolder"],
      })
    } catch (e: any) {
      toast(e.message || "خطا در بارگذاری فروشگاه", "error")
    } finally {
      setLoadingItems(false)
    }
  }, [toast])

  const loadOrders = useCallback(async () => {
    setLoadingOrders(true)
    try {
      const r = await api<{ orders: MyOrder[] }>("/api/shop/orders/my?limit=50")
      setMyOrders(r.orders)
    } catch (e: any) {
      toast(e.message || "خطا در بارگذاری سفارش‌ها", "error")
    } finally {
      setLoadingOrders(false)
    }
  }, [toast])

  const loadAdminOrders = useCallback(async () => {
    if (!admin) return
    setLoadingAdmin(true)
    try {
      const r = await api<{ orders: AdminOrder[] }>("/api/shop/orders")
      setAdminOrders(r.orders)
    } catch (e: any) {
      toast(e.message || "خطا در بارگذاری سفارش‌ها", "error")
    } finally {
      setLoadingAdmin(false)
    }
  }, [admin, toast])

  useEffect(() => {
    loadItems()
    loadOrders()
  }, [loadItems, loadOrders])

  useEffect(() => {
    if (tab === "orders" && admin && adminOrders.length === 0) loadAdminOrders()
  }, [tab, admin, adminOrders.length, loadAdminOrders])

  const openBuy = (item: ShopItem) => {
    setActiveItem(item)
    setDialogOpen(true)
  }

  return (
    <div className="min-h-full p-3 sm:p-4 lg:p-6 max-w-5xl mx-auto w-full">
      <div className="mb-4 sm:mb-6 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <ShoppingBag className="w-5 h-5 text-primary" />
          <h2 className="text-lg sm:text-xl font-bold">فروشگاه کارول</h2>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setSection("wallet")}
          className="text-muted-foreground"
        >
          <Coins className="w-4 h-4 ml-1 text-gold" />
          <span className="tabular-nums">{faDigits(formatNumber(user?.coins ?? 0))}</span>
        </Button>
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as "items" | "orders")}>
        <TabsList className="grid w-full grid-cols-2 mb-5 max-w-sm">
          <TabsTrigger value="items">محصولات</TabsTrigger>
          <TabsTrigger value="orders">سفارش‌های من</TabsTrigger>
        </TabsList>

        <TabsContent value="items" className="mt-0">
          {loadingItems ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
              {[0, 1, 2, 3, 4, 5].map((i) => (
                <Skeleton key={i} className="h-52 rounded-2xl" />
              ))}
            </div>
          ) : items.length === 0 ? (
            <div className="text-center p-12 rounded-2xl border border-dashed border-border">
              <Package className="w-10 h-10 mx-auto mb-3 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">هنوز محصولی در فروشگاه وجود ندارد</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
              {items.map((item) => (
                <ShopCard key={item.id} item={item} onBuy={() => openBuy(item)} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="orders" className="mt-0">
          <div className="space-y-3">
            {loadingOrders ? (
              [0, 1, 2].map((i) => <Skeleton key={i} className="h-24 rounded-2xl" />)
            ) : myOrders.length === 0 ? (
              <div className="text-center p-12 rounded-2xl border border-dashed border-border">
                <Receipt className="w-10 h-10 mx-auto mb-3 text-muted-foreground" />
                <p className="text-sm text-muted-foreground mb-2">هنوز سفارشی ثبت نکرده‌اید</p>
                <Button size="sm" variant="secondary" onClick={() => setTab("items")}>
                  مشاهده محصولات
                </Button>
              </div>
            ) : (
              myOrders.map((o) => <OrderRow key={o.id} order={o} />)
            )}
          </div>

          {admin && (
            <div className="mt-8">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Receipt className="w-4 h-4 text-primary" />
                  <h3 className="font-bold">مدیریت سفارش‌ها</h3>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={loadAdminOrders}
                  disabled={loadingAdmin}
                >
                  {loadingAdmin ? <Loader2 className="w-4 h-4 animate-spin" /> : "به‌روزرسانی"}
                </Button>
              </div>
              {loadingAdmin ? (
                [0, 1, 2].map((i) => <Skeleton key={i} className="h-28 rounded-2xl mb-2" />)
              ) : adminOrders.length === 0 ? (
                <div className="text-center p-8 rounded-2xl border border-dashed border-border text-sm text-muted-foreground">
                  سفارش در انتظاری وجود ندارد
                </div>
              ) : (
                <div className="space-y-2">
                  {adminOrders.map((o) => (
                    <AdminOrderRow
                      key={o.id}
                      order={o}
                      busy={reviewingId === o.id}
                      onReview={async (action) => {
                        setReviewingId(o.id)
                        try {
                          await api(`/api/shop/orders/${o.id}`, {
                            method: "PATCH",
                            json: { action },
                          })
                          toast(action === "confirm" ? "سفارش تأیید شد" : "سفارش رد شد", "success")
                          await loadAdminOrders()
                          await loadOrders()
                          await refreshUser()
                        } catch (e: any) {
                          toast(e.message || "خطا در بررسی سفارش", "error")
                        } finally {
                          setReviewingId(null)
                        }
                      }}
                    />
                  ))}
                </div>
              )}
            </div>
          )}
        </TabsContent>
      </Tabs>

      <BuyDialog
        open={dialogOpen}
        onOpenChange={(o) => {
          setDialogOpen(o)
          if (!o) setActiveItem(null)
        }}
        item={activeItem}
        cardNumber={settings.cardNumber || ""}
        cardHolder={settings.cardHolder || ""}
        onSuccess={async () => {
          setDialogOpen(false)
          setActiveItem(null)
          await loadOrders()
          setTab("orders")
        }}
      />
    </div>
  )
}

function ShopCard({ item, onBuy }: { item: ShopItem; onBuy: () => void }) {
  const isVip = item.kind === "vip"
  const coins = item.kind === "coins" ? parseInt(item.payload, 10) || 0 : 0
  return (
    <div
      className={cn(
        "relative rounded-2xl border p-4 sm:p-5 flex flex-col gap-3 transition-all hover:shadow-soft",
        isVip
          ? "border-gold/40 bg-gradient-to-br from-gold/10 to-transparent"
          : "border-border bg-card",
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0 bg-muted">
          {item.imageUrl ? (
             
            <img src={item.imageUrl} alt="" className="w-full h-full object-cover rounded-xl" />
          ) : isVip ? (
            <Crown className="w-6 h-6 text-gold" />
          ) : (
            <Coins className="w-6 h-6 text-primary" />
          )}
        </div>
        {kindBadge(item.kind)}
      </div>

      <div className="flex-1 min-w-0">
        <h3 className="font-bold text-base mb-1 truncate">{item.title}</h3>
        <p className="text-xs text-muted-foreground line-clamp-2">
          {item.description || (coins > 0 ? `${faDigits(formatNumber(coins))} کارول‌کوین` : "—")}
        </p>
      </div>

      <div className="flex items-end justify-between gap-2 pt-1">
        <div>
          <div className="text-[10px] text-muted-foreground mb-0.5">قیمت</div>
          <div className="flex items-baseline gap-1">
            <span className="text-lg font-black tabular-nums">{faDigits(formatNumber(item.price))}</span>
            <span className="text-[10px] text-muted-foreground">تومان</span>
          </div>
        </div>
        <Button size="sm" onClick={onBuy} className={isVip ? "bg-gold text-gold-foreground hover:bg-gold/90" : ""}>
          خرید
        </Button>
      </div>
    </div>
  )
}

function OrderRow({ order }: { order: MyOrder }) {
  const meta = STATUS_META[order.status]
  const Icon = meta.icon
  return (
    <div className="rounded-2xl border border-border bg-card p-3 sm:p-4 flex items-center gap-3 hover:shadow-soft transition-all">
      <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center shrink-0", meta.cls)}>
        <Icon className="w-5 h-5" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-semibold text-sm truncate">
            {order.shopItem?.title || "سفارش سفارشی"}
          </span>
          <Badge variant="outline" className={cn("text-[10px] h-4 px-1.5", meta.cls)}>
            {meta.label}
          </Badge>
        </div>
        <div className="text-[11px] text-muted-foreground mt-0.5 flex items-center gap-2 flex-wrap tabular-nums">
          <span>{timeAgo(order.createdAt)}</span>
          <span className="opacity-50">•</span>
          <span>{faDigits(formatNumber(order.amount))} تومان</span>
          {order.coins > 0 && (
            <>
              <span className="opacity-50">•</span>
              <span className="text-gold">{faDigits(formatNumber(order.coins))} کوین</span>
            </>
          )}
        </div>
      </div>
      {order.receiptUrl && (
        <a
          href={order.receiptUrl}
          target="_blank"
          rel="noreferrer"
          className="shrink-0 p-2 rounded-lg hover:bg-accent text-muted-foreground hover:text-foreground transition-colors"
          title="مشاهده رسید"
        >
          <Receipt className="w-4 h-4" />
        </a>
      )}
    </div>
  )
}

function AdminOrderRow({
  order,
  busy,
  onReview,
}: {
  order: AdminOrder
  busy: boolean
  onReview: (action: "confirm" | "reject") => void
}) {
  const meta = STATUS_META[order.status]
  const Icon = meta.icon
  const pending = order.status === "pending"
  return (
    <div className="rounded-2xl border border-border bg-card p-3 sm:p-4">
      <div className="flex items-center gap-3">
        <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center shrink-0", meta.cls)}>
          <Icon className="w-5 h-5" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-semibold text-sm truncate">
              {order.shopItem?.title || "سفارش سفارشی"}
            </span>
            <Badge variant="outline" className={cn("text-[10px] h-4 px-1.5", meta.cls)}>
              {meta.label}
            </Badge>
          </div>
          <div className="text-[11px] text-muted-foreground mt-0.5 flex items-center gap-2 flex-wrap tabular-nums">
            <span>{order.user.displayName || order.user.username}</span>
            <span className="opacity-50">•</span>
            <span>{faDigits(formatNumber(order.amount))} تومان</span>
            <span className="opacity-50">•</span>
            <span>{timeAgo(order.createdAt)}</span>
            {order.reviewedAt && (
              <>
                <span className="opacity-50">•</span>
                <span>بررسی: {formatDate(order.reviewedAt)}</span>
              </>
            )}
          </div>
        </div>
        {order.receiptUrl && (
          <a
            href={order.receiptUrl}
            target="_blank"
            rel="noreferrer"
            className="shrink-0 p-2 rounded-lg hover:bg-accent text-muted-foreground hover:text-foreground transition-colors"
            title="مشاهده رسید"
          >
            <Receipt className="w-4 h-4" />
          </a>
        )}
      </div>
      {order.note && (
        <div className="mt-2 text-xs text-muted-foreground bg-muted/50 rounded-lg px-3 py-2">
          <span className="font-medium">یادداشت:</span> {order.note}
        </div>
      )}
      {pending && (
        <div className="mt-3 flex gap-2 justify-end">
          <Button
            size="sm"
            variant="outline"
            disabled={busy}
            onClick={() => onReview("reject")}
            className="text-rose-600 border-rose-500/30 hover:bg-rose-500/10"
          >
            <X className="w-4 h-4 ml-1" /> رد
          </Button>
          <Button
            size="sm"
            disabled={busy}
            onClick={() => onReview("confirm")}
            className="bg-emerald-600 hover:bg-emerald-700 text-white"
          >
            {busy ? <Loader2 className="w-4 h-4 animate-spin ml-1" /> : <Check className="w-4 h-4 ml-1" />}
            تأیید
          </Button>
        </div>
      )}
    </div>
  )
}

function BuyDialog({
  open,
  onOpenChange,
  item,
  cardNumber,
  cardHolder,
  onSuccess,
}: {
  open: boolean
  onOpenChange: (o: boolean) => void
  item: ShopItem | null
  cardNumber: string
  cardHolder: string
  onSuccess: () => void
}) {
  const { toast } = useApp()
  const [receiptUrl, setReceiptUrl] = useState<string | null>(null)
  const [note, setNote] = useState("")
  const [uploading, setUploading] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const fileRef = useRef<HTMLInputElement | null>(null)

  useEffect(() => {
    if (!open) {
      setReceiptUrl(null)
      setNote("")
      setUploading(false)
      setSubmitting(false)
    }
  }, [open])

  const onPickFile = async (file?: File | null) => {
    if (!file) return
    setUploading(true)
    try {
      const fd = new FormData()
      fd.append("file", file)
      fd.append("category", "receipt")
      const r = await fetch("/api/upload", { method: "POST", body: fd })
      const data = await r.json()
      if (!r.ok) throw new Error(data.error || "خطا در بارگذاری")
      setReceiptUrl(data.url)
      toast("رسید بارگذاری شد", "success")
    } catch (e: any) {
      toast(e.message || "خطا در بارگذاری رسید", "error")
    } finally {
      setUploading(false)
    }
  }

  const submit = async () => {
    if (!item) return
    if (!receiptUrl) {
      toast("لطفاً تصویر رسید را بارگذاری کنید", "error")
      return
    }
    setSubmitting(true)
    try {
      await api("/api/shop/orders", {
        method: "POST",
        json: {
          shopItemId: item.id,
          receiptUrl,
          note: note.trim() || undefined,
        },
      })
      toast("سفارش شما ثبت شد", "success")
      onSuccess()
    } catch (e: any) {
      toast(e.message || "خطا در ثبت سفارش", "error")
    } finally {
      setSubmitting(false)
    }
  }

  const copy = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text)
      toast(`${label} کپی شد`, "success")
    } catch {
      toast("کپی ناموفق بود", "error")
    }
  }

  if (!item) return null
  const isVip = item.kind === "vip"
  const coins = item.kind === "coins" ? parseInt(item.payload, 10) || 0 : 0

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto thin-scrollbar">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {isVip ? <Crown className="w-5 h-5 text-gold" /> : <Coins className="w-5 h-5 text-primary" />}
            خرید {item.title}
          </DialogTitle>
          <DialogDescription>
            {item.description || (coins > 0 ? `دریافت ${faDigits(formatNumber(coins))} کارول‌کوین` : "ثبت سفارش")}
          </DialogDescription>
        </DialogHeader>

        <div className="rounded-xl bg-primary/5 border border-primary/20 p-3 mb-3 flex items-center justify-between">
          <span className="text-xs text-muted-foreground">مبلغ قابل پرداخت</span>
          <div className="flex items-baseline gap-1">
            <span className="text-lg font-black tabular-nums">{faDigits(formatNumber(item.price))}</span>
            <span className="text-[11px] text-muted-foreground">تومان</span>
          </div>
        </div>

        <div className="space-y-3">
          <div className="text-xs font-semibold text-muted-foreground">مراحل خرید:</div>

          <div className="flex gap-2 items-start">
            <StepBadge n={1} />
            <div className="flex-1 text-sm">
              مبلغ را به کارت زیر کارت‌به‌کارت کنید:
              <div className={cn(
                "mt-2 rounded-xl border p-3 flex items-center justify-between gap-2",
                isVip ? "border-gold/40 bg-gold/5" : "border-border bg-muted/50",
              )}>
                <div className="min-w-0">
                  <div className="text-[11px] text-muted-foreground mb-0.5 flex items-center gap-1">
                    <CreditCard className="w-3 h-3" /> شماره کارت
                  </div>
                  <div className="font-mono text-sm font-bold tabular-nums tracking-wider truncate" dir="ltr">
                    {cardNumber || "—"}
                  </div>
                  {cardHolder && (
                    <div className="text-[11px] text-muted-foreground mt-1">به نام: {cardHolder}</div>
                  )}
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => copy(cardNumber, "شماره کارت")}
                  disabled={!cardNumber}
                >
                  <Copy className="w-3.5 h-3.5 ml-1" /> کپی
                </Button>
              </div>
            </div>
          </div>

          <div className="flex gap-2 items-start">
            <StepBadge n={2} />
            <div className="flex-1 text-sm">
              عکس رسید را بارگذاری کنید:
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => onPickFile(e.target.files?.[0])}
              />
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                disabled={uploading}
                className={cn(
                  "mt-2 w-full rounded-xl border-2 border-dashed p-4 flex flex-col items-center gap-2 transition-colors",
                  receiptUrl
                    ? "border-emerald-500/40 bg-emerald-500/5"
                    : "border-border hover:border-primary/50 hover:bg-accent",
                )}
              >
                {uploading ? (
                  <Loader2 className="w-6 h-6 animate-spin text-primary" />
                ) : receiptUrl ? (
                  <>
                    <Check className="w-6 h-6 text-emerald-500" />
                    <span className="text-xs text-emerald-600 font-medium">رسید بارگذاری شد</span>
                    { }
                    <img src={receiptUrl} alt="رسید" className="mt-1 max-h-24 rounded-lg" />
                  </>
                ) : (
                  <>
                    <Upload className="w-6 h-6 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">برای انتخاب کلیک کنید</span>
                    <span className="text-[10px] text-muted-foreground/70 flex items-center gap-1">
                      <ImageIcon className="w-3 h-3" /> تصویر رسید (حداکثر ۵ مگابایت)
                    </span>
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="flex gap-2 items-start">
            <StepBadge n={3} />
            <div className="flex-1 text-sm">
              یادداشت (اختیاری):
              <Textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="مثلاً کد رهگیری یا ساعت پرداخت…"
                maxLength={500}
                rows={2}
                className="mt-2 resize-none"
              />
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={submitting}>
            انصراف
          </Button>
          <Button
            onClick={submit}
            disabled={!receiptUrl || submitting || uploading}
            className={isVip ? "bg-gold text-gold-foreground hover:bg-gold/90" : ""}
          >
            {submitting ? (
              <Loader2 className="w-4 h-4 animate-spin ml-1" />
            ) : (
              <Receipt className="w-4 h-4 ml-1" />
            )}
            ثبت سفارش
          </Button>
        </DialogFooter>

        <p className="text-[11px] text-muted-foreground text-center pt-1">
          پس از ثبت سفارش، توسط مدیر بررسی شده و در صورت تأیید، کوین/VIP به حساب شما افزوده می‌شود.
        </p>
      </DialogContent>
    </Dialog>
  )
}

function StepBadge({ n }: { n: number }) {
  return (
    <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-bold flex items-center justify-center shrink-0">
      {faDigits(n)}
    </div>
  )
}
