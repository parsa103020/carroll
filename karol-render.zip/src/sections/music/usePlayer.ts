"use client"

import { create } from "zustand"

export interface PlayerTrack {
  id: string
  title: string
  artist: string
  album?: string | null
  coverUrl?: string | null
  audioUrl?: string | null
  duration: number
  plays?: number
}

type RepeatMode = "off" | "all" | "one"

interface PlayerState {
  queue: PlayerTrack[]
  currentIndex: number
  isPlaying: boolean
  currentTime: number
  duration: number
  volume: number
  muted: boolean
  repeat: RepeatMode
  shuffle: boolean
  audioEl: HTMLAudioElement | null
  expanded: boolean

  setAudioEl: (el: HTMLAudioElement | null) => void
  playTracks: (tracks: PlayerTrack[], startIndex?: number) => void
  playTrack: (track: PlayerTrack) => void
  togglePlay: () => void
  next: () => void
  prev: () => void
  seek: (t: number) => void
  setCurrentTime: (t: number) => void
  setDuration: (d: number) => void
  setVolume: (v: number) => void
  toggleMute: () => void
  cycleRepeat: () => void
  toggleShuffle: () => void
  onEnded: () => void
  setExpanded: (b: boolean) => void
  removeFromQueue: (index: number) => void
  addToQueue: (track: PlayerTrack) => void
  current: () => PlayerTrack | null
}

function shuffleArray<T>(arr: T[]): T[] {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

export const usePlayer = create<PlayerState>((set, get) => ({
  queue: [],
  currentIndex: -1,
  isPlaying: false,
  currentTime: 0,
  duration: 0,
  volume: 0.85,
  muted: false,
  repeat: "off",
  shuffle: false,
  audioEl: null,
  expanded: false,

  setAudioEl: (el) => {
    const prev = get().audioEl
    if (prev && prev !== el) {
      prev.pause()
      prev.removeEventListener("timeupdate", timeUpdateHandler)
      prev.removeEventListener("loadedmetadata", loadedMetaHandler)
      prev.removeEventListener("ended", endedHandler)
    }
    if (el) {
      el.volume = get().muted ? 0 : get().volume
      el.addEventListener("timeupdate", timeUpdateHandler)
      el.addEventListener("loadedmetadata", loadedMetaHandler)
      el.addEventListener("ended", endedHandler)
    }
    set({ audioEl: el })
  },

  playTracks: (tracks, startIndex = 0) => {
    if (!tracks.length) return
    const q = get().shuffle ? shuffleArray(tracks) : tracks
    const start = get().shuffle ? 0 : Math.max(0, Math.min(startIndex, q.length - 1))
    set({ queue: q, currentIndex: start, currentTime: 0 })
    const el = get().audioEl
    if (el && q[start]?.audioUrl) {
      el.src = q[start].audioUrl!
      el.currentTime = 0
      el.play().then(() => set({ isPlaying: true })).catch(() => set({ isPlaying: false }))
    } else {
      set({ isPlaying: false })
    }
  },

  playTrack: (track) => {
    const q = get().queue
    const existing = q.findIndex((t) => t.id === track.id)
    if (existing >= 0) {
      set({ currentIndex: existing, currentTime: 0 })
    } else {
      const newQueue = get().shuffle ? [] : [...q, track]
      if (get().shuffle) {
        set({ queue: [track], currentIndex: 0, currentTime: 0 })
      } else {
        set({ queue: newQueue, currentIndex: newQueue.length - 1, currentTime: 0 })
      }
    }
    const el = get().audioEl
    const cur = get().queue[get().currentIndex]
    if (el && cur?.audioUrl) {
      el.src = cur.audioUrl
      el.currentTime = 0
      el.play().then(() => set({ isPlaying: true })).catch(() => set({ isPlaying: false }))
    }
  },

  togglePlay: () => {
    const { audioEl, isPlaying, currentIndex, queue } = get()
    if (!audioEl || currentIndex < 0 || !queue[currentIndex]?.audioUrl) return
    if (isPlaying) {
      audioEl.pause()
      set({ isPlaying: false })
    } else {
      audioEl.play().then(() => set({ isPlaying: true })).catch(() => set({ isPlaying: false }))
    }
  },

  next: () => {
    const { queue, currentIndex, repeat, audioEl } = get()
    if (!queue.length) return
    let nextIdx = currentIndex + 1
    if (nextIdx >= queue.length) {
      if (repeat === "all") nextIdx = 0
      else {
        set({ isPlaying: false, currentTime: 0 })
        if (audioEl) audioEl.pause()
        return
      }
    }
    set({ currentIndex: nextIdx, currentTime: 0 })
    if (audioEl && queue[nextIdx]?.audioUrl) {
      audioEl.src = queue[nextIdx].audioUrl!
      audioEl.currentTime = 0
      audioEl.play().then(() => set({ isPlaying: true })).catch(() => set({ isPlaying: false }))
    }
  },

  prev: () => {
    const { queue, currentIndex, audioEl, currentTime } = get()
    if (!queue.length) return
    let idx = currentIndex
    if (currentTime > 3) {
      if (audioEl) audioEl.currentTime = 0
      set({ currentTime: 0 })
      return
    }
    idx = currentIndex - 1
    if (idx < 0) idx = queue.length - 1
    set({ currentIndex: idx, currentTime: 0 })
    if (audioEl && queue[idx]?.audioUrl) {
      audioEl.src = queue[idx].audioUrl!
      audioEl.currentTime = 0
      audioEl.play().then(() => set({ isPlaying: true })).catch(() => set({ isPlaying: false }))
    }
  },

  seek: (t) => {
    const el = get().audioEl
    if (el) el.currentTime = t
    set({ currentTime: t })
  },

  setCurrentTime: (t) => set({ currentTime: t }),
  setDuration: (d) => set({ duration: d }),

  setVolume: (v) => {
    const el = get().audioEl
    if (el) {
      el.volume = v
      el.muted = v === 0
    }
    set({ volume: v, muted: v === 0 })
  },

  toggleMute: () => {
    const el = get().audioEl
    const muted = !get().muted
    if (el) el.muted = muted
    set({ muted })
  },

  cycleRepeat: () => {
    const order: RepeatMode[] = ["off", "all", "one"]
    const i = order.indexOf(get().repeat)
    set({ repeat: order[(i + 1) % order.length] })
  },

  toggleShuffle: () => set({ shuffle: !get().shuffle }),

  onEnded: () => {
    const { repeat, queue, currentIndex, audioEl } = get()
    if (repeat === "one") {
      if (audioEl) {
        audioEl.currentTime = 0
        audioEl.play().catch(() => {})
      }
      return
    }
    let nextIdx = currentIndex + 1
    if (nextIdx >= queue.length) {
      if (repeat === "all") nextIdx = 0
      else {
        set({ isPlaying: false, currentTime: 0 })
        return
      }
    }
    set({ currentIndex: nextIdx, currentTime: 0 })
    if (audioEl && queue[nextIdx]?.audioUrl) {
      audioEl.src = queue[nextIdx].audioUrl!
      audioEl.currentTime = 0
      audioEl.play().then(() => set({ isPlaying: true })).catch(() => set({ isPlaying: false }))
    }
  },

  setExpanded: (b) => set({ expanded: b }),

  removeFromQueue: (index) => {
    const { queue, currentIndex, audioEl } = get()
    if (index < 0 || index >= queue.length) return
    const newQueue = queue.filter((_, i) => i !== index)
    let newIdx = currentIndex
    if (index < currentIndex) newIdx = currentIndex - 1
    else if (index === currentIndex) newIdx = Math.min(currentIndex, newQueue.length - 1)
    set({ queue: newQueue, currentIndex: newIdx })
    if (index === currentIndex && audioEl) {
      if (newQueue.length === 0) {
        audioEl.pause()
        audioEl.src = ""
        set({ isPlaying: false })
      } else if (newQueue[newIdx]?.audioUrl) {
        audioEl.src = newQueue[newIdx].audioUrl!
        audioEl.currentTime = 0
        audioEl.play().then(() => set({ isPlaying: true })).catch(() => set({ isPlaying: false }))
      }
    }
  },

  addToQueue: (track) => {
    const { queue, currentIndex, audioEl, isPlaying } = get()
    const newQueue = [...queue, track]
    set({ queue: newQueue })
    if (currentIndex < 0) {
      set({ currentIndex: 0, currentTime: 0 })
      if (audioEl && track.audioUrl) {
        audioEl.src = track.audioUrl
        audioEl.play().then(() => set({ isPlaying: true })).catch(() => set({ isPlaying: false }))
      }
    } else if (!isPlaying && audioEl) {
      // nothing
    }
  },

  current: () => {
    const { queue, currentIndex } = get()
    return currentIndex >= 0 && currentIndex < queue.length ? queue[currentIndex] : null
  },
}))

function timeUpdateHandler() {
  const el = usePlayer.getState().audioEl
  if (el) usePlayer.getState().setCurrentTime(el.currentTime)
}
function loadedMetaHandler() {
  const el = usePlayer.getState().audioEl
  if (el && isFinite(el.duration)) usePlayer.getState().setDuration(el.duration)
}
function endedHandler() {
  usePlayer.getState().onEnded()
}

export function formatDuration(s: number): string {
  if (!s || !isFinite(s) || s < 0) return "۰:۰۰"
  const m = Math.floor(s / 60)
  const sec = Math.floor(s % 60)
  const fa = (n: number) => n.toLocaleString("fa-IR", { useGrouping: false }).padStart(2, "۰")
  return `${m.toLocaleString("fa-IR", { useGrouping: false })}:${fa(sec)}`
}
