"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import { useApp, isAppAdmin } from "@/lib/store"
import { api, formatNumber, faDigits } from "@/lib/format"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet"
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  Music as MusicIcon,
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Volume2,
  Volume1,
  VolumeX,
  Shuffle,
  Repeat,
  Repeat1,
  Upload,
  Search,
  Plus,
  Trash2,
  ListMusic,
  MoreVertical,
  ChevronLeft,
  ChevronRight,
  Headphones,
  X,
  Clock,
  Disc3,
  ListPlus,
  Check,
  AudioLines,
  Globe,
  Save,
  Loader2,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { usePlayer, formatDuration, type PlayerTrack } from "./usePlayer"

interface TrackT extends PlayerTrack {
  createdAt?: string
  source?: string
  externalId?: string | null
  genre?: string | null
}

interface PlaylistT {
  id: string
  name: string
  count: number
  createdAt: string
}

const COVER_GRADIENTS = [
  "from-emerald-500 to-amber-500",
  "from-rose-500 to-amber-500",
  "from-emerald-600 to-teal-400",
  "from-amber-500 to-orange-500",
  "from-emerald-500 to-cyan-500",
  "from-fuchsia-500 to-amber-500",
]

function hashStr(s: string): number {
  let h = 0
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0
  return Math.abs(h)
}

function CoverArt({
  coverUrl,
  title,
  artist,
  size = "w-12 h-12",
  rounded = "rounded-lg",
  showIcon = true,
  className,
}: {
  coverUrl?: string | null
  title: string
  artist?: string
  size?: string
  rounded?: string
  showIcon?: boolean
  className?: string
}) {
  const [errored, setErrored] = useState(false)
  const g = COVER_GRADIENTS[hashStr(title + (artist || "")) % COVER_GRADIENTS.length]
  if (coverUrl && !errored) {
    return (
      <div className={cn("relative overflow-hidden bg-muted shrink-0", size, rounded, className)}>
        <img
          src={coverUrl}
          alt={title}
          loading="lazy"
          onError={() => setErrored(true)}
          className="w-full h-full object-cover"
        />
      </div>
    )
  }
  return (
    <div
      className={cn(
        "relative shrink-0 bg-gradient-to-br flex items-center justify-center text-white",
        size,
        rounded,
        g,
        className,
      )}
    >
      {showIcon ? <MusicIcon className="w-1/2 h-1/2 opacity-90" /> : null}
    </div>
  )
}

function UploadDialog({ open, onOpenChange, onCreated }: {
  open: boolean
  onOpenChange: (b: boolean) => void
  onCreated: (t: TrackT) => void
}) {
  const { toast } = useApp()
  const [title, setTitle] = useState("")
  const [artist, setArtist] = useState("")
  const [album, setAlbum] = useState("")
  const [audioFile, setAudioFile] = useState<File | null>(null)
  const [coverFile, setCoverFile] = useState<File | null>(null)
  const [duration, setDuration] = useState(0)
  const [audioUrl, setAudioUrl] = useState<string | null>(null)
  const [coverUrl, setCoverUrl] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [uploadingAudio, setUploadingAudio] = useState(false)
  const [uploadingCover, setUploadingCover] = useState(false)
  const durationProbeRef = useRef<HTMLAudioElement | null>(null)

  useEffect(() => {
    if (!open) {
      setTitle("")
      setArtist("")
      setAlbum("")
      setAudioFile(null)
      setCoverFile(null)
      setDuration(0)
      setAudioUrl(null)
      setCoverUrl(null)
    }
  }, [open])

  async function probeDuration(file: File) {
    const url = URL.createObjectURL(file)
    const a = new Audio()
    a.src = url
    durationProbeRef.current = a
    await new Promise<void>((resolve) => {
      const done = () => resolve()
      a.addEventListener("loadedmetadata", done, { once: true })
      a.addEventListener("error", done, { once: true })
      setTimeout(done, 4000)
    })
    if (isFinite(a.duration) && a.duration > 0) setDuration(Math.round(a.duration))
    URL.revokeObjectURL(url)
  }

  async function pickAudio(files: FileList | null) {
    const f = files?.[0]
    if (!f) return
    if (!f.type.startsWith("audio/")) {
      toast("فقط فایل صوتی مجاز است", "error")
      return
    }
    setAudioFile(f)
    setAudioUrl(null)
    if (!title) {
      const base = f.name.replace(/\.[^.]+$/, "")
      setTitle(base)
    }
    probeDuration(f)
    setUploadingAudio(true)
    try {
      const fd = new FormData()
      fd.append("file", f)
      fd.append("category", "drive")
      const r = await api<{ url: string }>("/api/upload", { method: "POST", body: fd })
      setAudioUrl(r.url)
      toast("فایل صوتی آپلود شد", "success")
    } catch (e: any) {
      toast(e.message || "خطا در آپلود صوت", "error")
      setAudioFile(null)
    } finally {
      setUploadingAudio(false)
    }
  }

  async function pickCover(files: FileList | null) {
    const f = files?.[0]
    if (!f) return
    if (!f.type.startsWith("image/")) {
      toast("فقط تصویر مجاز است", "error")
      return
    }
    setCoverFile(f)
    setCoverUrl(null)
    setUploadingCover(true)
    try {
      const fd = new FormData()
      fd.append("file", f)
      fd.append("category", "drive")
      const r = await api<{ url: string }>("/api/upload", { method: "POST", body: fd })
      setCoverUrl(r.url)
    } catch (e: any) {
      toast(e.message || "خطا در آپلود کاور", "error")
      setCoverFile(null)
    } finally {
      setUploadingCover(false)
    }
  }

  async function submit() {
    if (!title.trim() || !artist.trim()) {
      toast("عنوان و خواننده الزامی است", "error")
      return
    }
    if (!audioUrl) {
      toast("فایل صوتی هنوز آپلود نشده", "error")
      return
    }
    setSubmitting(true)
    try {
      const r = await api<{ track: TrackT }>("/api/music/tracks", {
        method: "POST",
        json: {
          title: title.trim(),
          artist: artist.trim(),
          album: album.trim() || undefined,
          audioUrl,
          coverUrl: coverUrl || undefined,
          duration,
        },
      })
      toast("آهنگ منتشر شد", "success")
      onCreated(r.track)
      onOpenChange(false)
    } catch (e: any) {
      toast(e.message || "خطا در انتشار", "error")
    } finally {
      setSubmitting(false)
    }
  }

  const canSubmit = !!title.trim() && !!artist.trim() && !!audioUrl && !submitting

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>آپلود آهنگ جدید</DialogTitle>
          <DialogDescription>فایل صوتی و کاور (اختیاری) را آپلود کنید.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="flex gap-3">
            <label className="cursor-pointer">
              <div className="w-20 h-20 rounded-lg overflow-hidden border border-border/60 bg-muted">
                {coverUrl ? (
                  <img src={coverUrl} alt="" className="w-full h-full object-cover" />
                ) : (
                  <div className={cn("w-full h-full bg-gradient-to-br from-emerald-500 to-amber-500 flex items-center justify-center text-white")}>
                    <Disc3 className="w-8 h-8" />
                  </div>
                )}
              </div>
              <input type="file" accept="image/*" className="hidden" onChange={(e) => pickCover(e.target.files)} />
            </label>
            <div className="flex-1 space-y-2">
              <Input placeholder="عنوان آهنگ *" value={title} onChange={(e) => setTitle(e.target.value)} />
              <Input placeholder="نام خواننده *" value={artist} onChange={(e) => setArtist(e.target.value)} />
            </div>
          </div>
          <Input placeholder="آلبوم (اختیاری)" value={album} onChange={(e) => setAlbum(e.target.value)} />

          <div className="rounded-lg border border-dashed border-border p-3">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0">
                <div className={cn("w-9 h-9 rounded-md flex items-center justify-center shrink-0", audioUrl ? "bg-primary/15 text-primary" : "bg-muted text-muted-foreground")}>
                  <AudioLines className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-medium truncate">{audioFile?.name || "فایل صوتی انتخاب نشده"}</div>
                  <div className="text-[11px] text-muted-foreground">
                    {uploadingAudio ? "در حال آپلود…" : audioUrl ? "آپلود کامل شد" : "mp3، m4a، wav و…"}
                  </div>
                </div>
              </div>
              <label>
                <Button asChild size="sm" variant="outline">
                  <span>
                    <Upload className="w-3.5 h-3.5 ml-1" /> انتخاب
                  </span>
                </Button>
                <input type="file" accept="audio/*" className="hidden" onChange={(e) => pickAudio(e.target.files)} />
              </label>
            </div>
            {duration > 0 && (
              <div className="mt-2 text-[11px] text-muted-foreground flex items-center gap-1">
                <Clock className="w-3 h-3" /> مدت: {faDigits(formatDuration(duration))}
              </div>
            )}
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)} disabled={submitting}>لغو</Button>
          <Button className="gradient-karol text-white" disabled={!canSubmit} onClick={submit}>
            {submitting ? "…" : "انتشار آهنگ"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

function CreatePlaylistDialog({ open, onOpenChange, onCreated }: {
  open: boolean
  onOpenChange: (b: boolean) => void
  onCreated: (p: PlaylistT) => void
}) {
  const { toast } = useApp()
  const [name, setName] = useState("")
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => { if (!open) setName("") }, [open])

  async function submit() {
    if (!name.trim()) return
    setSubmitting(true)
    try {
      const r = await api<{ playlist: PlaylistT }>("/api/music/playlists", {
        method: "POST",
        json: { name: name.trim() },
      })
      toast("پلی‌لیست ساخته شد", "success")
      onCreated(r.playlist)
      onOpenChange(false)
    } catch (e: any) {
      toast(e.message || "خطا", "error")
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>پلی‌لیست جدید</DialogTitle>
        </DialogHeader>
        <Input
          placeholder="نام پلی‌لیست"
          value={name}
          autoFocus
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") submit() }}
        />
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>لغو</Button>
          <Button className="gradient-karol text-white" disabled={!name.trim() || submitting} onClick={submit}>
            {submitting ? "…" : "ساخت"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

function AddToPlaylistMenu({ trackId, playlists, onAdded }: {
  trackId: string
  playlists: PlaylistT[]
  onAdded: (pl: PlaylistT) => void
}) {
  const { toast } = useApp()
  const [busy, setBusy] = useState<string | null>(null)
  async function add(pl: PlaylistT) {
    setBusy(pl.id)
    try {
      await api(`/api/music/playlists/${pl.id}/items`, {
        method: "POST",
        json: { trackId },
      })
      toast(`به «${pl.name}» اضافه شد`, "success")
      onAdded(pl)
    } catch (e: any) {
      toast(e.message || "خطا", "error")
    } finally {
      setBusy(null)
    }
  }
  return (
    <>
      <DropdownMenuLabel>افزودن به پلی‌لیست</DropdownMenuLabel>
      {playlists.length === 0 ? (
        <div className="px-2 py-1.5 text-xs text-muted-foreground">پلی‌لیستی ندارید</div>
      ) : (
        playlists.map((p) => (
          <DropdownMenuItem
            key={p.id}
            disabled={busy === p.id}
            onClick={() => add(p)}
            className="justify-between"
          >
            <span className="truncate max-w-[160px]">{p.name}</span>
            <span className="text-[10px] text-muted-foreground tabular-nums">{faDigits(p.count)}</span>
          </DropdownMenuItem>
        ))
      )}
    </>
  )
}

function TrackRow({
  track,
  isActive,
  isPlaying,
  onPlay,
  onDelete,
  playlists,
  onAddedToPlaylist,
  showPlays = true,
  external = false,
  saved = false,
  onSave,
  saving = false,
}: {
  track: TrackT
  isActive: boolean
  isPlaying: boolean
  onPlay: () => void
  onDelete?: () => void
  playlists: PlaylistT[]
  onAddedToPlaylist: (pl: PlaylistT) => void
  showPlays?: boolean
  external?: boolean
  saved?: boolean
  onSave?: () => void
  saving?: boolean
}) {
  const canDelete = !!onDelete
  const showSave = external && onSave && !saved
  return (
    <div
      className={cn(
        "group flex items-center gap-3 p-2 rounded-lg transition-colors cursor-pointer",
        isActive ? "bg-primary/10" : "hover:bg-accent/60",
      )}
      onClick={onPlay}
    >
      <div className="relative shrink-0">
        <CoverArt coverUrl={track.coverUrl} title={track.title} artist={track.artist} size="w-11 h-11" />
        <div
          className={cn(
            "absolute inset-0 rounded-lg flex items-center justify-center bg-black/40 transition-opacity",
            isActive ? "opacity-100" : "opacity-0 group-hover:opacity-100",
          )}
        >
          {isActive && isPlaying ? (
            <Pause className="w-4 h-4 text-white" />
          ) : (
            <Play className="w-4 h-4 text-white fill-current ms-0.5" />
          )}
        </div>
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 min-w-0">
          <span className={cn("text-sm font-medium truncate", isActive && "text-primary")}>{track.title}</span>
          {external && (
            <Badge variant="secondary" className="shrink-0 px-1.5 py-0 text-[9px] gap-0.5 font-normal">
              <Globe className="w-2.5 h-2.5" /> آی‌تیونز
            </Badge>
          )}
          {external && saved && (
            <Badge variant="outline" className="shrink-0 px-1.5 py-0 text-[9px] gap-0.5 font-normal text-primary border-primary/40">
              <Check className="w-2.5 h-2.5" /> ذخیره
            </Badge>
          )}
        </div>
        <div className="text-xs text-muted-foreground truncate">
          {track.artist}{track.album ? ` · ${track.album}` : ""}{track.genre && external ? ` · ${track.genre}` : ""}
        </div>
      </div>
      {showPlays && !external && (
        <div className="hidden sm:flex items-center gap-1 text-[11px] text-muted-foreground tabular-nums">
          <Headphones className="w-3 h-3" />
          {faDigits(formatNumber(track.plays || 0))}
        </div>
      )}
      {external && (
        <div className="hidden sm:block text-[10px] text-muted-foreground/80 shrink-0">۳۰ث پیش‌نمایش</div>
      )}
      <div className="text-[11px] text-muted-foreground tabular-nums w-10 text-center shrink-0">
        {faDigits(formatDuration(track.duration))}
      </div>
      {showSave ? (
        <Button
          variant="outline"
          size="sm"
          className="h-8 shrink-0 gap-1"
          disabled={saving}
          onClick={(e) => { e.stopPropagation(); onSave!() }}
        >
          {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
          ذخیره
        </Button>
      ) : (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 shrink-0"
              onClick={(e) => e.stopPropagation()}
            >
              <MoreVertical className="w-4 h-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
            <DropdownMenuItem onClick={onPlay}>
              <Play className="w-4 h-4 ml-2" /> پخش
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <AddToPlaylistMenu trackId={track.id} playlists={playlists} onAdded={onAddedToPlaylist} />
            {canDelete && (
              <>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={onDelete}>
                  <Trash2 className="w-4 h-4 ml-2" /> حذف آهنگ
                </DropdownMenuItem>
              </>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      )}
    </div>
  )
}

function PlayerBar() {
  const {
    queue,
    currentIndex,
    isPlaying,
    currentTime,
    duration,
    volume,
    muted,
    repeat,
    shuffle,
    togglePlay,
    next,
    prev,
    seek,
    setVolume,
    toggleMute,
    cycleRepeat,
    toggleShuffle,
    setExpanded,
  } = usePlayer()

  const track = currentIndex >= 0 ? queue[currentIndex] : null
  if (!track) return null

  const dur = duration || track.duration || 0
  const VolIcon = muted || volume === 0 ? VolumeX : volume < 0.5 ? Volume1 : Volume2

  return (
    <div className="shrink-0 border-t border-border/60 glass">
      <div className="px-3 sm:px-4 py-2.5 flex items-center gap-3">
        <div className="hidden sm:flex items-center gap-1">
          <Button variant="ghost" size="icon" className="h-9 w-9" onClick={toggleShuffle} title="پخش تصادفی">
            <Shuffle className={cn("w-4 h-4", shuffle && "text-primary")} />
          </Button>
          <Button variant="ghost" size="icon" className="h-9 w-9" onClick={prev} title="قبلی">
            <SkipBack className="w-4 h-4" />
          </Button>
        </div>
        <Button
          variant="default"
          size="icon"
          className="h-10 w-10 rounded-full gradient-karol text-white shrink-0"
          onClick={togglePlay}
        >
          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ms-0.5 fill-current" />}
        </Button>
        <div className="hidden sm:flex items-center gap-1">
          <Button variant="ghost" size="icon" className="h-9 w-9" onClick={next} title="بعدی">
            <SkipForward className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-9 w-9" onClick={cycleRepeat} title="تکرار">
            {repeat === "one" ? <Repeat1 className="w-4 h-4 text-primary" /> : <Repeat className={cn("w-4 h-4", repeat !== "off" && "text-primary")} />}
          </Button>
        </div>

        <button
          className="flex items-center gap-3 min-w-0 flex-1 text-right cursor-pointer"
          onClick={() => setExpanded(true)}
        >
          <CoverArt coverUrl={track.coverUrl} title={track.title} artist={track.artist} size="w-11 h-11" showIcon />
          <div className="min-w-0 hidden sm:block flex-1">
            <div className="text-sm font-semibold truncate">{track.title}</div>
            <div className="text-xs text-muted-foreground truncate">{track.artist}</div>
          </div>
          <div className="min-w-0 flex-1 sm:hidden">
            <div className="text-sm font-semibold truncate">{track.title}</div>
            <div className="text-xs text-muted-foreground truncate">{track.artist}</div>
          </div>
        </button>

        <div className="hidden md:flex items-center gap-2 flex-1 max-w-md">
          <span className="text-[11px] text-muted-foreground tabular-nums w-9 text-center">
            {faDigits(formatDuration(currentTime))}
          </span>
          <Slider
            value={[currentTime]}
            max={dur || 1}
            step={1}
            onValueChange={(v) => seek(v[0])}
            className="flex-1"
          />
          <span className="text-[11px] text-muted-foreground tabular-nums w-9 text-center">
            {faDigits(formatDuration(dur))}
          </span>
        </div>

        <div className="hidden lg:flex items-center gap-2 w-28">
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={toggleMute}>
            <VolIcon className="w-4 h-4" />
          </Button>
          <Slider
            value={[muted ? 0 : volume]}
            max={1}
            step={0.01}
            onValueChange={(v) => setVolume(v[0])}
            className="flex-1"
          />
        </div>
      </div>

      <div className="md:hidden px-3 pb-2 -mt-1">
        <Slider
          value={[currentTime]}
          max={dur || 1}
          step={1}
          onValueChange={(v) => seek(v[0])}
        />
        <div className="flex items-center justify-between mt-1 text-[10px] text-muted-foreground tabular-nums">
          <span>{faDigits(formatDuration(currentTime))}</span>
          <span>{faDigits(formatDuration(dur))}</span>
        </div>
      </div>
    </div>
  )
}

function NowPlayingSheet() {
  const {
    expanded,
    setExpanded,
    queue,
    currentIndex,
    isPlaying,
    currentTime,
    duration,
    volume,
    muted,
    repeat,
    shuffle,
    togglePlay,
    next,
    prev,
    seek,
    setVolume,
    toggleMute,
    cycleRepeat,
    toggleShuffle,
    removeFromQueue,
  } = usePlayer()

  const track = currentIndex >= 0 ? queue[currentIndex] : null

  return (
    <Sheet open={expanded} onOpenChange={setExpanded}>
      <SheetContent side="bottom" className="h-[85vh] p-0 flex flex-col rounded-t-2xl">
        <SheetHeader className="px-4 pt-4 pb-2 border-b border-border/60">
          <SheetTitle className="text-center">در حال پخش</SheetTitle>
        </SheetHeader>
        {track && (
          <div className="flex-1 overflow-y-auto thin-scrollbar">
            <div className="p-4 flex flex-col items-center">
              <CoverArt
                coverUrl={track.coverUrl}
                title={track.title}
                artist={track.artist}
                size="w-56 h-56"
                rounded="rounded-2xl"
                className="shadow-soft"
              />
              <div className="mt-5 text-center">
                <div className="text-xl font-bold">{track.title}</div>
                <div className="text-sm text-muted-foreground mt-1">{track.artist}{track.album ? ` · ${track.album}` : ""}</div>
              </div>

              <div className="w-full max-w-md mt-6">
                <Slider
                  value={[currentTime]}
                  max={duration || track.duration || 1}
                  step={1}
                  onValueChange={(v) => seek(v[0])}
                />
                <div className="flex justify-between mt-1.5 text-[11px] text-muted-foreground tabular-nums">
                  <span>{faDigits(formatDuration(currentTime))}</span>
                  <span>{faDigits(formatDuration(duration || track.duration))}</span>
                </div>
              </div>

              <div className="flex items-center gap-2 mt-5">
                <Button variant="ghost" size="icon" className="h-10 w-10" onClick={toggleShuffle}>
                  <Shuffle className={cn("w-5 h-5", shuffle && "text-primary")} />
                </Button>
                <Button variant="ghost" size="icon" className="h-12 w-12" onClick={prev}>
                  <SkipBack className="w-5 h-5" />
                </Button>
                <Button
                  size="icon"
                  className="h-14 w-14 rounded-full gradient-karol text-white"
                  onClick={togglePlay}
                >
                  {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ms-0.5 fill-current" />}
                </Button>
                <Button variant="ghost" size="icon" className="h-12 w-12" onClick={next}>
                  <SkipForward className="w-5 h-5" />
                </Button>
                <Button variant="ghost" size="icon" className="h-10 w-10" onClick={cycleRepeat}>
                  {repeat === "one" ? <Repeat1 className="w-5 h-5 text-primary" /> : <Repeat className={cn("w-5 h-5", repeat !== "off" && "text-primary")} />}
                </Button>
              </div>

              <div className="w-full max-w-md mt-5 flex items-center gap-2">
                <Button variant="ghost" size="icon" className="h-9 w-9" onClick={toggleMute}>
                  {muted || volume === 0 ? <VolumeX className="w-4 h-4" /> : volume < 0.5 ? <Volume1 className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </Button>
                <Slider
                  value={[muted ? 0 : volume]}
                  max={1}
                  step={0.01}
                  onValueChange={(v) => setVolume(v[0])}
                />
              </div>
            </div>

            <div className="px-4 pb-6">
              <div className="flex items-center gap-2 mb-2 text-sm font-semibold text-muted-foreground">
                <ListMusic className="w-4 h-4" /> صف پخش
                <span className="text-xs font-normal">({faDigits(queue.length)} آهنگ)</span>
              </div>
              <div className="space-y-1 max-h-72 overflow-y-auto thin-scrollbar">
                {queue.map((t, i) => (
                  <div
                    key={t.id + i}
                    className={cn(
                      "group flex items-center gap-3 p-2 rounded-lg cursor-pointer",
                      i === currentIndex ? "bg-primary/10" : "hover:bg-accent/60",
                    )}
                    onClick={() => {
                      usePlayer.getState().playTracks(queue, i)
                    }}
                  >
                    <CoverArt coverUrl={t.coverUrl} title={t.title} artist={t.artist} size="w-9 h-9" />
                    <div className="flex-1 min-w-0">
                      <div className={cn("text-sm truncate", i === currentIndex && "text-primary")}>{t.title}</div>
                      <div className="text-[11px] text-muted-foreground truncate">{t.artist}</div>
                    </div>
                    <span className="text-[11px] text-muted-foreground tabular-nums">{faDigits(formatDuration(t.duration))}</span>
                    <button
                      className="opacity-0 group-hover:opacity-100 transition-opacity p-1"
                      onClick={(e) => { e.stopPropagation(); removeFromQueue(i) }}
                    >
                      <X className="w-3.5 h-3.5 text-muted-foreground hover:text-destructive" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </SheetContent>
    </Sheet>
  )
}

function EmptyState({ icon: Icon, title, desc, action }: {
  icon: any
  title: string
  desc?: string
  action?: React.ReactNode
}) {
  return (
    <div className="text-center py-12 px-4">
      <div className="w-14 h-14 mx-auto rounded-2xl bg-muted flex items-center justify-center mb-3">
        <Icon className="w-7 h-7 text-muted-foreground" />
      </div>
      <div className="font-semibold text-sm">{title}</div>
      {desc && <div className="text-xs text-muted-foreground mt-1 max-w-xs mx-auto">{desc}</div>}
      {action && <div className="mt-4 flex justify-center">{action}</div>}
    </div>
  )
}

const GENRE_CHIPS = [
  { label: "پاپ فارسی", term: "persian pop" },
  { label: "ایرانی", term: "iranian music" },
  { label: "پاپ", term: "pop hits" },
  { label: "راک", term: "rock" },
  { label: "کلاسیک", term: "classical" },
  { label: "فارسی", term: "farsi" },
  { label: "جاز", term: "jazz" },
  { label: "الکترونیک", term: "electronic" },
]

function GenreChips({ active, onPick }: { active: string; onPick: (term: string) => void }) {
  return (
    <div className="flex items-center gap-2 overflow-x-auto thin-scrollbar pb-1 -mx-1 px-1">
      {GENRE_CHIPS.map((c) => {
        const isActive = active === c.term
        return (
          <button
            key={c.term}
            onClick={() => onPick(isActive ? "" : c.term)}
            className={cn(
              "shrink-0 px-3 h-8 rounded-full text-xs font-medium border transition-colors",
              isActive
                ? "bg-primary text-primary-foreground border-primary"
                : "bg-card border-border hover:border-primary/40 hover:text-primary",
            )}
          >
            {c.label}
          </button>
        )
      })}
    </div>
  )
}

export default function MusicSection() {
  const { user, toast } = useApp()
  const [tab, setTab] = useState<"library" | "playlists" | "queue">("library")
  const [tracks, setTracks] = useState<TrackT[]>([])
  const [popular, setPopular] = useState<TrackT[]>([])
  const [loading, setLoading] = useState(true)
  const [q, setQ] = useState("")
  const [searching, setSearching] = useState(false)
  const [extTracks, setExtTracks] = useState<TrackT[]>([])
  const [extLoading, setExtLoading] = useState(false)
  const [extError, setExtError] = useState<string | null>(null)
  const [savedExtIds, setSavedExtIds] = useState<Set<string>>(new Set())
  const [savingExtId, setSavingExtId] = useState<string | null>(null)
  const [uploadOpen, setUploadOpen] = useState(false)
  const [createPlOpen, setCreatePlOpen] = useState(false)
  const [playlists, setPlaylists] = useState<PlaylistT[]>([])
  const [activePlaylistId, setActivePlaylistId] = useState<string | null>(null)
  const [activePlaylist, setActivePlaylist] = useState<{ id: string; name: string; tracks: TrackT[] } | null>(null)
  const [loadingPl, setLoadingPl] = useState(false)
  const [deleteTrackId, setDeleteTrackId] = useState<string | null>(null)
  const [deletePlaylistId, setDeletePlaylistId] = useState<string | null>(null)

  const audioRef = useRef<HTMLAudioElement | null>(null)
  const setAudioEl = usePlayer((s) => s.setAudioEl)
  const playTracks = usePlayer((s) => s.playTracks)
  const playTrack = usePlayer((s) => s.playTrack)
  const currentTrack = usePlayer((s) => s.current())
  const isPlaying = usePlayer((s) => s.isPlaying)
  const queue = usePlayer((s) => s.queue)
  const removeFromQueue = usePlayer((s) => s.removeFromQueue)

  const isAdmin = isAppAdmin(user)

  const loadTracks = useCallback(async (search?: string) => {
    if (search !== undefined) {
      setSearching(true)
    } else {
      setLoading(true)
    }
    try {
      const url = search ? `/api/music/tracks?q=${encodeURIComponent(search)}` : `/api/music/tracks`
      const d = await api<{ tracks: TrackT[]; popular: TrackT[] }>(url)
      setTracks(d.tracks)
      if (d.popular) setPopular(d.popular)
    } catch (e: any) {
      toast(e.message || "خطا در بارگذاری", "error")
    } finally {
      setLoading(false)
      setSearching(false)
    }
  }, [toast])

  const loadExternal = useCallback(async (search: string) => {
    setExtLoading(true)
    setExtError(null)
    try {
      const d = await api<{ tracks: TrackT[]; error?: string }>(
        `/api/music/search-external?q=${encodeURIComponent(search)}`,
      )
      setExtTracks(d.tracks || [])
      if (d.error) setExtError(d.error)
    } catch {
      setExtTracks([])
      setExtError("جستجوی خارجی موقتاً در دسترس نیست")
    } finally {
      setExtLoading(false)
    }
  }, [])

  const loadPlaylists = useCallback(async () => {
    try {
      const d = await api<{ playlists: PlaylistT[] }>("/api/music/playlists")
      setPlaylists(d.playlists)
    } catch (e: any) {
      // ignore
    }
  }, [])

  useEffect(() => {
    loadTracks()
    loadPlaylists()
  }, [loadTracks, loadPlaylists])

  useEffect(() => {
    if (audioRef.current) setAudioEl(audioRef.current)
  }, [setAudioEl])

  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current)
    if (q === "") {
      setExtTracks([])
      setExtError(null)
      loadTracks()
      return
    }
    debounceRef.current = setTimeout(() => {
      loadTracks(q)
      loadExternal(q)
    }, 400)
    return () => { if (debounceRef.current) clearTimeout(debounceRef.current) }
  }, [q, loadTracks, loadExternal])

  // increment plays when current track changes (local tracks only)
  const lastIncremented = useRef<string | null>(null)
  useEffect(() => {
    if (!currentTrack) return
    if (lastIncremented.current === currentTrack.id) return
    lastIncremented.current = currentTrack.id
    if (currentTrack.id.startsWith("ext-")) return
    fetch(`/api/music/${currentTrack.id}/play`, { method: "POST" }).catch(() => {})
  }, [currentTrack])

  function playFromList(list: TrackT[], index: number) {
    const playable = list.filter((t) => !!t.audioUrl)
    if (!playable.length) {
      toast("این آهنگ فایل صوتی ندارد", "error")
      return
    }
    playTracks(playable, list.findIndex((t) => t.id === playable[index].id))
  }

  function playSingle(t: TrackT) {
    if (!t.audioUrl) {
      toast("این آهنگ فایل صوتی ندارد", "error")
      return
    }
    playTrack(t)
  }

  async function saveExternalTrack(t: TrackT) {
    if (!t.externalId || !t.audioUrl) return
    setSavingExtId(t.id)
    try {
      const r = await api<{ track: TrackT; existed: boolean }>("/api/music/tracks", {
        method: "POST",
        json: {
          title: t.title,
          artist: t.artist,
          album: t.album || undefined,
          audioUrl: t.audioUrl,
          coverUrl: t.coverUrl || undefined,
          duration: t.duration,
          source: "external",
          externalId: t.externalId,
        },
      })
      setSavedExtIds((s) => new Set(s).add(t.id))
      setTracks((ts) => {
        if (ts.some((x) => x.id === r.track.id)) return ts
        return [r.track, ...ts]
      })
      toast(r.existed ? "از قبل در کتابخانه ذخیره شده" : "به کتابخانه ذخیره شد", "success")
    } catch (e: any) {
      toast(e.message || "خطا در ذخیره", "error")
    } finally {
      setSavingExtId(null)
    }
  }

  async function openPlaylist(id: string) {
    setActivePlaylistId(id)
    setLoadingPl(true)
    try {
      const d = await api<{ playlist: { id: string; name: string; tracks: TrackT[] } }>(`/api/music/playlists/${id}`)
      setActivePlaylist(d.playlist)
    } catch (e: any) {
      toast(e.message || "خطا", "error")
    } finally {
      setLoadingPl(false)
    }
  }

  function onAddedToPlaylist(pl: PlaylistT) {
    setPlaylists((ps) => ps.map((p) => (p.id === pl.id ? { ...p, count: p.count + 1 } : p)))
    if (activePlaylist?.id === pl.id) {
      // refresh active
      openPlaylist(pl.id)
    }
  }

  async function confirmDeleteTrack() {
    if (!deleteTrackId) return
    try {
      await api(`/api/music/tracks/${deleteTrackId}`, { method: "DELETE" })
      toast("آهنگ حذف شد", "success")
      setTracks((ts) => ts.filter((t) => t.id !== deleteTrackId))
      setPopular((ps) => ps.filter((t) => t.id !== deleteTrackId))
      if (activePlaylist) {
        setActivePlaylist({
          ...activePlaylist,
          tracks: activePlaylist.tracks.filter((t) => t.id !== deleteTrackId),
        })
      }
    } catch (e: any) {
      toast(e.message || "خطا در حذف", "error")
    } finally {
      setDeleteTrackId(null)
    }
  }

  async function removeTrackFromPlaylist(itemId: string) {
    if (!activePlaylist) return
    try {
      await api(`/api/music/playlists/${activePlaylist.id}/items?itemId=${itemId}`, { method: "DELETE" })
      setActivePlaylist({
        ...activePlaylist,
        tracks: activePlaylist.tracks.filter((t) => (t as any).itemId !== itemId),
      })
      setPlaylists((ps) => ps.map((p) => (p.id === activePlaylist.id ? { ...p, count: Math.max(0, p.count - 1) } : p)))
      toast("حذف شد از پلی‌لیست", "success")
    } catch (e: any) {
      toast(e.message || "خطا", "error")
    }
  }

  async function confirmDeletePlaylist() {
    if (!deletePlaylistId) return
    try {
      await api(`/api/music/playlists/${deletePlaylistId}`, { method: "DELETE" })
      toast("پلی‌لیست حذف شد", "success")
      setPlaylists((ps) => ps.filter((p) => p.id !== deletePlaylistId))
      if (activePlaylistId === deletePlaylistId) {
        setActivePlaylistId(null)
        setActivePlaylist(null)
      }
    } catch (e: any) {
      toast(e.message || "خطا", "error")
    } finally {
      setDeletePlaylistId(null)
    }
  }

  function onTrackCreated(t: TrackT) {
    setTracks((ts) => [t, ...ts])
    toast("آهنگ به کتابخانه اضافه شد", "success")
  }

  return (
    <div className="h-full flex flex-col">
      {/* Hidden audio element */}
      <audio ref={audioRef} preload="metadata" />

      {/* Scrollable content */}
      <div className="flex-1 min-h-0 overflow-y-auto thin-scrollbar">
        <div className="max-w-5xl mx-auto px-3 sm:px-5 py-4 sm:py-6 pb-6 space-y-4">
          {/* Header */}
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div>
              <h1 className="text-xl sm:text-2xl font-black flex items-center gap-2">
                <span className="text-gradient-karol">موزیک</span>
                <Badge variant="secondary" className="font-normal">{faDigits(tracks.length)} آهنگ</Badge>
              </h1>
              <p className="text-xs text-muted-foreground mt-0.5">کتابخانه موسیقی کارول</p>
            </div>
            <Button className="gradient-karol text-white" onClick={() => setUploadOpen(true)}>
              <Upload className="w-4 h-4 ml-1.5" /> آپلود آهنگ
            </Button>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
            <Input
              placeholder="جستجوی آهنگ، خواننده یا آلبوم…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              className="pr-9 h-10 bg-card"
            />
            {q && (
              <button
                onClick={() => setQ("")}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Genre discovery chips */}
          <GenreChips active={q} onPick={(term) => setQ(term)} />

          <Tabs value={tab} onValueChange={(v) => setTab(v as any)}>
            <TabsList>
              <TabsTrigger value="library"><MusicIcon className="w-3.5 h-3.5" /> کتابخانه</TabsTrigger>
              <TabsTrigger value="playlists"><ListMusic className="w-3.5 h-3.5" /> پلی‌لیست‌های من</TabsTrigger>
              <TabsTrigger value="queue">
                <ListPlus className="w-3.5 h-3.5" /> صف پخش
                {queue.length > 0 && (
                  <span className="ms-1 text-[10px] tabular-nums">{faDigits(queue.length)}</span>
                )}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="library" className="mt-4 space-y-5">
              {/* Popular */}
              {!q && popular.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-2.5">
                    <Headphones className="w-4 h-4 text-gold" />
                    <h2 className="font-bold text-sm">محبوب‌ترین‌ها</h2>
                  </div>
                  <div className="flex gap-3 overflow-x-auto thin-scrollbar pb-2 -mx-1 px-1">
                    {popular.map((t) => (
                      <button
                        key={t.id}
                        onClick={() => playSingle(t)}
                        className="shrink-0 w-36 text-right group"
                      >
                        <div className="relative w-36 h-36 rounded-xl overflow-hidden bg-muted mb-2">
                          <CoverArt coverUrl={t.coverUrl} title={t.title} artist={t.artist} size="w-36 h-36" rounded="rounded-xl" />
                          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors flex items-center justify-center">
                            <div className="w-11 h-11 rounded-full gradient-karol text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                              <Play className="w-5 h-5 ms-0.5 fill-current" />
                            </div>
                          </div>
                        </div>
                        <div className="text-xs font-semibold truncate">{t.title}</div>
                        <div className="text-[11px] text-muted-foreground truncate">{t.artist}</div>
                        <div className="text-[10px] text-muted-foreground mt-0.5 flex items-center gap-1">
                          <Headphones className="w-3 h-3" /> {faDigits(formatNumber(t.plays || 0))}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Track list */}
              <div>
                <div className="flex items-center gap-2 mb-2.5">
                  <MusicIcon className="w-4 h-4 text-primary" />
                  <h2 className="font-bold text-sm">
                    {q ? `نتایج جستجو برای «${q}»` : "همه آهنگ‌ها"}
                  </h2>
                  {searching && <span className="text-xs text-muted-foreground">…</span>}
                </div>
                {loading ? (
                  <div className="space-y-2">
                    {[...Array(6)].map((_, i) => (
                      <div key={i} className="flex items-center gap-3 p-2">
                        <Skeleton className="w-11 h-11 rounded-lg" />
                        <div className="flex-1 space-y-1.5">
                          <Skeleton className="h-3 w-40" />
                          <Skeleton className="h-2.5 w-24" />
                        </div>
                        <Skeleton className="w-8 h-8 rounded-full" />
                      </div>
                    ))}
                  </div>
                ) : tracks.length === 0 ? (
                  <EmptyState
                    icon={MusicIcon}
                    title={q ? "نتیجه‌ای پیدا نشد" : "هنوز آهنگی آپلود نشده"}
                    desc={q ? "عبارت دیگری را امتحان کنید" : "اولین آهنگ را آپلود کنید و موسیقی کارول را شروع کنید."}
                    action={!q ? (
                      <Button className="gradient-karol text-white" onClick={() => setUploadOpen(true)}>
                        <Upload className="w-4 h-4 ml-1.5" /> آپلود اولین آهنگ
                      </Button>
                    ) : undefined}
                  />
                ) : (
                  <Card className="shadow-soft">
                    <CardContent className="p-2 sm:p-3 space-y-0.5">
                      {tracks.map((t, i) => (
                        <TrackRow
                          key={t.id}
                          track={t}
                          isActive={currentTrack?.id === t.id}
                          isPlaying={isPlaying}
                          onPlay={() => playFromList(tracks, i)}
                          playlists={playlists}
                          onAddedToPlaylist={onAddedToPlaylist}
                          onDelete={isAdmin ? () => setDeleteTrackId(t.id) : undefined}
                        />
                      ))}
                    </CardContent>
                  </Card>
                )}
              </div>

              {/* External (iTunes) results */}
              {q && (
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2.5 flex-wrap">
                    <div className="flex items-center gap-2 min-w-0">
                      <Globe className="w-4 h-4 text-accent" />
                      <h2 className="font-bold text-sm">نتایج آی‌تیونز</h2>
                      {extLoading && <Loader2 className="w-3.5 h-3.5 animate-spin text-muted-foreground" />}
                      {!extLoading && extTracks.length > 0 && (
                        <Badge variant="secondary" className="font-normal text-[10px]">
                          {faDigits(extTracks.length)} نتیجه
                        </Badge>
                      )}
                    </div>
                    <span className="text-[10px] text-muted-foreground/80">
                      پخش ۳۰ ثانیه پیش‌نمایش — برای ذخیره دائمی، علامت «ذخیره» را بزنید
                    </span>
                  </div>
                  {extError ? (
                    <div className="rounded-lg border border-border/60 bg-card p-3 text-xs text-muted-foreground text-center">
                      {extError}
                    </div>
                  ) : extLoading ? (
                    <div className="space-y-2">
                      {[...Array(5)].map((_, i) => (
                        <div key={i} className="flex items-center gap-3 p-2">
                          <Skeleton className="w-11 h-11 rounded-lg" />
                          <div className="flex-1 space-y-1.5">
                            <Skeleton className="h-3 w-44" />
                            <Skeleton className="h-2.5 w-28" />
                          </div>
                          <Skeleton className="h-8 w-16 rounded-md" />
                        </div>
                      ))}
                    </div>
                  ) : extTracks.length === 0 ? (
                    <div className="rounded-lg border border-dashed border-border/60 p-3 text-xs text-muted-foreground text-center">
                      نتیجه خارجی‌ای پیدا نشد
                    </div>
                  ) : (
                    <Card className="shadow-soft">
                      <CardContent className="p-2 sm:p-3 space-y-0.5">
                        {extTracks.map((t, i) => (
                          <TrackRow
                            key={t.id}
                            track={t}
                            external
                            saved={savedExtIds.has(t.id)}
                            saving={savingExtId === t.id}
                            onSave={() => saveExternalTrack(t)}
                            isActive={currentTrack?.id === t.id}
                            isPlaying={isPlaying}
                            onPlay={() => playFromList(extTracks, i)}
                            playlists={playlists}
                            onAddedToPlaylist={onAddedToPlaylist}
                            showPlays={false}
                          />
                        ))}
                      </CardContent>
                    </Card>
                  )}
                </div>
              )}
            </TabsContent>

            <TabsContent value="playlists" className="mt-4 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="font-bold text-sm">پلی‌لیست‌های من</h2>
                <Button size="sm" variant="outline" onClick={() => setCreatePlOpen(true)}>
                  <Plus className="w-4 h-4 ml-1" /> پلی‌لیست جدید
                </Button>
              </div>

              {activePlaylist ? (
                <Card className="shadow-soft">
                  <CardContent className="p-3 sm:p-4">
                    <div className="flex items-center gap-3 mb-3">
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setActivePlaylist(null); setActivePlaylistId(null) }}>
                        <ChevronRight className="w-4 h-4" />
                      </Button>
                      <div className="flex-1 min-w-0">
                        <div className="font-bold truncate">{activePlaylist.name}</div>
                        <div className="text-xs text-muted-foreground">{faDigits(activePlaylist.tracks.length)} آهنگ</div>
                      </div>
                      {activePlaylist.tracks.length > 0 && (
                        <Button size="sm" className="gradient-karol text-white" onClick={() => playFromList(activePlaylist.tracks, 0)}>
                          <Play className="w-4 h-4 ml-1" /> پخش همه
                        </Button>
                      )}
                    </div>
                    {loadingPl ? (
                      <div className="space-y-2">
                        {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-12 w-full rounded-lg" />)}
                      </div>
                    ) : activePlaylist.tracks.length === 0 ? (
                      <EmptyState
                        icon={ListMusic}
                        title="پلی‌لیست خالی است"
                        desc="از منوی هر آهنگ، آن را به این پلی‌لیست اضافه کنید."
                      />
                    ) : (
                      <div className="space-y-0.5">
                        {activePlaylist.tracks.map((t, i) => (
                          <div key={t.id + i}>
                            <TrackRow
                              track={t}
                              isActive={currentTrack?.id === t.id}
                              isPlaying={isPlaying}
                              onPlay={() => playFromList(activePlaylist.tracks, i)}
                              playlists={playlists}
                              onAddedToPlaylist={onAddedToPlaylist}
                              onDelete={isAdmin ? () => setDeleteTrackId(t.id) : undefined}
                            />
                            <button
                              className="block w-full text-center text-[11px] text-muted-foreground hover:text-destructive py-1"
                              onClick={() => removeTrackFromPlaylist((t as any).itemId)}
                            >
                              حذف از این پلی‌لیست
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ) : (
                playlists.length === 0 ? (
                  <EmptyState
                    icon={ListMusic}
                    title="هنوز پلی‌لیستی نساخته‌اید"
                    desc="پلی‌لیست‌های خود را بسازید و آهنگ‌های مورد علاقه را جمع‌آوری کنید."
                    action={
                      <Button className="gradient-karol text-white" onClick={() => setCreatePlOpen(true)}>
                        <Plus className="w-4 h-4 ml-1.5" /> ساخت پلی‌لیست
                      </Button>
                    }
                  />
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {playlists.map((p) => (
                      <Card key={p.id} className="shadow-soft hover:border-primary/40 transition-colors cursor-pointer" onClick={() => openPlaylist(p.id)}>
                        <CardContent className="p-4 flex items-center gap-3">
                          <div className="w-12 h-12 rounded-lg gradient-karol flex items-center justify-center text-white shrink-0">
                            <ListMusic className="w-5 h-5" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="font-semibold truncate">{p.name}</div>
                            <div className="text-xs text-muted-foreground">{faDigits(p.count)} آهنگ</div>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-muted-foreground hover:text-destructive"
                            onClick={(e) => { e.stopPropagation(); setDeletePlaylistId(p.id) }}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )
              )}
            </TabsContent>

            <TabsContent value="queue" className="mt-4">
              {queue.length === 0 ? (
                <EmptyState
                  icon={ListPlus}
                  title="صف پخش خالی است"
                  desc="آهنگی را پخش کنید تا صف پخش ساخته شود."
                />
              ) : (
                <Card className="shadow-soft">
                  <CardContent className="p-3 space-y-0.5">
                    <div className="text-xs text-muted-foreground px-2 py-1.5 mb-1">
                      {faDigits(queue.length)} آهنگ در صف — با کلیک روی هر آهنگ، پخش می‌شود.
                    </div>
                    {queue.map((t, i) => (
                      <div
                        key={t.id + i}
                        className={cn(
                          "group flex items-center gap-3 p-2 rounded-lg cursor-pointer",
                          currentTrack?.id === t.id ? "bg-primary/10" : "hover:bg-accent/60",
                        )}
                        onClick={() => playTracks(queue, i)}
                      >
                        <div className="w-6 text-center text-xs text-muted-foreground tabular-nums shrink-0">
                          {currentTrack?.id === t.id && isPlaying ? (
                            <Pause className="w-3.5 h-3.5 mx-auto text-primary" />
                          ) : (
                            faDigits(i + 1)
                          )}
                        </div>
                        <CoverArt coverUrl={t.coverUrl} title={t.title} artist={t.artist} size="w-10 h-10" />
                        <div className="flex-1 min-w-0">
                          <div className={cn("text-sm truncate", currentTrack?.id === t.id && "text-primary")}>{t.title}</div>
                          <div className="text-[11px] text-muted-foreground truncate">{t.artist}</div>
                        </div>
                        <span className="text-[11px] text-muted-foreground tabular-nums">{faDigits(formatDuration(t.duration))}</span>
                        <button
                          className="opacity-0 group-hover:opacity-100 transition-opacity p-1"
                          onClick={(e) => { e.stopPropagation(); removeFromQueue(i) }}
                        >
                          <X className="w-3.5 h-3.5 text-muted-foreground hover:text-destructive" />
                        </button>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Player bar */}
      <PlayerBar />

      {/* Hidden expanded now playing */}
      <NowPlayingSheet />

      {/* Upload dialog */}
      <UploadDialog open={uploadOpen} onOpenChange={setUploadOpen} onCreated={onTrackCreated} />

      {/* Create playlist */}
      <CreatePlaylistDialog
        open={createPlOpen}
        onOpenChange={setCreatePlOpen}
        onCreated={(p) => setPlaylists((ps) => [p, ...ps])}
      />

      {/* Delete track confirm */}
      <AlertDialog open={!!deleteTrackId} onOpenChange={(o) => { if (!o) setDeleteTrackId(null) }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف آهنگ</AlertDialogTitle>
            <AlertDialogDescription>این آهنگ برای همیشه حذف می‌شود. مطمئن هستید؟</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>لغو</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDeleteTrack}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete playlist confirm */}
      <AlertDialog open={!!deletePlaylistId} onOpenChange={(o) => { if (!o) setDeletePlaylistId(null) }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف پلی‌لیست</AlertDialogTitle>
            <AlertDialogDescription>این پلی‌لیست حذف می‌شود ولی آهنگ‌ها در کتابخانه باقی می‌مانند.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>لغو</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDeletePlaylist}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
