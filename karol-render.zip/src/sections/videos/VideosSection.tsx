"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import { useApp, isAppAdmin } from "@/lib/store"
import { api, timeAgo, formatNumber, faDigits } from "@/lib/format"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Search,
  Plus,
  Play,
  Heart,
  MessageCircle,
  Share2,
  Eye,
  Trash2,
  ChevronLeft,
  Film,
  Send,
  Clock,
  X,
  ImageIcon,
  Upload as UploadIcon,
  Crown,
} from "lucide-react"

interface OwnerT {
  id: string
  username: string
  displayName: string | null
  avatarUrl: string | null
  isVip: boolean
}

interface VideoT {
  id: string
  title: string
  description: string | null
  videoUrl: string
  thumbnailUrl: string | null
  category: string
  duration: number
  views: number
  createdAt: string
  likes: number
  comments: number
  liked: boolean
  owner: OwnerT
}

interface CommentT {
  id: string
  content: string
  createdAt: string
  user: OwnerT
}

const CATEGORIES: { key: string; label: string }[] = [
  { key: "all", label: "همه" },
  { key: "entertainment", label: "سرگرمی" },
  { key: "education", label: "آموزش" },
  { key: "music", label: "موسیقی" },
  { key: "sports", label: "ورزش" },
  { key: "technology", label: "تکنولوژی" },
  { key: "news", label: "خبری" },
  { key: "other", label: "دیگر" },
]

function categoryLabel(key: string): string {
  return CATEGORIES.find((c) => c.key === key)?.label || "دیگر"
}

function formatDuration(s: number): string {
  if (!s || s < 0) return "۰:۰۰"
  const sec = Math.floor(s)
  const h = Math.floor(sec / 3600)
  const m = Math.floor((sec % 3600) / 60)
  const r = sec % 60
  const pad = (n: number) => String(n).padStart(2, "0")
  const str = h > 0 ? `${h}:${pad(m)}:${pad(r)}` : `${m}:${pad(r)}`
  return faDigits(str)
}

function initials(o: OwnerT): string {
  const n = o.displayName?.[0] || o.username[0]
  return n ? n.toUpperCase() : "?"
}

function uploadWithProgress(
  url: string,
  fd: FormData,
  onProgress: (pct: number) => void,
): Promise<any> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest()
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100))
    }
    xhr.onload = () => {
      try {
        const r = JSON.parse(xhr.responseText || "{}")
        if (xhr.status >= 200 && xhr.status < 300) resolve(r)
        else reject(new Error(r.error || `خطا ${xhr.status}`))
      } catch {
        reject(new Error(`خطا ${xhr.status}`))
      }
    }
    xhr.onerror = () => reject(new Error("خطای شبکه"))
    xhr.open("POST", url)
    xhr.send(fd)
  })
}

async function extractVideoMeta(
  file: File,
): Promise<{ duration: number; thumbnail: Blob | null }> {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file)
    const v = document.createElement("video")
    v.preload = "metadata"
    v.muted = true
    v.src = url
    let settled = false
    const finish = (duration: number, thumbnail: Blob | null) => {
      if (settled) return
      settled = true
      URL.revokeObjectURL(url)
      resolve({ duration, thumbnail })
    }
    v.addEventListener("loadedmetadata", () => {
      const duration = v.duration || 0
      try {
        v.currentTime = Math.min(2, duration * 0.25)
      } catch {
        finish(duration, null)
      }
    })
    v.addEventListener("seeked", () => {
      try {
        const canvas = document.createElement("canvas")
        const w = v.videoWidth || 640
        const h = v.videoHeight || 360
        canvas.width = w
        canvas.height = h
        const ctx = canvas.getContext("2d")
        if (!ctx) return finish(v.duration || 0, null)
        ctx.drawImage(v, 0, 0, w, h)
        canvas.toBlob(
          (blob) => finish(v.duration || 0, blob),
          "image/jpeg",
          0.85,
        )
      } catch {
        finish(v.duration || 0, null)
      }
    })
    v.addEventListener("error", () => finish(0, null))
    setTimeout(() => finish(v.duration || 0, null), 6000)
  })
}

function OwnerRow({ owner, size = "sm" }: { owner: OwnerT; size?: "sm" | "md" }) {
  const dim = size === "md" ? "w-10 h-10" : "w-8 h-8"
  return (
    <div className="flex items-center gap-2 min-w-0">
      <Avatar className={cn(dim, "shrink-0")}>
        <AvatarImage src={owner.avatarUrl || undefined} />
        <AvatarFallback className="bg-primary/15 text-primary text-xs font-bold">
          {initials(owner)}
        </AvatarFallback>
      </Avatar>
      <div className="min-w-0">
        <div className="flex items-center gap-1">
          <span className={cn("truncate font-medium", size === "md" ? "text-sm" : "text-xs")}>
            {owner.displayName || owner.username}
          </span>
          {owner.isVip && <Crown className="w-3 h-3 text-gold shrink-0" />}
        </div>
        {size === "md" && (
          <div className="text-xs text-muted-foreground truncate">@{owner.username}</div>
        )}
      </div>
    </div>
  )
}

function VideoCard({ v, onClick }: { v: VideoT; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="group text-right rounded-xl overflow-hidden bg-card border border-border/60 hover:border-primary/40 hover:shadow-soft transition-all"
    >
      <div className="relative aspect-video bg-muted overflow-hidden">
        {v.thumbnailUrl ? (
          <img
            src={v.thumbnailUrl}
            alt={v.title}
            loading="lazy"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center gradient-karol opacity-30">
            <Film className="w-8 h-8 text-white" />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
            <Play className="w-5 h-5 text-white fill-white mr-0.5" />
          </div>
        </div>
        {v.duration > 0 && (
          <span className="absolute bottom-1.5 left-1.5 px-1.5 py-0.5 rounded bg-black/75 text-white text-[10px] font-medium tabular-nums">
            {formatDuration(v.duration)}
          </span>
        )}
        <span className="absolute top-1.5 right-1.5 px-1.5 py-0.5 rounded bg-black/60 text-white text-[10px] font-medium flex items-center gap-1">
          <Eye className="w-3 h-3" />
          {formatNumber(v.views)}
        </span>
      </div>
      <div className="p-3 space-y-2">
        <h3 className="text-sm font-semibold leading-snug line-clamp-2 min-h-[2.5rem]">
          {v.title}
        </h3>
        <OwnerRow owner={v.owner} />
        <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
          <span>{timeAgo(v.createdAt)}</span>
          <span className="flex items-center gap-1">
            <Heart className="w-3 h-3" />
            {formatNumber(v.likes)}
          </span>
          <span className="flex items-center gap-1">
            <MessageCircle className="w-3 h-3" />
            {formatNumber(v.comments)}
          </span>
        </div>
      </div>
    </button>
  )
}

function GridSkeleton() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      {[...Array(8)].map((_, i) => (
        <div key={i} className="rounded-xl overflow-hidden bg-card border border-border/60">
          <Skeleton className="aspect-video w-full" />
          <div className="p-3 space-y-2">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-2/3" />
            <div className="flex items-center gap-2 pt-1">
              <Skeleton className="w-8 h-8 rounded-full" />
              <Skeleton className="h-3 w-24" />
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

function EmptyState({ hasQuery }: { hasQuery: boolean }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 text-center">
      <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
        <Film className="w-8 h-8 text-primary" />
      </div>
      <h3 className="text-base font-semibold mb-1">
        {hasQuery ? "ویدیویی پیدا نشد" : "هنوز ویدیویی وجود ندارد"}
      </h3>
      <p className="text-sm text-muted-foreground max-w-xs">
        {hasQuery
          ? "عبارت دیگری را جستجو کنید یا فیلتر را تغییر دهید."
          : "اولین ویدیو را آپلود کنید و تجربه‌ای متفاوت بسازید."}
      </p>
    </div>
  )
}

function VideoGrid({
  videos,
  loading,
  hasQuery,
  onOpen,
}: {
  videos: VideoT[]
  loading: boolean
  hasQuery: boolean
  onOpen: (v: VideoT) => void
}) {
  if (loading) return <GridSkeleton />
  if (videos.length === 0) return <EmptyState hasQuery={hasQuery} />
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      {videos.map((v) => (
        <VideoCard key={v.id} v={v} onClick={() => onOpen(v)} />
      ))}
    </div>
  )
}

function CommentsSection({ videoId }: { videoId: string }) {
  const { user, toast } = useApp()
  const [comments, setComments] = useState<CommentT[]>([])
  const [loading, setLoading] = useState(true)
  const [text, setText] = useState("")
  const [posting, setPosting] = useState(false)
  const [cursor, setCursor] = useState<string | null>(null)
  const [loadingMore, setLoadingMore] = useState(false)
  const [hasMore, setHasMore] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const d = await api<{ comments: CommentT[]; nextCursor: string | null }>(
        `/api/videos/${videoId}/comments`,
      )
      setComments(d.comments)
      setCursor(d.nextCursor)
      setHasMore(!!d.nextCursor)
    } catch {
    } finally {
      setLoading(false)
    }
  }, [videoId])

  useEffect(() => {
    load()
  }, [load])

  async function loadMore() {
    if (!cursor) return
    setLoadingMore(true)
    try {
      const d = await api<{ comments: CommentT[]; nextCursor: string | null }>(
        `/api/videos/${videoId}/comments?cursor=${cursor}`,
      )
      setComments((c) => [...c, ...d.comments])
      setCursor(d.nextCursor)
      setHasMore(!!d.nextCursor)
    } catch {
    } finally {
      setLoadingMore(false)
    }
  }

  async function submit() {
    const content = text.trim()
    if (!content || posting) return
    setPosting(true)
    try {
      const d = await api<{ comment: CommentT }>(`/api/videos/${videoId}/comments`, {
        method: "POST",
        json: { content },
      })
      setComments((c) => [d.comment, ...c])
      setText("")
    } catch (e: any) {
      toast(e.message, "error")
    } finally {
      setPosting(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <MessageCircle className="w-4 h-4 text-primary" />
        <h3 className="text-sm font-semibold">نظرات</h3>
        <span className="text-xs text-muted-foreground">({formatNumber(comments.length)})</span>
      </div>

      {user && (
        <div className="flex gap-2">
          <Avatar className="w-9 h-9 shrink-0">
            <AvatarImage src={user.avatarUrl || undefined} />
            <AvatarFallback className="bg-primary/15 text-primary text-xs font-bold">
              {(user.displayName?.[0] || user.username[0] || "?").toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 flex gap-2">
            <Input
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="نظرتان را بنویسید…"
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault()
                  submit()
                }
              }}
              className="flex-1"
              maxLength={2000}
            />
            <Button
              size="icon"
              onClick={submit}
              disabled={posting || !text.trim()}
              className="gradient-karol text-white shrink-0"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}

      {loading ? (
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="flex gap-2">
              <Skeleton className="w-9 h-9 rounded-full shrink-0" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-3 w-32" />
                <Skeleton className="h-4 w-full" />
              </div>
            </div>
          ))}
        </div>
      ) : comments.length === 0 ? (
        <div className="text-center py-8 text-sm text-muted-foreground">
          هنوز نظری ثبت نشده. اولین نفر باشید!
        </div>
      ) : (
        <div className="space-y-3">
          {comments.map((c) => (
            <div key={c.id} className="flex gap-2">
              <Avatar className="w-9 h-9 shrink-0">
                <AvatarImage src={c.user.avatarUrl || undefined} />
                <AvatarFallback className="bg-primary/15 text-primary text-xs font-bold">
                  {initials(c.user)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-xs font-semibold">
                    {c.user.displayName || c.user.username}
                  </span>
                  {c.user.isVip && <Crown className="w-3 h-3 text-gold" />}
                  <span className="text-[11px] text-muted-foreground">
                    {timeAgo(c.createdAt)}
                  </span>
                </div>
                <p className="text-sm leading-relaxed whitespace-pre-wrap break-words mt-0.5">
                  {c.content}
                </p>
              </div>
            </div>
          ))}
          {hasMore && (
            <div className="flex justify-center pt-2">
              <Button variant="ghost" size="sm" onClick={loadMore} disabled={loadingMore}>
                {loadingMore ? "…" : "بیشتر"}
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

function VideoDetail({
  video,
  onBack,
}: {
  video: VideoT
  onBack: () => void
}) {
  const { user, toast } = useApp()
  const [current, setCurrent] = useState<VideoT>(video)
  const [liked, setLiked] = useState(video.liked)
  const [likes, setLikes] = useState(video.likes)
  const [descOpen, setDescOpen] = useState(false)
  const [related, setRelated] = useState<VideoT[]>([])
  const [relatedLoading, setRelatedLoading] = useState(true)
  const viewIncremented = useRef(false)
  const [confirmingDelete, setConfirmingDelete] = useState(false)
  const [deleting, setDeleting] = useState(false)

  useEffect(() => {
    setCurrent(video)
    setLiked(video.liked)
    setLikes(video.likes)
    setDescOpen(false)
    viewIncremented.current = false
  }, [video])

  useEffect(() => {
    if (viewIncremented.current) return
    viewIncremented.current = true
    api(`/api/videos/${current.id}/view`, { method: "POST" })
      .then((d: any) => {
        setCurrent((c) => ({ ...c, views: d.views }))
      })
      .catch(() => {})
  }, [current.id])

  useEffect(() => {
    setRelatedLoading(true)
    const params = new URLSearchParams({ limit: "8", exclude: current.id })
    if (current.category && current.category !== "general") {
      params.set("category", current.category)
    }
    api<{ videos: VideoT[] }>(`/api/videos?${params.toString()}`)
      .then((d) => {
        if (d.videos.length < 4) {
          api<{ videos: VideoT[] }>(`/api/videos?limit=8&exclude=${current.id}`)
            .then((d2) => {
              const seen = new Set(d.videos.map((v) => v.id))
              const merged = [...d.videos, ...d2.videos.filter((v) => !seen.has(v.id))].slice(0, 8)
              setRelated(merged)
            })
            .finally(() => setRelatedLoading(false))
        } else {
          setRelated(d.videos)
          setRelatedLoading(false)
        }
      })
      .catch(() => setRelatedLoading(false))
  }, [current.id, current.category])

  async function toggleLike() {
    if (!user) {
      toast("برای لایک ابتدا وارد شوید", "error")
      return
    }
    const prevLiked = liked
    const prevLikes = likes
    setLiked(!liked)
    setLikes(likes + (liked ? -1 : 1))
    try {
      const d = await api<{ liked: boolean; likes: number }>(
        `/api/videos/${current.id}/like`,
        { method: "POST" },
      )
      setLiked(d.liked)
      setLikes(d.likes)
    } catch {
      setLiked(prevLiked)
      setLikes(prevLikes)
    }
  }

  function share() {
    const url = window.location.href
    if (navigator.share) {
      navigator.share({ title: current.title, url }).catch(() => {})
    } else if (navigator.clipboard) {
      navigator.clipboard.writeText(url).then(
        () => toast("لینک کپی شد", "success"),
        () => toast("کپی لینک ناموفق بود", "error"),
      )
    } else {
      toast("اشتراک‌گذاری پشتیبانی نمی‌شود", "error")
    }
  }

  async function doDelete() {
    setDeleting(true)
    try {
      await api(`/api/videos/${current.id}`, { method: "DELETE" })
      toast("ویدیو حذف شد", "success")
      onBack()
    } catch (e: any) {
      toast(e.message, "error")
    } finally {
      setDeleting(false)
      setConfirmingDelete(false)
    }
  }

  const canDelete = user && (user.id === current.owner.id || isAppAdmin(user))
  const longDesc = (current.description?.length || 0) > 200

  return (
    <div className="px-3 sm:px-4 py-3">
      <button
        onClick={onBack}
        className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-3 transition-colors"
      >
        <ChevronLeft className="w-4 h-4" />
        بازگشت به ویدیوها
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 space-y-4">
          <video
            key={current.id}
            controls
            autoPlay
            playsInline
            poster={current.thumbnailUrl || undefined}
            className="w-full aspect-video bg-black rounded-xl"
            src={current.videoUrl}
          />

          <div>
            <h1 className="text-lg sm:text-xl font-bold leading-snug">{current.title}</h1>
            <div className="flex flex-wrap items-center gap-2 mt-2 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <Eye className="w-3.5 h-3.5" />
                {formatNumber(current.views)} بازدید
              </span>
              <span>·</span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                {timeAgo(current.createdAt)}
              </span>
              <span>·</span>
              <Badge variant="secondary" className="text-[11px]">
                {categoryLabel(current.category)}
              </Badge>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 pb-3 border-b border-border/60">
            <Button
              variant={liked ? "default" : "outline"}
              size="sm"
              onClick={toggleLike}
              className={cn(
                liked && "bg-rose-500 hover:bg-rose-600 text-white border-rose-500",
              )}
            >
              <Heart className={cn("w-4 h-4 ml-1", liked && "fill-current")} />
              {formatNumber(likes)}
            </Button>
            <Button variant="outline" size="sm" onClick={share}>
              <Share2 className="w-4 h-4 ml-1" />
              اشتراک‌گذاری
            </Button>
            {canDelete && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setConfirmingDelete(true)}
                className="text-destructive hover:text-destructive hover:bg-destructive/10"
              >
                <Trash2 className="w-4 h-4 ml-1" />
                حذف
              </Button>
            )}
            <div className="mr-auto">
              <OwnerRow owner={current.owner} size="md" />
            </div>
          </div>

          {current.description && (
            <div className="bg-muted/40 rounded-lg p-3 text-sm leading-relaxed">
              <p
                className={cn(
                  "whitespace-pre-wrap break-words",
                  !descOpen && longDesc && "line-clamp-3",
                )}
              >
                {current.description}
              </p>
              {longDesc && (
                <button
                  onClick={() => setDescOpen((o) => !o)}
                  className="text-xs font-semibold text-primary mt-2 hover:underline"
                >
                  {descOpen ? "نمایش کمتر" : "نمایش بیشتر"}
                </button>
              )}
            </div>
          )}

          <div className="pt-2">
            <CommentsSection videoId={current.id} />
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-muted-foreground">ویدیوهای مرتبط</h3>
          {relatedLoading ? (
            <div className="space-y-3">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="flex gap-2">
                  <Skeleton className="w-32 aspect-video rounded-lg shrink-0" />
                  <div className="flex-1 space-y-2 py-1">
                    <Skeleton className="h-3 w-full" />
                    <Skeleton className="h-3 w-2/3" />
                    <Skeleton className="h-2.5 w-20" />
                  </div>
                </div>
              ))}
            </div>
          ) : related.length === 0 ? (
            <p className="text-xs text-muted-foreground">ویدیوی مرتبطی یافت نشد.</p>
          ) : (
            <div className="space-y-2 max-h-[calc(100vh-9rem)] overflow-y-auto thin-scrollbar pr-1">
              {related.map((rv) => (
                <RelatedCard key={rv.id} v={rv} onClick={() => setCurrent(rv)} />
              ))}
            </div>
          )}
        </div>
      </div>

      <Dialog open={confirmingDelete} onOpenChange={setConfirmingDelete}>
        <DialogContent showCloseButton={false} className="max-w-sm">
          <DialogHeader>
            <DialogTitle>حذف ویدیو</DialogTitle>
            <DialogDescription>
              آیا از حذف این ویدیو مطمئن هستید؟ این عمل قابل بازگشت نیست.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setConfirmingDelete(false)} disabled={deleting}>
              انصراف
            </Button>
            <Button
              onClick={doDelete}
              disabled={deleting}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              {deleting ? "…" : "حذف کن"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

function RelatedCard({ v, onClick }: { v: VideoT; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex gap-2 text-right w-full group rounded-lg p-1 hover:bg-accent/50 transition-colors"
    >
      <div className="relative w-32 aspect-video rounded-lg overflow-hidden bg-muted shrink-0">
        {v.thumbnailUrl ? (
          <img
            src={v.thumbnailUrl}
            alt={v.title}
            loading="lazy"
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center gradient-karol opacity-30">
            <Film className="w-5 h-5 text-white" />
          </div>
        )}
        {v.duration > 0 && (
          <span className="absolute bottom-1 left-1 px-1 py-0.5 rounded bg-black/75 text-white text-[9px] tabular-nums">
            {formatDuration(v.duration)}
          </span>
        )}
      </div>
      <div className="flex-1 min-w-0 py-0.5">
        <h4 className="text-xs font-semibold leading-snug line-clamp-2">{v.title}</h4>
        <div className="text-[11px] text-muted-foreground mt-1 truncate">
          {v.owner.displayName || v.owner.username}
        </div>
        <div className="flex items-center gap-2 text-[10px] text-muted-foreground mt-0.5">
          <span className="flex items-center gap-0.5">
            <Eye className="w-2.5 h-2.5" />
            {formatNumber(v.views)}
          </span>
          <span>{timeAgo(v.createdAt)}</span>
        </div>
      </div>
    </button>
  )
}

function UploadDialog({
  open,
  onClose,
  onUploaded,
}: {
  open: boolean
  onClose: () => void
  onUploaded: (v: VideoT) => void
}) {
  const { toast } = useApp()
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [category, setCategory] = useState("general")
  const [videoFile, setVideoFile] = useState<File | null>(null)
  const [videoPreview, setVideoPreview] = useState<string | null>(null)
  const [thumbnailUrl, setThumbnailUrl] = useState<string | null>(null)
  const [thumbnailPreview, setThumbnailPreview] = useState<string | null>(null)
  const [duration, setDuration] = useState(0)
  const [progress, setProgress] = useState(0)
  const [stage, setStage] = useState<"idle" | "uploading" | "finalizing">("idle")
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    if (!open) {
      setTitle("")
      setDescription("")
      setCategory("general")
      setVideoFile(null)
      if (videoPreview) URL.revokeObjectURL(videoPreview)
      setVideoPreview(null)
      setThumbnailUrl(null)
      if (thumbnailPreview) URL.revokeObjectURL(thumbnailPreview)
      setThumbnailPreview(null)
      setDuration(0)
      setProgress(0)
      setStage("idle")
      setSubmitting(false)
    }
  }, [open])

  async function onPickVideo(file: File | null) {
    if (!file) return
    if (!file.type.startsWith("video/")) {
      toast("فقط فایل ویدیویی مجاز است", "error")
      return
    }
    if (videoPreview) URL.revokeObjectURL(videoPreview)
    setVideoFile(file)
    setVideoPreview(URL.createObjectURL(file))
    setThumbnailUrl(null)
    setThumbnailPreview(null)
    setDuration(0)
    toast("در حال آماده‌سازی پیش‌نمایش…", "default")
    try {
      const meta = await extractVideoMeta(file)
      setDuration(meta.duration)
      if (meta.thumbnail) {
        const fd = new FormData()
        fd.append("file", meta.thumbnail, "thumb.jpg")
        fd.append("category", "drive")
        const r = await api<{ url: string }>("/api/upload", { method: "POST", body: fd })
        setThumbnailUrl(r.url)
        setThumbnailPreview(r.url)
      }
    } catch (e: any) {
      toast("پیش‌نمایش ساخته نشد، مشکلی نیست", "error")
    }
  }

  async function onPickThumb(file: File | null) {
    if (!file) return
    if (!file.type.startsWith("image/")) {
      toast("فقط تصویر مجاز است", "error")
      return
    }
    try {
      const fd = new FormData()
      fd.append("file", file)
      fd.append("category", "drive")
      const r = await api<{ url: string }>("/api/upload", { method: "POST", body: fd })
      if (thumbnailPreview && thumbnailPreview.startsWith("/storage")) {
        // previous auto thumb already uploaded, just replace preview
      }
      setThumbnailUrl(r.url)
      setThumbnailPreview(r.url)
    } catch (e: any) {
      toast(e.message, "error")
    }
  }

  async function submit() {
    if (!title.trim()) return toast("عنوان الزامی است", "error")
    if (!videoFile) return toast("ویدیو را انتخاب کنید", "error")
    setSubmitting(true)
    setStage("uploading")
    setProgress(0)
    try {
      const fd = new FormData()
      fd.append("file", videoFile)
      fd.append("category", "video")
      const r = await uploadWithProgress("/api/upload", fd, setProgress)
      setStage("finalizing")
      const d = await api<{ video: VideoT }>("/api/videos", {
        method: "POST",
        json: {
          title: title.trim(),
          description: description.trim() || null,
          videoUrl: r.url,
          thumbnailUrl,
          category,
          duration,
        },
      })
      toast("ویدیو منتشر شد", "success")
      onUploaded(d.video)
    } catch (e: any) {
      toast(e.message || "خطا در آپلود", "error")
    } finally {
      setSubmitting(false)
      setStage("idle")
    }
  }

  const busy = submitting

  return (
    <Dialog open={open} onOpenChange={(o) => !busy && onClose()}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto thin-scrollbar">
        <DialogHeader>
          <DialogTitle>آپلود ویدیوی جدید</DialogTitle>
          <DialogDescription>ویدیوی خود را منتشر کنید تا دیگران ببینند.</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="v-title">عنوان *</Label>
            <Input
              id="v-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="یک عنوان جذاب بنویسید"
              maxLength={200}
              disabled={busy}
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="v-desc">توضیحات</Label>
            <Textarea
              id="v-desc"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="توضیحات ویدیو (اختیاری)"
              rows={3}
              maxLength={5000}
              disabled={busy}
            />
          </div>

          <div className="space-y-1.5">
            <Label>دسته‌بندی</Label>
            <Select value={category} onValueChange={setCategory} disabled={busy}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="انتخاب دسته" />
              </SelectTrigger>
              <SelectContent>
                {CATEGORIES.filter((c) => c.key !== "all").map((c) => (
                  <SelectItem key={c.key} value={c.key}>
                    {c.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label>فایل ویدیو *</Label>
            <label className="block">
              <div className="relative aspect-video rounded-lg overflow-hidden border-2 border-dashed border-border/70 hover:border-primary/50 transition-colors cursor-pointer bg-muted/30">
                {videoPreview ? (
                  <video
                    src={videoPreview}
                    className="w-full h-full object-contain bg-black"
                    muted
                  />
                ) : (
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-muted-foreground">
                    <UploadIcon className="w-8 h-8 mb-2" />
                    <span className="text-xs">برای انتخاب ویدیو کلیک کنید</span>
                    <span className="text-[10px] mt-1">MP4, WebM, MOV</span>
                  </div>
                )}
              </div>
              <input
                type="file"
                accept="video/*"
                className="hidden"
                onChange={(e) => onPickVideo(e.target.files?.[0] || null)}
                disabled={busy}
              />
            </label>
            {videoFile && (
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span className="truncate">{videoFile.name}</span>
                {duration > 0 && <span className="tabular-nums">{formatDuration(duration)}</span>}
              </div>
            )}
          </div>

          <div className="space-y-1.5">
            <Label>کاور ویدیو (اختیاری)</Label>
            <div className="flex items-center gap-3">
              <div className="w-24 aspect-video rounded-lg overflow-hidden bg-muted shrink-0 border border-border/60">
                {thumbnailPreview ? (
                  <img
                    src={thumbnailPreview}
                    alt="thumbnail"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <ImageIcon className="w-5 h-5 text-muted-foreground" />
                  </div>
                )}
              </div>
              <div className="flex-1 space-y-1">
                <p className="text-[11px] text-muted-foreground">
                  کاور به‌صورت خودکار از ویدیو ساخته می‌شود. می‌توانید تصویر دلخواه انتخاب کنید.
                </p>
                <label className="inline-block">
                  <Button variant="outline" size="sm" asChild disabled={busy}>
                    <span className="cursor-pointer">
                      <ImageIcon className="w-3.5 h-3.5 ml-1" />
                      انتخاب تصویر
                    </span>
                  </Button>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => onPickThumb(e.target.files?.[0] || null)}
                    disabled={busy}
                  />
                </label>
              </div>
            </div>
          </div>

          {submitting && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">
                  {stage === "uploading" ? "در حال آپلود ویدیو…" : "در حال انتشار…"}
                </span>
                <span className="font-semibold tabular-nums">
                  {stage === "uploading" ? faDigits(`${progress}٪`) : "…"}
                </span>
              </div>
              {stage === "uploading" && <Progress value={progress} />}
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={onClose} disabled={busy}>
            انصراف
          </Button>
          <Button
            onClick={submit}
            disabled={busy || !title.trim() || !videoFile}
            className="gradient-karol text-white"
          >
            {busy ? "…" : "انتشار ویدیو"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

export default function VideosSection() {
  const { toast } = useApp()
  const [view, setView] = useState<"grid" | "detail">("grid")
  const [selected, setSelected] = useState<VideoT | null>(null)
  const [videos, setVideos] = useState<VideoT[]>([])
  const [loading, setLoading] = useState(true)
  const [loadingMore, setLoadingMore] = useState(false)
  const [cursor, setCursor] = useState<string | null>(null)
  const [hasMore, setHasMore] = useState(false)
  const [category, setCategory] = useState("all")
  const [searchInput, setSearchInput] = useState("")
  const [search, setSearch] = useState("")
  const [uploadOpen, setUploadOpen] = useState(false)

  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput.trim()), 350)
    return () => clearTimeout(t)
  }, [searchInput])

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams({ limit: "20" })
      if (category !== "all") params.set("category", category)
      if (search) params.set("q", search)
      const d = await api<{ videos: VideoT[]; nextCursor: string | null }>(
        `/api/videos?${params.toString()}`,
      )
      setVideos(d.videos)
      setCursor(d.nextCursor)
      setHasMore(!!d.nextCursor)
    } catch (e: any) {
      toast(e.message, "error")
    } finally {
      setLoading(false)
    }
  }, [category, search, toast])

  useEffect(() => {
    load()
  }, [load])

  async function loadMore() {
    if (!cursor || loadingMore) return
    setLoadingMore(true)
    try {
      const params = new URLSearchParams({ limit: "20", cursor })
      if (category !== "all") params.set("category", category)
      if (search) params.set("q", search)
      const d = await api<{ videos: VideoT[]; nextCursor: string | null }>(
        `/api/videos?${params.toString()}`,
      )
      setVideos((v) => [...v, ...d.videos])
      setCursor(d.nextCursor)
      setHasMore(!!d.nextCursor)
    } catch (e: any) {
      toast(e.message, "error")
    } finally {
      setLoadingMore(false)
    }
  }

  function openDetail(v: VideoT) {
    setSelected(v)
    setView("detail")
    if (typeof window !== "undefined") window.scrollTo({ top: 0 })
  }

  function backToGrid() {
    setView("grid")
    setSelected(null)
    load()
  }

  function onUploaded(v: VideoT) {
    setUploadOpen(false)
    openDetail(v)
    toast("ویدیو منتشر شد", "success")
  }

  if (view === "detail" && selected) {
    return (
      <div className="min-h-full">
        <VideoDetail video={selected} onBack={backToGrid} />
      </div>
    )
  }

  return (
    <div className="min-h-full">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 py-4 sm:py-5">
        <div className="flex items-center gap-2 mb-3">
          <div className="relative flex-1">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
            <input
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="جستجوی ویدیو یا کاربر…"
              className="w-full h-10 pr-10 pl-9 rounded-full bg-card border border-border/60 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all"
            />
            {searchInput && (
              <button
                onClick={() => setSearchInput("")}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
          <Button
            onClick={() => setUploadOpen(true)}
            className="gradient-karol text-white shrink-0"
            size="sm"
          >
            <Plus className="w-4 h-4 ml-1" />
            <span className="hidden sm:inline">آپلود ویدیو</span>
          </Button>
        </div>

        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2 mb-3">
          {CATEGORIES.map((c) => (
            <button
              key={c.key}
              onClick={() => setCategory(c.key)}
              className={cn(
                "shrink-0 px-4 h-9 rounded-full text-sm font-medium transition-all border",
                category === c.key
                  ? "bg-primary text-primary-foreground border-primary shadow-soft"
                  : "bg-card text-muted-foreground hover:text-foreground border-border/60 hover:border-primary/40",
              )}
            >
              {c.label}
            </button>
          ))}
        </div>

        <VideoGrid
          videos={videos}
          loading={loading}
          hasQuery={!!search || category !== "all"}
          onOpen={openDetail}
        />

        {hasMore && !loading && (
          <div className="flex justify-center mt-5">
            <Button variant="outline" onClick={loadMore} disabled={loadingMore}>
              {loadingMore ? "در حال بارگذاری…" : "ویدیوهای بیشتر"}
            </Button>
          </div>
        )}
      </div>

      <button
        onClick={() => setUploadOpen(true)}
        aria-label="آپلود ویدیو"
        className="sm:hidden fixed bottom-20 left-4 z-30 w-14 h-14 rounded-full gradient-karol text-white shadow-soft flex items-center justify-center active:scale-95 transition-transform"
      >
        <Plus className="w-6 h-6" />
      </button>

      <UploadDialog
        open={uploadOpen}
        onClose={() => setUploadOpen(false)}
        onUploaded={onUploaded}
      />
    </div>
  )
}
