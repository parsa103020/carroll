"use client"

import { useEffect, useState, useCallback } from "react"
import { useApp } from "@/lib/store"
import { api, faDigits, timeAgo } from "@/lib/format"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Ticket as TicketIcon, Search, RefreshCw, Inbox } from "lucide-react"
import { cn } from "@/lib/utils"
import { EmptyState, Loader, TICKET_STATUS } from "./shared"

export function TicketsTab() {
  const { setSection, toast } = useApp()
  const [tickets, setTickets] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState("open")
  const [q, setQ] = useState("")

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (statusFilter !== "all") params.set("status", statusFilter)
      if (q) params.set("q", q)
      const d = await api<any>(`/api/tickets?${params}`)
      setTickets(d.tickets || [])
    } catch (e: any) { toast(e.message, "error") }
    finally { setLoading(false) }
  }, [statusFilter, q, toast])

  useEffect(() => { const t = setTimeout(load, 250); return () => clearTimeout(t) }, [load])

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-bold">تیکت‌های پشتیبانی</h2>
        <p className="text-xs text-muted-foreground mt-0.5">برای پاسخ کامل، تیکت را در بخش خودش باز کنید</p>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        {[
          { v: "open", label: "باز" },
          { v: "pending", label: "در انتظار" },
          { v: "closed", label: "بسته" },
          { v: "all", label: "همه" },
        ].map((f) => (
          <Button key={f.v} size="sm" variant={statusFilter === f.v ? "default" : "outline"} onClick={() => setStatusFilter(f.v)}>
            {f.label}
          </Button>
        ))}
        <div className="relative flex-1 min-w-[180px]">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="جستجوی موضوع یا کاربر…" className="pr-9" />
        </div>
        <Button variant="outline" size="icon" onClick={load} disabled={loading}>
          <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
        </Button>
      </div>

      {loading ? <Loader rows={5} /> : tickets.length === 0 ? (
        <EmptyState icon={Inbox} title="تیکتی نیست" />
      ) : (
        <div className="space-y-2">
          {tickets.map((t) => (
            <Card key={t.id} className="glass hover:shadow-soft transition-shadow cursor-pointer" onClick={() => setSection("tickets", { id: t.id })}>
              <CardContent className="p-3">
                <div className="flex items-start gap-3">
                  <Avatar className="w-9 h-9">
                    <AvatarImage src={t.owner?.avatarUrl || undefined} />
                    <AvatarFallback className="text-xs bg-primary/15 text-primary">{t.owner?.username?.[0]?.toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium text-sm truncate">{t.subject}</span>
                      <Badge className={cn("text-[10px]", TICKET_STATUS[t.status]?.cls)}>{TICKET_STATUS[t.status]?.label}</Badge>
                      {t.priority === "high" && <Badge className="text-[10px] bg-rose-500/15 text-rose-600">فوری</Badge>}
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {t.owner?.displayName || t.owner?.username} · {timeAgo(t.updatedAt)}
                    </div>
                    {t.lastMessage && (
                      <div className="text-xs text-muted-foreground mt-1 line-clamp-1">
                        {t.lastMessage.isAdmin && <span className="text-primary">[پشتیبانی] </span>}
                        {t.lastMessage.content}
                      </div>
                    )}
                  </div>
                  <div className="flex flex-col items-end gap-1 shrink-0">
                    <Badge variant="secondary" className="text-[10px]">{faDigits(t.messagesCount)} پیام</Badge>
                    <Button size="sm" variant="ghost" className="h-7 text-xs">باز کردن ←</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
