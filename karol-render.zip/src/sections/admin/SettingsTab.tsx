"use client"

import { useEffect, useState, useCallback } from "react"
import { useApp } from "@/lib/store"
import { api } from "@/lib/format"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import {
  Settings as SettingsIcon, HardDrive, MessageCircle, Film, Video as VideoIcon,
  TrendingUp, FileText, Crown, ShoppingBag, RefreshCw, Check, Loader2,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { bytesFromMB, mbFromBytes, Loader } from "./shared"

type FieldDef = { key: string; label: string; type: "text" | "number" | "switch" | "mb" | "textarea" }
type SettingGroup = { key: string; label: string; icon: React.ComponentType<{ className?: string }>; fields: FieldDef[] }

const SETTING_GROUPS: SettingGroup[] = [
  {
    key: "general", label: "عمومی", icon: SettingsIcon,
    fields: [
      { key: "general.siteName", label: "نام سایت", type: "text" },
      { key: "general.maintenance", label: "حالت تعمیر", type: "switch" },
      { key: "general.signupOpen", label: "ثبت‌نام باز است", type: "switch" },
    ],
  },
  {
    key: "upload", label: "آپلود", icon: HardDrive,
    fields: [
      { key: "upload.dailyLimitBytes", label: "سهمیه روزانه (مگابایت)", type: "mb" },
      { key: "upload.maxFileBytes", label: "حداکثر حجم فایل (مگابایت)", type: "mb" },
    ],
  },
  {
    key: "chat", label: "چت", icon: MessageCircle,
    fields: [
      { key: "chat.maxMessageLength", label: "حداکثر طول پیام", type: "number" },
      { key: "chat.imageMaxBytes", label: "حداکثر حجم تصویر (مگابایت)", type: "mb" },
      { key: "chat.videoMaxBytes", label: "حداکثر حجم ویدیو (مگابایت)", type: "mb" },
      { key: "chat.voiceMaxBytes", label: "حداکثر حجم صوت (مگابایت)", type: "mb" },
      { key: "chat.gifMaxBytes", label: "حداکثر حجم گیف (مگابایت)", type: "mb" },
      { key: "chat.stickerMaxBytes", label: "حداکثر حجم استیکر (مگابایت)", type: "mb" },
      { key: "chat.rateLimitSeconds", label: "فاصله پیام (ثانیه)", type: "number" },
      { key: "chat.allowVoice", label: "اجازه صوت", type: "switch" },
      { key: "chat.allowStickers", label: "اجازه استیکر", type: "switch" },
      { key: "chat.allowGifs", label: "اجازه گیف", type: "switch" },
      { key: "chat.allowImages", label: "اجازه تصویر", type: "switch" },
      { key: "chat.allowVideos", label: "اجازه ویدیو", type: "switch" },
    ],
  },
  { key: "reel", label: "ریلز", icon: Film, fields: [{ key: "reel.maxBytes", label: "حداکثر حجم ریلز (مگابایت)", type: "mb" }] },
  { key: "video", label: "ویدیو", icon: VideoIcon, fields: [{ key: "video.maxBytes", label: "حداکثر حجم ویدیو (مگابایت)", type: "mb" }] },
  { key: "music", label: "موسیقی", icon: TrendingUp, fields: [{ key: "music.externalSearch", label: "جستجوی خارجی", type: "switch" }] },
  { key: "feed", label: "فیید", icon: FileText, fields: [{ key: "feed.maxMedia", label: "حداکثر رسانه در پست", type: "number" }] },
  {
    key: "vip", label: "VIP", icon: Crown,
    fields: [
      { key: "vip.pricePerMonth", label: "قیمت ماهانه (تومان)", type: "number" },
      { key: "vip.bonusUploadBytes", label: "سهمیه اضافی VIP (مگابایت)", type: "mb" },
      { key: "vip.exclusiveRoom", label: "روم اختصاصی VIP", type: "switch" },
    ],
  },
  {
    key: "shop", label: "فروشگاه", icon: ShoppingBag,
    fields: [
      { key: "shop.cardNumber", label: "شماره کارت", type: "text" },
      { key: "shop.cardHolder", label: "نام صاحب کارت", type: "text" },
    ],
  },
]

export function SettingsTab() {
  const { toast } = useApp()
  const [settings, setSettings] = useState<Record<string, string>>({})
  const [original, setOriginal] = useState<Record<string, string>>({})
  const [loading, setLoading] = useState(true)
  const [savingGroup, setSavingGroup] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const d = await api<Record<string, string>>("/api/settings")
      setSettings(d); setOriginal(d)
    } catch (e: any) { toast(e.message, "error") }
    finally { setLoading(false) }
  }, [toast])

  useEffect(() => { load() }, [load])

  function setField(key: string, val: string) {
    setSettings((s) => ({ ...s, [key]: val }))
  }

  async function saveGroup(g: SettingGroup) {
    const changes: Record<string, string> = {}
    for (const f of g.fields) {
      let v = settings[f.key] ?? ""
      if (f.type === "mb") {
        const mb = parseFloat(v)
        if (!Number.isFinite(mb) || mb < 0) {
          toast(`مقدار «${f.label}» نامعتبر است`, "error"); return
        }
        v = bytesFromMB(mb)
      }
      if (v !== (original[f.key] ?? "")) changes[f.key] = v
    }
    if (Object.keys(changes).length === 0) { toast("تغییری برای ذخیره نیست"); return }
    setSavingGroup(g.key)
    try {
      await api("/api/settings", { method: "PUT", json: changes })
      setOriginal((o) => ({ ...o, ...changes }))
      toast("تنظیمات ذخیره شد", "success")
    } catch (e: any) { toast(e.message, "error") }
    finally { setSavingGroup(null) }
  }

  if (loading) return <Loader rows={4} />

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold">تنظیمات پلتفرم</h2>
          <p className="text-xs text-muted-foreground mt-0.5">پیکربندی کلی کارول — هر گروه مستقل ذخیره می‌شود</p>
        </div>
        <Button variant="outline" size="sm" onClick={load}>
          <RefreshCw className="w-4 h-4 ml-1.5" /> بازخوانی
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {SETTING_GROUPS.map((g) => {
          const dirty = g.fields.some((f) => (settings[f.key] ?? "") !== (original[f.key] ?? ""))
          return (
            <Card key={g.key} className="glass">
              <CardHeader className="pb-3 flex flex-row items-center justify-between">
                <CardTitle className="text-sm font-semibold flex items-center gap-2">
                  <g.icon className="w-4 h-4 text-primary" /> {g.label}
                </CardTitle>
                <Button size="sm" variant={dirty ? "default" : "outline"} disabled={savingGroup === g.key || !dirty} onClick={() => saveGroup(g)}>
                  {savingGroup === g.key ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5 ml-1" />}
                  ذخیره
                </Button>
              </CardHeader>
              <CardContent className="space-y-3">
                {g.fields.map((f) => {
                  const raw = settings[f.key] ?? ""
                  const display = f.type === "mb" ? String(Math.round(mbFromBytes(raw))) : raw
                  return (
                    <div key={f.key} className="space-y-1.5">
                      <Label className="text-xs">{f.label}</Label>
                      {f.type === "switch" ? (
                        <div className="flex items-center gap-2">
                          <Switch checked={raw === "true"} onCheckedChange={(c) => setField(f.key, c ? "true" : "false")} />
                          <span className="text-xs text-muted-foreground">{raw === "true" ? "روشن" : "خاموش"}</span>
                        </div>
                      ) : f.type === "textarea" ? (
                        <Textarea value={display} onChange={(e) => setField(f.key, e.target.value)} rows={2} />
                      ) : (
                        <Input type={f.type === "number" || f.type === "mb" ? "number" : "text"} value={display} onChange={(e) => setField(f.key, e.target.value)} className={cn(f.type === "mb" && "tabular-nums")} />
                      )}
                    </div>
                  )
                })}
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
