"use client"

import { useEffect, useState, useCallback } from "react"
import { useApp } from "@/lib/store"
import { api, formatBytes, formatNumber, faDigits, timeAgo, formatDate } from "@/lib/format"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import {
  Package, Boxes, ShoppingCart, Plus, Edit2, Trash2, RefreshCw, Loader2,
  Check, AlertTriangle, Copy,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { EmptyState, Loader, StatCard } from "./shared"

export function ConfigsTab() {
  const [tab, setTab] = useState<"packages" | "stock" | "purchases">("packages")
  return (
    <div className="space-y-4 animate-fade-in">
      <div>
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Package className="w-5 h-5 text-accent" />
          مدیریت کانفیگ‌ها
        </h2>
        <p className="text-xs text-muted-foreground mt-0.5">بسته‌های V2Ray، موجودی و خریدها</p>
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as any)}>
        <TabsList>
          <TabsTrigger value="packages"><Package className="w-3.5 h-3.5 ml-1" /> بسته‌ها</TabsTrigger>
          <TabsTrigger value="stock"><Boxes className="w-3.5 h-3.5 ml-1" /> موجودی</TabsTrigger>
          <TabsTrigger value="purchases"><ShoppingCart className="w-3.5 h-3.5 ml-1" /> خریدها</TabsTrigger>
        </TabsList>

        <TabsContent value="packages" className="mt-3">
          <PackagesSubTab />
        </TabsContent>
        <TabsContent value="stock" className="mt-3">
          <StockSubTab />
        </TabsContent>
        <TabsContent value="purchases" className="mt-3">
          <PurchasesSubTab />
        </TabsContent>
      </Tabs>
    </div>
  )
}

function PackagesSubTab() {
  const { toast } = useApp()
  const [packages, setPackages] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState<any | null>(null)
  const [creating, setCreating] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState<any | null>(null)
  const [busyId, setBusyId] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const d = await api<any>("/api/admin/configs/packages")
      setPackages(d.packages || [])
    } catch (e: any) { toast(e.message, "error") }
    finally { setLoading(false) }
  }, [toast])

  useEffect(() => { load() }, [load])

  async function toggleActive(p: any) {
    setBusyId(p.id)
    try {
      await api(`/api/admin/configs/packages/${p.id}`, { method: "PATCH", json: { active: !p.active } })
      toast(p.active ? "بسته غیرفعال شد" : "بسته فعال شد", "success")
      await load()
    } catch (e: any) { toast(e.message, "error") }
    finally { setBusyId(null) }
  }

  async function save(pkg: any, isNew: boolean) {
    try {
      if (isNew) await api("/api/admin/configs/packages", { method: "POST", json: pkg })
      else await api(`/api/admin/configs/packages/${pkg.id}`, { method: "PATCH", json: pkg })
      toast("بسته ذخیره شد", "success")
      setEditing(null); setCreating(false)
      await load()
    } catch (e: any) { toast(e.message, "error") }
  }

  async function del(id: string) {
    try {
      await api(`/api/admin/configs/packages/${id}`, { method: "DELETE" })
      toast("بسته حذف شد", "success")
      setDeleteTarget(null)
      await load()
    } catch (e: any) { toast(e.message, "error") }
  }

  const lowStock = packages.filter((p) => p.unassignedStock === 0)

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 flex-1">
          <StatCard icon={Package} label="بسته‌ها" value={faDigits(packages.length)} />
          <StatCard icon={Check} label="فعال" value={faDigits(packages.filter((p) => p.active).length)} accent="text-success" />
          <StatCard icon={AlertTriangle} label="ناموجود" value={faDigits(lowStock.length)} accent={lowStock.length > 0 ? "text-danger" : undefined} />
          <StatCard icon={ShoppingCart} label="خریدها" value={faDigits(packages.reduce((s, p) => s + (p.purchasesCount || 0), 0))} />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="icon" onClick={load} disabled={loading} className="h-9 w-9">
            <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
          </Button>
          <Button size="sm" onClick={() => setCreating(true)} className="shadow-glow">
            <Plus className="w-4 h-4 ml-1" /> بسته جدید
          </Button>
        </div>
      </div>

      {lowStock.length > 0 && (
        <Card className="bg-warning-15 border-amber-500/30">
          <CardContent className="p-3 flex items-center gap-2 text-xs">
            <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
            <span>
              {faDigits(lowStock.length)} بسته موجودی صفر دارند:{" "}
              <span className="font-medium">{lowStock.map((p) => p.name).join("، ")}</span>
            </span>
          </CardContent>
        </Card>
      )}

      {loading ? <Loader rows={4} /> : packages.length === 0 ? (
        <EmptyState icon={Package} title="بسته‌ای نیست" hint="اولین بسته کانفیگ را بسازید" />
      ) : (
        <Card className="glass">
          <CardContent className="p-0">
            <div className="hidden md:block">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>نام</TableHead>
                    <TableHead>حجم</TableHead>
                    <TableHead className="text-center">قیمت (سکه)</TableHead>
                    <TableHead className="text-center">مدت</TableHead>
                    <TableHead className="text-center">موجودی</TableHead>
                    <TableHead className="text-center">خریدها</TableHead>
                    <TableHead className="text-center">فعال</TableHead>
                    <TableHead className="text-left">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {packages.map((p) => (
                    <TableRow key={p.id} className={cn(p.unassignedStock === 0 && "bg-warning-15/50")}>
                      <TableCell className="font-medium">{p.name}</TableCell>
                      <TableCell>{formatBytes(p.volumeBytes)}</TableCell>
                      <TableCell className="text-center tabular-nums text-gold">{faDigits(formatNumber(p.priceCoins))}</TableCell>
                      <TableCell className="text-center tabular-nums">{faDigits(p.durationDays)} روز</TableCell>
                      <TableCell className="text-center">
                        <Badge variant="secondary" className={cn("text-[10px]", p.unassignedStock === 0 ? "bg-rose-500/15 text-rose-500" : "bg-emerald-500/15 text-emerald-500")}>
                          {faDigits(p.unassignedStock)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center tabular-nums">{faDigits(p.purchasesCount || 0)}</TableCell>
                      <TableCell className="text-center">
                        <Switch checked={p.active} onCheckedChange={() => toggleActive(p)} disabled={busyId === p.id} />
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1 justify-end">
                          <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => setEditing(p)}>
                            <Edit2 className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => setDeleteTarget(p)}>
                            <Trash2 className="w-3.5 h-3.5 text-rose-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            <div className="md:hidden divide-y divide-border/40">
              {packages.map((p) => (
                <div key={p.id} className={cn("p-3 space-y-2", p.unassignedStock === 0 && "bg-warning-15/50")}>
                  <div className="flex items-start justify-between">
                    <div className="min-w-0">
                      <div className="font-medium text-sm truncate">{p.name}</div>
                      <div className="text-xs text-muted-foreground mt-0.5">
                        {formatBytes(p.volumeBytes)} · {faDigits(p.durationDays)} روز
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => setEditing(p)}>
                        <Edit2 className="w-3.5 h-3.5" />
                      </Button>
                      <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => setDeleteTarget(p)}>
                        <Trash2 className="w-3.5 h-3.5 text-rose-500" />
                      </Button>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge className="text-[10px] text-gold bg-gold/15">{faDigits(formatNumber(p.priceCoins))} سکه</Badge>
                    <Badge variant="secondary" className={cn("text-[10px]", p.unassignedStock === 0 ? "bg-rose-500/15 text-rose-500" : "bg-emerald-500/15 text-emerald-500")}>
                      موجودی: {faDigits(p.unassignedStock)}
                    </Badge>
                    <Badge variant="secondary" className="text-[10px]">{faDigits(p.purchasesCount || 0)} خرید</Badge>
                  </div>
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[11px] text-muted-foreground">فعال</span>
                    <Switch checked={p.active} onCheckedChange={() => toggleActive(p)} disabled={busyId === p.id} />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {(editing || creating) && (
        <PackageDialog pkg={editing} isNew={creating} onClose={() => { setEditing(null); setCreating(false) }} onSave={save} />
      )}

      {deleteTarget && (
        <AlertDialog open onOpenChange={(o) => !o && setDeleteTarget(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>حذف بسته</AlertDialogTitle>
              <AlertDialogDescription>
                آیا از حذف «{deleteTarget.name}» مطمئن هستید؟
                {(deleteTarget.purchasesCount || 0) > 0 && " این بسته خرید دارد و قابل حذف نیست."}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>انصراف</AlertDialogCancel>
              <AlertDialogAction
                className="bg-rose-500 hover:bg-rose-600 text-white"
                disabled={(deleteTarget.purchasesCount || 0) > 0}
                onClick={() => del(deleteTarget.id)}
              >
                حذف
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  )
}

function PackageDialog({ pkg, isNew, onClose, onSave }: { pkg: any; isNew: boolean; onClose: () => void; onSave: (p: any, isNew: boolean) => void }) {
  const [name, setName] = useState(pkg?.name || "")
  const [volumeMB, setVolumeMB] = useState(pkg ? String(Math.round(parseInt(pkg.volumeBytes, 10) / (1024 * 1024))) : "10")
  const [priceCoins, setPriceCoins] = useState(String(pkg?.priceCoins ?? "500"))
  const [durationDays, setDurationDays] = useState(String(pkg?.durationDays ?? "30"))
  const [active, setActive] = useState(pkg?.active ?? true)

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{isNew ? "بسته جدید" : "ویرایش بسته"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <div className="space-y-1.5">
            <Label>نام بسته</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="مثلاً: ۱ گیگابایت" maxLength={100} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>حجم (مگابایت)</Label>
              <Input type="number" value={volumeMB} onChange={(e) => setVolumeMB(e.target.value)} min={1} />
            </div>
            <div className="space-y-1.5">
              <Label>قیمت (سکه)</Label>
              <Input type="number" value={priceCoins} onChange={(e) => setPriceCoins(e.target.value)} min={0} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>مدت (روز)</Label>
              <Input type="number" value={durationDays} onChange={(e) => setDurationDays(e.target.value)} min={1} />
            </div>
            <div className="space-y-1.5">
              <Label>وضعیت</Label>
              <div className="flex items-center gap-2 h-9 px-3 rounded-lg glass border border-border/40">
                <Switch checked={active} onCheckedChange={setActive} />
                <span className="text-xs">{active ? "فعال" : "غیرفعال"}</span>
              </div>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>انصراف</Button>
          <Button
            onClick={() => onSave({
              id: pkg?.id,
              name: name.trim(),
              volumeBytes: String(Math.max(1, parseInt(volumeMB, 10) || 1) * 1024 * 1024),
              priceCoins: parseInt(priceCoins, 10) || 0,
              durationDays: parseInt(durationDays, 10) || 30,
              active,
            }, isNew)}
            disabled={!name.trim()}
          >
            ذخیره
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

function StockSubTab() {
  const { toast } = useApp()
  const [packages, setPackages] = useState<any[]>([])
  const [stock, setStock] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [packageId, setPackageId] = useState<string>("all")
  const [assignedFilter, setAssignedFilter] = useState<string>("all")
  const [busyId, setBusyId] = useState<string | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<any | null>(null)
  const [bulkOpen, setBulkOpen] = useState(false)
  const [bulkText, setBulkText] = useState("")
  const [bulkPkg, setBulkPkg] = useState<string>("")
  const [bulkSaving, setBulkSaving] = useState(false)

  const loadPackages = useCallback(async () => {
    try {
      const d = await api<any>("/api/admin/configs/packages")
      setPackages(d.packages || [])
      if (!bulkPkg && d.packages?.length) setBulkPkg(d.packages[0].id)
    } catch (e: any) { toast(e.message, "error") }
  }, [bulkPkg, toast])

  const loadStock = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (packageId !== "all") params.set("packageId", packageId)
      if (assignedFilter !== "all") params.set("assigned", assignedFilter)
      const d = await api<any>(`/api/admin/configs/stock?${params}`)
      setStock(d.stock || [])
    } catch (e: any) { toast(e.message, "error") }
    finally { setLoading(false) }
  }, [packageId, assignedFilter, toast])

  useEffect(() => { loadPackages() }, [loadPackages])
  useEffect(() => { loadStock() }, [loadStock])

  async function del(id: string) {
    setBusyId(id)
    try {
      await api(`/api/admin/configs/stock/${id}`, { method: "DELETE" })
      toast("کانفیگ حذف شد", "success")
      setDeleteTarget(null)
      await Promise.all([loadStock(), loadPackages()])
    } catch (e: any) { toast(e.message, "error") }
    finally { setBusyId(null) }
  }

  async function bulkAdd() {
    if (!bulkPkg) { toast("بسته را انتخاب کنید", "error"); return }
    if (!bulkText.trim()) { toast("حداقل یک کانفیگ وارد کنید", "error"); return }
    setBulkSaving(true)
    try {
      const d = await api<any>("/api/admin/configs/stock", {
        method: "POST",
        json: { packageId: bulkPkg, configs: bulkText },
      })
      toast(`${faDigits(d.added)} کانفیگ اضافه شد`, "success")
      setBulkText("")
      setBulkOpen(false)
      await Promise.all([loadStock(), loadPackages()])
    } catch (e: any) { toast(e.message, "error") }
    finally { setBulkSaving(false) }
  }

  const lowStockPackages = packages.filter((p) => p.unassignedStock === 0)

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2 flex-1">
          <StatCard icon={Boxes} label="موجودی کل" value={faDigits(stock.length)} />
          <StatCard icon={Check} label="آزاد" value={faDigits(stock.filter((s) => !s.assignedToId).length)} accent="text-success" />
          <StatCard icon={AlertTriangle} label="بسته‌های ناموجود" value={faDigits(lowStockPackages.length)} accent={lowStockPackages.length > 0 ? "text-danger" : undefined} />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="icon" onClick={() => { loadStock(); loadPackages() }} disabled={loading} className="h-9 w-9">
            <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
          </Button>
          <Button size="sm" onClick={() => setBulkOpen(true)} className="shadow-glow">
            <Plus className="w-4 h-4 ml-1" /> افزودن دسته‌ای
          </Button>
        </div>
      </div>

      {lowStockPackages.length > 0 && (
        <Card className="bg-warning-15 border-amber-500/30">
          <CardContent className="p-3 flex items-center gap-2 text-xs">
            <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
            <span>بسته‌های با موجودی صفر: <span className="font-medium">{lowStockPackages.map((p) => p.name).join("، ")}</span></span>
          </CardContent>
        </Card>
      )}

      <div className="flex items-center gap-2 flex-wrap">
        <Select value={packageId} onValueChange={setPackageId}>
          <SelectTrigger className="w-[180px] h-9"><SelectValue placeholder="همه بسته‌ها" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه بسته‌ها</SelectItem>
            {packages.map((p) => (
              <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={assignedFilter} onValueChange={setAssignedFilter}>
          <SelectTrigger className="w-[150px] h-9"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه</SelectItem>
            <SelectItem value="false">آزاد</SelectItem>
            <SelectItem value="true">اختصاص‌یافته</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {loading ? <Loader rows={4} /> : stock.length === 0 ? (
        <EmptyState icon={Boxes} title="کانفیگی نیست" hint="از دکمه «افزودن دسته‌ای» استفاده کنید" />
      ) : (
        <div className="space-y-2">
          {stock.map((s) => (
            <Card key={s.id} className={cn("glass", s.assignedToId && "border-border/60 opacity-80")}>
              <CardContent className="p-3 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 text-xs flex-wrap">
                      <Badge variant="secondary" className="text-[10px] bg-primary/15 text-primary">{s.package?.name || "—"}</Badge>
                      {s.assignedToId ? (
                        <Badge className="text-[10px] bg-rose-500/15 text-rose-500">اختصاص‌یافته</Badge>
                      ) : (
                        <Badge className="text-[10px] bg-emerald-500/15 text-emerald-500">آزاد</Badge>
                      )}
                      <span className="text-muted-foreground">· {timeAgo(s.createdAt)}</span>
                    </div>
                    <div className="mt-1.5 font-mono text-[11px] text-muted-foreground truncate bg-muted/40 border border-border/30 rounded px-2 py-1" dir="ltr">
                      {s.configText}
                    </div>
                    {s.assignedTo && (
                      <div className="text-[10px] text-muted-foreground mt-1">
                        اختصاص به: @{s.assignedTo.username}
                        {s.assignedAt && ` · ${timeAgo(s.assignedAt)}`}
                      </div>
                    )}
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-8 w-8 p-0"
                      onClick={() => {
                        navigator.clipboard?.writeText(s.configText).then(
                          () => toast("کپی شد", "success"),
                          () => toast("کپی ناموفق", "error"),
                        )
                      }}
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-8 w-8 p-0"
                      disabled={!!s.assignedToId || busyId === s.id}
                      onClick={() => setDeleteTarget(s)}
                    >
                      {busyId === s.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5 text-rose-500" />}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {bulkOpen && (
        <Dialog open onOpenChange={(o) => !o && setBulkOpen(false)}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>افزودن دسته‌ای کانفیگ</DialogTitle>
            </DialogHeader>
            <div className="space-y-3 py-2">
              <div className="space-y-1.5">
                <Label>بسته</Label>
                <Select value={bulkPkg} onValueChange={setBulkPkg}>
                  <SelectTrigger><SelectValue placeholder="انتخاب بسته" /></SelectTrigger>
                  <SelectContent>
                    {packages.map((p) => (
                      <SelectItem key={p.id} value={p.id}>{p.name} (موجودی: {faDigits(p.unassignedStock)})</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>کانفیگ‌ها (هر خط یک کانفیگ)</Label>
                <Textarea
                  value={bulkText}
                  onChange={(e) => setBulkText(e.target.value)}
                  rows={8}
                  placeholder={"vless://...\nvmess://...\nTrojan://..."}
                  className="font-mono text-xs"
                  dir="ltr"
                />
                <p className="text-[10px] text-muted-foreground">حداکثر ۵۰۰ کانفیگ در هر بار</p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setBulkOpen(false)}>انصراف</Button>
              <Button onClick={bulkAdd} disabled={bulkSaving || !bulkText.trim() || !bulkPkg}>
                {bulkSaving && <Loader2 className="w-4 h-4 animate-spin ml-1" />}
                افزودن
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {deleteTarget && (
        <AlertDialog open onOpenChange={(o) => !o && setDeleteTarget(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>حذف کانفیگ</AlertDialogTitle>
              <AlertDialogDescription>این کانفیگ از موجودی حذف خواهد شد.</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>انصراف</AlertDialogCancel>
              <AlertDialogAction className="bg-rose-500 hover:bg-rose-600 text-white" onClick={() => del(deleteTarget.id)}>حذف</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  )
}

function PurchasesSubTab() {
  const { toast } = useApp()
  const [purchases, setPurchases] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [status, setStatus] = useState<string>("all")
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [total, setTotal] = useState(0)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (status !== "all") params.set("status", status)
      params.set("page", String(page))
      const d = await api<any>(`/api/admin/configs/purchases?${params}`)
      setPurchases(d.purchases || [])
      setTotal(d.total)
      setTotalPages(d.totalPages || 1)
    } catch (e: any) { toast(e.message, "error") }
    finally { setLoading(false) }
  }, [status, page, toast])

  useEffect(() => { load() }, [load])
  useEffect(() => { setPage(1) }, [status])

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-[150px] h-9"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه</SelectItem>
            <SelectItem value="active">فعال</SelectItem>
            <SelectItem value="expired">منقضی</SelectItem>
          </SelectContent>
        </Select>
        <Button variant="outline" size="icon" onClick={load} disabled={loading} className="h-9 w-9">
          <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
        </Button>
      </div>

      <div className="text-xs text-muted-foreground">{faDigits(total)} خرید</div>

      {loading ? <Loader rows={4} /> : purchases.length === 0 ? (
        <EmptyState icon={ShoppingCart} title="خریدی نیست" />
      ) : (
        <>
          <Card className="glass">
            <CardContent className="p-0">
              <div className="hidden md:block">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>کاربر</TableHead>
                      <TableHead>بسته</TableHead>
                      <TableHead>حجم</TableHead>
                      <TableHead className="text-center">قیمت</TableHead>
                      <TableHead>انقضا</TableHead>
                      <TableHead>وضعیت</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {purchases.map((p) => {
                      const expired = new Date(p.expiresAt) < new Date()
                      return (
                        <TableRow key={p.id}>
                          <TableCell className="font-medium">@{p.user?.username || "—"}</TableCell>
                          <TableCell>{p.package?.name || "—"}</TableCell>
                          <TableCell>{formatBytes(p.volumeBytes)}</TableCell>
                          <TableCell className="text-center tabular-nums text-gold">{faDigits(formatNumber(p.pricePaid))}</TableCell>
                          <TableCell className="text-xs">{formatDate(p.expiresAt)}</TableCell>
                          <TableCell>
                            <Badge className={cn("text-[10px]", expired ? "bg-rose-500/15 text-rose-500" : "bg-emerald-500/15 text-emerald-500")}>
                              {expired ? "منقضی" : "فعال"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </div>
              <div className="md:hidden divide-y divide-border/40">
                {purchases.map((p) => {
                  const expired = new Date(p.expiresAt) < new Date()
                  return (
                    <div key={p.id} className="p-3 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-sm">@{p.user?.username || "—"}</span>
                        <Badge className={cn("text-[10px]", expired ? "bg-rose-500/15 text-rose-500" : "bg-emerald-500/15 text-emerald-500")}>
                          {expired ? "منقضی" : "فعال"}
                        </Badge>
                      </div>
                      <div className="text-xs text-muted-foreground">{p.package?.name} · {formatBytes(p.volumeBytes)}</div>
                      <div className="text-[11px] text-muted-foreground">
                        {faDigits(formatNumber(p.pricePaid))} سکه · انقضا: {formatDate(p.expiresAt)}
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2">
              <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))}>قبلی</Button>
              <span className="text-xs text-muted-foreground px-2">{faDigits(page)} / {faDigits(totalPages)}</span>
              <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>بعدی</Button>
            </div>
          )}
        </>
      )}
    </div>
  )
}
