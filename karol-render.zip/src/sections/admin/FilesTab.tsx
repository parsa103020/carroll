"use client"

import { useEffect, useState, useCallback } from "react"
import { useApp } from "@/lib/store"
import { api, formatBytes, formatNumber, faDigits, timeAgo } from "@/lib/format"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import { HardDrive, Search, RefreshCw, Eye, Trash2, Loader2 } from "lucide-react"
import { cn } from "@/lib/utils"
import { EmptyState, Loader } from "./shared"

export function FilesTab() {
  const { toast } = useApp()
  const [files, setFiles] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [q, setQ] = useState("")
  const [category, setCategory] = useState("")
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [total, setTotal] = useState(0)
  const [busyId, setBusyId] = useState<string | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<any | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (q) params.set("q", q)
      if (category) params.set("category", category)
      params.set("page", String(page))
      const d = await api<any>(`/api/admin/files?${params}`)
      setFiles(d.files || [])
      setTotal(d.total)
      setTotalPages(d.totalPages)
    } catch (e: any) { toast(e.message, "error") }
    finally { setLoading(false) }
  }, [q, category, page, toast])

  useEffect(() => { const t = setTimeout(load, 250); return () => clearTimeout(t) }, [load])
  useEffect(() => { setPage(1) }, [q, category])

  async function togglePublic(f: any) {
    setBusyId(f.id)
    try {
      await api(`/api/admin/files/${f.id}`, { method: "PATCH", json: { isPublic: !f.isPublic } })
      toast(f.isPublic ? "خصوصی شد" : "عمومی شد", "success")
      await load()
    } catch (e: any) { toast(e.message, "error") }
    finally { setBusyId(null) }
  }

  async function del(id: string) {
    setBusyId(id)
    try {
      await api(`/api/admin/files/${id}`, { method: "DELETE" })
      toast("فایل حذف شد", "success")
      setDeleteTarget(null)
      await load()
    } catch (e: any) { toast(e.message, "error") }
    finally { setBusyId(null) }
  }

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-bold">مدیریت فایل‌ها</h2>
        <p className="text-xs text-muted-foreground mt-0.5">تمام فایل‌های آپلودشده در پلتفرم</p>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[180px]">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="نام فایل یا کاربر…" className="pr-9" />
        </div>
        <Select value={category || "all"} onValueChange={(v) => setCategory(v === "all" ? "" : v)}>
          <SelectTrigger className="w-[140px]"><SelectValue placeholder="همه دسته‌ها" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه</SelectItem>
            <SelectItem value="image">تصاویر</SelectItem>
            <SelectItem value="video">ویدیو</SelectItem>
            <SelectItem value="audio">صوت</SelectItem>
            <SelectItem value="gif">گیف</SelectItem>
            <SelectItem value="file">فایل</SelectItem>
          </SelectContent>
        </Select>
        <Button variant="outline" size="icon" onClick={load} disabled={loading}>
          <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
        </Button>
      </div>

      <div className="text-xs text-muted-foreground">{faDigits(formatNumber(total))} فایل · صفحه {faDigits(page)} از {faDigits(totalPages || 1)}</div>

      {loading ? <Loader rows={6} /> : files.length === 0 ? (
        <EmptyState icon={HardDrive} title="فایلی نیست" />
      ) : (
        <Card className="glass">
          <CardContent className="p-0">
            <div className="hidden md:block">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>نام</TableHead>
                    <TableHead>مالک</TableHead>
                    <TableHead className="text-center">حجم</TableHead>
                    <TableHead className="text-center">دسته</TableHead>
                    <TableHead className="text-center">عمومی</TableHead>
                    <TableHead>تاریخ</TableHead>
                    <TableHead className="text-left">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {files.map((f) => (
                    <TableRow key={f.id}>
                      <TableCell className="font-medium max-w-[200px] truncate">{f.name}</TableCell>
                      <TableCell>{f.owner?.displayName || f.owner?.username || "—"}</TableCell>
                      <TableCell className="text-center text-xs tabular-nums">{formatBytes(f.size)}</TableCell>
                      <TableCell className="text-center">
                        <Badge variant="secondary" className="text-[10px]">{f.category}</Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <Switch checked={f.isPublic} disabled={busyId === f.id} onCheckedChange={() => togglePublic(f)} />
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">{timeAgo(f.createdAt)}</TableCell>
                      <TableCell>
                        <div className="flex gap-1 justify-end">
                          <a href={f.url} target="_blank" rel="noreferrer">
                            <Button size="sm" variant="ghost" className="h-8 w-8 p-0"><Eye className="w-3.5 h-3.5" /></Button>
                          </a>
                          <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-rose-500" disabled={busyId === f.id} onClick={() => setDeleteTarget(f)}>
                            {busyId === f.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            <div className="md:hidden divide-y divide-border/40">
              {files.map((f) => (
                <div key={f.id} className="p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-sm truncate flex-1">{f.name}</span>
                    <Badge variant="secondary" className="text-[10px]">{f.category}</Badge>
                  </div>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>{f.owner?.displayName || f.owner?.username}</span>
                    <span className="tabular-nums">{formatBytes(f.size)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Switch checked={f.isPublic} disabled={busyId === f.id} onCheckedChange={() => togglePublic(f)} />
                      <span className="text-xs text-muted-foreground">{f.isPublic ? "عمومی" : "خصوصی"}</span>
                    </div>
                    <div className="flex gap-1">
                      <a href={f.url} target="_blank" rel="noreferrer">
                        <Button size="sm" variant="ghost" className="h-8 w-8 p-0"><Eye className="w-3.5 h-3.5" /></Button>
                      </a>
                      <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-rose-500" disabled={busyId === f.id} onClick={() => setDeleteTarget(f)}>
                        {busyId === f.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))}>قبلی</Button>
          <span className="text-xs text-muted-foreground px-2">{faDigits(page)} / {faDigits(totalPages)}</span>
          <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>بعدی</Button>
        </div>
      )}

      {deleteTarget && (
        <AlertDialog open onOpenChange={(o) => !o && setDeleteTarget(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>حذف فایل</AlertDialogTitle>
              <AlertDialogDescription>آیا از حذف «{deleteTarget.name}» مطمئن هستید؟ فایل از دیسک نیز حذف خواهد شد.</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>انصراف</AlertDialogCancel>
              <AlertDialogAction className="bg-rose-500 hover:bg-rose-600 text-white" onClick={() => del(deleteTarget.id)}>حذف</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  )
}
