"use client"

import { useState } from "react"
import { useApp } from "@/lib/store"
import { Card, CardContent } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Shield, Users, Settings as SettingsIcon, MessageCircle, FileText, ShoppingBag,
  Ticket as TicketIcon, HardDrive, LayoutDashboard, FileWarning, Package,
  UserCog, Activity,
} from "lucide-react"
import { cn } from "@/lib/utils"
import type { AdminTab } from "./shared"
import { DashboardTab } from "./DashboardTab"
import { UsersTab } from "./UsersTab"
import { SettingsTab } from "./SettingsTab"
import { ChatTab } from "./ChatTab"
import { ReportsTab } from "./ReportsTab"
import { ConfigsTab } from "./ConfigsTab"
import { ContentTab } from "./ContentTab"
import { ShopTab } from "./ShopTab"
import { TicketsTab } from "./TicketsTab"
import { FilesTab } from "./FilesTab"
import { LogsTab } from "./LogsTab"
import { RolesTab } from "./RolesTab"

const TABS: { id: AdminTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: "dashboard", label: "داشبورد", icon: LayoutDashboard },
  { id: "users", label: "کاربران", icon: Users },
  { id: "roles", label: "نقش‌ها", icon: UserCog },
  { id: "settings", label: "تنظیمات", icon: SettingsIcon },
  { id: "chat", label: "چت", icon: MessageCircle },
  { id: "reports", label: "گزارش‌ها", icon: FileWarning },
  { id: "content", label: "محتوا", icon: FileText },
  { id: "configs", label: "کانفیگ‌ها", icon: Package },
  { id: "shop", label: "فروشگاه", icon: ShoppingBag },
  { id: "tickets", label: "تیکت‌ها", icon: TicketIcon },
  { id: "files", label: "فایل‌ها", icon: HardDrive },
  { id: "logs", label: "لاگ‌ها", icon: Activity },
]

export default function AdminSection() {
  const { user, sectionParams } = useApp()
  const [active, setActive] = useState<AdminTab>(
    (sectionParams?.tab as AdminTab) || "dashboard",
  )

  if (!user || !user.roles.includes("admin")) {
    return (
      <div className="min-h-full flex items-center justify-center p-6">
        <Card className="glass max-w-md w-full">
          <CardContent className="p-8 text-center">
            <div className="w-14 h-14 rounded-2xl bg-rose-500/15 text-rose-500 flex items-center justify-center mx-auto mb-4">
              <Shield className="w-7 h-7" />
            </div>
            <h2 className="text-lg font-bold">دسترسی غیرمجاز</h2>
            <p className="text-sm text-muted-foreground mt-2">
              این بخش فقط برای مدیران قابل دسترسی است. اگر فکر می‌کنید این خطا اشتباه است، با پشتیبانی تماس بگیرید.
            </p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="h-full flex flex-col">
      <div className="px-4 lg:px-6 pt-4 lg:pt-5 pb-3">
        <div className="max-w-6xl mx-auto">
          <div className="rounded-2xl gradient-aurora p-4 lg:p-5 shadow-glow">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white/15 backdrop-blur flex items-center justify-center shrink-0">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <div className="min-w-0">
                <h1 className="text-lg lg:text-xl font-black text-white truncate">
                  پنل مدیریت کارول
                </h1>
                <p className="text-[11px] lg:text-xs text-white/80 mt-0.5">
                  دسترسی کامل به مدیریت پلتفرم
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 min-h-0 flex flex-col lg:flex-row">
        <aside className="lg:w-56 lg:shrink-0 border-b lg:border-b-0 lg:border-l border-border/40 p-2 lg:p-3">
          <div className="flex lg:flex-col gap-1 overflow-x-auto lg:overflow-visible thin-scrollbar no-scrollbar lg:h-full">
            {TABS.map((t) => {
              const isActive = active === t.id
              return (
                <button
                  key={t.id}
                  onClick={() => setActive(t.id)}
                  className={cn(
                    "flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium transition-all shrink-0 lg:w-full lg:justify-start justify-center min-h-[40px]",
                    isActive
                      ? "bg-primary text-primary-foreground shadow-soft"
                      : "text-muted-foreground hover:bg-accent hover:text-accent-foreground",
                  )}
                >
                  <t.icon className="w-4 h-4 shrink-0" />
                  <span className="whitespace-nowrap">{t.label}</span>
                </button>
              )
            })}
          </div>
        </aside>

        <div className="flex-1 min-h-0 min-w-0">
          <ScrollArea className="h-full">
            <div className="p-4 lg:p-6 max-w-6xl mx-auto">
              <div key={active} className="animate-fade-in">
                {active === "dashboard" && <DashboardTab onNavigate={setActive} />}
                {active === "users" && <UsersTab />}
                {active === "settings" && <SettingsTab />}
                {active === "chat" && <ChatTab />}
                {active === "reports" && <ReportsTab />}
                {active === "configs" && <ConfigsTab />}
                {active === "content" && <ContentTab />}
                {active === "shop" && <ShopTab />}
                {active === "tickets" && <TicketsTab />}
                {active === "files" && <FilesTab />}
                {active === "logs" && <LogsTab />}
                {active === "roles" && <RolesTab />}
              </div>
            </div>
          </ScrollArea>
        </div>
      </div>
    </div>
  )
}
