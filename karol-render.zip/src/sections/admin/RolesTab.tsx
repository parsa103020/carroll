"use client"

import { useEffect, useState, useCallback } from "react"
import { useApp } from "@/lib/store"
import { api, formatNumber, faDigits } from "@/lib/format"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Shield, Crown, MessageSquare, Video, Film, HardDrive, ShoppingBag, Ticket, Megaphone, UserCog, Search, Check } from "lucide-react"
import { cn } from "@/lib/utils"
import { EmptyState, Loader } from "./shared"

interface UserT {
  id: string
  username: string
  displayName: string | null
  avatarUrl: string | null
  roles: string
  isVip: boolean
}

const ROLES = [
  { key: "admin", label: "مدیر کل", icon: Shield, color: "#fb7185", duties: ["دسترسی کامل به همه بخش‌ها", "مدیریت کاربران و نقش‌ها", "تنظیمات سایت", "مشاهده لاگ‌ها"] },
  { key: "moderator", label: "ناظم عمومی", icon: UserCog, color: "#2dd4bf", duties: ["نظارت بر کل پلتفرم", "حذف محتوای نامناسب", "مدیریت گزارش‌ها"] },
  { key: "chat_mod", label: "ناظم چت", icon: MessageSquare, color: "#a78bfa", duties: ["حذف پیام‌ها", "کیک و میوت کاربران", "پاسخ به گزارش‌های چت", "مدیریت روم‌ها"] },
  { key: "video_mod", label: "ناظم ویدیو", icon: Video, color: "#fbbf24", duties: ["حذف ویدیوهای نامناسب", "مدیریت کامنت‌های ویدیو"] },
  { key: "reel_mod", label: "ناظم ریلز", icon: Film, color: "#f472b6", duties: ["حذف ریلزهای نامناسب", "مدیریت کامنت‌های ریلز"] },
  { key: "feed_mod", label: "ناظم فید", icon: Megaphone, color: "#a3e635", duties: ["حذف پست‌های نامناسب", "مدیریت کامنت‌های فید"] },
  { key: "drive_mod", label: "ناظم فایل‌ها", icon: HardDrive, color: "#38bdf8", duties: ["حذف فایل‌های نامناسب", "مدیریت آپلود سنتر"] },
  { key: "shop_mod", label: "ناظم فروشگاه", icon: ShoppingBag, color: "#fbbf24", duties: ["بررسی رسیدهای پرداخت", "تأیید/رد سفارش‌ها"] },
  { key: "ticket_mod", label: "ناظم تیکت", icon: Ticket, color: "#c4b5fd", duties: ["پاسخ به تیکت‌ها", "بستن تیکت‌ها"] },
]

export function RolesTab() {
  const { toast } = useApp()
  const [counts, setCounts] = useState<Record<string, number>>({})
  const [loading, setLoading] = useState(true)
  const [assignRole, setAssignRole] = useState<typeof ROLES[0] | null>(null)
  const [users, setUsers] = useState<UserT[]>([])
  const [search, setSearch] = useState("")
  const [selectedUser, setSelectedUser] = useState<UserT | null>(null)
  const [busy, setBusy] = useState(false)

  const loadCounts = useCallback(async () => {
    setLoading(true)
    try {
      const d = await api<{ counts: Record<string, number> }>("/api/admin/users/role-counts")
      setCounts(d.counts)
    } catch {}
    finally { setLoading(false) }
  }, [])

  useEffect(() => { loadCounts() }, [loadCounts])

  async function searchUsers(q: string) {
    setSearch(q)
    if (q.length < 2) { setUsers([]); return }
    try {
      const d = await api<{ users: UserT[] }>(`/api/admin/users?q=${encodeURIComponent(q)}&pageSize=10`)
      setUsers(d.users)
    } catch {}
  }

  async function assignRoleToUser() {
    if (!selectedUser || !assignRole) return
    setBusy(true)
    try {
      const currentRoles = selectedUser.roles.split(",").map((r) => r.trim()).filter(Boolean)
      const newRoles = currentRoles.includes(assignRole.key)
        ? currentRoles.filter((r) => r !== assignRole.key)
        : [...currentRoles, assignRole.key, ...(currentRoles.includes("user") ? [] : ["user"])]
      await api(`/api/admin/users/${selectedUser.id}`, { method: "PATCH", json: { roles: newRoles.join(",") } })
      toast(`${assignRole.label} ${currentRoles.includes(assignRole.key) ? "سلب شد" : "اختصاص یافت"}`, "success")
      setSelectedUser(null)
      setAssignRole(null)
      loadCounts()
    } catch (e: any) {
      toast(e.message, "error")
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl gradient-aurora flex items-center justify-center shadow-glow">
          <UserCog className="w-5 h-5 text-white" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-primary-c">نقش‌های مدیران</h2>
          <p className="text-xs text-muted-c">وظایف هر نقش و اختصاص آن به کاربران</p>
        </div>
      </div>

      {loading ? (
        <Loader rows={3} />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {ROLES.map((role) => {
            const count = counts[role.key] || 0
            return (
              <Card key={role.key} className="glass border-hair overflow-hidden hover:border-accent-soft/40 transition-colors">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: `${role.color}22`, color: role.color }}>
                        <role.icon className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="font-semibold text-primary-c text-sm">{role.label}</div>
                        <div className="text-[10px] text-muted-c font-mono">{role.key}</div>
                      </div>
                    </div>
                    <Badge className="bg-accent-15 text-accent-soft">{faDigits(count)} کاربر</Badge>
                  </div>
                  <div className="space-y-1 mb-3">
                    <div className="text-[10px] text-muted-c font-semibold uppercase tracking-wider">وظایف:</div>
                    {role.duties.map((d) => (
                      <div key={d} className="flex items-start gap-1.5 text-[11px] text-secondary-c">
                        <Check className="w-3 h-3 text-accent-soft shrink-0 mt-0.5" />
                        <span>{d}</span>
                      </div>
                    ))}
                  </div>
                  <Button size="sm" variant="outline" className="w-full" onClick={() => setAssignRole(role)}>
                    <UserCog className="w-3.5 h-3.5 ml-1.5" /> اختصاص نقش
                  </Button>
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}

      <Dialog open={!!assignRole} onOpenChange={(o) => { if (!o) { setAssignRole(null); setSelectedUser(null); setUsers([]); setSearch("") } }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>اختصاص نقش: {assignRole?.label}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-c" />
              <Input value={search} onChange={(e) => searchUsers(e.target.value)} placeholder="نام کاربری را جستجو کنید…" className="pr-9" autoFocus />
            </div>
            <ScrollArea className="h-64">
              {users.length === 0 ? (
                <div className="text-center text-xs text-muted-c py-8">برای جستجو حداقل ۲ حرف وارد کنید</div>
              ) : (
                <div className="space-y-1">
                  {users.map((u) => {
                    const hasRole = u.roles.split(",").map((r) => r.trim()).includes(assignRole!.key)
                    const isSel = selectedUser?.id === u.id
                    return (
                      <button
                        key={u.id}
                        onClick={() => setSelectedUser(isSel ? null : u)}
                        className={cn(
                          "w-full flex items-center gap-3 p-2.5 rounded-lg border transition-colors text-right",
                          isSel ? "border-accent-soft bg-accent-15" : "border-hair hover:bg-white/[0.03]",
                        )}
                      >
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={u.avatarUrl || undefined} />
                          <AvatarFallback className="text-xs bg-accent-15 text-accent-soft">{u.username[0]?.toUpperCase()}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium text-primary-c truncate">{u.displayName || u.username}</div>
                          <div className="text-[10px] text-muted-c">@{u.username}</div>
                        </div>
                        {hasRole && <Badge className="bg-success-15 text-success text-[10px]">دارای نقش</Badge>}
                        {u.isVip && <Crown className="w-3.5 h-3.5 text-gold" />}
                      </button>
                    )
                  })}
                </div>
              )}
            </ScrollArea>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setAssignRole(null); setSelectedUser(null) }}>انصراف</Button>
            <Button onClick={assignRoleToUser} disabled={!selectedUser || busy} className="gradient-karol text-white">
              {selectedUser && selectedUser.roles.split(",").map((r) => r.trim()).includes(assignRole!.key) ? "سلب نقش" : "اختصاص نقش"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
