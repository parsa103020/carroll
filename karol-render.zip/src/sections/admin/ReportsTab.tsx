"use client"

import { useEffect, useState, useCallback } from "react"
import { useApp } from "@/lib/store"
import { api, timeAgo, faDigits } from "@/lib/format"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  FileWarning, Check, Ban, RefreshCw, Loader2, MoreVertical, ShieldAlert, Inbox, UserFlag,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { EmptyState, Loader } from "./shared"

const REPORT_STATUS: Record<string, { label: string; cls: string }> = {
  open: { label: "باز", cls: "bg-rose-500/15 text-rose-500" },
  dismissed: { label: "رد شده", cls: "bg-muted text-muted-foreground" },
  resolved: { label: "حل شده", cls: "bg-emerald-500/15 text-emerald-500" },
}

const USER_REPORT_REASONS: Record<string, string> = {
  spam: "اسپم",
  insult: "توهین",
  inappropriate: "محتوای نامناسب",
  fraud: "کلاهبرداری",
  other: "دیگر",
}

type ReportTab = "chat" | "users"

export function ReportsTab() {
  const { toast } = useApp()
  const [tab, setTab] = useState<ReportTab>("chat")
  const [reports, setReports] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [status, setStatus] = useState<string>("open")
  const [busyId, setBusyId] = useState<string | null>(null)

  const endpoint =
    tab === "chat" ? "/api/admin/chat/reports" : "/api/admin/users/reports"

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const d = await api<any>(`${endpoint}?status=${status}`)
      setReports(d.reports || [])
    } catch (e: any) {
      toast(e.message, "error")
    } finally {
      setLoading(false)
    }
  }, [endpoint, status, toast])

  useEffect(() => {
    load()
  }, [load])

  async function chatReportAction(
    id: string,
    action: "dismiss" | "delete_message" | "ban_user",
    reason?: string,
  ) {
    setBusyId(id)
    try {
      await api(`/api/admin/chat/reports/${id}/action`, {
        method: "POST",
        json: { action, ...(reason ? { reason } : {}) },
      })
      const labels = {
        dismiss: "گزارش رد شد",
        delete_message: "پیام حذف شد",
        ban_user: "کاربر مسدود شد",
      }
      toast(labels[action], "success")
      await load()
    } catch (e: any) {
      toast(e.message, "error")
    } finally {
      setBusyId(null)
    }
  }

  async function userReportAction(
    id: string,
    action: "dismiss" | "ban_user",
    reason?: string,
  ) {
    setBusyId(id)
    try {
      await api(`/api/admin/users/reports/${id}/action`, {
        method: "POST",
        json: { action, ...(reason ? { reason } : {}) },
      })
      const labels = { dismiss: "گزارش رد شد", ban_user: "کاربر مسدود شد" }
      toast(labels[action], "success")
      await load()
    } catch (e: any) {
      toast(e.message, "error")
    } finally {
      setBusyId(null)
    }
  }

  const openCount = reports.filter((r) => r.status === "open").length

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h2 className="text-xl font-bold flex items-center gap-2">
            <FileWarning className="w-5 h-5 text-rose-500" />
            گزارش‌ها
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            گزارش پیام‌های چت و کاربران
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <div className="inline-flex rounded-lg border border-border bg-card/40 overflow-hidden">
            <button
              onClick={() => setTab("chat")}
              className={cn(
                "px-3 h-9 text-xs font-medium transition-colors",
                tab === "chat"
                  ? "bg-primary/15 text-primary"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              پیام‌ها
            </button>
            <button
              onClick={() => setTab("users")}
              className={cn(
                "px-3 h-9 text-xs font-medium transition-colors border-r border-border/60",
                tab === "users"
                  ? "bg-primary/15 text-primary"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              کاربران
            </button>
          </div>
          <Select value={status} onValueChange={setStatus}>
            <SelectTrigger className="w-[140px] h-9">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="open">باز</SelectItem>
              <SelectItem value="dismissed">رد شده</SelectItem>
              <SelectItem value="resolved">حل شده</SelectItem>
              <SelectItem value="all">همه</SelectItem>
            </SelectContent>
          </Select>
          <Button
            variant="outline"
            size="icon"
            onClick={load}
            disabled={loading}
            className="h-9 w-9"
          >
            <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
          </Button>
        </div>
      </div>

      {!loading && reports.length > 0 && (
        <div className="text-xs text-muted-foreground">
          {faDigits(reports.length)} گزارش
          {status === "open" && openCount > 0 && (
            <span className="text-rose-500 mr-1">
              · {faDigits(openCount)} مورد نیازمند بررسی
            </span>
          )}
        </div>
      )}

      {loading ? (
        <Loader rows={4} />
      ) : reports.length === 0 ? (
        <EmptyState
          icon={Inbox}
          title="گزارشی وجود ندارد"
          hint={
            tab === "chat"
              ? "پیام‌های گزارش‌شده اینجا نمایش داده می‌شوند"
              : "کاربران گزارش‌شده اینجا نمایش داده می‌شوند"
          }
        />
      ) : (
        <div className="space-y-2">
          {tab === "chat"
            ? reports.map((rp) => {
                const st = REPORT_STATUS[rp.status] || REPORT_STATUS.open
                return (
                  <Card
                    key={rp.id}
                    className={cn("glass", rp.status === "open" && "border-rose-500/30")}
                  >
                    <CardContent className="p-3 space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0 space-y-2">
                          <div className="flex items-center gap-2 text-xs flex-wrap">
                            <Badge className={cn("text-[10px]", st.cls)}>{st.label}</Badge>
                            <span className="text-muted-foreground">روم:</span>
                            <span className="font-medium">{rp.room?.name || "—"}</span>
                            <span className="text-muted-foreground">·</span>
                            <span className="text-muted-foreground">{timeAgo(rp.createdAt)}</span>
                          </div>

                          <div className="p-2 rounded-lg bg-muted/40 border border-border/40 space-y-1">
                            <div className="flex items-center gap-2 text-[11px]">
                              <span className="text-muted-foreground">از:</span>
                              <Avatar className="w-5 h-5">
                                <AvatarImage src={rp.reportedUser?.avatarUrl || undefined} />
                                <AvatarFallback className="text-[9px] bg-primary/15 text-primary">
                                  {rp.message?.username?.[0]?.toUpperCase() || "?"}
                                </AvatarFallback>
                              </Avatar>
                              <span className="font-medium">@{rp.message?.username || "—"}</span>
                              {rp.reportedUser && (
                                <span className="text-muted-foreground">
                                  · @{rp.reportedUser.username}
                                </span>
                              )}
                            </div>
                            <div className="text-sm">
                              {rp.message?.deletedAt ? (
                                <span className="text-muted-foreground italic line-through">
                                  {rp.message?.content || "[رسانه حذف شده]"}
                                </span>
                              ) : rp.message?.type === "text" ? (
                                rp.message.content || "[خالی]"
                              ) : rp.message?.mediaUrl ? (
                                <a
                                  href={rp.message.mediaUrl}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="text-primary text-xs underline"
                                >
                                  مشاهده رسانه
                                </a>
                              ) : (
                                <span className="text-muted-foreground italic">[رسانه]</span>
                              )}
                            </div>
                            <div className="text-[10px] text-muted-foreground pt-1 border-t border-border/30">
                              <span className="text-rose-500/80">دلیل:</span> {rp.reason}
                            </div>
                          </div>

                          <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
                            <ShieldAlert className="w-3 h-3" />
                            <span>گزارش‌دهنده: @{rp.reporter?.username || "—"}</span>
                          </div>
                        </div>

                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-8 w-8 p-0 shrink-0"
                              disabled={busyId === rp.id}
                            >
                              {busyId === rp.id ? (
                                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                              ) : (
                                <MoreVertical className="w-3.5 h-3.5" />
                              )}
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="left">
                            <DropdownMenuItem
                              onClick={() => chatReportAction(rp.id, "dismiss")}
                            >
                              <Check className="w-4 h-4 ml-2 text-emerald-500" /> رد گزارش
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => chatReportAction(rp.id, "delete_message")}
                              disabled={!!rp.message?.deletedAt}
                            >
                              <FileWarning className="w-4 h-4 ml-2 text-rose-500" /> حذف پیام
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() =>
                                chatReportAction(rp.id, "ban_user", "تخلف در چت")
                              }
                              disabled={
                                !rp.reportedUserId || rp.reportedUser?.banned
                              }
                            >
                              <Ban className="w-4 h-4 ml-2 text-rose-500" /> مسدود کاربر
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </CardContent>
                  </Card>
                )
              })
            : reports.map((rp) => {
                const st = REPORT_STATUS[rp.status] || REPORT_STATUS.open
                const reasonLabel =
                  USER_REPORT_REASONS[rp.reason] || rp.reason || "—"
                return (
                  <Card
                    key={rp.id}
                    className={cn("glass", rp.status === "open" && "border-rose-500/30")}
                  >
                    <CardContent className="p-3 space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0 space-y-2">
                          <div className="flex items-center gap-2 text-xs flex-wrap">
                            <Badge className={cn("text-[10px]", st.cls)}>{st.label}</Badge>
                            <span className="text-muted-foreground">دلیل:</span>
                            <span className="font-medium">{reasonLabel}</span>
                            <span className="text-muted-foreground">·</span>
                            <span className="text-muted-foreground">
                              {timeAgo(rp.createdAt)}
                            </span>
                            {rp.reportedUser?.banned && (
                              <Badge className="text-[9px] bg-rose-500/15 text-rose-500">
                                مسدود شده
                              </Badge>
                            )}
                          </div>

                          <div className="p-2 rounded-lg bg-muted/40 border border-border/40 space-y-1">
                            <div className="flex items-center gap-2 text-[11px]">
                              <span className="text-muted-foreground">کاربر گزارش‌شده:</span>
                              <Avatar className="w-5 h-5">
                                <AvatarImage src={rp.reportedUser?.avatarUrl || undefined} />
                                <AvatarFallback className="text-[9px] bg-primary/15 text-primary">
                                  {rp.reportedUser?.username?.[0]?.toUpperCase() || "?"}
                                </AvatarFallback>
                              </Avatar>
                              <span className="font-medium">
                                @{rp.reportedUser?.username || "—"}
                              </span>
                              {rp.reportedUser?.displayName && (
                                <span className="text-muted-foreground">
                                  · {rp.reportedUser.displayName}
                                </span>
                              )}
                            </div>
                            {rp.description && (
                              <div className="text-sm text-muted-foreground pt-1 border-t border-border/30">
                                {rp.description}
                              </div>
                            )}
                          </div>

                          <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
                            <ShieldAlert className="w-3 h-3" />
                            <span>گزارش‌دهنده: @{rp.reporter?.username || "—"}</span>
                          </div>
                        </div>

                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-8 w-8 p-0 shrink-0"
                              disabled={busyId === rp.id}
                            >
                              {busyId === rp.id ? (
                                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                              ) : (
                                <MoreVertical className="w-3.5 h-3.5" />
                              )}
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="left">
                            <DropdownMenuItem
                              onClick={() => userReportAction(rp.id, "dismiss")}
                            >
                              <Check className="w-4 h-4 ml-2 text-emerald-500" /> رد گزارش
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() =>
                                userReportAction(rp.id, "ban_user", "گزارش رفتار نامناسب")
                              }
                              disabled={
                                !rp.reportedUserId || rp.reportedUser?.banned
                              }
                            >
                              <Ban className="w-4 h-4 ml-2 text-rose-500" /> مسدود کاربر
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
        </div>
      )}
    </div>
  )
}
