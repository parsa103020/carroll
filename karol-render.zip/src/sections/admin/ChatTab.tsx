"use client"

import { useEffect, useState, useCallback } from "react"
import { useApp } from "@/lib/store"
import { api, timeAgo, faDigits } from "@/lib/format"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import {
  MessageCircle, Check, Trash2, Plus, RefreshCw, Loader2, Edit2, ArrowRight,
  Search, RotateCcw, ImageIcon, Film, Mic, Sticker, FileText, Type,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { EmptyState, Loader } from "./shared"

const MSG_TYPE_META: Record<string, { label: string; icon: React.ComponentType<{ className?: string }>; cls: string }> = {
  text: { label: "متن", icon: Type, cls: "bg-primary/15 text-primary" },
  image: { label: "تصویر", icon: ImageIcon, cls: "bg-emerald-500/15 text-emerald-500" },
  video: { label: "ویدیو", icon: Film, cls: "bg-rose-500/15 text-rose-500" },
  voice: { label: "صوت", icon: Mic, cls: "bg-amber-500/15 text-amber-500" },
  gif: { label: "گیف", icon: ImageIcon, cls: "bg-purple-500/15 text-purple-500" },
  sticker: { label: "استیکر", icon: Sticker, cls: "bg-pink-500/15 text-pink-500" },
  file: { label: "فایل", icon: FileText, cls: "bg-sky-500/15 text-sky-500" },
}

export function ChatTab() {
  const { toast } = useApp()
  const [rooms, setRooms] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [editingRoom, setEditingRoom] = useState<any | null>(null)
  const [creatingRoom, setCreatingRoom] = useState(false)
  const [deleteRoom, setDeleteRoom] = useState<any | null>(null)
  const [selectedRoom, setSelectedRoom] = useState<any | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const rm = await api<any>("/api/chat/rooms")
      setRooms(rm.rooms || [])
    } catch (e: any) { toast(e.message, "error") }
    finally { setLoading(false) }
  }, [toast])

  useEffect(() => { load() }, [load])

  async function saveRoom(room: any, isNew: boolean) {
    try {
      if (isNew) await api("/api/chat/rooms", { method: "POST", json: room })
      else await api(`/api/chat/rooms/${room.id}`, { method: "PATCH", json: room })
      toast("روم ذخیره شد", "success")
      setEditingRoom(null); setCreatingRoom(false)
      await load()
    } catch (e: any) { toast(e.message, "error") }
  }

  async function deleteRoomFn(id: string) {
    try {
      await api(`/api/chat/rooms/${id}`, { method: "DELETE" })
      toast("روم حذف شد", "success")
      setDeleteRoom(null)
      await load()
    } catch (e: any) { toast(e.message, "error") }
  }

  if (selectedRoom) {
    return (
      <RoomMessagesBrowser
        room={selectedRoom}
        onBack={() => setSelectedRoom(null)}
      />
    )
  }

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h2 className="text-xl font-bold">مدیریت چت</h2>
          <p className="text-xs text-muted-foreground mt-0.5">روم‌ها و پیام‌ها</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={load} disabled={loading}>
            <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
          </Button>
          <Button size="sm" onClick={() => setCreatingRoom(true)}>
            <Plus className="w-4 h-4 ml-1" /> روم جدید
          </Button>
        </div>
      </div>

      {loading ? <Loader rows={4} /> : rooms.length === 0 ? (
        <EmptyState icon={MessageCircle} title="رومی وجود ندارد" />
      ) : (
        <Card className="glass">
          <CardContent className="p-0">
            <div className="hidden md:block">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>نام</TableHead>
                    <TableHead>نوع</TableHead>
                    <TableHead className="text-center">اعضا</TableHead>
                    <TableHead className="text-center">ترتیب</TableHead>
                    <TableHead className="text-left">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rooms.map((r) => (
                    <TableRow
                      key={r.id}
                      className="cursor-pointer hover:bg-accent-15"
                      onClick={() => setSelectedRoom(r)}
                    >
                      <TableCell className="font-medium">
                        <button className="text-right hover:text-primary transition-colors">{r.name}</button>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary" className={r.type === "vip" ? "bg-gold/15 text-gold" : ""}>
                          {r.type === "vip" ? "VIP" : "عمومی"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center tabular-nums">{faDigits(r.memberCount)}</TableCell>
                      <TableCell className="text-center tabular-nums">{faDigits(r.order)}</TableCell>
                      <TableCell onClick={(e) => e.stopPropagation()}>
                        <div className="flex gap-1 justify-end">
                          <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => setEditingRoom(r)}>
                            <Edit2 className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => setDeleteRoom(r)}>
                            <Trash2 className="w-3.5 h-3.5 text-rose-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            <div className="md:hidden divide-y divide-border/40">
              {rooms.map((r) => (
                <div key={r.id} className="p-3 flex items-center justify-between" onClick={() => setSelectedRoom(r)}>
                  <div className="min-w-0">
                    <div className="font-medium text-sm truncate">{r.name}</div>
                    <div className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1">
                      <Badge variant="secondary" className={cn("text-[10px]", r.type === "vip" ? "bg-gold/15 text-gold" : "")}>
                        {r.type === "vip" ? "VIP" : "عمومی"}
                      </Badge>
                      {faDigits(r.memberCount)} عضو
                    </div>
                  </div>
                  <div className="flex gap-1" onClick={(e) => e.stopPropagation()}>
                    <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => setEditingRoom(r)}>
                      <Edit2 className="w-3.5 h-3.5" />
                    </Button>
                    <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => setDeleteRoom(r)}>
                      <Trash2 className="w-3.5 h-3.5 text-rose-500" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {(editingRoom || creatingRoom) && (
        <RoomDialog room={editingRoom} isNew={creatingRoom} onClose={() => { setEditingRoom(null); setCreatingRoom(false) }} onSave={saveRoom} />
      )}

      {deleteRoom && (
        <AlertDialog open onOpenChange={(o) => !o && setDeleteRoom(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>حذف روم</AlertDialogTitle>
              <AlertDialogDescription>آیا از حذف «{deleteRoom.name}» مطمئن هستید؟ تمام پیام‌ها و اعضا نیز حذف خواهند شد.</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>انصراف</AlertDialogCancel>
              <AlertDialogAction className="bg-rose-500 hover:bg-rose-600 text-white" onClick={() => deleteRoomFn(deleteRoom.id)}>حذف</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  )
}

function RoomMessagesBrowser({ room, onBack }: { room: any; onBack: () => void }) {
  const { toast } = useApp()
  const [messages, setMessages] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [q, setQ] = useState("")
  const [onlyDeleted, setOnlyDeleted] = useState(false)
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [total, setTotal] = useState(0)
  const [busyId, setBusyId] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (q) params.set("q", q)
      if (onlyDeleted) params.set("deleted", "true")
      params.set("page", String(page))
      const d = await api<any>(`/api/admin/chat/rooms/${room.id}/messages?${params}`)
      setMessages(d.messages || [])
      setTotal(d.total)
      setTotalPages(d.totalPages || 1)
    } catch (e: any) { toast(e.message, "error") }
    finally { setLoading(false) }
  }, [room.id, q, onlyDeleted, page, toast])

  useEffect(() => {
    const t = setTimeout(load, 250)
    return () => clearTimeout(t)
  }, [load])

  useEffect(() => { setPage(1) }, [q, onlyDeleted])

  async function softDelete(id: string) {
    setBusyId(id)
    try {
      await api(`/api/admin/chat/messages/${id}`, { method: "DELETE" })
      toast("پیام حذف شد", "success")
      await load()
    } catch (e: any) { toast(e.message, "error") }
    finally { setBusyId(null) }
  }

  async function restore(id: string) {
    setBusyId(id)
    try {
      await api(`/api/admin/chat/messages/${id}`, { method: "PATCH", json: { restore: true } })
      toast("پیام بازیابی شد", "success")
      await load()
    } catch (e: any) { toast(e.message, "error") }
    finally { setBusyId(null) }
  }

  return (
    <div className="space-y-3 animate-fade-in">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" onClick={onBack} className="h-9">
          <ArrowRight className="w-4 h-4 ml-1" /> بازگشت
        </Button>
        <div className="min-w-0">
          <h2 className="text-lg font-bold truncate">{room.name}</h2>
          <p className="text-[11px] text-muted-foreground">پیام‌های روم (شامل حذف‌شده‌ها)</p>
        </div>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="جستجوی متن یا نام کاربری…" className="pr-9" />
        </div>
        <label className="flex items-center gap-2 px-3 py-2 rounded-lg glass border border-border/40 cursor-pointer text-xs">
          <Switch checked={onlyDeleted} onCheckedChange={setOnlyDeleted} />
          <span>فقط حذف‌شده</span>
        </label>
        <Button variant="outline" size="icon" onClick={load} disabled={loading} className="h-9 w-9">
          <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
        </Button>
      </div>

      <div className="text-xs text-muted-foreground">{faDigits(total)} پیام · صفحه {faDigits(page)} از {faDigits(totalPages || 1)}</div>

      {loading ? <Loader rows={5} /> : messages.length === 0 ? (
        <EmptyState icon={MessageCircle} title="پیامی نیست" hint="جستجو را تغییر دهید یا فیلتر را حذف کنید" />
      ) : (
        <div className="space-y-2">
          {messages.map((m) => {
            const meta = MSG_TYPE_META[m.type] || MSG_TYPE_META.text
            const deleted = !!m.deletedAt
            return (
              <Card
                key={m.id}
                className={cn(
                  "glass",
                  deleted && "border-rose-500/30 bg-rose-500/5",
                )}
              >
                <CardContent className="p-3 space-y-1.5">
                  <div className="flex items-center gap-2 text-xs flex-wrap">
                    <Badge variant="secondary" className={cn("text-[10px]", meta.cls)}>
                      <meta.icon className="w-3 h-3 ml-1" /> {meta.label}
                    </Badge>
                    <span className="font-medium">@{m.username}</span>
                    <span className="text-muted-foreground">·</span>
                    <span className="text-muted-foreground">{timeAgo(m.createdAt)}</span>
                    {deleted && (
                      <Badge className="text-[10px] bg-rose-500/15 text-rose-500">حذف شده</Badge>
                    )}
                    {m.user?.banned && (
                      <Badge className="text-[10px] bg-rose-500/15 text-rose-500">کاربر مسدود</Badge>
                    )}
                  </div>
                  <div className={cn("text-sm", deleted && "line-through text-muted-foreground")}>
                    {m.type === "text" ? (
                      m.content || "[خالی]"
                    ) : m.mediaUrl ? (
                      <a href={m.mediaUrl} target="_blank" rel="noreferrer" className="text-primary text-xs underline">
                        مشاهده رسانه
                      </a>
                    ) : deleted ? (
                      <span className="text-muted-foreground italic">[رسانه حذف شده]</span>
                    ) : (
                      <span className="text-muted-foreground italic">[رسانه]</span>
                    )}
                  </div>
                  <div className="flex justify-end gap-1 pt-1">
                    {deleted ? (
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-8"
                        disabled={busyId === m.id}
                        onClick={() => restore(m.id)}
                      >
                        {busyId === m.id ? <Loader2 className="w-3.5 h-3.5 animate-spin ml-1" /> : <RotateCcw className="w-3.5 h-3.5 ml-1" />}
                        بازیابی
                      </Button>
                    ) : (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 text-rose-500 hover:bg-rose-500/10"
                        disabled={busyId === m.id}
                        onClick={() => softDelete(m.id)}
                      >
                        {busyId === m.id ? <Loader2 className="w-3.5 h-3.5 animate-spin ml-1" /> : <Trash2 className="w-3.5 h-3.5 ml-1" />}
                        حذف
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}

      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))}>قبلی</Button>
          <span className="text-xs text-muted-foreground px-2">{faDigits(page)} / {faDigits(totalPages)}</span>
          <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>بعدی</Button>
        </div>
      )}
    </div>
  )
}

function RoomDialog({ room, isNew, onClose, onSave }: { room: any; isNew: boolean; onClose: () => void; onSave: (r: any, isNew: boolean) => void }) {
  const [name, setName] = useState(room?.name || "")
  const [description, setDescription] = useState(room?.description || "")
  const [type, setType] = useState(room?.type || "public")
  const [order, setOrder] = useState(String(room?.order ?? 0))

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{isNew ? "روم جدید" : "ویرایش روم"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <div className="space-y-1.5">
            <Label>نام</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} maxLength={100} />
          </div>
          <div className="space-y-1.5">
            <Label>توضیحات</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} maxLength={500} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>نوع</Label>
              <Select value={type} onValueChange={setType}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="public">عمومی</SelectItem>
                  <SelectItem value="vip">VIP</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>ترتیب</Label>
              <Input type="number" value={order} onChange={(e) => setOrder(e.target.value)} min={0} />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>انصراف</Button>
          <Button onClick={() => onSave({ id: room?.id, name, description: description || null, type, order: parseInt(order, 10) || 0 }, isNew)} disabled={!name.trim()}>
            ذخیره
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
