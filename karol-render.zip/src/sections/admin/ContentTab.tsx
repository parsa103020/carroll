"use client"

import { useEffect, useState, useCallback, useMemo } from "react"
import { useApp } from "@/lib/store"
import { api, formatNumber, faDigits, timeAgo } from "@/lib/format"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import { FileText, Film, Video as VideoIcon, Search, RefreshCw, Trash2, Loader2, Eye } from "lucide-react"
import { cn } from "@/lib/utils"
import { EmptyState, Loader } from "./shared"

export function ContentTab() {
  const { toast } = useApp()
  const [kind, setKind] = useState<"feed" | "reels" | "videos">("feed")
  const [items, setItems] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [q, setQ] = useState("")
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [total, setTotal] = useState(0)
  const [deleteTarget, setDeleteTarget] = useState<any | null>(null)
  const [busyId, setBusyId] = useState<string | null>(null)

  const endpoint = useMemo(() => {
    if (kind === "feed") return "/api/admin/content/feed"
    if (kind === "reels") return "/api/admin/content/reels"
    return "/api/admin/content/videos"
  }, [kind])

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (q) params.set("q", q)
      params.set("page", String(page))
      const d = await api<any>(`${endpoint}?${params}`)
      setItems(d[kind] || [])
      setTotal(d.total)
      setTotalPages(d.totalPages)
    } catch (e: any) { toast(e.message, "error") }
    finally { setLoading(false) }
  }, [endpoint, q, page, kind, toast])

  useEffect(() => { const t = setTimeout(load, 250); return () => clearTimeout(t) }, [load])
  useEffect(() => { setPage(1) }, [q, kind])

  async function del(id: string) {
    setBusyId(id)
    try {
      await api(`${endpoint}/${id}`, { method: "DELETE" })
      toast("محتوا حذف شد", "success")
      setDeleteTarget(null)
      await load()
    } catch (e: any) { toast(e.message, "error") }
    finally { setBusyId(null) }
  }

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-bold">مدیریت محتوا</h2>
        <p className="text-xs text-muted-foreground mt-0.5">پست‌ها، ریلزها و ویدیوها</p>
      </div>

      <Tabs value={kind} onValueChange={(v) => setKind(v as any)}>
        <TabsList>
          <TabsTrigger value="feed"><FileText className="w-3.5 h-3.5 ml-1" /> پست‌ها</TabsTrigger>
          <TabsTrigger value="reels"><Film className="w-3.5 h-3.5 ml-1" /> ریلز</TabsTrigger>
          <TabsTrigger value="videos"><VideoIcon className="w-3.5 h-3.5 ml-1" /> ویدیو</TabsTrigger>
        </TabsList>

        <TabsContent value={kind} className="space-y-3 mt-3">
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="جستجو…" className="pr-9" />
            </div>
            <Button variant="outline" size="icon" onClick={load} disabled={loading}>
              <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
            </Button>
          </div>

          <div className="text-xs text-muted-foreground">{faDigits(formatNumber(total))} مورد · صفحه {faDigits(page)} از {faDigits(totalPages || 1)}</div>

          {loading ? <Loader rows={5} /> : items.length === 0 ? (
            <EmptyState icon={FileText} title="محتوایی نیست" />
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {items.map((it) => (
                <Card key={it.id} className="glass overflow-hidden">
                  <div className="aspect-video bg-muted/40 relative">
                    {kind === "feed" ? (
                      it.mediaUrls?.[0] ? (
                        <img src={it.mediaUrls[0]} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center"><FileText className="w-8 h-8 text-muted-foreground" /></div>
                      )
                    ) : kind === "reels" ? (
                      <video src={it.videoUrl} poster={it.posterUrl || undefined} className="w-full h-full object-cover" preload="metadata" muted />
                    ) : (
                      it.thumbnailUrl ? (
                        <img src={it.thumbnailUrl} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <video src={it.videoUrl} className="w-full h-full object-cover" preload="metadata" muted />
                      )
                    )}
                    <div className="absolute top-1.5 right-1.5 flex gap-1">
                      {kind !== "feed" && (
                        <Badge className="bg-black/70 text-white text-[10px]">
                          <Eye className="w-2.5 h-2.5 ml-1" />{faDigits(formatNumber(it.views || 0))}
                        </Badge>
                      )}
                    </div>
                  </div>
                  <CardContent className="p-3 space-y-2">
                    <div className="flex items-center gap-2">
                      <Avatar className="w-6 h-6">
                        <AvatarImage src={it.owner?.avatarUrl || undefined} />
                        <AvatarFallback className="text-[10px] bg-primary/15 text-primary">{it.owner?.username?.[0]?.toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div className="text-xs min-w-0 flex-1">
                        <div className="font-medium truncate">{it.owner?.displayName || it.owner?.username}</div>
                        <div className="text-[10px] text-muted-foreground">{timeAgo(it.createdAt)}</div>
                      </div>
                    </div>
                    <p className="text-xs line-clamp-2 text-muted-foreground">
                      {kind === "feed" ? it.content || (it.mediaUrls?.length ? `[${faDigits(it.mediaUrls.length)} تصویر]` : "") : kind === "reels" ? it.caption || it.musicTitle || "—" : it.title}
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex gap-2 text-[10px] text-muted-foreground">
                        <span>♥ {faDigits(it.likes || 0)}</span>
                        <span>💬 {faDigits(it.comments || 0)}</span>
                        {kind !== "feed" && <span>👁 {faDigits(it.views || 0)}</span>}
                      </div>
                      <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-rose-500" disabled={busyId === it.id} onClick={() => setDeleteTarget(it)}>
                        {busyId === it.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2">
              <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))}>قبلی</Button>
              <span className="text-xs text-muted-foreground px-2">{faDigits(page)} / {faDigits(totalPages)}</span>
              <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>بعدی</Button>
            </div>
          )}
        </TabsContent>
      </Tabs>

      {deleteTarget && (
        <AlertDialog open onOpenChange={(o) => !o && setDeleteTarget(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>حذف محتوا</AlertDialogTitle>
              <AlertDialogDescription>این عمل قابل بازگشت نیست. فایل رسانه‌ای نیز حذف خواهد شد.</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>انصراف</AlertDialogCancel>
              <AlertDialogAction className="bg-rose-500 hover:bg-rose-600 text-white" onClick={() => del(deleteTarget.id)}>حذف</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  )
}
