"use client"

import { useEffect, useState, useCallback } from "react"
import { useApp } from "@/lib/store"
import { api, formatNumber, faDigits, timeAgo } from "@/lib/format"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Users, Crown, Coins, Ticket as TicketIcon, ShoppingBag, HardDrive, Film,
  Video as VideoIcon, FileText, Ban, Loader2, ShoppingCart, Inbox, FileWarning,
  RefreshCw, AlertCircle, Check,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { StatCard, EmptyState, Loader, type AdminTab } from "./shared"

export function DashboardTab({ onNavigate }: { onNavigate: (t: AdminTab) => void }) {
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [banning, setBanning] = useState<string | null>(null)
  const { toast } = useApp()

  const load = useCallback(async () => {
    setLoading(true); setError(null)
    try {
      const d = await api<any>("/api/admin/stats")
      setData(d)
    } catch (e: any) { setError(e.message || "خطا در بارگذاری") }
    finally { setLoading(false) }
  }, [])

  useEffect(() => { load() }, [load])

  async function quickBan(userId: string) {
    setBanning(userId)
    try {
      await api(`/api/admin/users/${userId}`, { method: "PATCH", json: { banned: true, banReason: "مسدودیت سریع از داشبورد" } })
      toast("کاربر مسدود شد", "success")
      await load()
    } catch (e: any) { toast(e.message, "error") }
    finally { setBanning(null) }
  }

  if (loading) return <Loader rows={5} />
  if (error) return <EmptyState icon={AlertCircle} title={error} />
  if (!data) return null

  const s = data.stats
  const r = data.recent

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold">داشبورد مدیریت</h2>
          <p className="text-xs text-muted-foreground mt-0.5">نمای کلی پلتفرم کارول</p>
        </div>
        <Button variant="outline" size="sm" onClick={load} disabled={loading}>
          <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
          <span className="mr-1.5">به‌روزرسانی</span>
        </Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
        <StatCard icon={Users} label="کاربران" value={faDigits(formatNumber(s.totalUsers))} hint={`${faDigits(formatNumber(s.onlineUsers))} آنلاین`} />
        <StatCard icon={Coins} label="سکه در گردش" value={faDigits(formatNumber(s.totalCoins))} accent="text-gold" />
        <StatCard icon={Crown} label="اعضای VIP" value={faDigits(formatNumber(s.vipMembers))} accent="text-gold" />
        <StatCard icon={TicketIcon} label="تیکت‌های باز" value={faDigits(formatNumber(s.openTickets))} accent={s.openTickets > 0 ? "text-amber-600" : undefined} />
        <StatCard icon={ShoppingBag} label="سفارش‌های در انتظار" value={faDigits(formatNumber(s.pendingOrders))} accent={s.pendingOrders > 0 ? "text-amber-600" : undefined} />
        <StatCard icon={HardDrive} label="فایل‌ها" value={faDigits(formatNumber(s.totalFiles))} />
        <StatCard icon={Film} label="ریلزها" value={faDigits(formatNumber(s.totalReels))} />
        <StatCard icon={VideoIcon} label="ویدیوها" value={faDigits(formatNumber(s.totalVideos))} />
        <StatCard icon={FileText} label="پست‌ها" value={faDigits(formatNumber(s.totalPosts))} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="glass">
          <CardHeader className="pb-2 flex flex-row items-center justify-between">
            <CardTitle className="text-sm font-semibold">کاربران جدید</CardTitle>
            <Button variant="ghost" size="sm" onClick={() => onNavigate("users")} className="h-7 text-xs">همه</Button>
          </CardHeader>
          <CardContent className="space-y-2 max-h-72 overflow-y-auto thin-scrollbar">
            {r.users.length === 0 ? <EmptyState icon={Users} title="کاربری نیست" /> : r.users.map((u: any) => (
              <div key={u.id} className="flex items-center gap-2 p-2 rounded-lg hover:bg-accent/50">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={u.avatarUrl || undefined} />
                  <AvatarFallback className="text-xs bg-primary/15 text-primary">{u.username[0]?.toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium truncate">{u.displayName || u.username}</div>
                  <div className="text-[10px] text-muted-foreground">@{u.username} · {timeAgo(u.createdAt)}</div>
                </div>
                {u.banned ? (
                  <Badge variant="secondary" className="text-[10px] bg-rose-500/15 text-rose-600">مسدود</Badge>
                ) : (
                  <Button size="sm" variant="ghost" className="h-7 w-7 p-0" disabled={banning === u.id} onClick={() => quickBan(u.id)}>
                    {banning === u.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Ban className="w-3.5 h-3.5 text-rose-500" />}
                  </Button>
                )}
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="glass">
          <CardHeader className="pb-2 flex flex-row items-center justify-between">
            <CardTitle className="text-sm font-semibold">سفارش‌های در انتظار</CardTitle>
            <Button variant="ghost" size="sm" onClick={() => onNavigate("shop")} className="h-7 text-xs">همه</Button>
          </CardHeader>
          <CardContent className="space-y-2 max-h-72 overflow-y-auto thin-scrollbar">
            {r.orders.length === 0 ? <EmptyState icon={ShoppingCart} title="سفارشی نیست" /> : r.orders.map((o: any) => (
              <div key={o.id} className="p-2 rounded-lg hover:bg-accent/50">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium truncate">{o.shopItem?.title || "سفارش"}</span>
                  <Badge className="text-[10px] bg-amber-500/15 text-amber-600">{faDigits(formatNumber(o.amount))} ت</Badge>
                </div>
                <div className="text-[10px] text-muted-foreground mt-0.5">
                  {o.user?.displayName || o.user?.username} · {timeAgo(o.createdAt)}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="glass">
          <CardHeader className="pb-2 flex flex-row items-center justify-between">
            <CardTitle className="text-sm font-semibold">تیکت‌های باز</CardTitle>
            <Button variant="ghost" size="sm" onClick={() => onNavigate("tickets")} className="h-7 text-xs">همه</Button>
          </CardHeader>
          <CardContent className="space-y-2 max-h-72 overflow-y-auto thin-scrollbar">
            {r.tickets.length === 0 ? <EmptyState icon={Inbox} title="تیکتی نیست" /> : r.tickets.map((t: any) => (
              <div key={t.id} className="p-2 rounded-lg hover:bg-accent/50">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-medium truncate flex-1">{t.subject}</span>
                  <Badge className="text-[10px] bg-emerald-500/15 text-emerald-600">{faDigits(t.messagesCount)} پیام</Badge>
                </div>
                <div className="text-[10px] text-muted-foreground mt-0.5">
                  {t.owner?.displayName || t.owner?.username} · {timeAgo(t.updatedAt)}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="glass">
          <CardHeader className="pb-2 flex flex-row items-center justify-between">
            <CardTitle className="text-sm font-semibold">گزارش‌های چت</CardTitle>
            <Button variant="ghost" size="sm" onClick={() => onNavigate("reports")} className="h-7 text-xs">همه</Button>
          </CardHeader>
          <CardContent className="space-y-2 max-h-72 overflow-y-auto thin-scrollbar">
            {r.reports.length === 0 ? <EmptyState icon={FileWarning} title="گزارشی نیست" /> : r.reports.map((rp: any) => (
              <div key={rp.id} className="p-2 rounded-lg hover:bg-accent/50">
                <div className="text-xs font-medium truncate">
                  {rp.message?.content?.slice(0, 60) || "[رسانه]"}
                  {rp.message?.deletedAt && <span className="text-[10px] text-muted-foreground"> · حذف شده</span>}
                </div>
                <div className="text-[10px] text-muted-foreground mt-0.5">
                  گزارش‌دهنده: {rp.reporter?.username} · {timeAgo(rp.createdAt)}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        {([
          { id: "users", label: "کاربران", icon: Users },
          { id: "settings", label: "تنظیمات", icon: Check },
          { id: "chat", label: "چت", icon: FileWarning },
          { id: "reports", label: "گزارش‌ها", icon: FileWarning },
          { id: "configs", label: "کانفیگ‌ها", icon: ShoppingBag },
          { id: "content", label: "محتوا", icon: FileText },
          { id: "shop", label: "فروشگاه", icon: ShoppingBag },
          { id: "tickets", label: "تیکت‌ها", icon: TicketIcon },
          { id: "files", label: "فایل‌ها", icon: HardDrive },
        ] as const).map((t) => (
          <Button key={t.id} variant="outline" className="h-auto py-3 justify-start" onClick={() => onNavigate(t.id)}>
            <t.icon className="w-4 h-4 ml-2" />
            <span>{t.label}</span>
          </Button>
        ))}
      </div>
    </div>
  )
}
