import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { cn } from "@/lib/utils"

export type AdminTab = "dashboard" | "users" | "settings" | "chat" | "reports" | "configs" | "content" | "shop" | "tickets" | "files" | "logs" | "roles"

export function bytesFromMB(mb: number): string { return String(Math.round(mb * 1024 * 1024)) }
export function mbFromBytes(b: string | number): number {
  const n = typeof b === "string" ? parseInt(b, 10) : b
  if (!Number.isFinite(n) || n <= 0) return 0
  return n / (1024 * 1024)
}

export function RoleBadges({ roles }: { roles: string }) {
  const list = roles.split(",").map((r) => r.trim()).filter(Boolean)
  const map: Record<string, { label: string; cls: string }> = {
    admin: { label: "مدیر", cls: "bg-primary/15 text-primary" },
    moderator: { label: "ناظم", cls: "bg-emerald-500/15 text-emerald-600" },
    chat_mod: { label: "ناظم چت", cls: "bg-amber-500/15 text-amber-600" },
    video_mod: { label: "ناظم ویدیو", cls: "bg-rose-500/15 text-rose-600" },
    reel_mod: { label: "ناظم ریلز", cls: "bg-purple-500/15 text-purple-600" },
    feed_mod: { label: "ناظم فیید", cls: "bg-emerald-500/15 text-emerald-600" },
    drive_mod: { label: "ناظم فایل", cls: "bg-orange-500/15 text-orange-600" },
    shop_mod: { label: "ناظم فروش", cls: "bg-amber-500/15 text-amber-600" },
    ticket_mod: { label: "ناظم تیکت", cls: "bg-cyan-500/15 text-cyan-600" },
    user: { label: "کاربر", cls: "bg-muted text-muted-foreground" },
  }
  return (
    <div className="flex flex-wrap gap-1">
      {list.filter((r) => r !== "user").map((r) => (
        <Badge key={r} variant="secondary" className={cn("text-[10px] font-medium", map[r]?.cls || "bg-muted")}>
          {map[r]?.label || r}
        </Badge>
      ))}
    </div>
  )
}

export function StatCard({ icon: Icon, label, value, hint, accent }: {
  icon: React.ComponentType<{ className?: string }>
  label: string; value: string | number; hint?: string; accent?: string
}) {
  return (
    <div className="glass rounded-xl border border-border/40 p-4 overflow-hidden">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-[11px] text-muted-foreground truncate">{label}</div>
          <div className={cn("text-2xl font-black mt-1 tabular-nums", accent)}>{value}</div>
          {hint && <div className="text-[10px] text-muted-foreground/80 mt-0.5">{hint}</div>}
        </div>
        <div className="shrink-0 w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
          <Icon className="w-5 h-5" />
        </div>
      </div>
    </div>
  )
}

export function EmptyState({ icon: Icon, title, hint }: { icon: React.ComponentType<{ className?: string }>; title: string; hint?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-10 text-center">
      <div className="w-12 h-12 rounded-xl bg-muted/50 flex items-center justify-center mb-3">
        <Icon className="w-6 h-6 text-muted-foreground" />
      </div>
      <p className="text-sm font-medium">{title}</p>
      {hint && <p className="text-xs text-muted-foreground mt-1">{hint}</p>}
    </div>
  )
}

export function Loader({ rows = 3 }: { rows?: number }) {
  return (
    <div className="space-y-2">
      {Array.from({ length: rows }).map((_, i) => (
        <Skeleton key={i} className="h-12 w-full" />
      ))}
    </div>
  )
}

export const TICKET_STATUS: Record<string, { label: string; cls: string }> = {
  open: { label: "باز", cls: "bg-emerald-500/15 text-emerald-600" },
  pending: { label: "در انتظار", cls: "bg-amber-500/15 text-amber-600" },
  closed: { label: "بسته", cls: "bg-muted text-muted-foreground" },
}
