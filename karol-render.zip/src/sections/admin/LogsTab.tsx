"use client"

import { useEffect, useState, useCallback } from "react"
import { useApp } from "@/lib/store"
import { api, timeAgo, formatDate, faDigits } from "@/lib/format"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ScrollArea } from "@/components/ui/scroll-area"
import { ShieldAlert, Search, RefreshCw, ChevronDown, ChevronRight, Activity, AlertTriangle, Info, AlertOctagon } from "lucide-react"
import { cn } from "@/lib/utils"
import { EmptyState, Loader } from "./shared"

interface AuditLogT {
  id: string
  actorId: string | null
  actorName: string
  actor?: { id: string; username: string; avatarUrl: string | null } | null
  action: string
  targetType: string
  targetId: string
  description: string
  severity: "info" | "warning" | "danger"
  ip: string | null
  userAgent: string | null
  metadata: string | null
  createdAt: string
}

const SEVERITY_META = {
  info: { label: "اطلاع", icon: Info, cls: "bg-accent-15 text-accent-soft" },
  warning: { label: "هشدار", icon: AlertTriangle, cls: "bg-warning-15 text-warning" },
  danger: { label: "خطرناک", icon: AlertOctagon, cls: "bg-danger-15 text-danger" },
}

export function LogsTab() {
  const { toast } = useApp()
  const [logs, setLogs] = useState<AuditLogT[]>([])
  const [loading, setLoading] = useState(true)
  const [severity, setSeverity] = useState<string>("")
  const [action, setAction] = useState("")
  const [actor, setActor] = useState("")
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [total, setTotal] = useState(0)
  const [expanded, setExpanded] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (severity) params.set("severity", severity)
      if (action) params.set("action", action)
      if (actor) params.set("actor", actor)
      params.set("page", String(page))
      const d = await api<{ logs: AuditLogT[]; total: number; totalPages: number }>(`/api/admin/audit-logs?${params}`)
      setLogs(d.logs)
      setTotal(d.total)
      setTotalPages(d.totalPages)
    } catch (e: any) {
      toast(e.message, "error")
    } finally {
      setLoading(false)
    }
  }, [severity, action, actor, page, toast])

  useEffect(() => {
    const t = setTimeout(load, 250)
    return () => clearTimeout(t)
  }, [load])

  useEffect(() => { setPage(1) }, [severity, action, actor])

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl gradient-aurora flex items-center justify-center shadow-glow">
          <Activity className="w-5 h-5 text-white" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-primary-c">لاگ‌های سیستم</h2>
          <p className="text-xs text-muted-c">تمام اقدامات مدیران و رویدادهای حساس ثبت می‌شود</p>
        </div>
      </div>

      <Card className="glass border-hair">
        <CardContent className="p-4 space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-c" />
              <Input value={action} onChange={(e) => setAction(e.target.value)} placeholder="جستجوی عملیات (مثلاً user.ban)…" className="pr-9" />
            </div>
            <div className="relative flex-1 min-w-[180px]">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-c" />
              <Input value={actor} onChange={(e) => setActor(e.target.value)} placeholder="نام مدیر…" className="pr-9" />
            </div>
            <Select value={severity || "all"} onValueChange={(v) => setSeverity(v === "all" ? "" : v)}>
              <SelectTrigger className="w-[140px]"><SelectValue placeholder="همه سطوح" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه سطوح</SelectItem>
                <SelectItem value="info">اطلاع</SelectItem>
                <SelectItem value="warning">هشدار</SelectItem>
                <SelectItem value="danger">خطرناک</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="icon" onClick={load} disabled={loading}>
              <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
            </Button>
          </div>

          <div className="text-xs text-muted-c">
            {faDigits(total)} رویداد — صفحه {faDigits(page)} از {faDigits(totalPages || 1)}
          </div>

          {loading ? (
            <Loader rows={6} />
          ) : logs.length === 0 ? (
            <EmptyState icon={ShieldAlert} title="رویدادی ثبت نشده" hint="اقدامات مدیران اینجا نمایش داده می‌شود" />
          ) : (
            <div className="space-y-1.5">
              {logs.map((log) => {
                const meta = SEVERITY_META[log.severity]
                const isExp = expanded === log.id
                let parsedMeta: any = null
                if (log.metadata) {
                  try { parsedMeta = JSON.parse(log.metadata) } catch {}
                }
                return (
                  <div key={log.id} className="rounded-lg border border-hair bg-surface/50 overflow-hidden">
                    <button
                      onClick={() => setExpanded(isExp ? null : log.id)}
                      className="w-full flex items-center gap-3 p-3 hover:bg-white/[0.03] transition-colors text-right"
                    >
                      {isExp ? <ChevronDown className="w-4 h-4 text-muted-c shrink-0" /> : <ChevronRight className="w-4 h-4 text-muted-c shrink-0" />}
                      <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center shrink-0", meta.cls)}>
                        <meta.icon className="w-4 h-4" />
                      </div>
                      <Avatar className="w-7 h-7 shrink-0">
                        <AvatarImage src={log.actor?.avatarUrl || undefined} />
                        <AvatarFallback className="text-[10px] bg-accent-15 text-accent-soft">{log.actorName[0]?.toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-sm font-semibold text-primary-c">{log.actorName}</span>
                          <Badge variant="secondary" className={cn("text-[10px] font-mono", meta.cls)}>{log.action}</Badge>
                          {log.targetType && <span className="text-[10px] text-muted-c">→ {log.targetType}</span>}
                        </div>
                        <div className="text-xs text-muted-c truncate">{log.description || "—"}</div>
                      </div>
                      <div className="text-[10px] text-muted-c shrink-0 text-left">
                        <div>{timeAgo(log.createdAt)}</div>
                        {log.ip && <div className="font-mono opacity-70">{log.ip}</div>}
                      </div>
                    </button>
                    {isExp && (
                      <div className="px-3 pb-3 pt-1 border-t border-hair space-y-2 animate-fade-in">
                        {log.description && <div className="text-xs text-secondary-c">{log.description}</div>}
                        <div className="flex flex-wrap gap-3 text-[10px] text-muted-c">
                          {log.targetId && <span>هدف: <code className="font-mono">{log.targetId}</code></span>}
                          {log.userAgent && <span className="truncate max-w-[300px]">UA: {log.userAgent.slice(0, 80)}</span>}
                          <span>زمان دقیق: {formatDate(log.createdAt)}</span>
                        </div>
                        {parsedMeta && (
                          <div className="rounded bg-deep p-2 border border-hair">
                            <div className="text-[10px] text-muted-c mb-1">متادیتا:</div>
                            <pre className="text-[10px] text-secondary-c overflow-x-auto thin-scrollbar">{JSON.stringify(parsedMeta, null, 2)}</pre>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          )}

          {totalPages > 1 && (
            <div className="flex items-center justify-between pt-2">
              <Button variant="outline" size="sm" disabled={page <= 1 || loading} onClick={() => setPage((p) => p - 1)}>قبلی</Button>
              <span className="text-xs text-muted-c">{faDigits(page)} / {faDigits(totalPages)}</span>
              <Button variant="outline" size="sm" disabled={page >= totalPages || loading} onClick={() => setPage((p) => p + 1)}>بعدی</Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
