"use client"

import { useEffect, useState, useCallback } from "react"
import { useApp } from "@/lib/store"
import { api, formatNumber, faDigits, timeAgo } from "@/lib/format"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Switch } from "@/components/ui/switch"
import { Checkbox } from "@/components/ui/checkbox"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog"
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Edit2, Ban, Crown, Trash2, Search, RefreshCw, MoreVertical, Check, Loader2, Users } from "lucide-react"
import { cn } from "@/lib/utils"
import { RoleBadges, EmptyState, Loader } from "./shared"

const ROLES_LIST = [
  { key: "admin", label: "مدیر کل" },
  { key: "moderator", label: "ناظم" },
  { key: "chat_mod", label: "ناظم چت" },
  { key: "video_mod", label: "ناظم ویدیو" },
  { key: "reel_mod", label: "ناظم ریلز" },
  { key: "feed_mod", label: "ناظم فیید" },
  { key: "drive_mod", label: "ناظم فایل" },
  { key: "shop_mod", label: "ناظم فروش" },
  { key: "ticket_mod", label: "ناظم تیکت" },
]

export function UsersTab() {
  const { toast } = useApp()
  const [users, setUsers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [q, setQ] = useState("")
  const [role, setRole] = useState("")
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [total, setTotal] = useState(0)
  const [editing, setEditing] = useState<any | null>(null)
  const [banTarget, setBanTarget] = useState<any | null>(null)
  const [vipTarget, setVipTarget] = useState<any | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<any | null>(null)
  const [busyId, setBusyId] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (q) params.set("q", q)
      if (role) params.set("role", role)
      params.set("page", String(page))
      const d = await api<any>(`/api/admin/users?${params}`)
      setUsers(d.users)
      setTotal(d.total)
      setTotalPages(d.totalPages)
    } catch (e: any) { toast(e.message, "error") }
    finally { setLoading(false) }
  }, [q, role, page, toast])

  useEffect(() => {
    const t = setTimeout(load, 250)
    return () => clearTimeout(t)
  }, [load])

  useEffect(() => { setPage(1) }, [q, role])

  async function quickAction(id: string, action: "ban" | "unban") {
    setBusyId(id)
    try {
      await api(`/api/admin/users/${id}`, {
        method: "PATCH",
        json: action === "ban"
          ? { banned: true, banReason: "مسدود شده توسط ادمین" }
          : { banned: false, banReason: null },
      })
      toast(action === "ban" ? "کاربر مسدود شد" : "کاربر رفع مسدودیت شد", "success")
      await load()
    } catch (e: any) { toast(e.message, "error") }
    finally { setBusyId(null) }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="جستجوی نام کاربری یا نمایشی…" className="pr-9" />
        </div>
        <Select value={role || "all"} onValueChange={(v) => setRole(v === "all" ? "" : v)}>
          <SelectTrigger className="w-[160px]"><SelectValue placeholder="همه نقش‌ها" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه</SelectItem>
            <SelectItem value="admin">مدیران</SelectItem>
            <SelectItem value="moderator">ناظم‌ها</SelectItem>
            <SelectItem value="vip">اعضای VIP</SelectItem>
            <SelectItem value="banned">مسدود شده‌ها</SelectItem>
          </SelectContent>
        </Select>
        <Button variant="outline" size="icon" onClick={load} disabled={loading}>
          <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
        </Button>
      </div>

      <div className="text-xs text-muted-foreground">
        {faDigits(formatNumber(total))} کاربر یافت شد — صفحه {faDigits(page)} از {faDigits(totalPages || 1)}
      </div>

      <Card className="glass">
        <CardContent className="p-0">
          {loading ? <Loader rows={6} /> : users.length === 0 ? (
            <EmptyState icon={Users} title="کاربری یافت نشد" />
          ) : (
            <>
              <div className="hidden md:block">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>کاربر</TableHead>
                      <TableHead>نقش‌ها</TableHead>
                      <TableHead className="text-center">سکه</TableHead>
                      <TableHead className="text-center">VIP</TableHead>
                      <TableHead>عضویت</TableHead>
                      <TableHead>آخرین ورود</TableHead>
                      <TableHead className="text-left">عملیات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users.map((u) => (
                      <TableRow key={u.id} className={cn(u.banned && "opacity-60")}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Avatar className="w-8 h-8">
                              <AvatarImage src={u.avatarUrl || undefined} />
                              <AvatarFallback className="text-xs bg-primary/15 text-primary">{u.username[0]?.toUpperCase()}</AvatarFallback>
                            </Avatar>
                            <div className="min-w-0">
                              <div className="text-sm font-medium truncate">{u.displayName || u.username}</div>
                              <div className="text-xs text-muted-foreground">@{u.username}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell><RoleBadges roles={u.roles} /></TableCell>
                        <TableCell className="text-center text-gold font-bold tabular-nums">{faDigits(formatNumber(u.coins))}</TableCell>
                        <TableCell className="text-center">
                          {u.isVip ? (
                            <Badge className="bg-gold/15 text-gold"><Crown className="w-3 h-3 ml-1" />VIP</Badge>
                          ) : u.banned ? (
                            <Badge variant="secondary" className="bg-rose-500/15 text-rose-600">مسدود</Badge>
                          ) : <span className="text-muted-foreground text-xs">—</span>}
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">{timeAgo(u.createdAt)}</TableCell>
                        <TableCell className="text-xs text-muted-foreground">{u.lastLoginAt ? timeAgo(u.lastLoginAt) : "—"}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1 justify-end">
                            <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => setEditing(u)}>
                              <Edit2 className="w-3.5 h-3.5" />
                            </Button>
                            <Button size="sm" variant="ghost" className="h-8 w-8 p-0" disabled={busyId === u.id} onClick={() => quickAction(u.id, u.banned ? "unban" : "ban")}>
                              <Ban className={cn("w-3.5 h-3.5", u.banned ? "text-emerald-500" : "text-rose-500")} />
                            </Button>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button size="sm" variant="ghost" className="h-8 w-8 p-0"><MoreVertical className="w-3.5 h-3.5" /></Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="left">
                                <DropdownMenuItem onClick={() => setVipTarget(u)}>
                                  <Crown className="w-4 h-4 ml-2 text-gold" /> اعطای VIP
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => setBanTarget(u)}>
                                  <Ban className="w-4 h-4 ml-2 text-rose-500" /> {u.banned ? "رفع مسدودیت" : "مسدود کردن"}
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-destructive" onClick={() => setDeleteTarget(u)}>
                                  <Trash2 className="w-4 h-4 ml-2" /> حذف کاربر
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="md:hidden divide-y divide-border/40">
                {users.map((u) => (
                  <div key={u.id} className={cn("p-3 space-y-2", u.banned && "opacity-60")}>
                    <div className="flex items-center gap-2">
                      <Avatar className="w-9 h-9">
                        <AvatarImage src={u.avatarUrl || undefined} />
                        <AvatarFallback className="text-xs bg-primary/15 text-primary">{u.username[0]?.toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium truncate">{u.displayName || u.username}</div>
                        <div className="text-xs text-muted-foreground">@{u.username}</div>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button size="sm" variant="ghost" className="h-8 w-8 p-0"><MoreVertical className="w-4 h-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="left">
                          <DropdownMenuItem onClick={() => setEditing(u)}><Edit2 className="w-4 h-4 ml-2" /> ویرایش</DropdownMenuItem>
                          <DropdownMenuItem onClick={() => setVipTarget(u)}><Crown className="w-4 h-4 ml-2 text-gold" /> اعطای VIP</DropdownMenuItem>
                          <DropdownMenuItem onClick={() => setBanTarget(u)}><Ban className="w-4 h-4 ml-2 text-rose-500" /> {u.banned ? "رفع مسدودیت" : "مسدود"}</DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-destructive" onClick={() => setDeleteTarget(u)}><Trash2 className="w-4 h-4 ml-2" /> حذف</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    <RoleBadges roles={u.roles} />
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span className="text-gold font-bold tabular-nums">{faDigits(formatNumber(u.coins))} سکه</span>
                      {u.isVip && <Badge className="bg-gold/15 text-gold text-[10px]"><Crown className="w-3 h-3 ml-1" />VIP</Badge>}
                      {u.banned && <Badge variant="secondary" className="bg-rose-500/15 text-rose-600 text-[10px]">مسدود</Badge>}
                      <span>· {timeAgo(u.createdAt)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))}>قبلی</Button>
          <span className="text-xs text-muted-foreground px-2">{faDigits(page)} / {faDigits(totalPages)}</span>
          <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>بعدی</Button>
        </div>
      )}

      {editing && <EditUserDialog user={editing} onClose={() => setEditing(null)} onSaved={load} />}
      {banTarget && <BanDialog user={banTarget} onClose={() => setBanTarget(null)} onDone={() => { setBanTarget(null); load() }} />}
      {vipTarget && <VipDialog user={vipTarget} onClose={() => setVipTarget(null)} onDone={() => { setVipTarget(null); load() }} />}
      {deleteTarget && (
        <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>حذف کاربر</AlertDialogTitle>
              <AlertDialogDescription>
                آیا از حذف «{deleteTarget.displayName || deleteTarget.username}» مطمئن هستید؟ این عمل قابل بازگشت نیست و تمام محتوای کاربر نیز حذف خواهد شد.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>انصراف</AlertDialogCancel>
              <AlertDialogAction
                className="bg-rose-500 hover:bg-rose-600 text-white"
                onClick={async () => {
                  try {
                    await api(`/api/admin/users/${deleteTarget.id}`, { method: "DELETE" })
                    toast("کاربر حذف شد", "success")
                    setDeleteTarget(null)
                    await load()
                  } catch (e: any) { toast(e.message, "error") }
                }}
              >حذف</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  )
}

function EditUserDialog({ user, onClose, onSaved }: { user: any; onClose: () => void; onSaved: () => void }) {
  const { toast } = useApp()
  const [displayName, setDisplayName] = useState(user.displayName || "")
  const [roles, setRoles] = useState<string[]>(user.roles.split(",").map((r: string) => r.trim()).filter(Boolean))
  const [limitMB, setLimitMB] = useState(Math.round(parseInt(user.dailyUploadLimitBytes || "0", 10) / (1024 * 1024)) || 0)
  const [coinAdjust, setCoinAdjust] = useState("")
  const [coinReason, setCoinReason] = useState("")
  const [saving, setSaving] = useState(false)

  function toggleRole(r: string) {
    setRoles((arr) => arr.includes(r) ? arr.filter((x) => x !== r) : [...arr, r])
  }

  async function save() {
    setSaving(true)
    try {
      const payload: any = {
        displayName,
        roles: roles.includes("user") ? roles : [...roles, "user"],
        dailyUploadLimitBytes: parseFloat(limitMB) || 0,
      }
      if (coinAdjust) {
        payload.coinAdjust = parseInt(coinAdjust, 10)
        if (coinReason) payload.coinReason = coinReason
      }
      await api(`/api/admin/users/${user.id}`, { method: "PATCH", json: payload })
      toast("کاربر به‌روزرسانی شد", "success")
      onClose(); onSaved()
    } catch (e: any) { toast(e.message, "error") }
    finally { setSaving(false) }
  }

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto thin-scrollbar">
        <DialogHeader>
          <DialogTitle>ویرایش کاربر — @{user.username}</DialogTitle>
          <DialogDescription>نام نمایشی، نقش‌ها، سهمیه آپلود و سکه</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="space-y-1.5">
            <Label>نام نمایشی</Label>
            <Input value={displayName} onChange={(e) => setDisplayName(e.target.value)} maxLength={60} />
          </div>

          <div className="space-y-2">
            <Label>نقش‌ها</Label>
            <div className="grid grid-cols-2 gap-2">
              {ROLES_LIST.map((r) => (
                <label key={r.key} className="flex items-center gap-2 text-sm cursor-pointer p-2 rounded-lg hover:bg-accent/50">
                  <Checkbox checked={roles.includes(r.key)} onCheckedChange={() => toggleRole(r.key)} />
                  <span>{r.label}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>سهمیه آپلود روزانه (مگابایت)</Label>
            <Input type="number" value={limitMB} onChange={(e) => setLimitMB(e.target.value)} min={0} />
          </div>

          <div className="space-y-2 pt-2 border-t">
            <Label className="text-gold">تنظیم سکه</Label>
            <p className="text-[11px] text-muted-foreground">موجودی فعلی: {faDigits(formatNumber(user.coins))} سکه</p>
            <div className="flex items-center gap-2">
              <Input type="number" value={coinAdjust} onChange={(e) => setCoinAdjust(e.target.value)} placeholder="مثلاً ۱۰۰۰۰ یا -۵۰۰۰" />
              <span className="text-xs text-muted-foreground whitespace-nowrap">سکه</span>
            </div>
            <Input value={coinReason} onChange={(e) => setCoinReason(e.target.value)} placeholder="دلیل (اختیاری)" maxLength={200} />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>انصراف</Button>
          <Button onClick={save} disabled={saving}>
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4 ml-1" />}
            ذخیره
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

function BanDialog({ user, onClose, onDone }: { user: any; onClose: () => void; onDone: () => void }) {
  const { toast } = useApp()
  const [reason, setReason] = useState(user.banReason || "")
  const [saving, setSaving] = useState(false)
  const unban = !!user.banned

  async function submit() {
    setSaving(true)
    try {
      await api(`/api/admin/users/${user.id}`, {
        method: "PATCH",
        json: unban ? { banned: false, banReason: null } : { banned: true, banReason: reason || "بدون دلیل" },
      })
      toast(unban ? "مسدودیت رفع شد" : "کاربر مسدود شد", "success")
      onDone()
    } catch (e: any) { toast(e.message, "error") }
    finally { setSaving(false) }
  }

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{unban ? "رفع مسدودیت" : "مسدود کردن کاربر"}</DialogTitle>
          <DialogDescription>@{user.username}</DialogDescription>
        </DialogHeader>
        {!unban && (
          <div className="space-y-1.5 py-2">
            <Label>دلیل مسدودیت</Label>
            <Textarea value={reason} onChange={(e) => setReason(e.target.value)} rows={3} maxLength={500} placeholder="مثلاً تخلف از قوانین چت" />
          </div>
        )}
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>انصراف</Button>
          <Button onClick={submit} disabled={saving} className={unban ? "" : "bg-rose-500 hover:bg-rose-600 text-white"}>
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Ban className="w-4 h-4 ml-1" />}
            {unban ? "رفع مسدودیت" : "مسدود کردن"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

function VipDialog({ user, onClose, onDone }: { user: any; onClose: () => void; onDone: () => void }) {
  const { toast } = useApp()
  const [days, setDays] = useState("30")
  const [saving, setSaving] = useState(false)

  async function submit() {
    const d = parseInt(days, 10)
    if (!Number.isFinite(d) || d <= 0) { toast("تعداد روز نامعتبر است", "error"); return }
    setSaving(true)
    try {
      await api(`/api/admin/users/${user.id}`, { method: "PATCH", json: { isVip: true, vipDays: d } })
      toast(`VIP برای ${faDigits(d)} روز اعطا شد`, "success")
      onDone()
    } catch (e: any) { toast(e.message, "error") }
    finally { setSaving(false) }
  }

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>اعطای VIP — @{user.username}</DialogTitle>
          <DialogDescription>عضویت VIP به مدت تعیین‌شده اعطا می‌شود</DialogDescription>
        </DialogHeader>
        <div className="space-y-1.5 py-2">
          <Label>مدت (روز)</Label>
          <Input type="number" value={days} onChange={(e) => setDays(e.target.value)} min={1} />
          <div className="flex gap-2 mt-2">
            {[7, 30, 90, 365].map((d) => (
              <Button key={d} variant="outline" size="sm" onClick={() => setDays(String(d))}>{faDigits(d)} روز</Button>
            ))}
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>انصراف</Button>
          <Button onClick={submit} disabled={saving} className="bg-gold hover:bg-gold/90 text-gold-foreground">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Crown className="w-4 h-4 ml-1" />}
            اعطای VIP
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
