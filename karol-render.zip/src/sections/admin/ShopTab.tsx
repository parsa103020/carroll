"use client"

import { useEffect, useState, useCallback, useMemo } from "react"
import { useApp } from "@/lib/store"
import { api, formatNumber, faDigits, timeAgo } from "@/lib/format"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog"
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import {
  ShoppingBag, ShoppingCart, Check, X, Eye, Plus, Edit2, Trash2, RefreshCw, Loader2, Image as ImageIcon,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { EmptyState, Loader } from "./shared"

export function ShopTab() {
  const { toast } = useApp()
  const [tab, setTab] = useState<"orders" | "items">("orders")
  const [orders, setOrders] = useState<any[]>([])
  const [items, setItems] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState("pending")
  const [busyId, setBusyId] = useState<string | null>(null)
  const [reviewReceipt, setReviewReceipt] = useState<any | null>(null)
  const [editingItem, setEditingItem] = useState<any | null>(null)
  const [creatingItem, setCreatingItem] = useState(false)
  const [deleteItem, setDeleteItem] = useState<any | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const [o, i] = await Promise.all([
        api<any>("/api/shop/orders"),
        api<any>("/api/admin/shop/items"),
      ])
      setOrders(o.orders || [])
      setItems(i.items || [])
    } catch (e: any) { toast(e.message, "error") }
    finally { setLoading(false) }
  }, [toast])

  useEffect(() => { load() }, [load])

  async function reviewOrder(id: string, action: "confirm" | "reject") {
    setBusyId(id)
    try {
      await api(`/api/shop/orders/${id}`, { method: "PATCH", json: { action: action === "reject" ? "reject" : "confirm" } })
      toast(action === "confirm" ? "سفارش تأیید شد" : "سفارش رد شد", "success")
      setReviewReceipt(null)
      await load()
    } catch (e: any) { toast(e.message, "error") }
    finally { setBusyId(null) }
  }

  async function saveItem(item: any, isNew: boolean) {
    try {
      if (isNew) await api("/api/shop/items", { method: "POST", json: item })
      else await api(`/api/admin/shop/items/${item.id}`, { method: "PATCH", json: item })
      toast("محصول ذخیره شد", "success")
      setEditingItem(null); setCreatingItem(false)
      await load()
    } catch (e: any) { toast(e.message, "error") }
  }

  async function deleteItemFn(id: string) {
    try {
      await api(`/api/admin/shop/items/${id}`, { method: "DELETE" })
      toast("محصول حذف شد", "success")
      setDeleteItem(null)
      await load()
    } catch (e: any) { toast(e.message, "error") }
  }

  const filteredOrders = useMemo(() => {
    if (statusFilter === "all") return orders
    return orders.filter((o) => o.status === statusFilter)
  }, [orders, statusFilter])

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-bold">مدیریت فروشگاه</h2>
        <p className="text-xs text-muted-foreground mt-0.5">سفارش‌ها و محصولات</p>
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as any)}>
        <TabsList>
          <TabsTrigger value="orders"><ShoppingCart className="w-3.5 h-3.5 ml-1" /> سفارش‌ها</TabsTrigger>
          <TabsTrigger value="items"><ShoppingBag className="w-3.5 h-3.5 ml-1" /> محصولات</TabsTrigger>
        </TabsList>

        <TabsContent value="orders" className="space-y-3 mt-3">
          <div className="flex items-center gap-2 flex-wrap">
            {[
              { v: "pending", label: "در انتظار", cls: "bg-amber-500/15 text-amber-600" },
              { v: "confirmed", label: "تأیید شده", cls: "bg-emerald-500/15 text-emerald-600" },
              { v: "rejected", label: "رد شده", cls: "bg-rose-500/15 text-rose-600" },
              { v: "all", label: "همه", cls: "" },
            ].map((f) => (
              <Button key={f.v} size="sm" variant={statusFilter === f.v ? "default" : "outline"} onClick={() => setStatusFilter(f.v)}>
                {f.label}
                <Badge className={cn("mr-2 ml-0 text-[10px]", f.cls || "bg-muted text-muted-foreground")}>
                  {faDigits(orders.filter((o) => f.v === "all" || o.status === f.v).length)}
                </Badge>
              </Button>
            ))}
            <div className="flex-1" />
            <Button variant="outline" size="sm" onClick={load} disabled={loading}>
              <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
            </Button>
          </div>

          {loading ? <Loader rows={4} /> : filteredOrders.length === 0 ? (
            <EmptyState icon={ShoppingCart} title="سفارشی نیست" hint="سفارش‌های جدید اینجا نمایش داده می‌شوند" />
          ) : (
            <div className="space-y-2">
              {filteredOrders.map((o) => (
                <Card key={o.id} className="glass">
                  <CardContent className="p-3">
                    <div className="flex items-start gap-3">
                      {o.receiptUrl ? (
                        <button onClick={() => setReviewReceipt(o)} className="w-16 h-16 rounded-lg overflow-hidden border border-border shrink-0 relative group">
                          <img src={o.receiptUrl} alt="رسید" className="w-full h-full object-cover" />
                          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors flex items-center justify-center">
                            <Eye className="w-4 h-4 text-white opacity-0 group-hover:opacity-100" />
                          </div>
                        </button>
                      ) : (
                        <div className="w-16 h-16 rounded-lg bg-muted/40 flex items-center justify-center shrink-0">
                          <ImageIcon className="w-5 h-5 text-muted-foreground" />
                        </div>
                      )}

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-medium text-sm">{o.shopItem?.title || "سفارش"}</span>
                          <Badge className={cn(
                            "text-[10px]",
                            o.status === "pending" ? "bg-amber-500/15 text-amber-600" :
                            o.status === "confirmed" ? "bg-emerald-500/15 text-emerald-600" :
                            "bg-rose-500/15 text-rose-600"
                          )}>
                            {o.status === "pending" ? "در انتظار" : o.status === "confirmed" ? "تأیید شد" : "رد شد"}
                          </Badge>
                        </div>
                        <div className="text-xs text-muted-foreground mt-1">
                          {o.user?.displayName || o.user?.username} · {timeAgo(o.createdAt)}
                        </div>
                        <div className="text-xs mt-1">
                          <span className="font-bold text-gold tabular-nums">{faDigits(formatNumber(o.amount))}</span>
                          <span className="text-muted-foreground"> تومان</span>
                          {o.coins > 0 && <span className="text-muted-foreground"> · {faDigits(formatNumber(o.coins))} سکه</span>}
                        </div>
                        {o.note && (
                          <div className="text-[11px] text-muted-foreground mt-1 p-1.5 rounded bg-muted/40 border border-border/40">
                            📝 {o.note}
                          </div>
                        )}
                      </div>

                      {o.status === "pending" && (
                        <div className="flex flex-col gap-1 shrink-0">
                          <Button size="sm" className="h-7 text-xs bg-emerald-500 hover:bg-emerald-600" disabled={busyId === o.id} onClick={() => reviewOrder(o.id, "confirm")}>
                            {busyId === o.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5 ml-1" />}
                            تأیید
                          </Button>
                          <Button size="sm" variant="outline" className="h-7 text-xs text-rose-500 border-rose-500/40 hover:bg-rose-500/10" disabled={busyId === o.id} onClick={() => reviewOrder(o.id, "reject")}>
                            <X className="w-3.5 h-3.5 ml-1" /> رد
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="items" className="space-y-3 mt-3">
          <div className="flex justify-end">
            <Button size="sm" onClick={() => setCreatingItem(true)}>
              <Plus className="w-4 h-4 ml-1" /> محصول جدید
            </Button>
          </div>
          {loading ? <Loader rows={4} /> : items.length === 0 ? (
            <EmptyState icon={ShoppingBag} title="محصولی نیست" />
          ) : (
            <Card className="glass">
              <CardContent className="p-0">
                <div className="hidden md:block">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>عنوان</TableHead>
                        <TableHead>نوع</TableHead>
                        <TableHead className="text-center">قیمت</TableHead>
                        <TableHead className="text-center">سفارش‌ها</TableHead>
                        <TableHead className="text-center">فعال</TableHead>
                        <TableHead className="text-left">عملیات</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {items.map((it) => (
                        <TableRow key={it.id}>
                          <TableCell className="font-medium">{it.title}</TableCell>
                          <TableCell>
                            <Badge variant="secondary" className={it.kind === "vip" ? "bg-gold/15 text-gold" : ""}>
                              {it.kind === "vip" ? "VIP" : it.kind === "coins" ? "سکه" : "محصول"}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-center tabular-nums">{faDigits(formatNumber(it.price))}</TableCell>
                          <TableCell className="text-center tabular-nums">{faDigits(it._count?.orders || 0)}</TableCell>
                          <TableCell className="text-center">
                            <Switch checked={it.active} onCheckedChange={async (c) => {
                              try { await api(`/api/admin/shop/items/${it.id}`, { method: "PATCH", json: { active: c } }); await load() } catch (e: any) { toast(e.message, "error") }
                            }} />
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-1 justify-end">
                              <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => setEditingItem(it)}>
                                <Edit2 className="w-3.5 h-3.5" />
                              </Button>
                              <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => setDeleteItem(it)}>
                                <Trash2 className="w-3.5 h-3.5 text-rose-500" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                <div className="md:hidden divide-y divide-border/40">
                  {items.map((it) => (
                    <div key={it.id} className="p-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-sm">{it.title}</span>
                        <Badge variant="secondary" className={it.kind === "vip" ? "bg-gold/15 text-gold" : ""}>
                          {it.kind === "vip" ? "VIP" : it.kind === "coins" ? "سکه" : "محصول"}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-gold font-bold tabular-nums">{faDigits(formatNumber(it.price))} ت</span>
                        <div className="flex items-center gap-2">
                          <span className="text-muted-foreground">{faDigits(it._count?.orders || 0)} سفارش</span>
                          <Switch checked={it.active} onCheckedChange={async (c) => {
                            try { await api(`/api/admin/shop/items/${it.id}`, { method: "PATCH", json: { active: c } }); await load() } catch (e: any) { toast(e.message, "error") }
                          }} />
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <Button size="sm" variant="outline" className="flex-1 h-8" onClick={() => setEditingItem(it)}>
                          <Edit2 className="w-3.5 h-3.5 ml-1" /> ویرایش
                        </Button>
                        <Button size="sm" variant="outline" className="h-8 w-8 p-0" onClick={() => setDeleteItem(it)}>
                          <Trash2 className="w-3.5 h-3.5 text-rose-500" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {reviewReceipt && (
        <Dialog open onOpenChange={(o) => !o && setReviewReceipt(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>بررسی رسید سفارش</DialogTitle>
              <DialogDescription>{reviewReceipt.shopItem?.title} — {reviewReceipt.user?.displayName || reviewReceipt.user?.username}</DialogDescription>
            </DialogHeader>
            <div className="space-y-3">
              {reviewReceipt.receiptUrl && (
                <div className="rounded-lg overflow-hidden border border-border">
                  <img src={reviewReceipt.receiptUrl} alt="رسید" className="w-full max-h-[60vh] object-contain bg-muted/30" />
                </div>
              )}
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="p-2 rounded bg-muted/40"><div className="text-[10px] text-muted-foreground">مبلغ</div><div className="font-bold text-gold tabular-nums">{faDigits(formatNumber(reviewReceipt.amount))} تومان</div></div>
                <div className="p-2 rounded bg-muted/40"><div className="text-[10px] text-muted-foreground">سکه</div><div className="font-bold tabular-nums">{faDigits(formatNumber(reviewReceipt.coins || 0))}</div></div>
                <div className="p-2 rounded bg-muted/40 col-span-2"><div className="text-[10px] text-muted-foreground">یادداشت</div><div className="text-xs">{reviewReceipt.note || "—"}</div></div>
              </div>
            </div>
            {reviewReceipt.status === "pending" && (
              <DialogFooter>
                <Button variant="outline" className="text-rose-500 border-rose-500/40 hover:bg-rose-500/10" disabled={busyId === reviewReceipt.id} onClick={() => reviewOrder(reviewReceipt.id, "reject")}>
                  {busyId === reviewReceipt.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <X className="w-4 h-4 ml-1" />} رد سفارش
                </Button>
                <Button className="bg-emerald-500 hover:bg-emerald-600" disabled={busyId === reviewReceipt.id} onClick={() => reviewOrder(reviewReceipt.id, "confirm")}>
                  {busyId === reviewReceipt.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4 ml-1" />} تأیید سفارش
                </Button>
              </DialogFooter>
            )}
          </DialogContent>
        </Dialog>
      )}

      {(editingItem || creatingItem) && (
        <ItemDialog item={editingItem} isNew={creatingItem} onClose={() => { setEditingItem(null); setCreatingItem(false) }} onSave={saveItem} />
      )}

      {deleteItem && (
        <AlertDialog open onOpenChange={(o) => !o && setDeleteItem(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>حذف محصول</AlertDialogTitle>
              <AlertDialogDescription>آیا از حذف «{deleteItem.title}» مطمئن هستید؟ سفارش‌های مربوطه حفظ می‌شوند اما محصول دیگر قابل انتخاب نیست.</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>انصراف</AlertDialogCancel>
              <AlertDialogAction className="bg-rose-500 hover:bg-rose-600 text-white" onClick={() => deleteItemFn(deleteItem.id)}>حذف</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  )
}

function ItemDialog({ item, isNew, onClose, onSave }: { item: any; isNew: boolean; onClose: () => void; onSave: (i: any, isNew: boolean) => void }) {
  const [title, setTitle] = useState(item?.title || "")
  const [description, setDescription] = useState(item?.description || "")
  const [price, setPrice] = useState(String(item?.price ?? 100000))
  const [kind, setKind] = useState(item?.kind || "coins")
  const [payload, setPayload] = useState(item?.payload || "")
  const [imageUrl, setImageUrl] = useState(item?.imageUrl || "")
  const [active, setActive] = useState(item?.active ?? true)

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto thin-scrollbar">
        <DialogHeader>
          <DialogTitle>{isNew ? "محصول جدید" : "ویرایش محصول"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <div className="space-y-1.5"><Label>عنوان</Label><Input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={200} /></div>
          <div className="space-y-1.5"><Label>توضیحات</Label><Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} maxLength={1000} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>نوع</Label>
              <Select value={kind} onValueChange={setKind}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="coins">بسته سکه</SelectItem>
                  <SelectItem value="vip">اشتراک VIP</SelectItem>
                  <SelectItem value="custom">سایر</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>قیمت (تومان)</Label><Input type="number" value={price} onChange={(e) => setPrice(e.target.value)} min={0} /></div>
          </div>
          <div className="space-y-1.5">
            <Label>{kind === "coins" ? "مقدار سکه" : kind === "vip" ? "تعداد روز" : "مقدار"}</Label>
            <Input type="number" value={payload} onChange={(e) => setPayload(e.target.value)} />
          </div>
          <div className="space-y-1.5"><Label>آدرس تصویر</Label><Input value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} placeholder="/storage/..." /></div>
          <div className="flex items-center gap-2">
            <Switch checked={active} onCheckedChange={setActive} />
            <Label>فعال</Label>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>انصراف</Button>
          <Button onClick={() => onSave({ id: item?.id, title, description: description || null, price: parseInt(price, 10) || 0, kind, payload, imageUrl: imageUrl || null, active }, isNew)} disabled={!title.trim()}>
            ذخیره
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
