"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import { useApp, type CurrentUser } from "@/lib/store"
import { api, formatBytes, formatNumber, formatDate, timeAgo, faDigits } from "@/lib/format"
import { cn } from "@/lib/utils"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Skeleton } from "@/components/ui/skeleton"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Crown,
  Pencil,
  Coins,
  FileText,
  Newspaper,
  Film,
  Video as VideoIcon,
  HardDrive,
  Shield,
  Check,
  Loader2,
  ImageIcon,
  File as FileIcon,
  Music2,
  Eye,
  Heart,
  MessageCircle,
  Upload as UploadIcon,
  X,
  Sparkles,
  Palette,
  Type,
} from "lucide-react"
import { UserAvatar } from "@/components/karol/UserAvatar"
import { UserName } from "@/components/karol/UserName"

interface Stats {
  counts: { files: number; posts: number; reels: number; videos: number }
  quota: { used: string; limit: string; resetAt: string }
}

interface FileT {
  id: string
  name: string
  url: string
  size: string
  mime: string
  category: string
  isPublic: boolean
  createdAt: string
}

interface PostT {
  id: string
  content: string | null
  mediaUrls: string[]
  createdAt: string
  likes: number
  comments: number
}

interface ReelT {
  id: string
  videoUrl: string
  posterUrl: string | null
  caption: string | null
  musicTitle: string | null
  views: number
  createdAt: string
  likes: number
  comments: number
}

interface VideoT {
  id: string
  title: string
  description: string | null
  videoUrl: string
  thumbnailUrl: string | null
  category: string
  duration: number
  views: number
  createdAt: string
  likes: number
  comments: number
}

const ROLE_LABELS: Record<string, string> = {
  admin: "مدیر",
  moderator: "ناظم",
  chat_mod: "ناظم چت",
  user: "کاربر",
}

function roleLabel(role: string): string {
  return ROLE_LABELS[role] || role
}

function formatDuration(s: number): string {
  if (!s || s < 0) return "۰:۰۰"
  const sec = Math.floor(s)
  const h = Math.floor(sec / 3600)
  const m = Math.floor((sec % 3600) / 60)
  const r = sec % 60
  if (h > 0) return `${faDigits(h)}:${faDigits(String(m).padStart(2, "0"))}:${faDigits(String(r).padStart(2, "0"))}`
  return `${faDigits(m)}:${faDigits(String(r).padStart(2, "0"))}`
}

export default function ProfileSection() {
  const { user, toast, refreshUser, setSection } = useApp()
  const [stats, setStats] = useState<Stats | null>(null)
  const [loadingStats, setLoadingStats] = useState(true)
  const [editOpen, setEditOpen] = useState(false)
  const [pwOpen, setPwOpen] = useState(false)
  const [lastLoginAt, setLastLoginAt] = useState<string | null>(null)

  const loadStats = useCallback(async () => {
    setLoadingStats(true)
    try {
      const s = await api<Stats>("/api/profile/stats")
      setStats(s)
    } catch (e: any) {
      toast(e.message || "خطا در بارگذاری آمار", "error")
    } finally {
      setLoadingStats(false)
    }
  }, [toast])

  useEffect(() => {
    loadStats()
    api<{ user: { lastLoginAt: string | null } }>("/api/profile")
      .then((d) => setLastLoginAt(d.user.lastLoginAt))
      .catch(() => {})
  }, [loadStats])

  if (!user) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-40 w-full rounded-xl" />
        <Skeleton className="h-24 w-full rounded-xl" />
        <Skeleton className="h-64 w-full rounded-xl" />
      </div>
    )
  }

  return (
    <div className="min-h-full overflow-y-auto thin-scrollbar">
      <div className="max-w-5xl mx-auto p-3 sm:p-6 space-y-4 sm:space-y-6">
        <HeaderCard
          user={user}
          lastLoginAt={lastLoginAt}
          onEdit={() => setEditOpen(true)}
          onSaved={(u) => {
            refreshUser()
            loadStats()
          }}
          editOpen={editOpen}
          setEditOpen={setEditOpen}
          toast={toast}
        />

        {user.isVip && (
          <VipEffectsCard
            user={user}
            onSaved={() => refreshUser()}
            toast={toast}
          />
        )}

        <StatsRow stats={stats} loading={loadingStats} setSection={setSection} user={user} />

        <QuotaCard stats={stats} loading={loadingStats} />

        <Tabs defaultValue="files" className="w-full">
          <TabsList className="w-full justify-start overflow-x-auto no-scrollbar h-auto">
            <TabsTrigger value="files" className="gap-1.5">
              <FileText className="w-4 h-4" /> فایل‌های من
            </TabsTrigger>
            <TabsTrigger value="posts" className="gap-1.5">
              <Newspaper className="w-4 h-4" /> پست‌های من
            </TabsTrigger>
            <TabsTrigger value="reels" className="gap-1.5">
              <Film className="w-4 h-4" /> ریلزهای من
            </TabsTrigger>
            <TabsTrigger value="videos" className="gap-1.5">
              <VideoIcon className="w-4 h-4" /> ویدیوهای من
            </TabsTrigger>
          </TabsList>

          <TabsContent value="files" className="mt-4">
            <FilesTab onManage={() => setSection("drive")} />
          </TabsContent>
          <TabsContent value="posts" className="mt-4">
            <PostsTab onOpenFeed={() => setSection("feed")} />
          </TabsContent>
          <TabsContent value="reels" className="mt-4">
            <ReelsTab onOpenReels={() => setSection("reels")} />
          </TabsContent>
          <TabsContent value="videos" className="mt-4">
            <VideosTab onOpenVideos={() => setSection("videos")} />
          </TabsContent>
        </Tabs>

        <SecurityCard onOpen={() => setPwOpen(true)} />
        <PasswordDialog
          open={pwOpen}
          setOpen={setPwOpen}
          toast={toast}
        />
      </div>
    </div>
  )
}

function HeaderCard({
  user,
  lastLoginAt,
  onEdit,
  onSaved,
  editOpen,
  setEditOpen,
  toast,
}: {
  user: CurrentUser
  lastLoginAt: string | null
  onEdit: () => void
  onSaved: (u: CurrentUser) => void
  editOpen: boolean
  setEditOpen: (b: boolean) => void
  toast: (m: string, k?: "default" | "success" | "error") => void
}) {
  const [displayName, setDisplayName] = useState(user.displayName || "")
  const [bio, setBio] = useState(user.bio || "")
  const [avatarUrl, setAvatarUrl] = useState(user.avatarUrl || "")
  const [pendingUrl, setPendingUrl] = useState<string | null>(null)
  const [uploading, setUploading] = useState(false)
  const [saving, setSaving] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (editOpen) {
      setDisplayName(user.displayName || "")
      setBio(user.bio || "")
      setAvatarUrl(user.avatarUrl || "")
      setPendingUrl(null)
    }
  }, [editOpen, user])

  async function pickAvatar(file: File) {
    if (!file.type.startsWith("image/")) {
      toast("فقط تصویر مجاز است", "error")
      return
    }
    if (file.size > 5 * 1024 * 1024) {
      toast("حداکثر ۵ مگابایت", "error")
      return
    }
    setUploading(true)
    try {
      const fd = new FormData()
      fd.append("file", file)
      fd.append("category", "avatar")
      const r = await fetch("/api/upload", { method: "POST", body: fd })
      const d = await r.json()
      if (!r.ok) throw new Error(d.error || "خطا در آپلود")
      setPendingUrl(d.url)
      toast("تصویر آماده ذخیره", "success")
    } catch (e: any) {
      toast(e.message || "خطا در آپلود", "error")
    } finally {
      setUploading(false)
    }
  }

  async function save() {
    setSaving(true)
    try {
      const finalAvatar = pendingUrl || avatarUrl
      const d = await api<{ user: CurrentUser }>("/api/profile", {
        method: "PATCH",
        json: { displayName, bio, avatarUrl: finalAvatar },
      })
      onSaved(d.user)
      setEditOpen(false)
      toast("پروفایل به‌روزرسانی شد", "success")
    } catch (e: any) {
      toast(e.message || "خطا در ذخیره", "error")
    } finally {
      setSaving(false)
    }
  }

  const previewAvatar = pendingUrl || avatarUrl || user.avatarUrl || ""
  const initials = (user.displayName || user.username)[0]?.toUpperCase()

  return (
    <Card className="overflow-hidden border-border/60 shadow-soft">
      <div className="h-24 sm:h-28 gradient-karol" />
      <CardContent className="px-4 sm:px-6 pb-5 pt-0 -mt-12 sm:-mt-14">
        <div className="flex flex-col sm:flex-row sm:items-end gap-4">
          <div className="relative">
            <Avatar className="w-24 h-24 border-4 border-background rounded-2xl shadow-soft">
              <AvatarImage src={previewAvatar || undefined} />
              <AvatarFallback className="rounded-2xl bg-primary/15 text-primary text-3xl font-black">
                {initials}
              </AvatarFallback>
            </Avatar>
            {editOpen && (
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                disabled={uploading}
                className="absolute -bottom-1 -left-1 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-soft hover:scale-110 transition-transform disabled:opacity-60"
              >
                {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <UploadIcon className="w-4 h-4" />}
              </button>
            )}
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0]
                if (f) pickAvatar(f)
                e.target.value = ""
              }}
            />
          </div>

          <div className="flex-1 min-w-0 space-y-1.5">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl sm:text-2xl font-bold truncate">
                <UserName
                  user={{
                    displayName: user.displayName,
                    username: user.username,
                    isVip: user.isVip,
                    profileEffect: user.profileEffect,
                    nameColor: user.nameColor,
                  }}
                />
              </h2>
              {user.isVip && (
                <Badge className="bg-gold text-gold-foreground gap-1">
                  <Crown className="w-3 h-3" /> VIP
                </Badge>
              )}
              {user.roles
                .filter((r) => r !== "user")
                .map((r) => (
                  <Badge key={r} variant="secondary" className="gap-1">
                    <Shield className="w-3 h-3" /> {roleLabel(r)}
                  </Badge>
                ))}
            </div>
            <div className="text-sm text-muted-foreground">@{user.username}</div>
          </div>

          {!editOpen && (
            <Button variant="outline" size="sm" onClick={onEdit} className="gap-1.5">
              <Pencil className="w-4 h-4" /> ویرایش پروفایل
            </Button>
          )}
        </div>

        {!editOpen ? (
          <div className="mt-4 space-y-3">
            {user.bio ? (
              <p className="text-sm text-foreground/90 leading-relaxed whitespace-pre-wrap">{user.bio}</p>
            ) : (
              <p className="text-sm text-muted-foreground italic">بدون توضیحات</p>
            )}
            <div className="flex flex-wrap gap-x-5 gap-y-1 text-xs text-muted-foreground">
              <span>عضو از {formatDate(user.createdAt)}</span>
              {lastLoginAt && <span>آخرین ورود: {formatDate(lastLoginAt)}</span>}
              {user.vipExpiresAt && (
                <span className="text-gold">
                  انقضای VIP: {formatDate(user.vipExpiresAt)}
                </span>
              )}
            </div>
          </div>
        ) : (
          <div className="mt-5 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="displayName">نام نمایشی</Label>
              <Input
                id="displayName"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                maxLength={60}
                placeholder="نام نمایشی شما"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="bio">درباره من</Label>
              <Textarea
                id="bio"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                rows={3}
                maxLength={500}
                placeholder="چند خط درباره خودتان…"
              />
              <div className="text-[11px] text-muted-foreground text-left">{faDigits(bio.length)} / ۵۰۰</div>
            </div>
            {pendingUrl && (
              <div className="flex items-center gap-2 text-xs text-emerald-600 dark:text-emerald-400">
                <Check className="w-3.5 h-3.5" /> تصویر جدید آماده ذخیره است
              </div>
            )}
            <div className="flex gap-2 justify-end">
              <Button variant="ghost" onClick={() => setEditOpen(false)} disabled={saving}>
                <X className="w-4 h-4 ml-1" /> انصراف
              </Button>
              <Button onClick={save} disabled={saving} className="gap-1.5">
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                ذخیره
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

const PROFILE_EFFECT_OPTIONS: {
  value: string
  label: string
  desc: string
  ringClass?: string
}[] = [
  { value: "none", label: "بدون افکت", desc: "حالت ساده" },
  { value: "rgb", label: "حلقه RGB", desc: "حاشیه رنگین‌کمان متحرک", ringClass: "karol-rgb-ring" },
  { value: "rainbow", label: "متن رنگین‌کمان", desc: "اسم کاربر با رنگ متغیر" },
  { value: "pulse", label: "تپش نورانی", desc: "درخشش پالس‌دار دور آواتار", ringClass: "karol-pulse-glow" },
  { value: "gold", label: "حلقه طلایی", desc: "حاشیه طلایی ویژه VIP", ringClass: "karol-gold-ring" },
]

const PRESET_COLORS = [
  "#2dd4bf",
  "#a78bfa",
  "#fbbf24",
  "#f43f5e",
  "#a3e635",
  "#38bdf8",
  "#fb7185",
  "#c4b5fd",
]

function VipEffectsCard({
  user,
  onSaved,
  toast,
}: {
  user: CurrentUser
  onSaved: () => void
  toast: (m: string, k?: "default" | "success" | "error") => void
}) {
  const [animatedUrl, setAnimatedUrl] = useState(user.animatedAvatarUrl || "")
  const [pendingAnimatedUrl, setPendingAnimatedUrl] = useState<string | null>(null)
  const [effect, setEffect] = useState(user.profileEffect || "none")
  const [nameColor, setNameColor] = useState(user.nameColor || "")
  const [uploading, setUploading] = useState(false)
  const [savingEffect, setSavingEffect] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    setAnimatedUrl(user.animatedAvatarUrl || "")
    setEffect(user.profileEffect || "none")
    setNameColor(user.nameColor || "")
    setPendingAnimatedUrl(null)
  }, [user])

  async function pickGif(file: File) {
    const isGif = file.type === "image/gif" || /\.gif$/i.test(file.name)
    if (!file.type.startsWith("image/")) {
      toast("فقط تصویر مجاز است", "error")
      return
    }
    if (!isGif) {
      toast("برای آواتار متحرک فقط فایل GIF مجاز است", "error")
      return
    }
    if (file.size > 8 * 1024 * 1024) {
      toast("حداکثر ۸ مگابایت برای GIF", "error")
      return
    }
    setUploading(true)
    try {
      const fd = new FormData()
      fd.append("file", file)
      fd.append("category", "avatar")
      const r = await fetch("/api/upload", { method: "POST", body: fd })
      const d = await r.json()
      if (!r.ok) throw new Error(d.error || "خطا در آپلود")
      setPendingAnimatedUrl(d.url)
      toast("GIF آماده ذخیره است", "success")
    } catch (e: any) {
      toast(e.message || "خطا در آپلود", "error")
    } finally {
      setUploading(false)
    }
  }

  async function saveEffect(field: "animatedAvatarUrl" | "profileEffect" | "nameColor", value: string | null) {
    setSavingEffect(true)
    try {
      await api("/api/profile", { method: "PATCH", json: { [field]: value } })
      toast("ذخیره شد", "success")
      onSaved()
    } catch (e: any) {
      toast(e.message || "خطا در ذخیره", "error")
    } finally {
      setSavingEffect(false)
    }
  }

  async function saveAll() {
    setSavingEffect(true)
    try {
      const payload: Record<string, string | null> = {}
      if (pendingAnimatedUrl) payload.animatedAvatarUrl = pendingAnimatedUrl
      if (effect !== (user.profileEffect || "none")) payload.profileEffect = effect
      const targetColor = nameColor.trim() || null
      if (targetColor !== (user.nameColor || null)) payload.nameColor = targetColor
      if (Object.keys(payload).length === 0) {
        toast("تغییری برای ذخیره نیست", "default")
        return
      }
      await api("/api/profile", { method: "PATCH", json: payload })
      toast("افکت‌های VIP ذخیره شد", "success")
      setPendingAnimatedUrl(null)
      onSaved()
    } catch (e: any) {
      toast(e.message || "خطا در ذخیره", "error")
    } finally {
      setSavingEffect(false)
    }
  }

  const previewUser = {
    avatarUrl: user.avatarUrl,
    animatedAvatarUrl: pendingAnimatedUrl || animatedUrl || user.animatedAvatarUrl,
    isVip: true,
    profileEffect: effect,
    displayName: user.displayName,
    username: user.username,
    nameColor: nameColor || user.nameColor,
  }

  return (
    <Card className="border-gold/30 shadow-glow overflow-hidden">
      <div className="h-1.5 gradient-gold" />
      <CardContent className="p-4 sm:p-6 space-y-5">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gold/15 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-gold" />
          </div>
          <div>
            <h3 className="font-bold text-primary-c flex items-center gap-2">
              افکت‌های پروفایل VIP
              <Badge className="bg-gold text-gold-foreground gap-1 text-[10px]">
                <Crown className="w-2.5 h-2.5" /> VIP
              </Badge>
            </h3>
            <p className="text-xs text-muted-c mt-0.5">
              آواتار متحرک، حلقه رنگین‌کمان، نام رنگی و بیش‌تر
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-[200px_1fr] gap-5">
          <div className="flex flex-col items-center justify-start gap-3">
            <div className="text-[11px] text-muted-c">پیش‌نمایش زنده</div>
            <UserAvatar user={previewUser} size="xl" />
            <UserName user={previewUser} className="text-base" />
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              disabled={uploading}
              className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-gold/15 text-gold text-xs font-semibold hover:bg-gold/25 transition-colors disabled:opacity-60"
            >
              {uploading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <UploadIcon className="w-3.5 h-3.5" />}
              {pendingAnimatedUrl ? "تغییر GIF" : animatedUrl ? "تغییر GIF" : "آپلود GIF"}
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="image/gif"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0]
                if (f) pickGif(f)
                e.target.value = ""
              }}
            />
            {pendingAnimatedUrl && (
              <div className="text-[10px] text-gold flex items-center gap-1">
                <Check className="w-3 h-3" /> GIF جدید آماده ذخیره
              </div>
            )}
            {(animatedUrl || pendingAnimatedUrl) && (
              <button
                type="button"
                onClick={() => {
                  setPendingAnimatedUrl(null)
                  setAnimatedUrl("")
                  saveEffect("animatedAvatarUrl", null)
                }}
                className="text-[10px] text-danger hover:underline"
              >
                حذف آواتار متحرک
              </button>
            )}
          </div>

          <div className="space-y-5">
            <div>
              <div className="text-xs font-semibold text-primary-c mb-2 flex items-center gap-1.5">
                <Palette className="w-3.5 h-3.5 text-accent" />
                افکت پروفایل
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {PROFILE_EFFECT_OPTIONS.map((opt) => {
                  const active = effect === opt.value
                  return (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => setEffect(opt.value)}
                      className={cn(
                        "p-2.5 rounded-xl border text-right transition-all",
                        active
                          ? "border-gold bg-gold/10 shadow-soft"
                          : "border-hair bg-surface hover:bg-accent-15",
                      )}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-bold text-primary-c">{opt.label}</span>
                        {active && <Check className="w-3.5 h-3.5 text-gold shrink-0" />}
                      </div>
                      <div className="text-[10px] text-muted-c mt-0.5">{opt.desc}</div>
                    </button>
                  )
                })}
              </div>
            </div>

            <div>
              <div className="text-xs font-semibold text-primary-c mb-2 flex items-center gap-1.5">
                <Type className="w-3.5 h-3.5 text-accent" />
                رنگ نام کاربری
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => setNameColor("")}
                  className={cn(
                    "w-7 h-7 rounded-full border-2 flex items-center justify-center text-[10px] font-bold",
                    !nameColor ? "border-gold bg-gold/10 text-gold" : "border-hair text-muted-c",
                  )}
                  title="رنگ پیش‌فرض"
                >
                  ✕
                </button>
                {PRESET_COLORS.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setNameColor(c)}
                    className={cn(
                      "w-7 h-7 rounded-full border-2 transition-transform hover:scale-110",
                      nameColor.toLowerCase() === c.toLowerCase()
                        ? "border-gold scale-110"
                        : "border-hair",
                    )}
                    style={{ background: c }}
                    title={c}
                  />
                ))}
                <Input
                  value={nameColor}
                  onChange={(e) => setNameColor(e.target.value)}
                  placeholder="#2dd4bf"
                  dir="ltr"
                  className="w-28 h-7 text-[11px] bg-surface-2 border-hair"
                  maxLength={7}
                />
              </div>
              <p className="text-[10px] text-muted-c mt-1">
                وقتی افکت «متن رنگین‌کمان» فعال است، رنگ نام نادیده گرفته می‌شود.
              </p>
            </div>

            <div className="flex justify-end gap-2 pt-1 border-t border-hair">
              <Button
                onClick={saveAll}
                disabled={savingEffect}
                className="gap-1.5 gradient-gold text-gold-foreground border-0"
              >
                {savingEffect ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                ذخیره افکت‌ها
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function StatsRow({
  stats,
  loading,
  setSection,
  user,
}: {
  stats: Stats | null
  loading: boolean
  setSection: (s: any, p?: Record<string, any>) => void
  user: CurrentUser
}) {
  const items = [
    {
      key: "coins",
      label: "سکه",
      value: formatNumber(user.coins),
      icon: Coins,
      onClick: () => setSection("wallet"),
      gold: true,
    },
    {
      key: "files",
      label: "فایل",
      value: loading ? "…" : faDigits(stats?.counts.files ?? 0),
      icon: HardDrive,
      onClick: () => setSection("drive"),
    },
    {
      key: "posts",
      label: "پست",
      value: loading ? "…" : faDigits(stats?.counts.posts ?? 0),
      icon: Newspaper,
      onClick: () => setSection("feed"),
    },
    {
      key: "reels",
      label: "ریلز",
      value: loading ? "…" : faDigits(stats?.counts.reels ?? 0),
      icon: Film,
      onClick: () => setSection("reels"),
    },
    {
      key: "videos",
      label: "ویدیو",
      value: loading ? "…" : faDigits(stats?.counts.videos ?? 0),
      icon: VideoIcon,
      onClick: () => setSection("videos"),
    },
  ]

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5 sm:gap-3">
      {items.map((it) => (
        <button
          key={it.key}
          onClick={it.onClick}
          className={cn(
            "rounded-xl border border-border/60 bg-card p-3 sm:p-4 text-right hover:bg-accent transition-colors shadow-soft",
            it.gold && "border-gold/30 bg-gold/5",
          )}
        >
          <div className="flex items-center justify-between">
            <span
              className={cn(
                "text-xl sm:text-2xl font-black tabular-nums",
                it.gold && "text-gold",
              )}
            >
              {it.value}
            </span>
            <it.icon className={cn("w-4 h-4 text-muted-foreground", it.gold && "text-gold")} />
          </div>
          <div className="text-[11px] sm:text-xs text-muted-foreground mt-0.5">{it.label}</div>
        </button>
      ))}
    </div>
  )
}

function QuotaCard({ stats, loading }: { stats: Stats | null; loading: boolean }) {
  if (loading || !stats) {
    return <Skeleton className="h-24 w-full rounded-xl" />
  }
  const used = Number(stats.quota.used)
  const limit = Number(stats.quota.limit)
  const pct = limit > 0 ? Math.min(100, Math.round((used / limit) * 100)) : 0
  const reset = new Date(stats.quota.resetAt)
  const nextReset = new Date(reset)
  nextReset.setUTCDate(nextReset.getUTCDate() + 1)
  nextReset.setUTCHours(0, 0, 0, 0)

  return (
    <Card className="border-border/60 shadow-soft">
      <CardContent className="p-4 sm:p-5 space-y-3">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <HardDrive className="w-4 h-4 text-primary" />
            </div>
            <div>
              <div className="text-sm font-semibold">سهمیه آپلود امروز</div>
              <div className="text-[11px] text-muted-foreground">
                بازنشانی در {formatDate(nextReset)}
              </div>
            </div>
          </div>
          <div className="text-left">
            <div className="text-sm font-bold tabular-nums">
              {formatBytes(used)} <span className="text-muted-foreground">/ {formatBytes(limit)}</span>
            </div>
            <div className="text-[11px] text-muted-foreground">{faDigits(pct)}٪ استفاده شده</div>
          </div>
        </div>
        <Progress value={pct} className="h-2" />
      </CardContent>
    </Card>
  )
}

function FilesTab({ onManage }: { onManage: () => void }) {
  const { toast } = useApp()
  const [files, setFiles] = useState<FileT[]>([])
  const [loading, setLoading] = useState(true)
  const [cursor, setCursor] = useState<string | null>(null)
  const [next, setNext] = useState<string | null>(null)

  const load = useCallback(async (c?: string) => {
    try {
      const d = await api<{ files: FileT[]; nextCursor: string | null }>(
        c ? `/api/profile/files?cursor=${c}` : "/api/profile/files",
      )
      setFiles((prev) => (c ? [...prev, ...d.files] : d.files))
      setNext(d.nextCursor)
    } catch (e: any) {
      toast(e.message || "خطا", "error")
    } finally {
      setLoading(false)
    }
  }, [toast])

  useEffect(() => {
    load()
  }, [load])

  const images = files.filter((f) => f.category === "image" || f.mime.startsWith("image/"))
  const others = files.filter((f) => !(f.category === "image" || f.mime.startsWith("image/")))

  if (loading) {
    return <Skeleton className="h-64 w-full rounded-xl" />
  }

  if (files.length === 0) {
    return <EmptyState icon={FileText} text="هنوز فایلی آپلود نکرده‌اید" actionLabel="رفتن به آپلود سنتر" onAction={onManage} />
  }

  return (
    <div className="space-y-4">
      {images.length > 0 && (
        <div>
          <div className="text-xs text-muted-foreground mb-2">تصاویر ({faDigits(images.length)})</div>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2">
            {images.map((f) => (
              <a
                key={f.id}
                href={f.url}
                target="_blank"
                rel="noreferrer"
                className="aspect-square rounded-lg overflow-hidden border border-border/60 bg-muted hover:opacity-90 transition-opacity"
              >
                <img src={f.url} alt={f.name} className="w-full h-full object-cover" loading="lazy" />
              </a>
            ))}
          </div>
        </div>
      )}

      {others.length > 0 && (
        <div>
          <div className="text-xs text-muted-foreground mb-2">سایر فایل‌ها ({faDigits(others.length)})</div>
          <div className="space-y-1.5 max-h-72 overflow-y-auto thin-scrollbar pr-1">
            {others.map((f) => (
              <a
                key={f.id}
                href={f.url}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-3 p-2.5 rounded-lg border border-border/60 hover:bg-accent transition-colors"
              >
                <div className="w-9 h-9 rounded-lg bg-muted flex items-center justify-center shrink-0">
                  <FileIcon className="w-4 h-4 text-muted-foreground" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">{f.name}</div>
                  <div className="text-[11px] text-muted-foreground">
                    {formatBytes(f.size)} · {timeAgo(f.createdAt)}
                  </div>
                </div>
                {f.isPublic && <Badge variant="secondary" className="text-[10px]">عمومی</Badge>}
              </a>
            ))}
          </div>
        </div>
      )}

      {next && (
        <Button variant="outline" size="sm" onClick={() => { setCursor(next); load(next) }} className="w-full">
          بارگذاری بیشتر
        </Button>
      )}

      <div className="pt-2">
        <Button variant="ghost" size="sm" onClick={onManage} className="gap-1.5">
          <HardDrive className="w-4 h-4" /> مدیریت در آپلود سنتر
        </Button>
      </div>
    </div>
  )
}

function PostsTab({ onOpenFeed }: { onOpenFeed: () => void }) {
  const { toast } = useApp()
  const [posts, setPosts] = useState<PostT[]>([])
  const [loading, setLoading] = useState(true)
  const [next, setNext] = useState<string | null>(null)

  const load = useCallback(async () => {
    try {
      const d = await api<{ posts: PostT[]; nextCursor: string | null }>("/api/profile/posts")
      setPosts(d.posts)
      setNext(d.nextCursor)
    } catch (e: any) {
      toast(e.message || "خطا", "error")
    } finally {
      setLoading(false)
    }
  }, [toast])

  useEffect(() => {
    load()
  }, [load])

  if (loading) return <Skeleton className="h-64 w-full rounded-xl" />
  if (posts.length === 0) {
    return <EmptyState icon={Newspaper} text="هنوز پستی منتشر نکرده‌اید" actionLabel="رفتن به خانه" onAction={onOpenFeed} />
  }

  return (
    <div className="space-y-2">
      {posts.map((p) => (
        <button
          key={p.id}
          onClick={onOpenFeed}
          className="w-full text-right p-3 rounded-xl border border-border/60 hover:bg-accent transition-colors"
        >
          {p.content && (
            <p className="text-sm leading-relaxed line-clamp-2 mb-2">{p.content}</p>
          )}
          {p.mediaUrls.length > 0 && (
            <div className="flex gap-1.5 mb-2">
              {p.mediaUrls.slice(0, 4).map((u, i) => (
                <div key={i} className="w-14 h-14 rounded-md overflow-hidden bg-muted shrink-0">
                  <img src={u} alt="" className="w-full h-full object-cover" loading="lazy" />
                </div>
              ))}
              {p.mediaUrls.length > 4 && (
                <div className="w-14 h-14 rounded-md bg-muted flex items-center justify-center text-xs text-muted-foreground shrink-0">
                  +{faDigits(p.mediaUrls.length - 4)}
                </div>
              )}
            </div>
          )}
          <div className="flex items-center gap-4 text-[11px] text-muted-foreground">
            <span className="flex items-center gap-1">
              <Heart className="w-3 h-3" /> {faDigits(p.likes)}
            </span>
            <span className="flex items-center gap-1">
              <MessageCircle className="w-3 h-3" /> {faDigits(p.comments)}
            </span>
            <span className="ml-auto">{timeAgo(p.createdAt)}</span>
          </div>
        </button>
      ))}
    </div>
  )
}

function ReelsTab({ onOpenReels }: { onOpenReels: () => void }) {
  const { toast } = useApp()
  const [reels, setReels] = useState<ReelT[]>([])
  const [loading, setLoading] = useState(true)
  const [next, setNext] = useState<string | null>(null)

  const load = useCallback(async () => {
    try {
      const d = await api<{ reels: ReelT[]; nextCursor: string | null }>("/api/profile/reels")
      setReels(d.reels)
      setNext(d.nextCursor)
    } catch (e: any) {
      toast(e.message || "خطا", "error")
    } finally {
      setLoading(false)
    }
  }, [toast])

  useEffect(() => {
    load()
  }, [load])

  if (loading) return <Skeleton className="h-64 w-full rounded-xl" />
  if (reels.length === 0) {
    return <EmptyState icon={Film} text="هنوز ریلزی نساخته‌اید" actionLabel="ساخت ریلز" onAction={onOpenReels} />
  }

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
        {reels.map((r) => (
          <button
            key={r.id}
            onClick={onOpenReels}
            className="group relative aspect-[9/16] rounded-lg overflow-hidden bg-black"
          >
            {r.posterUrl ? (
              <img src={r.posterUrl} alt="" className="w-full h-full object-cover" loading="lazy" />
            ) : (
              <video
                src={r.videoUrl}
                className="w-full h-full object-cover"
                preload="metadata"
                muted
              />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            <div className="absolute bottom-1.5 right-1.5 left-1.5 text-white text-[10px]">
              {r.caption && <p className="line-clamp-1 mb-0.5">{r.caption}</p>}
              <div className="flex items-center gap-2 opacity-90">
                <span className="flex items-center gap-0.5"><Eye className="w-2.5 h-2.5" />{faDigits(r.views)}</span>
                <span className="flex items-center gap-0.5"><Heart className="w-2.5 h-2.5" />{faDigits(r.likes)}</span>
              </div>
            </div>
            {r.musicTitle && (
              <div className="absolute top-1.5 right-1.5 bg-black/40 backdrop-blur-sm rounded-full px-1.5 py-0.5 text-white text-[9px] flex items-center gap-0.5">
                <Music2 className="w-2.5 h-2.5" />
              </div>
            )}
          </button>
        ))}
      </div>
      {next && (
        <Button variant="outline" size="sm" className="w-full" onClick={load}>بارگذاری بیشتر</Button>
      )}
    </div>
  )
}

function VideosTab({ onOpenVideos }: { onOpenVideos: () => void }) {
  const { toast } = useApp()
  const [videos, setVideos] = useState<VideoT[]>([])
  const [loading, setLoading] = useState(true)
  const [next, setNext] = useState<string | null>(null)

  const load = useCallback(async () => {
    try {
      const d = await api<{ videos: VideoT[]; nextCursor: string | null }>("/api/profile/videos")
      setVideos(d.videos)
      setNext(d.nextCursor)
    } catch (e: any) {
      toast(e.message || "خطا", "error")
    } finally {
      setLoading(false)
    }
  }, [toast])

  useEffect(() => {
    load()
  }, [load])

  if (loading) return <Skeleton className="h-64 w-full rounded-xl" />
  if (videos.length === 0) {
    return <EmptyState icon={VideoIcon} text="هنوز ویدیویی نگذاشته‌اید" actionLabel="بارگذاری ویدیو" onAction={onOpenVideos} />
  }

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {videos.map((v) => (
          <button
            key={v.id}
            onClick={onOpenVideos}
            className="text-right rounded-xl overflow-hidden border border-border/60 hover:bg-accent transition-colors"
          >
            <div className="relative aspect-video bg-muted">
              {v.thumbnailUrl ? (
                <img src={v.thumbnailUrl} alt="" className="w-full h-full object-cover" loading="lazy" />
              ) : (
                <video src={v.videoUrl} className="w-full h-full object-cover" preload="metadata" muted />
              )}
              <div className="absolute bottom-1.5 left-1.5 bg-black/70 text-white text-[10px] px-1.5 py-0.5 rounded tabular-nums">
                {formatDuration(v.duration)}
              </div>
              <div className="absolute top-1.5 right-1.5 bg-black/50 text-white text-[10px] px-1.5 py-0.5 rounded flex items-center gap-0.5">
                <Eye className="w-2.5 h-2.5" /> {faDigits(v.views)}
              </div>
            </div>
            <div className="p-2.5">
              <div className="text-sm font-medium line-clamp-1">{v.title}</div>
              <div className="flex items-center gap-3 text-[11px] text-muted-foreground mt-1">
                <span className="flex items-center gap-0.5"><Heart className="w-3 h-3" />{faDigits(v.likes)}</span>
                <span className="flex items-center gap-0.5"><MessageCircle className="w-3 h-3" />{faDigits(v.comments)}</span>
                <span className="ml-auto">{timeAgo(v.createdAt)}</span>
              </div>
            </div>
          </button>
        ))}
      </div>
      {next && (
        <Button variant="outline" size="sm" className="w-full" onClick={load}>بارگذاری بیشتر</Button>
      )}
    </div>
  )
}

function SecurityCard({ onOpen }: { onOpen: () => void }) {
  return (
    <Card className="border-border/60 shadow-soft">
      <CardContent className="p-4 sm:p-5 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <Shield className="w-5 h-5 text-primary" />
          </div>
          <div>
            <div className="text-sm font-semibold">امنیت حساب</div>
            <div className="text-[11px] text-muted-foreground">رمز عبور خود را تغییر دهید</div>
          </div>
        </div>
        <Button variant="outline" size="sm" onClick={onOpen}>تغییر رمز عبور</Button>
      </CardContent>
    </Card>
  )
}

function PasswordDialog({
  open,
  setOpen,
  toast,
}: {
  open: boolean
  setOpen: (b: boolean) => void
  toast: (m: string, k?: "default" | "success" | "error") => void
}) {
  const [current, setCurrent] = useState("")
  const [next, setNext] = useState("")
  const [confirm, setConfirm] = useState("")
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (!open) {
      setCurrent("")
      setNext("")
      setConfirm("")
    }
  }, [open])

  async function submit() {
    setSaving(true)
    try {
      await api("/api/profile/password", {
        method: "POST",
        json: { current, new: next, confirm },
      })
      toast("رمز عبور تغییر کرد", "success")
      setOpen(false)
    } catch (e: any) {
      toast(e.message || "خطا", "error")
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>تغییر رمز عبور</DialogTitle>
          <DialogDescription>رمز عبور فعلی و رمز جدید را وارد کنید.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="cur">رمز عبور فعلی</Label>
            <Input id="cur" type="password" value={current} onChange={(e) => setCurrent(e.target.value)} autoComplete="current-password" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="new">رمز عبور جدید</Label>
            <Input id="new" type="password" value={next} onChange={(e) => setNext(e.target.value)} autoComplete="new-password" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="conf">تکرار رمز جدید</Label>
            <Input id="conf" type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="new-password" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)} disabled={saving}>انصراف</Button>
          <Button onClick={submit} disabled={saving || !current || !next || !confirm} className="gap-1.5">
            {saving && <Loader2 className="w-4 h-4 animate-spin" />}
            تغییر رمز
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

function EmptyState({
  icon: Icon,
  text,
  actionLabel,
  onAction,
}: {
  icon: React.ComponentType<{ className?: string }>
  text: string
  actionLabel?: string
  onAction?: () => void
}) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-12 px-4 rounded-xl border border-dashed border-border/60">
      <div className="w-14 h-14 rounded-2xl bg-muted flex items-center justify-center mb-3">
        <Icon className="w-6 h-6 text-muted-foreground" />
      </div>
      <p className="text-sm text-muted-foreground">{text}</p>
      {actionLabel && onAction && (
        <Button variant="outline" size="sm" onClick={onAction} className="mt-4">
          {actionLabel}
        </Button>
      )}
    </div>
  )
}
