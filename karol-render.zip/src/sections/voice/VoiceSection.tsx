"use client"

import { useEffect, useMemo, useRef, useState } from "react"
import { useApp, isAppAdmin } from "@/lib/store"
import { api, faDigits, timeAgo } from "@/lib/format"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  Mic,
  MicOff,
  Video as VideoIcon,
  VideoOff,
  MonitorUp,
  PhoneOff,
  Plus,
  Users,
  Volume2,
  Crown,
  Trash2,
  Loader2,
  Headphones,
  Radio,
  AlertTriangle,
  ArrowRight,
  Wifi,
  WifiOff,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { useVoiceRoom, type VoiceMember } from "./useVoiceRoom"

interface VoiceRoom {
  id: string
  name: string
  description: string | null
  type: string
  ownerId: string
  ownerName: string
  maxUsers: number
  createdAt: string
  isOwner: boolean
  canManage: boolean
}

export default function VoiceSection() {
  const { user, toast } = useApp()
  const [rooms, setRooms] = useState<VoiceRoom[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedRoom, setSelectedRoom] = useState<VoiceRoom | null>(null)
  const [iceServers, setIceServers] = useState<RTCIceServer[]>([])
  const [maxRoomUsers, setMaxRoomUsers] = useState(8)

  const auth = useMemo(
    () => ({
      userId: user?.id || "",
      username: user?.username || "",
      displayName: user?.displayName,
      avatarUrl: user?.avatarUrl,
    }),
    [user],
  )

  const voice = useVoiceRoom({ enabled: !!user, auth, iceServers })

  async function fetchIce() {
    try {
      const d = await api<{ iceServers: RTCIceServer[]; maxRoomUsers: number }>("/api/voice/ice")
      setIceServers(d.iceServers || [])
      setMaxRoomUsers(d.maxRoomUsers || 8)
    } catch {}
  }

  async function fetchRooms() {
    try {
      const d = await api<{ rooms: VoiceRoom[] }>("/api/voice/rooms")
      setRooms(d.rooms)
    } catch {
      toast("خطا در بارگذاری روم‌ها", "error")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchIce()
    fetchRooms()
  }, [])

  useEffect(() => {
    if (voice.error) toast(voice.error, "error")
  }, [voice.error, toast])

  async function joinRoom(room: VoiceRoom) {
    if (voice.inRoom) {
      voice.leaveRoom()
      await new Promise((r) => setTimeout(r, 300))
    }
    setSelectedRoom(room)
    await voice.joinRoom(room.id)
  }

  function leaveAndBack() {
    voice.leaveRoom()
    setSelectedRoom(null)
  }

  if (selectedRoom && voice.inRoom) {
    return (
      <ActiveRoomView
        room={selectedRoom}
        voice={voice}
        onLeave={leaveAndBack}
      />
    )
  }

  return (
    <div className="h-[calc(100vh-3.5rem-4rem)] lg:h-[calc(100vh-3.5rem)] flex flex-col bg-base">
      <div className="px-4 sm:px-6 py-4 border-b border-hair">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div>
            <h1 className="text-xl font-black text-primary-c flex items-center gap-2">
              <Headphones className="w-5 h-5 text-accent" />
              ویس کارول
            </h1>
            <p className="text-xs text-muted-c mt-0.5">
              با دوستان خود گفتگو صوتی برقرار کنید — حداکثر {faDigits(maxRoomUsers)} نفر در هر روم
            </p>
          </div>
          <CreateRoomDialog onCreated={fetchRooms} />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto thin-scrollbar p-4 sm:p-6">
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-32 w-full rounded-2xl" />
            ))}
          </div>
        ) : rooms.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="w-16 h-16 rounded-2xl bg-accent-15 flex items-center justify-center mb-4">
              <Radio className="w-8 h-8 text-accent" />
            </div>
            <p className="text-primary-c font-semibold mb-1">هنوز روم ویس ساخته نشده است</p>
            <p className="text-xs text-muted-c">اولین روم ویس را ایجاد کنید و دوستانتان را دعوت کنید</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {rooms.map((r) => (
              <RoomCard key={r.id} room={r} onJoin={() => joinRoom(r)} onDeleted={fetchRooms} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

function CreateRoomDialog({ onCreated }: { onCreated: () => void }) {
  const { toast } = useApp()
  const [open, setOpen] = useState(false)
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [type, setType] = useState<"public" | "vip">("public")
  const [submitting, setSubmitting] = useState(false)

  async function submit() {
    if (!name.trim()) {
      toast("نام روم را وارد کنید", "error")
      return
    }
    setSubmitting(true)
    try {
      await api("/api/voice/rooms", { method: "POST", json: { name, description, type } })
      toast("روم ویس ساخته شد", "success")
      setOpen(false)
      setName("")
      setDescription("")
      setType("public")
      onCreated()
    } catch (e: any) {
      toast(e.message || "خطا در ساخت روم", "error")
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2 gradient-karol text-white border-0">
          <Plus className="w-4 h-4" />
          روم جدید
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>ساخت روم ویس</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="vr-name">نام روم</Label>
            <Input
              id="vr-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="مثلاً: موسیقی و گفتگو"
              maxLength={60}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="vr-desc">توضیحات (اختیاری)</Label>
            <Textarea
              id="vr-desc"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="دربارهٔ این روم..."
              maxLength={200}
              rows={3}
            />
          </div>
          <div className="space-y-2">
            <Label>نوع روم</Label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setType("public")}
                className={cn(
                  "px-3 py-2 rounded-xl border text-sm font-medium transition-colors",
                  type === "public"
                    ? "bg-accent-15 text-accent-soft border-accent/30"
                    : "border-hair text-secondary-c hover:text-primary-c",
                )}
              >
                عمومی
              </button>
              <button
                onClick={() => setType("vip")}
                className={cn(
                  "px-3 py-2 rounded-xl border text-sm font-medium transition-colors",
                  type === "vip"
                    ? "bg-gold/15 text-gold border-gold/30"
                    : "border-hair text-secondary-c hover:text-primary-c",
                )}
              >
                VIP
              </button>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>
            انصراف
          </Button>
          <Button onClick={submit} disabled={submitting} className="gradient-karol text-white border-0">
            {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : "ساخت روم"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

function RoomCard({
  room,
  onJoin,
  onDeleted,
}: {
  room: VoiceRoom
  onJoin: () => void
  onDeleted: () => void
}) {
  const { user, toast } = useApp()
  const [confirmOpen, setConfirmOpen] = useState(false)
  const [deleting, setDeleting] = useState(false)

  const isVipLocked = room.type === "vip" && !user?.isVip && !isAppAdmin(user)

  async function del() {
    setDeleting(true)
    try {
      await api(`/api/voice/rooms/${room.id}`, { method: "DELETE" })
      toast("روم حذف شد", "success")
      setConfirmOpen(false)
      onDeleted()
    } catch (e: any) {
      toast(e.message || "خطا در حذف", "error")
    } finally {
      setDeleting(false)
    }
  }

  return (
    <div className="bg-surface rounded-2xl p-4 border border-hair flex flex-col gap-3 hover:border-accent/30 transition-colors">
      <div className="flex items-start gap-3">
        <div className="w-11 h-11 rounded-xl bg-accent-15 text-accent flex items-center justify-center shrink-0">
          <Radio className="w-5 h-5" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-primary-c truncate">{room.name}</h3>
            {room.type === "vip" && (
              <Badge className="bg-gold/15 text-gold border-0 gap-1 px-1.5 py-0">
                <Crown className="w-3 h-3" /> VIP
              </Badge>
            )}
          </div>
          {room.description ? (
            <p className="text-xs text-muted-c line-clamp-2 mt-0.5">{room.description}</p>
          ) : (
            <p className="text-xs text-muted-c mt-0.5">روم ویس عمومی</p>
          )}
        </div>
      </div>

      <div className="flex items-center justify-between text-[11px] text-muted-c">
        <span className="flex items-center gap-1">
          <Users className="w-3.5 h-3.5" />
          تا {faDigits(room.maxUsers)} نفر
        </span>
        <span className="flex items-center gap-1 truncate">
          ساخته‌شده توسط {room.ownerName}
        </span>
      </div>

      <div className="flex items-center gap-2">
        {isVipLocked ? (
          <Button variant="ghost" className="flex-1 gap-2 text-muted-c" disabled>
            <Crown className="w-4 h-4" /> مخصوص VIP
          </Button>
        ) : (
          <Button onClick={onJoin} className="flex-1 gap-2 gradient-karol text-white border-0">
            <Headphones className="w-4 h-4" />
            ورود به روم
          </Button>
        )}
        {room.canManage && (
          <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
            <Button
              variant="ghost"
              size="icon"
              className="text-danger hover:text-danger hover:bg-danger-15"
              onClick={() => setConfirmOpen(true)}
            >
              <Trash2 className="w-4 h-4" />
            </Button>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>حذف روم ویس؟</AlertDialogTitle>
                <AlertDialogDescription>
                  این روم برای همیشه حذف می‌شود. این عمل قابل بازگشت نیست.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>انصراف</AlertDialogCancel>
                <AlertDialogAction
                  onClick={del}
                  disabled={deleting}
                  className="bg-danger text-white hover:bg-danger/90"
                >
                  {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : "حذف"}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}
      </div>
    </div>
  )
}

function ActiveRoomView({
  room,
  voice,
  onLeave,
}: {
  room: VoiceRoom
  voice: ReturnType<typeof useVoiceRoom>
  onLeave: () => void
}) {
  const { user } = useApp()
  const localVideoRef = useRef<HTMLVideoElement | null>(null)
  const remoteVideoRefs = useRef<Map<string, HTMLVideoElement | null>>(new Map())
  const localScreenRef = useRef<HTMLVideoElement | null>(null)
  const remoteScreenRef = useRef<HTMLVideoElement | null>(null)
  const audioRefs = useRef<Map<string, HTMLAudioElement | null>>(new Map())

  useEffect(() => {
    if (localVideoRef.current && voice.localStream) {
      localVideoRef.current.srcObject = voice.localStream
    }
    if (localScreenRef.current && voice.localStream) {
      localScreenRef.current.srcObject = voice.localStream
    }
  }, [voice.localStream])

  useEffect(() => {
    voice.remoteStreams.forEach((stream, socketId) => {
      const el = remoteVideoRefs.current.get(socketId)
      if (el && el.srcObject !== stream) {
        el.srcObject = stream
      }
      const audioEl = audioRefs.current.get(socketId)
      if (audioEl && audioEl.srcObject !== stream) {
        audioEl.srcObject = stream
      }
    })
    const sharerId = voice.screenSharingSocketId
    if (sharerId) {
      const stream = voice.remoteStreams.get(sharerId)
      if (stream && remoteScreenRef.current && remoteScreenRef.current.srcObject !== stream) {
        remoteScreenRef.current.srcObject = stream
      }
    }
  }, [voice.remoteStreams, voice.screenSharingSocketId])

  const remoteMembers: VoiceMember[] = voice.members
  const totalParticipants = 1 + remoteMembers.length

  const localSharing = voice.isScreenSharing
  const remoteSharer = remoteMembers.find((m) => m.screenSharing) || null
  const someoneSharing =
    localSharing ||
    !!remoteSharer ||
    (!!voice.screenSharingSocketId &&
      remoteMembers.some((m) => m.socketId === voice.screenSharingSocketId))

  const remoteSharerName = remoteSharer
    ? remoteSharer.displayName || remoteSharer.username
    : ""
  const remoteSharerUsername = remoteSharer?.username || ""
  const remoteSharerAvatar = remoteSharer?.avatarUrl || null
  const remoteSharerMuted = !!remoteSharer?.muted
  const sharerIsLocal = localSharing

  return (
    <div className="h-[calc(100vh-3.5rem-4rem)] lg:h-[calc(100vh-3.5rem)] flex flex-col bg-base">
      <div className="px-4 sm:px-6 py-3 border-b border-hair flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={onLeave}
            className="lg:hidden flex items-center justify-center w-9 h-9 rounded-full hover:bg-white/[0.05]"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
          <div className="min-w-0">
            <h2 className="font-bold text-primary-c truncate flex items-center gap-2">
              <Radio className="w-4 h-4 text-accent shrink-0" />
              {room.name}
            </h2>
            <div className="flex items-center gap-2 text-[11px] text-muted-c">
              <Users className="w-3.5 h-3.5" />
              <span>{faDigits(totalParticipants)} نفر آنلاین</span>
              <span className="flex items-center gap-1">
                {voice.connected ? (
                  <>
                    <Wifi className="w-3.5 h-3.5 text-success" />
                    <span className="text-success">متصل</span>
                  </>
                ) : (
                  <>
                    <WifiOff className="w-3.5 h-3.5 text-danger" />
                    <span className="text-danger">در حال اتصال...</span>
                  </>
                )}
              </span>
            </div>
          </div>
        </div>
        <Button
          onClick={onLeave}
          variant="ghost"
          className="text-danger hover:text-danger hover:bg-danger-15 gap-2"
        >
          <PhoneOff className="w-4 h-4" />
          <span className="hidden sm:inline">ترک روم</span>
        </Button>
      </div>

      {voice.joining && (
        <div className="px-4 py-3 bg-accent-15 text-accent-soft text-sm flex items-center gap-2">
          <Loader2 className="w-4 h-4 animate-spin" />
          در حال اتصال به روم ویس...
        </div>
      )}

      <div className="flex-1 min-h-0 flex flex-col lg:flex-row gap-3 p-3 sm:p-4">
        {someoneSharing ? (
          <>
            <div className="flex-1 min-h-0 flex flex-col">
              <div className="relative flex-1 min-h-[40vh] lg:min-h-0 rounded-2xl overflow-hidden border border-gold/40 bg-surface-2 shadow-glow">
                {sharerIsLocal ? (
                  <video
                    ref={localScreenRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-contain bg-black"
                  />
                ) : (
                  <video
                    ref={remoteScreenRef}
                    autoPlay
                    playsInline
                    muted={false}
                    className="w-full h-full object-contain bg-black"
                  />
                )}
                <div className="absolute inset-x-0 top-0 p-3 bg-gradient-to-b from-black/70 to-transparent flex items-center gap-2">
                  <Badge className="bg-gold/20 text-gold border-0 gap-1 px-2 py-0.5">
                    <MonitorUp className="w-3 h-3" />
                    در حال اشتراک صفحه
                  </Badge>
                  <span className="text-white text-sm font-semibold drop-shadow">
                    {sharerIsLocal ? "شما" : remoteSharerName}
                    {sharerIsLocal && <span className="text-white/70 text-xs mr-1">(شما)</span>}
                  </span>
                </div>
                <div className="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-black/70 to-transparent flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {sharerIsLocal ? (
                      user?.avatarUrl ? (
                        <img src={user.avatarUrl} alt="" className="w-7 h-7 rounded-full object-cover" />
                      ) : (
                        <div className="w-7 h-7 rounded-full bg-accent-15 text-accent flex items-center justify-center text-xs font-bold">
                          {(user?.username || "?").charAt(0).toUpperCase()}
                        </div>
                      )
                    ) : remoteSharerAvatar ? (
                      <img src={remoteSharerAvatar} alt="" className="w-7 h-7 rounded-full object-cover" />
                    ) : (
                      <div className="w-7 h-7 rounded-full bg-accent-15 text-accent flex items-center justify-center text-xs font-bold">
                        {(remoteSharerName || "?").charAt(0).toUpperCase()}
                      </div>
                    )}
                    <span className="text-white text-xs">
                      @{sharerIsLocal ? user?.username : remoteSharerUsername}
                    </span>
                  </div>
                  <div
                    className={cn(
                      "w-7 h-7 rounded-full flex items-center justify-center",
                      (sharerIsLocal ? voice.isMuted : remoteSharerMuted)
                        ? "bg-danger text-white"
                        : "bg-success/20 text-success",
                    )}
                  >
                    {(sharerIsLocal ? voice.isMuted : remoteSharerMuted) ? (
                      <MicOff className="w-4 h-4" />
                    ) : (
                      <Mic className="w-4 h-4" />
                    )}
                  </div>
                </div>
              </div>
            </div>
            <div className="lg:w-64 xl:w-72 shrink-0 flex flex-col min-h-0">
              <div className="text-[11px] text-muted-c px-1 mb-2 flex items-center justify-between">
                <span>شرکت‌کنندگان</span>
                <span>{faDigits(1 + remoteMembers.length)} نفر</span>
              </div>
              <div className="flex-1 min-h-0 overflow-y-auto thin-scrollbar flex flex-row lg:grid lg:grid-cols-2 gap-2 lg:pb-1 pb-2">
                {!sharerIsLocal && (
                  <ParticipantTile
                    name="شما"
                    username={user?.username || ""}
                    avatarUrl={user?.avatarUrl || null}
                    isLocal
                    muted={voice.isMuted}
                    camOn={voice.camOn}
                    isScreenSharing={false}
                    compact
                    videoRef={localVideoRef}
                  />
                )}
                {remoteMembers
                  .filter((m) => !remoteSharer || m.socketId !== remoteSharer.socketId)
                  .map((m) => (
                    <ParticipantTile
                      key={m.socketId}
                      name={m.displayName || m.username}
                      username={m.username}
                      avatarUrl={m.avatarUrl || null}
                      muted={!!m.muted}
                      camOn={!!m.camOn}
                      isScreenSharing={false}
                      compact
                      videoRefCallback={(el) => {
                        if (el) remoteVideoRefs.current.set(m.socketId, el)
                        else remoteVideoRefs.current.delete(m.socketId)
                      }}
                    />
                  ))}
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 overflow-y-auto thin-scrollbar">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
              <ParticipantTile
                name="شما"
                username={user?.username || ""}
                avatarUrl={user?.avatarUrl || null}
                isLocal
                muted={voice.isMuted}
                camOn={voice.camOn}
                isScreenSharing={false}
                videoRef={localVideoRef}
              />
              {remoteMembers.map((m) => (
                <ParticipantTile
                  key={m.socketId}
                  name={m.displayName || m.username}
                  username={m.username}
                  avatarUrl={m.avatarUrl || null}
                  muted={!!m.muted}
                  camOn={!!m.camOn}
                  isScreenSharing={false}
                  videoRefCallback={(el) => {
                    if (el) remoteVideoRefs.current.set(m.socketId, el)
                    else remoteVideoRefs.current.delete(m.socketId)
                  }}
                />
              ))}
            </div>

            {remoteMembers.length === 0 && !voice.joining && (
              <div className="flex flex-col items-center justify-center py-12 text-center text-muted-c">
                <Users className="w-10 h-10 mb-2 opacity-50" />
                <p className="text-sm">در انتظار ورود سایر کاربران به روم...</p>
                <p className="text-xs mt-1">لینک روم را با دوستان به اشتراک بگذارید</p>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="border-t border-hair bg-surface p-3 sm:p-4">
        <div className="max-w-2xl mx-auto flex items-center justify-center gap-2 sm:gap-3">
          <ControlButton
            active={!voice.isMuted}
            onClick={voice.toggleMute}
            activeIcon={<Mic className="w-5 h-5" />}
            inactiveIcon={<MicOff className="w-5 h-5" />}
            activeLabel="میکروفون روشن"
            inactiveLabel="بی‌صدا"
            inactiveClass="bg-danger text-white"
          />
          <ControlButton
            active={voice.camOn}
            onClick={voice.toggleCamera}
            activeIcon={<VideoIcon className="w-5 h-5" />}
            inactiveIcon={<VideoOff className="w-5 h-5" />}
            activeLabel="دوربین روشن"
            inactiveLabel="دوربین خاموش"
          />
          {voice.canScreenShare && (
            <ControlButton
              active={voice.isScreenSharing}
              onClick={voice.isScreenSharing ? voice.stopScreenShare : voice.startScreenShare}
              activeIcon={<MonitorUp className="w-5 h-5" />}
              inactiveIcon={<MonitorUp className="w-5 h-5" />}
              activeLabel="اشتراک صفحه"
              inactiveLabel="اشتراک صفحه"
              activeClass="bg-gold text-gold-foreground"
            />
          )}
          <Button
            onClick={onLeave}
            className="bg-danger hover:bg-danger/90 text-white border-0 rounded-full h-12 px-5 gap-2 font-bold"
          >
            <PhoneOff className="w-5 h-5" />
            <span className="hidden sm:inline">خروج</span>
          </Button>
        </div>
      </div>

      {voice.remoteStreams.size > 0 && (
        <div className="sr-only" aria-hidden>
          {Array.from(voice.remoteStreams.entries()).map(([socketId, stream]) => (
            <audio
              key={socketId}
              autoPlay
              ref={(el) => {
                if (el) audioRefs.current.set(socketId, el)
                else audioRefs.current.delete(socketId)
                if (el && el.srcObject !== stream) el.srcObject = stream
              }}
            />
          ))}
        </div>
      )}
    </div>
  )
}

function ControlButton({
  active,
  onClick,
  activeIcon,
  inactiveIcon,
  activeLabel,
  inactiveLabel,
  activeClass = "bg-accent text-accent-foreground",
  inactiveClass = "bg-surface-2 text-primary-c",
}: {
  active: boolean
  onClick: () => void
  activeIcon: React.ReactNode
  inactiveIcon: React.ReactNode
  activeLabel: string
  inactiveLabel: string
  activeClass?: string
  inactiveClass?: string
}) {
  return (
    <button
      onClick={onClick}
      title={active ? activeLabel : inactiveLabel}
      className={cn(
        "h-12 w-12 rounded-full flex items-center justify-center transition-all",
        active ? activeClass : inactiveClass,
        "hover:opacity-90 active:scale-95",
      )}
    >
      {active ? activeIcon : inactiveIcon}
    </button>
  )
}

function ParticipantTile({
  name,
  username,
  avatarUrl,
  isLocal = false,
  muted,
  camOn,
  isScreenSharing = false,
  compact = false,
  videoRef,
  videoRefCallback,
}: {
  name: string
  username: string
  avatarUrl: string | null
  isLocal?: boolean
  muted: boolean
  camOn: boolean
  isScreenSharing?: boolean
  compact?: boolean
  videoRef?: React.RefObject<HTMLVideoElement | null>
  videoRefCallback?: (el: HTMLVideoElement | null) => void
}) {
  const avatarChar = (name || username || "?").charAt(0).toUpperCase()
  return (
    <div
      className={cn(
        "relative bg-surface-2 rounded-2xl overflow-hidden border border-hair group",
        compact
          ? "aspect-[4/3] w-32 sm:w-full shrink-0 lg:w-auto lg:aspect-video"
          : "aspect-video",
      )}
    >
      {camOn ? (
        <video
          ref={videoRefCallback || videoRef}
          autoPlay
          playsInline
          muted={isLocal}
          className="w-full h-full object-cover"
          style={{ transform: isLocal ? "scaleX(-1)" : undefined }}
        />
      ) : (
        <div className="absolute inset-0 flex items-center justify-center">
          {avatarUrl ? (
            <img
              src={avatarUrl}
              alt={name}
              className={cn("rounded-full object-cover", compact ? "w-12 h-12" : "w-20 h-20")}
            />
          ) : (
            <div
              className={cn(
                "rounded-full bg-accent-15 text-accent flex items-center justify-center font-black",
                compact ? "w-12 h-12 text-base" : "w-20 h-20 text-2xl",
              )}
            >
              {avatarChar}
            </div>
          )}
        </div>
      )}

      <div className="absolute inset-x-0 bottom-0 p-2 sm:p-2.5 bg-gradient-to-t from-black/80 to-transparent flex items-center justify-between">
        <div className="flex items-center gap-1.5 min-w-0">
          <span className={cn("text-white font-semibold truncate", compact ? "text-xs" : "text-sm")}>
            {name}
          </span>
          {isLocal && <span className="text-[10px] text-white/60">(شما)</span>}
          {isScreenSharing && (
            <Badge className="bg-gold/20 text-gold border-0 px-1.5 py-0 text-[9px] gap-1">
              <MonitorUp className="w-2.5 h-2.5" />
              صفحه
            </Badge>
          )}
        </div>
        <div
          className={cn(
            "rounded-full flex items-center justify-center shrink-0",
            muted ? "bg-danger text-white" : "bg-success/20 text-success",
            compact ? "w-5 h-5" : "w-6 h-6",
          )}
        >
          {muted ? <MicOff className="w-3 h-3" /> : <Mic className="w-3.5 h-3.5" />}
        </div>
      </div>

      {!camOn && !muted && (
        <div className="absolute top-2 right-2 w-6 h-6 rounded-full bg-success/20 text-success flex items-center justify-center">
          <Volume2 className="w-3.5 h-3.5" />
        </div>
      )}
    </div>
  )
}
