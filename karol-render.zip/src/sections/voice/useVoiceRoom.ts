"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import { io, type Socket } from "socket.io-client"
import { getSocketUrl } from "@/lib/socket-client"

export interface VoiceMember {
  socketId: string
  userId: string
  username: string
  displayName?: string | null
  avatarUrl?: string | null
  muted?: boolean
  camOn?: boolean
  screenSharing?: boolean
}

export interface UseVoiceRoomArgs {
  enabled: boolean
  auth: {
    userId: string
    username: string
    displayName: string | null
    avatarUrl: string | null
  }
  iceServers: RTCIceServer[]
}

export interface UseVoiceRoomResult {
  socket: Socket | null
  connected: boolean
  joining: boolean
  inRoom: boolean
  error: string | null
  localStream: MediaStream | null
  remoteStreams: Map<string, MediaStream>
  members: VoiceMember[]
  isMuted: boolean
  camOn: boolean
  isScreenSharing: boolean
  canScreenShare: boolean
  screenSharingSocketId: string | null
  joinRoom: (roomId: string) => Promise<void>
  leaveRoom: () => void
  toggleMute: () => void
  toggleCamera: () => Promise<void>
  startScreenShare: () => Promise<void>
  stopScreenShare: () => Promise<void>
}

const PC_CONFIG = (iceServers: RTCIceServer[]): RTCConfiguration => ({
  iceServers: iceServers.length ? iceServers : [{ urls: "stun:stun.l.google.com:19302" }],
})

const CAM_MAX_BITRATE = 500_000
const SCREEN_MAX_BITRATE = 2_500_000

function isScreenAudioTrack(t: MediaStreamTrack): boolean {
  return /tab|system|share|display|screen/i.test(t.label) || /tab|system|share|display|screen/i.test(t.id)
}

export function useVoiceRoom({ enabled, auth, iceServers }: UseVoiceRoomArgs): UseVoiceRoomResult {
  const [socket, setSocket] = useState<Socket | null>(null)
  const [connected, setConnected] = useState(false)
  const [joining, setJoining] = useState(false)
  const [inRoom, setInRoom] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [localStream, setLocalStream] = useState<MediaStream | null>(null)
  const [remoteStreams, setRemoteStreams] = useState<Map<string, MediaStream>>(new Map())
  const [members, setMembers] = useState<VoiceMember[]>([])
  const [isMuted, setIsMuted] = useState(false)
  const [camOn, setCamOn] = useState(false)
  const [isScreenSharing, setIsScreenSharing] = useState(false)
  const [canScreenShare, setCanScreenShare] = useState(false)
  const [screenSharingSocketId, setScreenSharingSocketId] = useState<string | null>(null)

  const pcsRef = useRef<Map<string, RTCPeerConnection>>(new Map())
  const localStreamRef = useRef<MediaStream | null>(null)
  const socketRef = useRef<Socket | null>(null)
  const roomIdRef = useRef<string | null>(null)
  const camOnRef = useRef(false)
  const screenShareRef = useRef(false)
  const originalVideoTrackRef = useRef<MediaStreamTrack | null>(null)
  const membersRef = useRef<Map<string, VoiceMember>>(new Map())
  const mutedRef = useRef(false)
  const iceServersRef = useRef<RTCIceServer[]>(iceServers)
  const authRef = useRef(auth)

  useEffect(() => {
    iceServersRef.current = iceServers
  }, [iceServers])
  useEffect(() => {
    authRef.current = auth
  }, [auth])

  useEffect(() => {
    if (typeof navigator !== "undefined" && navigator.mediaDevices && "getDisplayMedia" in navigator.mediaDevices) {
      setCanScreenShare(true)
    }
  }, [])

  const updateMembersState = useCallback(() => {
    setMembers(Array.from(membersRef.current.values()))
  }, [])

  const stopLocalStream = useCallback(() => {
    const s = localStreamRef.current
    if (s) {
      s.getTracks().forEach((t) => t.stop())
    }
    localStreamRef.current = null
    setLocalStream(null)
  }, [])

  const closePeer = useCallback((socketId: string) => {
    const pc = pcsRef.current.get(socketId)
    if (pc) {
      try {
        pc.close()
      } catch {}
      pcsRef.current.delete(socketId)
    }
    setRemoteStreams((prev) => {
      if (!prev.has(socketId)) return prev
      const next = new Map(prev)
      next.delete(socketId)
      return next
    })
    membersRef.current.delete(socketId)
    updateMembersState()
  }, [updateMembersState])

  const closeAllPeers = useCallback(() => {
    for (const id of Array.from(pcsRef.current.keys())) {
      const pc = pcsRef.current.get(id)
      if (pc) {
        try {
          pc.close()
        } catch {}
      }
    }
    pcsRef.current.clear()
    setRemoteStreams(new Map())
    membersRef.current.clear()
    updateMembersState()
  }, [updateMembersState])

  const applySenderBitrate = useCallback((pc: RTCPeerConnection, screenShare: boolean) => {
    for (const sender of pc.getSenders()) {
      if (!sender.track || sender.track.kind !== "video") continue
      try {
        const params = sender.getParameters()
        if (!params.encodings || params.encodings.length === 0) {
          params.encodings = [{}]
        }
        params.encodings = params.encodings.map((enc, i) =>
          i === 0 ? { ...enc, maxBitrate: screenShare ? SCREEN_MAX_BITRATE : CAM_MAX_BITRATE } : enc,
        )
        void sender.setParameters(params).catch(() => {})
      } catch {}
    }
  }, [])

  const createPeerConnection = useCallback(
    (peerSocketId: string, isInitiator: boolean): RTCPeerConnection | null => {
      const pc = new RTCPeerConnection(PC_CONFIG(iceServersRef.current))
      const local = localStreamRef.current
      if (local) {
        local.getTracks().forEach((track) => {
          try {
            pc.addTrack(track, local)
          } catch {}
        })
        applySenderBitrate(pc, screenShareRef.current)
      }
      const remoteStream = new MediaStream()
      setRemoteStreams((prev) => {
        const next = new Map(prev)
        next.set(peerSocketId, remoteStream)
        return next
      })
      pc.ontrack = (e) => {
        const stream = e.streams[0] || remoteStream
        if (e.streams[0]) {
          setRemoteStreams((prev) => {
            const next = new Map(prev)
            next.set(peerSocketId, e.streams[0])
            return next
          })
        } else {
          remoteStream.addTrack(e.track)
          setRemoteStreams((prev) => {
            const next = new Map(prev)
            next.set(peerSocketId, remoteStream)
            return next
          })
        }
        void stream
      }
      pc.onicecandidate = (e) => {
        if (e.candidate) {
          socketRef.current?.emit("voice:signal", { to: peerSocketId, data: { candidate: e.candidate } })
        }
      }
      pc.onconnectionstatechange = () => {
        if (pc.connectionState === "failed" || pc.connectionState === "closed") {
          closePeer(peerSocketId)
        }
      }
      if (isInitiator) {
        pc.onnegotiationneeded = async () => {
          try {
            const offer = await pc.createOffer({ offerToReceiveAudio: true, offerToReceiveVideo: true })
            await pc.setLocalDescription(offer)
            socketRef.current?.emit("voice:signal", { to: peerSocketId, data: { sdp: offer } })
          } catch {}
        }
      }
      pcsRef.current.set(peerSocketId, pc)
      return pc
    },
    [closePeer, applySenderBitrate],
  )

  const handleSignal = useCallback(
    async ({ from, data }: { from: string; data: { sdp?: RTCSessionDescriptionInit; candidate?: RTCIceCandidateInit } }) => {
      let pc = pcsRef.current.get(from)
      if (!pc) {
        pc = createPeerConnection(from, false)
        if (!pc) return
      }
      try {
        if (data.sdp) {
          if (data.sdp.type === "offer") {
            await pc.setRemoteDescription(new RTCSessionDescription(data.sdp))
            const ans = await pc.createAnswer()
            await pc.setLocalDescription(ans)
            socketRef.current?.emit("voice:signal", { to: from, data: { sdp: ans } })
          } else if (data.sdp.type === "answer") {
            await pc.setRemoteDescription(new RTCSessionDescription(data.sdp))
          }
        }
        if (data.candidate) {
          try {
            await pc.addIceCandidate(new RTCIceCandidate(data.candidate))
          } catch {}
        }
      } catch {}
    },
    [createPeerConnection],
  )

  const connectSocket = useCallback(() => {
    if (socketRef.current) return socketRef.current
    const s = io(getSocketUrl(), {
      transports: ["websocket", "polling"],
      auth: {
        userId: authRef.current.userId,
        username: authRef.current.username,
        displayName: authRef.current.displayName,
        avatarUrl: authRef.current.avatarUrl,
      },
      reconnection: true,
      reconnectionAttempts: 10,
      reconnectionDelay: 1500,
      timeout: 10000,
    })
    s.on("connect", () => {
      setConnected(true)
    })
    s.on("disconnect", () => setConnected(false))
    s.on("connect_error", () => setConnected(false))
    s.on("voice:users", ({ users }: { roomId: string; users: VoiceMember[] }) => {
      membersRef.current = new Map()
      users.forEach((u) => membersRef.current.set(u.socketId, u))
      updateMembersState()
      const sharer = users.find((u) => u.screenSharing)
      setScreenSharingSocketId(sharer ? sharer.socketId : null)
      for (const u of users) {
        if (u.socketId !== s.id) createPeerConnection(u.socketId, true)
      }
    })
    s.on("voice:user-joined", ({ user }: { roomId: string; user: VoiceMember }) => {
      membersRef.current.set(user.socketId, user)
      updateMembersState()
    })
    s.on("voice:user-left", ({ socketId }: { roomId: string; socketId: string }) => {
      closePeer(socketId)
      setScreenSharingSocketId((prev) => (prev === socketId ? null : prev))
    })
    s.on("voice:signal", handleSignal)
    s.on("voice:mute-state", ({ socketId, muted }: { socketId: string; muted: boolean }) => {
      const m = membersRef.current.get(socketId)
      if (m) {
        m.muted = muted
        updateMembersState()
      }
    })
    s.on("voice:cam-state", ({ socketId, on }: { socketId: string; on: boolean }) => {
      const m = membersRef.current.get(socketId)
      if (m) {
        m.camOn = on
        if (!on) m.screenSharing = false
        updateMembersState()
      }
      setScreenSharingSocketId((prev) => {
        if (prev === socketId && !on) return null
        return prev
      })
    })
    s.on(
      "voice:screen-state",
      ({ socketId, on }: { socketId: string; on: boolean }) => {
        const m = membersRef.current.get(socketId)
        if (m) {
          m.screenSharing = on
          if (on) m.camOn = true
          updateMembersState()
        }
        setScreenSharingSocketId((prev) => {
          if (on) return socketId
          if (prev === socketId) return null
          return prev
        })
      },
    )
    socketRef.current = s
    setSocket(s)
    return s
  }, [closePeer, createPeerConnection, handleSignal, updateMembersState])

  const joinRoom = useCallback(
    async (roomId: string) => {
      if (!enabled) return
      setError(null)
      setJoining(true)
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
            channelCount: 1,
            sampleRate: 48000,
          },
          video: {
            width: { ideal: 640 },
            height: { ideal: 480 },
            frameRate: { ideal: 24, max: 30 },
          },
        })
        localStreamRef.current = stream
        setLocalStream(stream)
        const videoTrack = stream.getVideoTracks()[0] || null
        originalVideoTrackRef.current = videoTrack
        if (videoTrack) {
          videoTrack.enabled = false
        }
        camOnRef.current = false
        const s = connectSocket()
        const doJoin = () => {
          s.emit("voice:join", {
            roomId,
            user: {
              id: authRef.current.userId,
              username: authRef.current.username,
              displayName: authRef.current.displayName,
              avatarUrl: authRef.current.avatarUrl,
            },
          })
          roomIdRef.current = roomId
          setInRoom(true)
          setJoining(false)
        }
        if (s.connected) doJoin()
        else s.once("connect", doJoin)
      } catch (e: any) {
        setJoining(false)
        const name = e?.name || ""
        if (name === "NotAllowedError" || name === "SecurityError") {
          setError("دسترسی میکروفون یا دوربین رد شد. لطفاً از تنظیمات مرورگر اجازه دهید.")
        } else if (name === "NotFoundError" || name === "DevicesNotFoundError") {
          setError("میکروفون یا دوربین یافت نشد.")
        } else if (name === "NotReadableError") {
          setError("میکروفون یا دوربین توسط برنامهٔ دیگری در حال استفاده است.")
        } else {
          setError("خطا در دسترسی به میکروفون. لطفاً دوباره تلاش کنید.")
        }
        stopLocalStream()
      }
    },
    [connectSocket, enabled, stopLocalStream],
  )

  const leaveRoom = useCallback(() => {
    const s = socketRef.current
    if (roomIdRef.current && s) {
      if (screenShareRef.current) {
        try {
          s.emit("voice:screen", { on: false })
        } catch {}
      }
      s.emit("voice:leave", { roomId: roomIdRef.current })
    }
    roomIdRef.current = null
    closeAllPeers()
    stopLocalStream()
    setIsMuted(false)
    mutedRef.current = false
    setCamOn(false)
    camOnRef.current = false
    setIsScreenSharing(false)
    screenShareRef.current = false
    originalVideoTrackRef.current = null
    setScreenSharingSocketId(null)
    setInRoom(false)
  }, [closeAllPeers, stopLocalStream])

  const toggleMute = useCallback(() => {
    const stream = localStreamRef.current
    if (!stream) return
    const audio = stream.getAudioTracks()[0]
    if (!audio) return
    const next = !audio.enabled
    audio.enabled = next
    mutedRef.current = !next
    setIsMuted(!next)
    socketRef.current?.emit("voice:mute", { muted: !next })
  }, [])

  const toggleCamera = useCallback(async () => {
    const stream = localStreamRef.current
    if (!stream) return
    const video = stream.getVideoTracks()[0]
    if (!video) return
    if (screenShareRef.current) return
    const next = !video.enabled
    video.enabled = next
    camOnRef.current = next
    setCamOn(next)
    socketRef.current?.emit("voice:cam", { on: next })
    for (const pc of pcsRef.current.values()) {
      const sender = pc.getSenders().find((s) => s.track && s.track.kind === "video")
      if (sender) {
        try {
          await sender.replaceTrack(video)
        } catch {}
      }
    }
  }, [])

  const startScreenShare = useCallback(async () => {
    if (!canScreenShare) return
    const stream = localStreamRef.current
    if (!stream) return
    const video = stream.getVideoTracks()[0]
    if (!video) return
    try {
      const display = await navigator.mediaDevices.getDisplayMedia({
        video: { frameRate: { ideal: 30, max: 30 } },
        audio: true,
      })
      const displayTrack = display.getVideoTracks()[0]
      if (!displayTrack) return
      const displayAudio = display.getAudioTracks()[0] || null
      const oldTrack = originalVideoTrackRef.current
      originalVideoTrackRef.current = video
      const idx = stream.getVideoTracks().indexOf(video)
      if (idx >= 0) {
        stream.removeTrack(video)
        stream.addTrack(displayTrack)
      }
      if (displayAudio) {
        stream.addTrack(displayAudio)
      }
      video.stop()
      displayTrack.enabled = true
      camOnRef.current = true
      setCamOn(true)
      screenShareRef.current = true
      setIsScreenSharing(true)
      setScreenSharingSocketId(socketRef.current?.id || null)
      socketRef.current?.emit("voice:cam", { on: true })
      socketRef.current?.emit("voice:screen", { on: true })
      for (const pc of pcsRef.current.values()) {
        const sender = pc.getSenders().find((s) => s.track && s.track.kind === "video")
        if (sender) {
          try {
            await sender.replaceTrack(displayTrack)
            const params = sender.getParameters()
            if (!params.encodings || params.encodings.length === 0) {
              params.encodings = [{}]
            }
            params.encodings = params.encodings.map((enc, i) =>
              i === 0 ? { ...enc, maxBitrate: SCREEN_MAX_BITRATE } : enc,
            )
            await sender.setParameters(params).catch(() => {})
          } catch {}
        }
        if (displayAudio) {
          try {
            pc.addTrack(displayAudio, stream)
          } catch {}
        }
      }
      displayTrack.onended = () => {
        void stopScreenShareRef.current?.()
      }
      void oldTrack
    } catch {}
  }, [canScreenShare])

  const stopScreenShare = useCallback(async () => {
    const stream = localStreamRef.current
    if (!stream) return
    const currentVideo = stream.getVideoTracks()[0]
    if (!currentVideo) return
    try {
      const displayAudioTracks = stream.getAudioTracks().filter(isScreenAudioTrack)
      const fresh = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          frameRate: { ideal: 24, max: 30 },
        },
        audio: false,
      })
      const newTrack = fresh.getVideoTracks()[0]
      if (!newTrack) return
      const idx = stream.getVideoTracks().indexOf(currentVideo)
      if (idx >= 0) {
        stream.removeTrack(currentVideo)
        stream.addTrack(newTrack)
      }
      currentVideo.stop()
      for (const t of displayAudioTracks) {
        try {
          stream.removeTrack(t)
          t.stop()
        } catch {}
        for (const pc of pcsRef.current.values()) {
          const sender = pc.getSenders().find((s) => s.track === t)
          if (sender) {
            try {
              await pc.removeTrack(sender)
            } catch {}
          }
        }
      }
      newTrack.enabled = false
      originalVideoTrackRef.current = newTrack
      camOnRef.current = false
      setCamOn(false)
      screenShareRef.current = false
      setIsScreenSharing(false)
      setScreenSharingSocketId((prev) => (prev === socketRef.current?.id ? null : prev))
      socketRef.current?.emit("voice:cam", { on: false })
      socketRef.current?.emit("voice:screen", { on: false })
      for (const pc of pcsRef.current.values()) {
        const sender = pc.getSenders().find((s) => s.track && s.track.kind === "video")
        if (sender) {
          try {
            await sender.replaceTrack(newTrack)
            const params = sender.getParameters()
            if (!params.encodings || params.encodings.length === 0) {
              params.encodings = [{}]
            }
            params.encodings = params.encodings.map((enc, i) =>
              i === 0 ? { ...enc, maxBitrate: CAM_MAX_BITRATE } : enc,
            )
            await sender.setParameters(params).catch(() => {})
          } catch {}
        }
      }
    } catch {}
  }, [])

  const stopScreenShareRef = useRef<() => Promise<void>>()
  useEffect(() => {
    // eslint-disable-next-line react-hooks/immutability
    stopScreenShareRef.current = stopScreenShare
  }, [stopScreenShare])

  useEffect(() => {
    return () => {
      if (roomIdRef.current) {
        socketRef.current?.emit("voice:leave", { roomId: roomIdRef.current })
      }
      closeAllPeers()
      stopLocalStream()
      if (socketRef.current) {
        socketRef.current.removeAllListeners()
        socketRef.current.disconnect()
        socketRef.current = null
      }
      setSocket(null)
      setConnected(false)
      setInRoom(false)
    }
  }, [closeAllPeers, stopLocalStream])

  return {
    socket,
    connected,
    joining,
    inRoom,
    error,
    localStream,
    remoteStreams,
    members,
    isMuted,
    camOn,
    isScreenSharing,
    canScreenShare,
    screenSharingSocketId,
    joinRoom,
    leaveRoom,
    toggleMute,
    toggleCamera,
    startScreenShare,
    stopScreenShare,
  }
}
