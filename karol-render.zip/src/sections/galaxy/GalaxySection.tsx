"use client"

import { useEffect, useState, useMemo, useRef, useCallback } from "react"
import { useApp, type SectionId } from "@/lib/store"
import { api, formatNumber } from "@/lib/format"
import { Sparkles, Orbit, TrendingUp, Users, Film, Video, Music, FileText, Crown, Zap } from "lucide-react"
import { cn } from "@/lib/utils"

interface Orb {
  id: string
  type: "post" | "reel" | "video" | "music" | "user"
  refId: string
  title: string
  subtitle: string
  avatar?: string | null
  poster?: string | null
  glow: number
  metric: number
  seed: number
  href: string
}

interface GalaxyStats {
  totalOrbs: number
  posts: number
  reels: number
  videos: number
  tracks: number
  vips: number
  brightest: Orb | null
}

const TYPE_META: Record<Orb["type"], { color: string; icon: React.ComponentType<{ className?: string }>; label: string }> = {
  post: { color: "#2dd4bf", icon: FileText, label: "پست" },
  reel: { color: "#a78bfa", icon: Film, label: "ریلز" },
  video: { color: "#fbbf24", icon: Video, label: "ویدیو" },
  music: { color: "#a3e635", icon: Music, label: "موزیک" },
  user: { color: "#f472b6", icon: Crown, label: "کاربر VIP" },
}

function seededPosition(seed: number, w: number, h: number) {
  const angle = (seed * 137.5 * Math.PI) / 180
  const radius = Math.sqrt((seed % 100) / 100) * Math.min(w, h) * 0.42
  return {
    x: w / 2 + Math.cos(angle) * radius,
    y: h / 2 + Math.sin(angle) * radius,
  }
}

function Starfield({ count = 80 }: { count?: number }) {
  const stars = useMemo(
    () =>
      Array.from({ length: count }, () => ({
        x: Math.random() * 100,
        y: Math.random() * 100,
        size: Math.random() * 1.5 + 0.5,
        delay: Math.random() * 4,
        duration: Math.random() * 3 + 2,
        opacity: Math.random() * 0.6 + 0.2,
      })),
    [count],
  )
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {stars.map((s, i) => (
        <span
          key={i}
          className="absolute rounded-full bg-white"
          style={{
            left: `${s.x}%`,
            top: `${s.y}%`,
            width: `${s.size}px`,
            height: `${s.size}px`,
            opacity: s.opacity,
            animation: `karol-pulse ${s.duration}s ease-in-out ${s.delay}s infinite`,
          }}
        />
      ))}
    </div>
  )
}

function OrbNode({ orb, pos, onClick }: { orb: Orb; pos: { x: number; y: number }; onClick: () => void }) {
  const meta = TYPE_META[orb.type]
  const size = 36 + orb.glow * 44
  const [hovered, setHovered] = useState(false)
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="absolute group"
      style={{
        left: pos.x,
        top: pos.y,
        width: size,
        height: size,
        transform: "translate(-50%, -50%)",
        animation: `orb-float ${6 + (orb.seed % 5)}s ease-in-out ${(orb.seed % 7) * 0.5}s infinite`,
      }}
    >
      <div
        className="absolute inset-0 rounded-full"
        style={{
          ["--orb-color" as any]: meta.color,
          background: orb.poster
            ? `url(${orb.poster}) center/cover`
            : orb.avatar
            ? `url(${orb.avatar}) center/cover`
            : `radial-gradient(circle at 35% 35%, ${meta.color}, ${meta.color}aa 60%, ${meta.color}33)`,
          boxShadow: `0 0 ${12 + orb.glow * 20}px ${meta.color}, 0 0 ${24 + orb.glow * 36}px ${meta.color}66`,
          animation: `orb-glow ${4 + (orb.seed % 3)}s ease-in-out infinite`,
        }}
      />
      <div className="absolute inset-0 rounded-full ring-1 ring-white/20" />
      <div
        className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center border-2"
        style={{ background: "var(--bg-base)", borderColor: meta.color }}
      >
        <meta.icon className="w-2.5 h-2.5" style={{ color: meta.color }} />
      </div>
      {hovered && (
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2.5 py-1.5 rounded-lg bg-deep border border-hair shadow-glow whitespace-nowrap z-50 animate-fade-in">
          <div className="text-[11px] font-semibold text-primary-c truncate max-w-[180px]">{orb.title}</div>
          <div className="text-[10px] text-muted-c">{orb.subtitle} · {meta.label}</div>
        </div>
      )}
    </button>
  )
}

export default function GalaxySection() {
  const { setSection } = useApp()
  const [orbs, setOrbs] = useState<Orb[]>([])
  const [stats, setStats] = useState<GalaxyStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<Orb["type"] | "all">("all")
  const [dims, setDims] = useState({ w: 800, h: 600 })
  const containerRef = useRef<HTMLDivElement>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const d = await api<{ orbs: Orb[]; stats: GalaxyStats }>("/api/galaxy/orbs")
      setOrbs(d.orbs)
      setStats(d.stats)
    } catch {
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  useEffect(() => {
    function update() {
      if (containerRef.current) {
        const r = containerRef.current.getBoundingClientRect()
        setDims({ w: r.width, h: r.height })
      }
    }
    update()
    window.addEventListener("resize", update)
    return () => window.removeEventListener("resize", update)
  }, [])

  const filtered = useMemo(() => {
    const list = filter === "all" ? orbs : orbs.filter((o) => o.type === filter)
    return list
  }, [orbs, filter])

  function navigate(href: string) {
    setSection(href as SectionId)
  }

  return (
    <div className="h-[calc(100vh-3.5rem)] lg:h-[calc(100vh-3.5rem)] flex flex-col bg-base">
      <div className="px-4 pt-4 pb-3 border-b border-hair">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl gradient-aurora flex items-center justify-center shadow-glow">
              <Orbit className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-black text-gradient-aurora leading-tight">کهکشان کارول</h2>
              <p className="text-[11px] text-muted-c">کشف محتوای زنده‌ی پلتفرم در یک نگاه</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-muted-c">
            <Zap className="w-3.5 h-3.5 text-accent-soft" />
            <span>{formatNumber(orbs.length)} گره فعال</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 mt-3 overflow-x-auto no-scrollbar">
          {([
            { v: "all" as const, label: "همه", color: "#2dd4bf" },
            { v: "post" as const, label: "پست‌ها", color: "#2dd4bf" },
            { v: "reel" as const, label: "ریلز", color: "#a78bfa" },
            { v: "video" as const, label: "ویدیو", color: "#fbbf24" },
            { v: "music" as const, label: "موزیک", color: "#a3e635" },
            { v: "user" as const, label: "VIPها", color: "#f472b6" },
          ]).map((f) => {
            const active = filter === f.v
            return (
              <button
                key={f.v}
                onClick={() => setFilter(f.v)}
                className={cn(
                  "px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all flex items-center gap-1.5",
                  active ? "text-white" : "bg-surface-2 text-muted-c hover:text-primary-c",
                )}
                style={active ? { background: f.color } : {}}
              >
                <span className="w-2 h-2 rounded-full" style={{ background: f.color }} />
                {f.label}
              </button>
            )
          })}
        </div>
      </div>

      <div ref={containerRef} className="flex-1 relative overflow-hidden galaxy-bg">
        <Starfield count={70} />

        {!loading && dims.w > 0 && filtered.map((orb) => {
          const pos = seededPosition(orb.seed, dims.w, dims.h)
          return <OrbNode key={orb.id} orb={orb} pos={pos} onClick={() => navigate(orb.href)} />
        })}

        {loading && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="flex flex-col items-center gap-3">
              <div className="w-14 h-14 rounded-full gradient-aurora animate-karol-pulse shadow-glow" />
              <p className="text-xs text-muted-c">در حال نقشه‌برداری از کهکشان…</p>
            </div>
          </div>
        )}

        {!loading && filtered.length === 0 && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <Orbit className="w-12 h-12 mx-auto mb-3 text-muted-c/50" />
              <p className="text-sm text-muted-c">هنوز گره‌ای در این بخش نیست</p>
            </div>
          </div>
        )}

        <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between pointer-events-none">
          <div className="glass rounded-xl px-3 py-2 border border-hair pointer-events-auto">
            <div className="text-[10px] text-muted-c mb-1">درخشان‌ترین گره</div>
            {stats?.brightest ? (
              <button onClick={() => navigate(stats.brightest!.href)} className="flex items-center gap-2 text-left">
                <div className="w-7 h-7 rounded-full" style={{ background: TYPE_META[stats.brightest.type].color, boxShadow: `0 0 12px ${TYPE_META[stats.brightest.type].color}` }} />
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-primary-c truncate max-w-[140px]">{stats.brightest.title}</div>
                  <div className="text-[10px] text-muted-c">{stats.brightest.subtitle}</div>
                </div>
              </button>
            ) : (
              <div className="text-xs text-muted-c">—</div>
            )}
          </div>

          <div className="glass rounded-xl px-3 py-2 border border-hair hidden sm:block pointer-events-auto">
            <div className="flex items-center gap-3 text-[10px] text-muted-c">
              {stats && (
                <>
                  <span className="flex items-center gap-1"><FileText className="w-3 h-3 text-accent" /> {formatNumber(stats.posts)}</span>
                  <span className="flex items-center gap-1"><Film className="w-3 h-3" style={{ color: TYPE_META.reel.color }} /> {formatNumber(stats.reels)}</span>
                  <span className="flex items-center gap-1"><Video className="w-3 h-3" style={{ color: TYPE_META.video.color }} /> {formatNumber(stats.videos)}</span>
                  <span className="flex items-center gap-1"><Music className="w-3 h-3" style={{ color: TYPE_META.music.color }} /> {formatNumber(stats.tracks)}</span>
                  <span className="flex items-center gap-1"><Crown className="w-3 h-3" style={{ color: TYPE_META.user.color }} /> {formatNumber(stats.vips)}</span>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="px-4 py-2.5 border-t border-hair flex items-center justify-between">
        <p className="text-[10px] text-muted-c flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-aurora" />
          روی هر گره بزن تا محتوا باز شود — هرچه درخشان‌تر، محبوب‌تر
        </p>
        <button onClick={load} className="text-[10px] text-accent-soft hover:text-accent transition-colors flex items-center gap-1">
          <TrendingUp className="w-3 h-3" /> به‌روزرسانی
        </button>
      </div>
    </div>
  )
}
