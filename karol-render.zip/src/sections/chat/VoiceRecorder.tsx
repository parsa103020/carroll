"use client"

import { useEffect, useRef, useState } from "react"
import { Mic, Send, X, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { faDigits } from "@/lib/format"

function fmt(s: number) {
  const m = Math.floor(s / 60)
  const r = s % 60
  return `${faDigits(m.toString().padStart(2, "0"))}:${faDigits(r.toString().padStart(2, "0"))}`
}

export function VoiceRecorder({
  onSend,
  onCancel,
  onError,
}: {
  onSend: (url: string, duration: number) => void
  onCancel: () => void
  onError: (msg: string) => void
}) {
  const [recording, setRecording] = useState(false)
  const [seconds, setSeconds] = useState(0)
  const [uploading, setUploading] = useState(false)
  const mrRef = useRef<MediaRecorder | null>(null)
  const chunksRef = useRef<Blob[]>([])
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const startRef = useRef(0)
  const [levels, setLevels] = useState<number[]>(Array(28).fill(0.2))

  async function start() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mr = new MediaRecorder(stream)
      chunksRef.current = []
      mr.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data)
      }
      mr.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop())
        if (chunksRef.current.length === 0) return
        setUploading(true)
        const blob = new Blob(chunksRef.current, { type: "audio/webm" })
        const duration = Math.max(1, Math.round((Date.now() - startRef.current) / 1000))
        const fd = new FormData()
        fd.append("file", blob, `voice-${Date.now()}.webm`)
        try {
          const r = await fetch("/api/chat/upload-voice", { method: "POST", body: fd })
          const data = await r.json()
          if (!r.ok) throw new Error(data.error || "خطا در آپلود صوت")
          onSend(data.url, duration)
        } catch (e: any) {
          onError(e.message || "خطا در آپلود صوت")
        } finally {
          setUploading(false)
        }
      }
      mr.start(200)
      mrRef.current = mr
      startRef.current = Date.now()
      setRecording(true)
      setSeconds(0)
      timerRef.current = setInterval(() => setSeconds((s) => s + 1), 1000)
    } catch {
      onError("دسترسی به میکروفون ممکن نیست")
    }
  }

  function stop() {
    if (mrRef.current && mrRef.current.state !== "inactive") {
      mrRef.current.stop()
    }
    if (timerRef.current) clearInterval(timerRef.current)
    setRecording(false)
  }

  function cancel() {
    if (mrRef.current && mrRef.current.state !== "inactive") {
      mrRef.current.onstop = null
      mrRef.current.stream.getTracks().forEach((t) => t.stop())
      mrRef.current.stop()
    }
    if (timerRef.current) clearInterval(timerRef.current)
    setRecording(false)
    setSeconds(0)
    onCancel()
  }

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current)
    }
  }, [])

  useEffect(() => {
    if (!recording) return
    const id = setInterval(() => {
      setLevels((prev) => prev.map(() => 0.2 + Math.random() * 0.8))
    }, 120)
    return () => clearInterval(id)
  }, [recording])

  if (uploading) {
    return (
      <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-card border border-border">
        <Loader2 className="w-4 h-4 animate-spin text-primary" />
        <span className="text-xs text-muted-foreground">در حال آپلود صوت…</span>
      </div>
    )
  }

  if (!recording) {
    return (
      <Button
        type="button"
        size="icon"
        variant="ghost"
        onClick={start}
        className="h-9 w-9 rounded-full text-muted-foreground hover:text-rose-500 shrink-0"
        title="ضبط صوت"
      >
        <Mic className="w-[18px] h-[18px]" />
      </Button>
    )
  }

  return (
    <div className="flex-1 flex items-center gap-2 px-3 py-2 rounded-xl bg-rose-500/10 border border-rose-500/30">
      <button
        type="button"
        onClick={cancel}
        className="w-8 h-8 rounded-full bg-rose-500 text-white flex items-center justify-center shrink-0"
        title="لغو"
      >
        <X className="w-4 h-4" />
      </button>
      <div className="flex items-center gap-2 flex-1">
        <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
        <div className="flex items-end gap-0.5 h-5 flex-1">
          {levels.map((v, i) => (
            <span
              key={i}
              className="flex-1 rounded-full bg-rose-500/70"
              style={{ height: `${Math.max(10, v * 100)}%`, transition: "height 120ms" }}
            />
          ))}
        </div>
        <span className="text-xs tabular-nums text-rose-600 dark:text-rose-400 font-mono">
          {fmt(seconds)}
        </span>
      </div>
      <button
        type="button"
        onClick={stop}
        className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center shrink-0"
        title="ارسال"
      >
        <Send className="w-4 h-4" />
      </button>
    </div>
  )
}
