"use client"

import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import { useApp, isModerator } from "@/lib/store"
import { api, faDigits } from "@/lib/format"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  ArrowRight,
  ChevronDown,
  Crown,
  Hash,
  Image as ImageIcon,
  Lock,
  MessageCircle,
  Send,
  Users,
  Video as VideoIcon,
  Gift,
  Loader2,
  WifiOff,
  Plus,
  Megaphone,
  Forward,
  Radio,
  MicOff,
} from "lucide-react"
import { cn } from "@/lib/utils"
import type { ChatMessage, ChatRoom, ChatSettings } from "./types"
import { DEFAULT_CHAT_SETTINGS } from "./types"
import { useChatSocket, useRoomPresence } from "./useChatSocket"
import { MessageRow, type MemberActions } from "./MessageRow"
import { VoiceRecorder } from "./VoiceRecorder"
import { StickerPicker } from "./StickerPicker"

const MAX_RENDERED = 300

function RoomKindBadge({ kind }: { kind: string }) {
  if (kind === "channel") {
    return (
      <span className="inline-flex items-center gap-0.5 px-1 py-0 rounded bg-amber-500/15 text-amber-600 text-[9px] font-bold leading-tight">
        <Megaphone className="w-2.5 h-2.5" />
        کانال
      </span>
    )
  }
  if (kind === "group") {
    return (
      <span className="inline-flex items-center gap-0.5 px-1 py-0 rounded bg-emerald-500/15 text-emerald-600 text-[9px] font-bold leading-tight">
        <Users className="w-2.5 h-2.5" />
        گروه
      </span>
    )
  }
  return (
    <span className="inline-flex items-center gap-0.5 px-1 py-0 rounded bg-muted/40 text-muted-foreground text-[9px] font-bold leading-tight">
      <Hash className="w-2.5 h-2.5" />
      روم
    </span>
  )
}

function roomIcon(room: ChatRoom) {
  if (room.iconUrl) return <img src={room.iconUrl} alt="" className="w-10 h-10 rounded-xl object-cover" />
  const Icon = room.roomKind === "channel" ? Megaphone : room.roomKind === "group" ? Users : Hash
  return (
    <div className="w-10 h-10 rounded-xl bg-primary/15 text-primary flex items-center justify-center">
      <Icon className="w-5 h-5" />
    </div>
  )
}

function RoomsList({
  rooms,
  loading,
  selectedId,
  onSelect,
  onlineByRoom,
}: {
  rooms: ChatRoom[]
  loading: boolean
  selectedId: string | null
  onSelect: (r: ChatRoom) => void
  onlineByRoom: Record<string, number>
}) {
  if (loading) {
    return (
      <div className="p-3 space-y-2">
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-16 w-full rounded-xl" />
        ))}
      </div>
    )
  }
  if (rooms.length === 0) {
    return (
      <div className="p-6 text-center text-sm text-muted-foreground">
        هنوز رومی ساخته نشده است.
      </div>
    )
  }
  return (
    <div className="p-2 space-y-1 overflow-y-auto thin-scrollbar flex-1">
      {rooms.map((r) => {
        const active = r.id === selectedId
        const online = onlineByRoom[r.id] || 0
        return (
          <button
            key={r.id}
            onClick={() => onSelect(r)}
            className={cn(
              "w-full flex items-center gap-3 p-2.5 rounded-xl transition-all text-right group",
              active ? "bg-primary/10 ring-1 ring-primary/30" : "hover:bg-accent",
            )}
          >
            <div className="relative shrink-0">
              {roomIcon(r)}
              {online > 0 && (
                <span className="absolute -bottom-0.5 -left-0.5 min-w-4 h-4 px-1 rounded-full bg-emerald-500 text-white text-[9px] font-bold flex items-center justify-center border-2 border-card">
                  {faDigits(online)}
                </span>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <span className={cn("font-semibold text-sm truncate", active ? "text-primary" : "text-foreground")}>
                  {r.name}
                </span>
                <RoomKindBadge kind={r.roomKind} />
                {r.type === "vip" && (
                  <Crown className="w-3.5 h-3.5 text-gold shrink-0" />
                )}
                {!r.accessible && <Lock className="w-3 h-3 text-muted-foreground shrink-0" />}
              </div>
              <div className="text-[11px] text-muted-foreground truncate">
                {r.description || (r.type === "vip" ? "روم وی‌آی‌پی" : "روم عمومی")}
              </div>
            </div>
            <div className="text-[10px] text-muted-foreground flex items-center gap-0.5 shrink-0">
              <Users className="w-3 h-3" />
              {faDigits(r.memberCount)}
            </div>
          </button>
        )
      })}
    </div>
  )
}

function TypingDots() {
  return (
    <span className="inline-flex items-center gap-0.5">
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          className="w-1 h-1 rounded-full bg-current animate-bounce"
          style={{ animationDelay: `${i * 0.15}s` }}
        />
      ))}
    </span>
  )
}

function Composer(props: {
  settings: ChatSettings
  text: string
  setText: (v: string) => void
  onSend: () => void
  sending: boolean
  replyTo: ChatMessage | null
  onCancelReply: () => void
  onImage: (file: File) => void
  onVideo: (file: File) => void
  onGif: (file: File) => void
  onVoiceSend: (url: string, duration: number) => void
  onVoiceError: (msg: string) => void
  onStickerPick: (url: string) => void
  onTextChange: (v: string) => void
  disabled?: boolean
  channelNotice?: string | null
}) {
  const taRef = useRef<HTMLTextAreaElement>(null)
  const fileImgRef = useRef<HTMLInputElement>(null)
  const fileVidRef = useRef<HTMLInputElement>(null)
  const fileGifRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    const ta = taRef.current
    if (!ta) return
    ta.style.height = "0px"
    ta.style.height = Math.min(140, ta.scrollHeight) + "px"
  }, [props.text])

  return (
    <div className="border-t border-border/60 bg-card/40 backdrop-blur px-2 py-2 sm:px-3">
      {props.channelNotice && (
        <div className="mb-2 px-3 py-2 rounded-lg bg-amber-500/10 border border-amber-500/30 text-xs text-amber-700 dark:text-amber-400 flex items-center gap-2">
          <Megaphone className="w-3.5 h-3.5 shrink-0" />
          <span>{props.channelNotice}</span>
        </div>
      )}
      {!props.channelNotice && props.replyTo && (
        <div className="mb-2 flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-accent/60 border-r-2 border-primary text-xs">
          <div className="flex-1 min-w-0">
            <span className="font-semibold text-primary">پاسخ به:</span>{" "}
            <span className="text-muted-foreground">
              {props.replyTo.user?.displayName || props.replyTo.user?.username || props.replyTo.username}
            </span>
            {props.replyTo.content && (
              <div className="truncate opacity-80">{props.replyTo.content}</div>
            )}
          </div>
          <button
            type="button"
            onClick={props.onCancelReply}
            className="w-6 h-6 rounded-full hover:bg-background flex items-center justify-center text-muted-foreground"
          >
            ✕
          </button>
        </div>
      )}

      {props.channelNotice ? null : (
        <div className="flex items-end gap-1.5">
          {props.settings.allowImages && (
            <>
              <Button
                type="button"
                size="icon"
                variant="ghost"
                onClick={() => fileImgRef.current?.click()}
                className="h-9 w-9 rounded-full text-muted-foreground hover:text-primary shrink-0"
                title="ارسال تصویر"
              >
                <ImageIcon className="w-[18px] h-[18px]" />
              </Button>
              <input
                ref={fileImgRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0]
                  if (f) props.onImage(f)
                  e.target.value = ""
                }}
              />
            </>
          )}

        {props.settings.allowVideos && (
          <>
            <Button
              type="button"
              size="icon"
              variant="ghost"
              onClick={() => fileVidRef.current?.click()}
              className="h-9 w-9 rounded-full text-muted-foreground hover:text-primary shrink-0"
              title="ارسال ویدیو"
            >
              <VideoIcon className="w-[18px] h-[18px]" />
            </Button>
            <input
              ref={fileVidRef}
              type="file"
              accept="video/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0]
                if (f) props.onVideo(f)
                e.target.value = ""
              }}
            />
          </>
        )}

        {props.settings.allowGifs && (
          <>
            <Button
              type="button"
              size="icon"
              variant="ghost"
              onClick={() => fileGifRef.current?.click()}
              className="h-9 w-9 rounded-full text-muted-foreground hover:text-primary shrink-0"
              title="ارسال گیف"
            >
              <Gift className="w-[18px] h-[18px]" />
            </Button>
            <input
              ref={fileGifRef}
              type="file"
              accept="image/gif"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0]
                if (f) props.onGif(f)
                e.target.value = ""
              }}
            />
          </>
        )}

        {props.settings.allowStickers && <StickerPicker onPick={props.onStickerPick} />}

        {props.settings.allowVoice && (
          <VoiceRecorder onSend={props.onVoiceSend} onCancel={() => {}} onError={props.onVoiceError} />
        )}

        <div className="flex-1 min-w-0 flex items-end gap-1.5 bg-background border border-border/60 rounded-2xl px-3 py-1.5 focus-within:ring-2 focus-within:ring-primary/30 transition-shadow">
          <textarea
            ref={taRef}
            value={props.text}
            onChange={(e) => props.onTextChange(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault()
                props.onSend()
              }
            }}
            rows={1}
            placeholder="پیام بنویسید…"
            maxLength={props.settings.maxMessageLength}
            className="flex-1 resize-none bg-transparent outline-none text-sm leading-relaxed max-h-[140px] thin-scrollbar placeholder:text-muted-foreground/60 py-1"
          />
          <Button
            type="button"
            size="icon"
            onClick={props.onSend}
            disabled={props.sending || !props.text.trim()}
            className="h-8 w-8 rounded-full shrink-0"
            title="ارسال"
          >
            {props.sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </Button>
        </div>
        </div>
      )}
    </div>
  )
}

export default function ChatSection() {
  const { user, toast, setSection } = useApp()
  const [rooms, setRooms] = useState<ChatRoom[]>([])
  const [roomsLoading, setRoomsLoading] = useState(true)
  const [selectedRoom, setSelectedRoom] = useState<ChatRoom | null>(null)
  const [mobileView, setMobileView] = useState<"rooms" | "messages">("rooms")
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [nextCursor, setNextCursor] = useState<string | null>(null)
  const [hasMore, setHasMore] = useState(false)
  const [loadingMore, setLoadingMore] = useState(false)
  const [loadingMessages, setLoadingMessages] = useState(false)
  const [text, setText] = useState("")
  const [sending, setSending] = useState(false)
  const [replyTo, setReplyTo] = useState<ChatMessage | null>(null)
  const [typingUsers, setTypingUsers] = useState<Set<string>>(new Set())
  const [showNewPill, setShowNewPill] = useState(false)
  const [lightbox, setLightbox] = useState<string | null>(null)
  const [vipLocked, setVipLocked] = useState<ChatRoom | null>(null)
  const [settings, setSettings] = useState<ChatSettings>(DEFAULT_CHAT_SETTINGS)
  const [presenceByRoom, setPresenceByRoom] = useState<Record<string, number>>({})
  const [createOpen, setCreateOpen] = useState(false)
  const [createKind, setCreateKind] = useState<"room" | "channel" | "group">("group")
  const [createForm, setCreateForm] = useState({ name: "", description: "" })
  const [creating, setCreating] = useState(false)
  const [forwardMsg, setForwardMsg] = useState<ChatMessage | null>(null)
  const [forwardTarget, setForwardTarget] = useState<string | null>(null)
  const [forwarding, setForwarding] = useState(false)
  const [mutedSelf, setMutedSelf] = useState(false)
  const [memberMutedMap, setMemberMutedMap] = useState<Record<string, boolean>>({})
  const [kickTarget, setKickTarget] = useState<ChatMessage | null>(null)
  const [banTarget, setBanTarget] = useState<ChatMessage | null>(null)
  const [reportTarget, setReportTarget] = useState<ChatMessage | null>(null)
  const [modActionLoading, setModActionLoading] = useState(false)
  const [kickReason, setKickReason] = useState("")
  const [reportReason, setReportReason] = useState("spam")
  const [reportDescription, setReportDescription] = useState("")

  const scrollRef = useRef<HTMLDivElement>(null)
  const atBottomRef = useRef(true)
  const loadingMoreRef = useRef(false)
  const hasMoreRef = useRef(false)
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const isTypingRef = useRef(false)

  const { socket, connected } = useChatSocket({
    enabled: !!user,
    auth: {
      userId: user?.id || "",
      username: user?.username || "",
      displayName: user?.displayName || null,
      avatarUrl: user?.avatarUrl || null,
      isVip: user?.isVip || false,
    },
  })

  const canModerate = isModerator(user)

  const loadSettings = useCallback(async () => {
    try {
      const all = await api<Record<string, string>>("/api/settings")
      setSettings({
        maxMessageLength: parseInt(all["chat.maxMessageLength"] || "2000", 10),
        allowVoice: all["chat.allowVoice"] !== "false",
        allowStickers: all["chat.allowStickers"] !== "false",
        allowGifs: all["chat.allowGifs"] !== "false",
        allowImages: all["chat.allowImages"] !== "false",
        allowVideos: all["chat.allowVideos"] !== "false",
      })
    } catch {}
  }, [])

  const loadRooms = useCallback(async () => {
    setRoomsLoading(true)
    try {
      const d = await api<{ rooms: ChatRoom[] }>("/api/chat/rooms")
      setRooms(d.rooms || [])
    } catch (e: any) {
      toast(e.message || "خطا در بارگذاری روم‌ها", "error")
    } finally {
      setRoomsLoading(false)
    }
  }, [toast])

  useEffect(() => {
    loadSettings()
    loadRooms()
  }, [loadSettings, loadRooms])

  const scrollToBottom = useCallback((smooth = false) => {
    const el = scrollRef.current
    if (!el) return
    el.scrollTo({ top: el.scrollHeight, behavior: smooth ? "smooth" : "auto" })
    atBottomRef.current = true
    setShowNewPill(false)
  }, [])

  const loadMessages = useCallback(
    async (roomId: string, smooth = false) => {
      setLoadingMessages(true)
      setMessages([])
      setNextCursor(null)
      setHasMore(false)
      hasMoreRef.current = false
      try {
        const d = await api<{ messages: ChatMessage[]; nextCursor: string | null }>(
          `/api/chat/rooms/${roomId}/messages?limit=50`,
        )
        const list = (d.messages || []).slice().reverse()
        setMessages(list)
        setNextCursor(d.nextCursor)
        setHasMore(!!d.nextCursor)
        hasMoreRef.current = !!d.nextCursor
        requestAnimationFrame(() => scrollToBottom(smooth))
      } catch (e: any) {
        toast(e.message || "خطا در بارگذاری پیام‌ها", "error")
      } finally {
        setLoadingMessages(false)
      }
    },
    [scrollToBottom, toast],
  )

  const loadOlder = useCallback(async () => {
    if (!selectedRoom || loadingMoreRef.current || !hasMoreRef.current || !nextCursor) return
    loadingMoreRef.current = true
    setLoadingMore(true)
    const el = scrollRef.current
    const oldScrollHeight = el?.scrollHeight || 0
    const oldScrollTop = el?.scrollTop || 0
    try {
      const d = await api<{ messages: ChatMessage[]; nextCursor: string | null }>(
        `/api/chat/rooms/${selectedRoom.id}/messages?cursor=${nextCursor}&limit=50`,
      )
      const older = (d.messages || []).slice().reverse()
      setMessages((prev) => {
        const next = [...older, ...prev]
        return next.length > MAX_RENDERED ? next.slice(next.length - MAX_RENDERED) : next
      })
      setNextCursor(d.nextCursor)
      setHasMore(!!d.nextCursor)
      hasMoreRef.current = !!d.nextCursor
      requestAnimationFrame(() => {
        const el2 = scrollRef.current
        if (!el2) return
        el2.scrollTop = el2.scrollHeight - oldScrollHeight + oldScrollTop
      })
    } catch (e: any) {
      toast(e.message || "خطا در بارگذاری پیام‌ها", "error")
    } finally {
      loadingMoreRef.current = false
      setLoadingMore(false)
    }
  }, [selectedRoom, nextCursor, toast])

  const handleScroll = useCallback(() => {
    const el = scrollRef.current
    if (!el) return
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 120
    atBottomRef.current = atBottom
    if (atBottom) setShowNewPill(false)
    if (el.scrollTop < 80 && hasMoreRef.current && !loadingMoreRef.current) {
      loadOlder()
    }
  }, [loadOlder])

  const handleSelectRoom = useCallback(
    (r: ChatRoom) => {
      if (!r.accessible) {
        setVipLocked(r)
        return
      }
      setSelectedRoom(r)
      setMobileView("messages")
      setReplyTo(null)
      setText("")
      setTypingUsers(new Set())
      setMutedSelf(false)
      setMemberMutedMap({})
      loadMessages(r.id)
    },
    [loadMessages],
  )

  useEffect(() => {
    if (!user || !selectedRoom) return
    let cancelled = false
    api<{ members: Array<{ user: { id: string }; muted: boolean }> }>(
      `/api/chat/rooms/${selectedRoom.id}/members`,
    )
      .then((d) => {
        if (cancelled) return
        const map: Record<string, boolean> = {}
        let selfMuted = false
        for (const m of d.members || []) {
          map[m.user.id] = !!m.muted
          if (m.user.id === user.id) selfMuted = !!m.muted
        }
        setMemberMutedMap(map)
        setMutedSelf(selfMuted)
      })
      .catch(() => {})
    return () => {
      cancelled = true
    }
  }, [user, selectedRoom])

  useEffect(() => {
    if (!socket || !selectedRoom || !connected) return
    socket.emit("chat:join", { roomId: selectedRoom.id })
    return () => {
      socket.emit("chat:leave", { roomId: selectedRoom.id })
    }
  }, [socket, selectedRoom, connected])

  const { online, onlineCount } = useRoomPresence(socket, selectedRoom?.id || null, user?.id || null)

  useEffect(() => {
    if (!selectedRoom) return
    setPresenceByRoom((prev) => ({ ...prev, [selectedRoom.id]: online.length }))
  }, [online, selectedRoom])

  useEffect(() => {
    if (!socket || !selectedRoom) return
    const onMessage = ({ roomId, message }: { roomId: string; message: ChatMessage }) => {
      if (roomId !== selectedRoom.id) return
      setMessages((prev) => {
        if (prev.some((m) => m.id === message.id)) return prev
        const next = [...prev, message]
        return next.length > MAX_RENDERED ? next.slice(next.length - MAX_RENDERED) : next
      })
      if (atBottomRef.current) {
        requestAnimationFrame(() => scrollToBottom())
      } else {
        setShowNewPill(true)
      }
    }
    const onDelete = ({ roomId, messageId }: { roomId: string; messageId: string }) => {
      if (roomId !== selectedRoom.id) return
      setMessages((prev) =>
        prev.map((m) =>
          m.id === messageId
            ? { ...m, deletedAt: new Date().toISOString(), content: null, mediaUrl: null, mediaMeta: null }
            : m,
        ),
      )
    }
    const onTyping = ({
      roomId,
      username,
      isTyping,
    }: {
      roomId: string
      username: string
      isTyping: boolean
    }) => {
      if (roomId !== selectedRoom.id || username === user?.username) return
      setTypingUsers((prev) => {
        const next = new Set(prev)
        if (isTyping) next.add(username)
        else next.delete(username)
        return next
      })
    }
    socket.on("chat:message", onMessage)
    socket.on("chat:delete", onDelete)
    socket.on("chat:typing", onTyping)
    return () => {
      socket.off("chat:message", onMessage)
      socket.off("chat:delete", onDelete)
      socket.off("chat:typing", onTyping)
    }
  }, [socket, selectedRoom, user?.username, scrollToBottom])

  useEffect(() => {
    if (!socket || !selectedRoom || !user) return
    const onKicked = ({
      roomId,
      userId,
      reason,
    }: {
      roomId: string
      userId: string
      reason?: string | null
    }) => {
      if (roomId !== selectedRoom.id) return
      if (userId !== user.id) return
      toast(
        reason
          ? `شما از این روم اخراج شدید — ${reason}`
          : "شما از این روم اخراج شدید",
        "error",
      )
      socket.emit("chat:leave", { roomId: selectedRoom.id })
      setSelectedRoom(null)
      setMobileView("rooms")
      setMessages([])
    }
    const onMuteState = ({
      roomId,
      userId,
      muted,
    }: {
      roomId: string
      userId: string
      muted: boolean
    }) => {
      if (roomId !== selectedRoom.id) return
      setMemberMutedMap((prev) => ({ ...prev, [userId]: !!muted }))
      if (userId === user.id) {
        setMutedSelf(!!muted)
        toast(
          muted
            ? "شما در این روم میوت شده‌اید"
            : "میوت شما در این روم لغو شد",
          muted ? "error" : "success",
        )
      }
    }
    const onBanned = ({ roomId, userId }: { roomId: string; userId: string }) => {
      if (roomId !== selectedRoom.id) return
      if (userId !== user.id) return
      toast("حساب شما مسدود شد", "error")
      setSelectedRoom(null)
      setMobileView("rooms")
      setMessages([])
    }
    socket.on("chat:kicked", onKicked)
    socket.on("chat:mute-state", onMuteState)
    socket.on("chat:banned", onBanned)
    return () => {
      socket.off("chat:kicked", onKicked)
      socket.off("chat:mute-state", onMuteState)
      socket.off("chat:banned", onBanned)
    }
  }, [socket, selectedRoom, user, toast])

  const onTextChange = useCallback(
    (v: string) => {
      setText(v)
      if (!socket || !selectedRoom || !connected) return
      if (!isTypingRef.current) {
        isTypingRef.current = true
        socket.emit("chat:typing", { roomId: selectedRoom.id, username: user!.username, isTyping: true })
      }
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current)
      typingTimeoutRef.current = setTimeout(() => {
        isTypingRef.current = false
        socket.emit("chat:typing", { roomId: selectedRoom!.id, username: user!.username, isTyping: false })
      }, 2000)
    },
    [socket, selectedRoom, connected, user],
  )

  const sendMessage = useCallback(
    async (payload: {
      type: ChatMessage["type"]
      content?: string | null
      mediaUrl?: string | null
      mediaMeta?: any
    }) => {
      if (!selectedRoom || !user) return null
      const tempId = `pending-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
      const optimistic: ChatMessage = {
        id: tempId,
        roomId: selectedRoom.id,
        userId: user.id,
        username: user.username,
        content: payload.content ?? null,
        type: payload.type,
        mediaUrl: payload.mediaUrl ?? null,
        mediaMeta: payload.mediaMeta ? JSON.stringify(payload.mediaMeta) : null,
        replyToId: replyTo?.id || null,
        forwardedFromId: null,
        forwardedFromName: null,
        createdAt: new Date().toISOString(),
        deletedAt: null,
        user: {
          id: user.id,
          username: user.username,
          displayName: user.displayName,
          avatarUrl: user.avatarUrl,
          isVip: user.isVip,
          isAdmin: user.roles.includes("admin"),
        },
        pending: true,
      }
      setMessages((prev) => [...prev, optimistic])
      atBottomRef.current = true
      requestAnimationFrame(() => scrollToBottom())
      try {
        const d = await api<{ message: ChatMessage }>(
          `/api/chat/rooms/${selectedRoom.id}/messages`,
          { method: "POST", json: { ...payload, replyToId: replyTo?.id || null } },
        )
        setMessages((prev) => prev.map((m) => (m.id === tempId ? d.message : m)))
        if (socket && connected) {
          socket.emit("chat:message", { roomId: selectedRoom.id, message: d.message })
        }
        setReplyTo(null)
        return d.message
      } catch (e: any) {
        setMessages((prev) => prev.filter((m) => m.id !== tempId))
        toast(e.message || "خطا در ارسال پیام", "error")
        return null
      }
    },
    [selectedRoom, user, replyTo, socket, connected, scrollToBottom, toast],
  )

  const handleSendText = useCallback(async () => {
    const v = text.trim()
    if (!v || sending) return
    setSending(true)
    setText("")
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current)
    if (isTypingRef.current && socket && selectedRoom) {
      isTypingRef.current = false
      socket.emit("chat:typing", { roomId: selectedRoom.id, username: user!.username, isTyping: false })
    }
    await sendMessage({ type: "text", content: v })
    setSending(false)
  }, [text, sending, sendMessage, socket, selectedRoom, user])

  const uploadMedia = useCallback(
    async (file: File, category: string, type: ChatMessage["type"]) => {
      if (!selectedRoom) return
      const fd = new FormData()
      fd.append("file", file)
      fd.append("category", category)
      setSending(true)
      try {
        const r = await api<{ url: string; size: number; mime: string }>("/api/upload", {
          method: "POST",
          body: fd,
        })
        await sendMessage({ type, mediaUrl: r.url, mediaMeta: { size: r.size, mime: r.mime } })
      } catch (e: any) {
        toast(e.message || "خطا در آپلود فایل", "error")
      } finally {
        setSending(false)
      }
    },
    [selectedRoom, sendMessage, toast],
  )

  const handleVoiceSend = useCallback(
    async (url: string, duration: number) => {
      await sendMessage({ type: "voice", mediaUrl: url, mediaMeta: { duration } })
    },
    [sendMessage],
  )

  const handleStickerPick = useCallback(
    async (url: string) => {
      await sendMessage({ type: "sticker", mediaUrl: url })
    },
    [sendMessage],
  )

  const handleDelete = useCallback(
    async (msg: ChatMessage) => {
      if (!selectedRoom) return
      const prev = messages
      setMessages((cur) =>
        cur.map((m) =>
          m.id === msg.id
            ? { ...m, deletedAt: new Date().toISOString(), content: null, mediaUrl: null, mediaMeta: null }
            : m,
        ),
      )
      try {
        await api(`/api/chat/rooms/${selectedRoom.id}/messages/${msg.id}`, { method: "DELETE" })
        if (socket && connected) {
          socket.emit("chat:delete", { roomId: selectedRoom.id, messageId: msg.id })
        }
        toast("پیام حذف شد", "success")
      } catch (e: any) {
        setMessages(prev)
        toast(e.message || "خطا در حذف پیام", "error")
      }
    },
    [selectedRoom, messages, socket, connected, toast],
  )

  const handleReport = useCallback(
    (msg: ChatMessage) => {
      toast("گزارش شما ثبت شد", "success")
    },
    [toast],
  )

  const handleKick = useCallback(
    async (msg: ChatMessage, reason: string) => {
      if (!selectedRoom || !msg.user) return
      setModActionLoading(true)
      try {
        await api(`/api/chat/rooms/${selectedRoom.id}/kick`, {
          method: "POST",
          json: { userId: msg.user.id, reason: reason.trim() || null },
        })
        if (socket && connected) {
          socket.emit("chat:kick", {
            roomId: selectedRoom.id,
            userId: msg.user.id,
            reason: reason.trim() || null,
          })
        }
        toast("کاربر از روم اخراج شد", "success")
        setKickTarget(null)
        setKickReason("")
      } catch (e: any) {
        toast(e.message || "خطا در اخراج کاربر", "error")
      } finally {
        setModActionLoading(false)
      }
    },
    [selectedRoom, socket, connected, toast],
  )

  const handleMuteToggle = useCallback(
    async (msg: ChatMessage, muted: boolean) => {
      if (!selectedRoom || !msg.user) return
      setModActionLoading(true)
      try {
        await api(`/api/chat/rooms/${selectedRoom.id}/members/${msg.user.id}`, {
          method: "PATCH",
          json: { muted },
        })
        setMemberMutedMap((prev) => ({ ...prev, [msg.user!.id]: muted }))
        if (socket && connected) {
          socket.emit("chat:mute-state", {
            roomId: selectedRoom.id,
            userId: msg.user.id,
            muted,
          })
        }
        toast(muted ? "کاربر میوت شد" : "میوت کاربر لغو شد", "success")
      } catch (e: any) {
        toast(e.message || "خطا در تغییر وضعیت میوت", "error")
      } finally {
        setModActionLoading(false)
      }
    },
    [selectedRoom, socket, connected, toast],
  )

  const handleBan = useCallback(
    async (msg: ChatMessage) => {
      if (!msg.user) return
      setModActionLoading(true)
      try {
        await api(`/api/admin/users/${msg.user.id}`, {
          method: "PATCH",
          json: { banned: true, banReason: "رفتار نامناسب در چت" },
        })
        if (selectedRoom && socket && connected) {
          socket.emit("chat:ban", {
            roomId: selectedRoom.id,
            userId: msg.user.id,
          })
        }
        toast("کاربر مسدود شد", "success")
        setBanTarget(null)
      } catch (e: any) {
        toast(e.message || "خطا در مسدود کردن کاربر", "error")
      } finally {
        setModActionLoading(false)
      }
    },
    [selectedRoom, socket, connected, toast],
  )

  const handleReportUser = useCallback(
    async (msg: ChatMessage, reason: string, description: string) => {
      if (!msg.user) return
      setModActionLoading(true)
      try {
        await api(`/api/users/${msg.user.id}/report`, {
          method: "POST",
          json: { reason, description: description.trim() || null },
        })
        toast("گزارش کاربر ثبت شد", "success")
        setReportTarget(null)
        setReportReason("spam")
        setReportDescription("")
      } catch (e: any) {
        toast(e.message || "خطا در ثبت گزارش", "error")
      } finally {
        setModActionLoading(false)
      }
    },
    [toast],
  )

  const memberActions: MemberActions = useMemo(
    () => ({
      canModerate,
      isMuted: false,
      onKick: (msg) => {
        setKickTarget(msg)
        setKickReason("")
      },
      onMuteToggle: (msg, muted) => {
        void handleMuteToggle(msg, muted)
      },
      onBan: (msg) => {
        setBanTarget(msg)
      },
      onReportUser: (msg) => {
        setReportTarget(msg)
        setReportReason("spam")
        setReportDescription("")
      },
      onReportMessage: (msg) => {
        handleReport(msg)
      },
    }),
    [canModerate, handleMuteToggle, handleReport],
  )

  const handleForward = useCallback(
    async (targetRoomId: string, source: ChatMessage) => {
      setForwarding(true)
      try {
        const fwdName = source.user?.displayName || source.user?.username || source.username
        const d = await api<{ message: ChatMessage }>(
          `/api/chat/rooms/${targetRoomId}/messages`,
          {
            method: "POST",
            json: {
              type: source.type,
              content: source.content,
              mediaUrl: source.mediaUrl,
              mediaMeta: source.mediaMeta ? JSON.parse(source.mediaMeta) : null,
              forwardedFromId: source.id,
              forwardedFromName: fwdName,
            },
          },
        )
        if (socket && connected) {
          socket.emit("chat:message", { roomId: targetRoomId, message: d.message })
        }
        const targetRoom = rooms.find((r) => r.id === targetRoomId)
        toast(`به ${targetRoom?.name || "روم"} فوروارد شد`, "success")
        setForwardMsg(null)
        setForwardTarget(null)
      } catch (e: any) {
        toast(e.message || "خطا در فوروارد پیام", "error")
      } finally {
        setForwarding(false)
      }
    },
    [rooms, socket, connected, toast],
  )

  const handleCreateRoom = useCallback(async () => {
    const name = createForm.name.trim()
    if (!name) {
      toast("نام الزامی است", "error")
      return
    }
    setCreating(true)
    try {
      const d = await api<{ room: ChatRoom }>("/api/chat/rooms", {
        method: "POST",
        json: {
          name,
          description: createForm.description.trim() || null,
          type: "public",
          roomKind: createKind,
        },
      })
      setRooms((prev) => [...prev, { ...d.room }])
      toast("با موفقیت ساخته شد", "success")
      setCreateOpen(false)
      setCreateForm({ name: "", description: "" })
    } catch (e: any) {
      toast(e.message || "خطا در ساخت روم", "error")
    } finally {
      setCreating(false)
    }
  }, [createForm, createKind, toast])

  const handleJoinRoom = useCallback(
    async (roomId: string) => {
      try {
        await api(`/api/chat/rooms/${roomId}/join`, { method: "POST" })
        toast("عضو شدید", "success")
        loadRooms()
      } catch (e: any) {
        toast(e.message || "خطا در عضویت", "error")
      }
    },
    [loadRooms, toast],
  )

  const typingList = useMemo(() => Array.from(typingUsers).slice(0, 3), [typingUsers])

  const messagesById = useMemo(() => {
    const m = new Map<string, ChatMessage>()
    for (const msg of messages) m.set(msg.id, msg)
    return m
  }, [messages])

  const replyToMessage = useMemo(() => {
    if (!replyTo) return null
    return messagesById.get(replyTo.id) || replyTo
  }, [replyTo, messagesById])

  const headerOnlineCount = onlineCount
  const isVipRoom = selectedRoom?.type === "vip"

  return (
    <div className="h-[calc(100vh-3.5rem-4rem)] lg:h-[calc(100vh-3.5rem)] flex overflow-hidden bg-background">
      <aside
        className={cn(
          "w-full lg:w-80 shrink-0 border-l border-border/60 flex flex-col bg-card/30",
          mobileView === "messages" ? "hidden lg:flex" : "flex",
        )}
      >
        <div className="h-14 px-4 flex items-center gap-2 border-b border-border/60">
          <MessageCircle className="w-5 h-5 text-primary" />
          <div className="flex-1">
            <div className="font-bold text-sm">روم‌های چت</div>
            <div className="text-[10px] text-muted-foreground">{faDigits(rooms.length)} روم فعال</div>
          </div>
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8 rounded-lg"
            onClick={() => setCreateOpen(true)}
            title="ساخت گروه یا کانال"
          >
            <Plus className="w-4 h-4" />
          </Button>
          <div className={cn("w-2 h-2 rounded-full", connected ? "bg-emerald-500" : "bg-muted-foreground/40")} />
        </div>
        <RoomsList
          rooms={rooms}
          loading={roomsLoading}
          selectedId={selectedRoom?.id || null}
          onSelect={handleSelectRoom}
          onlineByRoom={presenceByRoom}
        />
      </aside>

      <section
        className={cn(
          "flex-1 min-w-0 flex flex-col bg-background",
          mobileView === "rooms" ? "hidden lg:flex" : "flex",
        )}
      >
        {selectedRoom ? (
          <>
            <header className="h-14 px-3 sm:px-4 flex items-center gap-2 border-b border-border/60 bg-card/30 backdrop-blur shrink-0">
              <Button
                variant="ghost"
                size="icon"
                className="lg:hidden h-9 w-9 shrink-0"
                onClick={() => setMobileView("rooms")}
              >
                <ArrowRight className="w-5 h-5" />
              </Button>
              <div className="relative shrink-0">
                {roomIcon(selectedRoom)}
                {headerOnlineCount > 0 && (
                  <span className="absolute -bottom-0.5 -left-0.5 w-3 h-3 rounded-full bg-emerald-500 border-2 border-card" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-sm truncate">{selectedRoom.name}</span>
                  <RoomKindBadge kind={selectedRoom.roomKind} />
                  {isVipRoom && <Crown className="w-3.5 h-3.5 text-gold shrink-0" />}
                  {selectedRoom.roomKind === "channel" && !selectedRoom.isOwner && !canModerate && (
                    <Badge variant="outline" className="text-[10px] text-muted-foreground border-border/60 gap-0.5 py-0">
                      <Radio className="w-2.5 h-2.5" />
                      فقط خواندن
                    </Badge>
                  )}
                </div>
                <div className="text-[11px] text-muted-foreground flex items-center gap-1.5">
                  {headerOnlineCount > 0 ? (
                    <>
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      {faDigits(headerOnlineCount)} نفر آنلاین
                    </>
                  ) : (
                    <span>بدون حضور آنلاین</span>
                  )}
                  <span className="opacity-50">•</span>
                  <span>{faDigits(selectedRoom.memberCount)} عضو</span>
                  {selectedRoom.roomKind === "group" && !selectedRoom.isMember && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-6 ml-2 text-[10px] py-0 px-2"
                      onClick={() => handleJoinRoom(selectedRoom.id)}
                    >
                      عضویت
                    </Button>
                  )}
                </div>
              </div>
              {!connected && (
                <Badge variant="outline" className="text-amber-500 border-amber-500/40 gap-1">
                  <WifiOff className="w-3 h-3" /> قطع
                </Badge>
              )}
            </header>

            <div
              ref={scrollRef}
              onScroll={handleScroll}
              className="flex-1 overflow-y-auto thin-scrollbar py-2 relative"
            >
              {loadingMessages ? (
                <div className="p-4 space-y-3">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <Skeleton key={i} className={cn("h-12 rounded-2xl", i % 2 === 0 ? "w-2/3 mr-auto" : "w-1/2 ml-auto")} />
                  ))}
                </div>
              ) : (
                <>
                  {hasMore && (
                    <div className="flex justify-center py-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={loadOlder}
                        disabled={loadingMore}
                        className="text-xs text-muted-foreground"
                      >
                        {loadingMore ? (
                          <>
                            <Loader2 className="w-3 h-3 animate-spin ml-1" /> در حال بارگذاری…
                          </>
                        ) : (
                          "پیام‌های قدیمی‌تر"
                        )}
                      </Button>
                    </div>
                  )}
                  {messages.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-center p-6 gap-3">
                      <div className="w-14 h-14 rounded-2xl gradient-karol flex items-center justify-center">
                        <MessageCircle className="w-7 h-7 text-primary-foreground" />
                      </div>
                      <div className="text-sm font-semibold">شروع گفتگو</div>
                      <div className="text-xs text-muted-foreground max-w-xs">
                        اولین پیام را در «{selectedRoom.name}» ارسال کنید.
                      </div>
                    </div>
                  ) : (
                    <div className="pb-2">
                      {messages.map((m) => (
                        <MessageRow
                          key={m.id}
                          msg={m}
                          isOwn={!!user && m.userId === user.id}
                          replyTo={m.replyToId ? messagesById.get(m.replyToId) || null : null}
                          canModerate={canModerate}
                          onImageClick={setLightbox}
                          onReply={setReplyTo}
                          onDelete={handleDelete}
                          onReport={handleReport}
                          onForward={(msg) => {
                            setForwardMsg(msg)
                            setForwardTarget(null)
                          }}
                          memberActions={
                            m.user && m.user.id !== user?.id
                              ? {
                                  ...memberActions,
                                  isMuted: !!memberMutedMap[m.user.id],
                                }
                              : undefined
                          }
                        />
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>

            {typingList.length > 0 && (
              <div className="px-4 py-1.5 text-[11px] text-muted-foreground flex items-center gap-1.5 border-t border-border/40 bg-card/20">
                <TypingDots />
                <span>
                  {typingList.join("، ")} در حال نوشتن…
                </span>
              </div>
            )}

            {showNewPill && (
              <button
                onClick={() => scrollToBottom(true)}
                className="absolute left-1/2 -translate-x-1/2 bottom-32 z-10 px-3 py-1.5 rounded-full bg-primary text-primary-foreground text-xs font-medium shadow-soft flex items-center gap-1 animate-in fade-in slide-in-from-bottom-2"
              >
                <ChevronDown className="w-3 h-3" />
                پیام جدید
              </button>
            )}

            {mutedSelf && (
              <div className="px-3 py-2 bg-warning-15 border-t border-hair flex items-center gap-2 text-warning text-xs">
                <MicOff className="w-3.5 h-3.5 shrink-0" />
                <span>شما در این روم میوت شده‌اید — نمی‌توانید پیام ارسال کنید.</span>
              </div>
            )}

            <Composer
              settings={settings}
              text={text}
              setText={setText}
              onTextChange={onTextChange}
              onSend={handleSendText}
              sending={sending}
              replyTo={replyToMessage}
              onCancelReply={() => setReplyTo(null)}
              onImage={(f) => uploadMedia(f, "chatImage", "image")}
              onVideo={(f) => uploadMedia(f, "chatVideo", "video")}
              onGif={(f) => uploadMedia(f, "chatGif", "gif")}
              onVoiceSend={handleVoiceSend}
              onVoiceError={(m) => toast(m, "error")}
              onStickerPick={handleStickerPick}
              disabled={
                mutedSelf ||
                (selectedRoom.roomKind === "channel" &&
                  !selectedRoom.isOwner &&
                  !canModerate)
              }
              channelNotice={
                selectedRoom.roomKind === "channel" &&
                !selectedRoom.isOwner &&
                !canModerate
                  ? "این یک کانال است — فقط سازنده پیام می‌فرستد"
                  : null
              }
            />
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-8 gap-3">
            <div className="w-16 h-16 rounded-2xl gradient-karol flex items-center justify-center">
              <MessageCircle className="w-8 h-8 text-primary-foreground" />
            </div>
            <div className="text-base font-bold text-gradient-karol">به کارول چت خوش آمدید</div>
            <p className="text-xs text-muted-foreground max-w-xs">
              یک روم را از لیست انتخاب کنید تا گفتگو را آغاز کنید.
            </p>
          </div>
        )}
      </section>

      <Dialog open={!!vipLocked} onOpenChange={(o) => !o && setVipLocked(null)}>
        <DialogContent className="max-w-sm">
          <div className="flex flex-col items-center text-center gap-3 py-2">
            <div className="w-14 h-14 rounded-2xl gradient-gold flex items-center justify-center">
              <Crown className="w-7 h-7 text-gold-foreground" />
            </div>
            <div className="font-bold text-base">دسترسی محدود به اعضای VIP</div>
            <p className="text-sm text-muted-foreground">
              برای ورود به روم «{vipLocked?.name}» لازم است عضو وی‌آی‌پی کارول باشید.
            </p>
            <div className="flex gap-2 w-full">
              <Button variant="outline" className="flex-1" onClick={() => setVipLocked(null)}>
                بعداً
              </Button>
              <Button
                className="flex-1 bg-gold text-gold-foreground hover:bg-gold/90"
                onClick={() => {
                  setVipLocked(null)
                  setSection("vip")
                }}
              >
                <Crown className="w-4 h-4 ml-1" />
                عضویت VIP
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={!!lightbox} onOpenChange={(o) => !o && setLightbox(null)}>
        <DialogContent className="max-w-3xl p-0 overflow-hidden bg-black/95 border-none">
          {lightbox && (
            <img src={lightbox} alt="" className="w-full max-h-[85vh] object-contain" />
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={createOpen} onOpenChange={(o) => setCreateOpen(o)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>ساخت روم / گروه / کانال</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="grid grid-cols-3 gap-2">
              {([
                { id: "room", label: "روم", icon: Hash, hint: "عمومی برای همه" },
                { id: "group", label: "گروه", icon: Users, hint: "با عضویت کاربران" },
                { id: "channel", label: "کانال", icon: Megaphone, hint: "فقط سازنده پیام می‌دهد" },
              ] as const).map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setCreateKind(opt.id)}
                  className={cn(
                    "flex flex-col items-center gap-1 p-2.5 rounded-xl border-2 transition-all",
                    createKind === opt.id
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border/60 hover:bg-accent text-muted-foreground",
                  )}
                >
                  <opt.icon className="w-5 h-5" />
                  <span className="text-xs font-semibold">{opt.label}</span>
                </button>
              ))}
            </div>
            {createKind === "room" && !canModerate && (
              <div className="text-[11px] text-amber-600 dark:text-amber-400 bg-amber-500/10 border border-amber-500/30 rounded-lg px-2.5 py-1.5">
                ساخت روم عمومی فقط برای مدیران ممکن است.
              </div>
            )}
            <div className="space-y-1.5">
              <Label htmlFor="room-name">نام</Label>
              <Input
                id="room-name"
                value={createForm.name}
                onChange={(e) => setCreateForm((f) => ({ ...f, name: e.target.value }))}
                placeholder="مثلاً گروه دوستان"
                maxLength={50}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="room-desc">توضیحات (اختیاری)</Label>
              <Textarea
                id="room-desc"
                value={createForm.description}
                onChange={(e) => setCreateForm((f) => ({ ...f, description: e.target.value }))}
                placeholder="درباره این روم…"
                maxLength={200}
                rows={2}
              />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setCreateOpen(false)} disabled={creating}>
              انصراف
            </Button>
            <Button
              onClick={handleCreateRoom}
              disabled={creating || (createKind === "room" && !canModerate)}
              className="gradient-karol"
            >
              {creating ? <Loader2 className="w-4 h-4 animate-spin ml-1" /> : <Plus className="w-4 h-4 ml-1" />}
              ساخت
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!forwardMsg} onOpenChange={(o) => !o && setForwardMsg(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Forward className="w-4 h-4" />
              فوروارد پیام
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-2">
            <div className="text-xs text-muted-foreground">
              پیام را به کدام روم/گروه/کانال فوروارد کنید؟
            </div>
            {forwardMsg && (
              <div className="px-3 py-2 rounded-lg bg-muted/40 border border-border/60 text-xs">
                <div className="font-semibold mb-0.5">
                  {forwardMsg.user?.displayName || forwardMsg.user?.username || forwardMsg.username}
                </div>
                <div className="text-muted-foreground truncate">
                  {forwardMsg.type === "text"
                    ? forwardMsg.content
                    : forwardMsg.type === "sticker"
                      ? "استیکر"
                      : forwardMsg.type === "image"
                        ? "تصویر"
                        : forwardMsg.type === "video"
                          ? "ویدیو"
                          : forwardMsg.type === "voice"
                            ? "پیام صوتی"
                            : forwardMsg.type === "gif"
                              ? "گیف"
                              : ""}
                </div>
              </div>
            )}
            <div className="max-h-64 overflow-y-auto thin-scrollbar space-y-1">
              {rooms.length === 0 && (
                <div className="text-center text-xs text-muted-foreground py-6">رومی موجود نیست</div>
              )}
              {rooms.map((r) => (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => setForwardTarget(r.id)}
                  className={cn(
                    "w-full flex items-center gap-2 p-2 rounded-lg border transition-all text-right",
                    forwardTarget === r.id
                      ? "border-primary bg-primary/10"
                      : "border-border/60 hover:bg-accent",
                  )}
                >
                  <div className="w-8 h-8 rounded-lg bg-primary/15 text-primary flex items-center justify-center shrink-0">
                    {r.roomKind === "channel" ? (
                      <Megaphone className="w-4 h-4" />
                    ) : r.roomKind === "group" ? (
                      <Users className="w-4 h-4" />
                    ) : (
                      <Hash className="w-4 h-4" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold truncate">{r.name}</div>
                    <div className="text-[10px] text-muted-foreground">
                      {r.roomKind === "channel" ? "کانال" : r.roomKind === "group" ? "گروه" : "روم"} •{" "}
                      {faDigits(r.memberCount)} عضو
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setForwardMsg(null)} disabled={forwarding}>
              انصراف
            </Button>
            <Button
              disabled={!forwardTarget || forwarding}
              onClick={() => {
                if (forwardTarget && forwardMsg) {
                  handleForward(forwardTarget, forwardMsg)
                }
              }}
              className="gradient-karol"
            >
              {forwarding ? <Loader2 className="w-4 h-4 animate-spin ml-1" /> : <Forward className="w-4 h-4 ml-1" />}
              فوروارد
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!kickTarget} onOpenChange={(o) => !o && setKickTarget(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>اخراج کاربر از روم</DialogTitle>
            <DialogDescription>
              {kickTarget?.user?.displayName || kickTarget?.user?.username} از روم «{selectedRoom?.name}» اخراج می‌شود.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5">
              <Label htmlFor="kick-reason">دلیل (اختیاری)</Label>
              <Textarea
                id="kick-reason"
                value={kickReason}
                onChange={(e) => setKickReason(e.target.value)}
                placeholder="مثلاً: رفتار نامناسب"
                maxLength={300}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setKickTarget(null)} disabled={modActionLoading}>
              انصراف
            </Button>
            <Button
              className="bg-danger text-white hover:bg-danger/90"
              onClick={() => kickTarget && handleKick(kickTarget, kickReason)}
              disabled={modActionLoading}
            >
              {modActionLoading ? <Loader2 className="w-4 h-4 animate-spin ml-1" /> : null}
              اخراج
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!banTarget} onOpenChange={(o) => !o && setBanTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>مسدود کردن کاربر</AlertDialogTitle>
            <AlertDialogDescription>
              {banTarget?.user?.displayName || banTarget?.user?.username} از کل پلتفرم مسدود می‌شود و تمام نشست‌های او منقضی می‌گردد. این عمل با دلیل «رفتار نامناسب در چت» ثبت می‌شود.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={modActionLoading}>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => banTarget && handleBan(banTarget)}
              disabled={modActionLoading}
              className="bg-danger text-white hover:bg-danger/90"
            >
              {modActionLoading ? <Loader2 className="w-4 h-4 animate-spin ml-1" /> : null}
              مسدود کردن
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={!!reportTarget} onOpenChange={(o) => !o && setReportTarget(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>گزارش کاربر</DialogTitle>
            <DialogDescription>
              {reportTarget?.user?.displayName || reportTarget?.user?.username} را به تیم رسیدگی گزارش دهید.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5">
              <Label>دلیل گزارش</Label>
              <Select value={reportReason} onValueChange={setReportReason}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="spam">اسپم</SelectItem>
                  <SelectItem value="insult">توهین</SelectItem>
                  <SelectItem value="inappropriate">محتوای نامناسب</SelectItem>
                  <SelectItem value="fraud">کلاهبرداری</SelectItem>
                  <SelectItem value="other">دیگر</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="report-desc">توضیحات (اختیاری)</Label>
              <Textarea
                id="report-desc"
                value={reportDescription}
                onChange={(e) => setReportDescription(e.target.value)}
                placeholder="جزئیات بیشتر..."
                maxLength={1000}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setReportTarget(null)} disabled={modActionLoading}>
              انصراف
            </Button>
            <Button
              className="gradient-karol text-white border-0"
              onClick={() =>
                reportTarget &&
                handleReportUser(reportTarget, reportReason, reportDescription)
              }
              disabled={modActionLoading}
            >
              {modActionLoading ? <Loader2 className="w-4 h-4 animate-spin ml-1" /> : null}
              ثبت گزارش
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
