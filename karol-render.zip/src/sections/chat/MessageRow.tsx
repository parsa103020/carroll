"use client"

import { memo, useRef, useState } from "react"
import {
  Crown,
  Flag,
  Play,
  Pause,
  Trash2,
  FileWarning,
  MoreVertical,
  UserX,
  MicOff,
  Ban,
  Flag as UserFlag,
  Reply,
  Forward,
} from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { cn } from "@/lib/utils"
import { faDigits, formatTime } from "@/lib/format"
import type { ChatMessage } from "./types"
import { UserAvatar } from "@/components/karol/UserAvatar"
import { UserName } from "@/components/karol/UserName"

function parseMeta(m: string | null): any {
  if (!m) return null
  try {
    return JSON.parse(m)
  } catch {
    return null
  }
}

function NameTag({ msg, isOwn }: { msg: ChatMessage; isOwn: boolean }) {
  if (!msg.user) return <span className="text-xs font-semibold opacity-70">{msg.username}</span>
  return (
    <span className={cn("text-xs font-semibold flex items-center gap-1", isOwn ? "" : "text-primary")}>
      <UserName
        user={{
          displayName: msg.user.displayName,
          username: msg.user.username,
          isVip: msg.user.isVip,
          profileEffect: (msg.user as any).profileEffect,
          nameColor: (msg.user as any).nameColor,
        }}
        showCrown={false}
      />
      {msg.user.isVip && <Crown className="w-3 h-3 text-gold" />}
      {msg.user.isAdmin && (
        <span className="px-1 rounded bg-gold/20 text-gold text-[9px] leading-tight font-bold">مدیر</span>
      )}
    </span>
  )
}

function Avatar_({ msg }: { msg: ChatMessage }) {
  return (
    <UserAvatar
      user={{
        avatarUrl: msg.user?.avatarUrl || null,
        animatedAvatarUrl: (msg.user as any)?.animatedAvatarUrl || null,
        isVip: msg.user?.isVip,
        profileEffect: (msg.user as any)?.profileEffect,
        displayName: msg.user?.displayName || null,
        username: msg.user?.username || msg.username,
        nameColor: (msg.user as any)?.nameColor,
      }}
      size="xs"
    />
  )
}

const VoicePlayer = memo(function VoicePlayer({
  url,
  meta,
  isOwn,
}: {
  url: string
  meta: any
  isOwn: boolean
}) {
  const [playing, setPlaying] = useState(false)
  const [progress, setProgress] = useState(0)
  const [duration, setDuration] = useState(meta?.duration || 0)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  function toggle() {
    const el = audioRef.current
    if (!el) {
      const a = new Audio(url)
      audioRef.current = a
      a.addEventListener("timeupdate", () => setProgress(a.duration ? a.currentTime / a.duration : 0))
      a.addEventListener("loadedmetadata", () => setDuration(a.duration))
      a.addEventListener("ended", () => {
        setPlaying(false)
        setProgress(0)
      })
      a.play()
      setPlaying(true)
      return
    }
    if (playing) {
      el.pause()
      setPlaying(false)
    } else {
      el.play()
      setPlaying(true)
    }
  }

  const bars = 24
  const filled = Math.round(progress * bars)
  const total = duration || meta?.duration || 0
  const mm = Math.floor(total / 60)
  const ss = Math.floor(total % 60)
  const label = total ? `${faDigits(mm.toString().padStart(1, "0"))}:${faDigits(ss.toString().padStart(2, "0"))}` : "۰:۰۰"

  return (
    <div
      className={cn(
        "flex items-center gap-2 px-2 py-1.5 rounded-xl",
        isOwn ? "bg-primary-foreground/10" : "bg-background/60",
      )}
    >
      <button
        type="button"
        onClick={toggle}
        className={cn(
          "w-9 h-9 rounded-full flex items-center justify-center shrink-0",
          isOwn ? "bg-primary-foreground text-primary" : "bg-primary text-primary-foreground",
        )}
      >
        {playing ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 mr-0.5" />}
      </button>
      <div className="flex items-end gap-0.5 h-6 w-28">
        {Array.from({ length: bars }).map((_, i) => (
          <span
            key={i}
            className={cn("flex-1 rounded-full", isOwn ? "bg-primary-foreground/60" : "bg-foreground/40", i < filled && (isOwn ? "bg-primary-foreground" : "bg-primary"))}
            style={{ height: `${20 + (Math.sin(i * 1.7) + 1) * 30}%` }}
          />
        ))}
      </div>
      <span className={cn("text-[11px] tabular-nums font-mono", isOwn ? "text-primary-foreground/80" : "text-muted-foreground")}>
        {label}
      </span>
    </div>
  )
})

export interface MemberActions {
  canModerate: boolean
  isMuted: boolean
  onKick: (msg: ChatMessage) => void
  onMuteToggle: (msg: ChatMessage, muted: boolean) => void
  onBan: (msg: ChatMessage) => void
  onReportUser: (msg: ChatMessage) => void
  onReportMessage: (msg: ChatMessage) => void
}

interface RowProps {
  msg: ChatMessage
  isOwn: boolean
  replyTo?: ChatMessage | null
  canModerate: boolean
  onImageClick: (url: string) => void
  onReply: (msg: ChatMessage) => void
  onDelete: (msg: ChatMessage) => void
  onReport: (msg: ChatMessage) => void
  onForward?: (msg: ChatMessage) => void
  memberActions?: MemberActions
  highlight?: boolean
}

function RowImpl({
  msg,
  isOwn,
  replyTo,
  canModerate,
  onImageClick,
  onReply,
  onDelete,
  onReport,
  onForward,
  memberActions,
  highlight,
}: RowProps) {
  const [hovered, setHovered] = useState(false)
  const meta = parseMeta(msg.mediaMeta)

  if (msg.deletedAt) {
    return (
      <div className={cn("flex gap-2 px-3 py-1.5 group", isOwn ? "flex-row-reverse" : "flex-row")}>
        <div className="w-8 shrink-0" />
        <div className={cn("max-w-[78%] sm:max-w-[68%]")}>
          <div className="px-3 py-2 rounded-2xl bg-muted/50 text-muted-foreground italic text-xs flex items-center gap-2">
            <FileWarning className="w-3.5 h-3.5" />
            این پیام حذف شد
          </div>
        </div>
      </div>
    )
  }

  const isSticker = msg.type === "sticker"
  const bubbleClass = cn(
    "px-3 py-2 text-sm leading-relaxed break-words whitespace-pre-wrap shadow-soft transition-colors",
    isSticker ? "" : "rounded-2xl",
    isOwn ? "bg-primary text-primary-foreground rounded-bl-md" : "bg-card text-card-foreground border border-border/60 rounded-br-md",
    highlight && "ring-2 ring-gold/60",
  )

  const canShowMemberMenu = !!memberActions && !isOwn && !!msg.user
  const canModerateThis = canShowMemberMenu && memberActions!.canModerate

  return (
    <div
      className={cn("flex gap-2 px-3 py-1 group", isOwn ? "flex-row-reverse" : "flex-row")}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {!isOwn && !isSticker && <Avatar_ msg={msg} />}
      {(isOwn || isSticker) && <div className="w-8 shrink-0" />}

      <div className={cn("flex flex-col max-w-[82%] sm:max-w-[72%]", isOwn ? "items-end" : "items-start")}>
        {!isOwn && !isSticker && (
          <div className="px-1 mb-0.5">
            <NameTag msg={msg} isOwn={isOwn} />
          </div>
        )}

        {replyTo && !replyTo.deletedAt && (
          <div
            className={cn(
              "mx-1 mb-1 px-2.5 py-1 rounded-lg text-xs border-r-2 truncate max-w-full",
              isOwn ? "bg-primary-foreground/15 border-primary-foreground/60" : "bg-background/60 border-primary",
            )}
          >
            <div className={cn("font-semibold mb-0.5", isOwn ? "text-primary-foreground/90" : "text-primary")}>
              {replyTo.user?.displayName || replyTo.user?.username || replyTo.username}
            </div>
            <div className={cn("truncate opacity-80", isOwn ? "text-primary-foreground/80" : "text-muted-foreground")}>
              {replyTo.type === "text" ? replyTo.content || "" : replyTo.type === "sticker" ? "استیکر" : replyTo.type === "voice" ? "پیام صوتی" : replyTo.type === "image" ? "تصویر" : replyTo.type === "video" ? "ویدیو" : replyTo.type === "gif" ? "گیف" : ""}
            </div>
          </div>
        )}

        <div className="relative">
          <div className={bubbleClass}>
            {msg.type === "text" && <span>{msg.content}</span>}

            {(msg.type === "image" || msg.type === "gif") && msg.mediaUrl && (
              <button
                type="button"
                onClick={() => onImageClick(msg.mediaUrl!)}
                className="block rounded-xl overflow-hidden -m-1"
              >
                <img
                  src={msg.mediaUrl}
                  alt={msg.type === "gif" ? "گیف" : "تصویر"}
                  className="max-w-[240px] max-h-[280px] object-cover"
                  loading="lazy"
                />
              </button>
            )}

            {msg.type === "video" && msg.mediaUrl && (
              <video
                src={msg.mediaUrl}
                controls
                className="max-w-[280px] max-h-[300px] rounded-xl -m-1"
                preload="metadata"
              />
            )}

            {msg.type === "voice" && msg.mediaUrl && (
              <VoicePlayer url={msg.mediaUrl} meta={meta} isOwn={isOwn} />
            )}

            {msg.type === "sticker" && msg.mediaUrl && (
              <img
                src={msg.mediaUrl}
                alt="استیکر"
                className="w-32 h-32 object-contain"
                loading="lazy"
              />
            )}
          </div>

          {hovered && (
            <div
              className={cn(
                "absolute top-0 flex items-center gap-0.5 bg-card/95 border border-border/60 rounded-lg shadow-soft backdrop-blur px-1 py-0.5 z-10",
                isOwn ? "left-0 -translate-x-full ml-1" : "right-0 translate-x-full mr-1",
              )}
            >
              <button
                type="button"
                onClick={() => onReply(msg)}
                className="px-1.5 py-1 text-[11px] text-muted-foreground hover:text-primary rounded flex items-center gap-1"
                title="پاسخ"
              >
                <Reply className="w-3 h-3" />
              </button>
              {!isOwn && (
                <button
                  type="button"
                  onClick={() => onReport(msg)}
                  className="px-1.5 py-1 text-[11px] text-muted-foreground hover:text-rose-500 rounded"
                  title="گزارش پیام"
                >
                  <Flag className="w-3 h-3" />
                </button>
              )}
              {(isOwn || canModerate) && (
                <button
                  type="button"
                  onClick={() => onDelete(msg)}
                  className="px-1.5 py-1 text-[11px] text-muted-foreground hover:text-rose-500 rounded"
                  title="حذف"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              )}
              {onForward && (
                <button
                  type="button"
                  onClick={() => onForward(msg)}
                  className="px-1.5 py-1 text-[11px] text-muted-foreground hover:text-primary rounded flex items-center gap-1"
                  title="فوروارد"
                >
                  <Forward className="w-3 h-3" />
                </button>
              )}
              {canShowMemberMenu && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button
                      type="button"
                      className="px-1.5 py-1 text-[11px] text-muted-foreground hover:text-primary rounded"
                      title="عملیات کاربر"
                    >
                      <MoreVertical className="w-3 h-3" />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="start" className="min-w-[10rem]">
                    <DropdownMenuItem
                      onClick={() => memberActions!.onReportUser(msg)}
                      className="text-xs gap-2"
                    >
                      <UserFlag className="w-3.5 h-3.5 text-amber-500" />
                      گزارش کاربر
                    </DropdownMenuItem>
                    {canModerateThis && (
                      <>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          onClick={() => memberActions!.onKick(msg)}
                          className="text-xs gap-2 text-rose-500 focus:text-rose-500"
                        >
                          <UserX className="w-3.5 h-3.5" />
                          اخراج از روم
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => memberActions!.onMuteToggle(msg, !memberActions!.isMuted)}
                          className="text-xs gap-2"
                        >
                          <MicOff className="w-3.5 h-3.5" />
                          {memberActions!.isMuted ? "رفع بی‌صددا" : "بی‌صدا کردن"}
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => memberActions!.onBan(msg)}
                          className="text-xs gap-2 text-rose-500 focus:text-rose-500"
                        >
                          <Ban className="w-3.5 h-3.5" />
                          مسدود کردن کاربر
                        </DropdownMenuItem>
                      </>
                    )}
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>
          )}

          <div className={cn("text-[10px] mt-0.5 px-1 opacity-60 tabular-nums", isOwn ? "text-left" : "text-right")}>
            {formatTime(msg.createdAt)}
            {msg.pending && " • در حال ارسال…"}
          </div>
        </div>
      </div>
    </div>
  )
}

export const MessageRow = memo(RowImpl)
