"use client"

import { useEffect, useState } from "react"
import { io, type Socket } from "socket.io-client"
import { getSocketUrl } from "@/lib/socket-client"
import type { PresenceUser } from "./types"

interface UseChatSocketArgs {
  enabled: boolean
  auth: { userId: string; username: string; displayName: string | null; avatarUrl: string | null; isVip: boolean }
}

export function useChatSocket({ enabled, auth }: UseChatSocketArgs) {
  const [socket, setSocket] = useState<Socket | null>(null)
  const [connected, setConnected] = useState(false)

  useEffect(() => {
    if (!enabled || !auth.userId) return
    const s = io(getSocketUrl(), {
      transports: ["websocket", "polling"],
      auth,
      reconnection: true,
      reconnectionAttempts: 20,
      reconnectionDelay: 1200,
      timeout: 10000,
    })
    const onConn = () => {
      setSocket(s)
      setConnected(true)
    }
    const onDisc = () => setConnected(false)
    s.on("connect", onConn)
    s.on("disconnect", onDisc)
    s.on("connect_error", onDisc)
    return () => {
      s.off("connect", onConn)
      s.off("disconnect", onDisc)
      s.off("connect_error", onDisc)
      s.removeAllListeners()
      s.disconnect()
      setSocket(null)
      setConnected(false)
    }
  }, [enabled, auth.userId, auth.username, auth.displayName, auth.avatarUrl, auth.isVip])

  return { socket, connected }
}

export function useRoomPresence(
  socket: Socket | null,
  roomId: string | null,
  currentUserId: string | null,
) {
  const [online, setOnline] = useState<PresenceUser[]>([])
  useEffect(() => {
    if (!socket || !roomId) return
    const onPresence = (data: { roomId: string; users: PresenceUser[] }) => {
      if (data.roomId === roomId) setOnline(data.users)
    }
    socket.on("chat:presence", onPresence)
    return () => {
      socket.off("chat:presence", onPresence)
    }
  }, [socket, roomId])

  const onlineCount = online.filter((u) => u.userId !== currentUserId).length
  const isOnline = (userId: string) => online.some((u) => u.userId === userId)
  return { online, onlineCount, isOnline }
}
