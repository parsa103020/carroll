"use client"

import { useEffect, useMemo, useRef, useState } from "react"
import {
  Sticker as StickerIcon,
  Search,
  Plus,
  Loader2,
  Upload,
  Trash2,
  Sparkles,
  Image as ImageIcon,
} from "lucide-react"
import { api } from "@/lib/format"
import { useApp } from "@/lib/store"
import { Skeleton } from "@/components/ui/skeleton"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { cn } from "@/lib/utils"
import type { Sticker, StickerPack } from "./types"

type TabKind = "sticker" | "gif" | "popular" | "mine"

const TABS: { id: TabKind; label: string }[] = [
  { id: "sticker", label: "استیکرها" },
  { id: "gif", label: "گیف‌ها" },
  { id: "popular", label: "محبوب‌ها" },
  { id: "mine", label: "استیکرهای من" },
]

const DEFAULT_CATEGORIES = ["احساسات", "حیوانات", "متن", "متفرقه"]

function StickerTile({
  s,
  onPick,
  onDelete,
  canDelete,
}: {
  s: Sticker
  onPick: (url: string) => void
  onDelete?: (id: string) => void
  canDelete?: boolean
}) {
  return (
    <div className="group relative aspect-square rounded-lg hover:bg-accent/60 p-1 transition-colors">
      <button
        type="button"
        onClick={() => onPick(s.url)}
        className="w-full h-full flex items-center justify-center"
        title={s.name || ""}
      >
        <img
          src={s.url}
          alt={s.name || ""}
          className="w-full h-full object-contain"
          loading="lazy"
        />
      </button>
      {s.name && (
        <div className="pointer-events-none absolute -top-1 right-1 left-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="text-[9px] text-center bg-card/95 border border-border/60 rounded px-1 py-0.5 truncate shadow-soft">
            {s.name}
          </div>
        </div>
      )}
      {canDelete && onDelete && (
        <button
          type="button"
          onClick={() => onDelete(s.id)}
          className="absolute -top-1 -left-1 w-5 h-5 rounded-full bg-card border border-border/60 shadow-soft opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-rose-500 hover:bg-rose-500 hover:text-white"
          title="حذف"
        >
          <Trash2 className="w-3 h-3" />
        </button>
      )}
    </div>
  )
}

function UploadDialog({ open, onOpenChange, kind, onUploaded }: {
  open: boolean
  onOpenChange: (o: boolean) => void
  kind: TabKind
  onUploaded: () => void
}) {
  const { toast } = useApp()
  const [file, setFile] = useState<File | null>(null)
  const [name, setName] = useState("")
  const [category, setCategory] = useState("")
  const [uploadKind, setUploadKind] = useState<"sticker" | "gif">("sticker")
  const [submitting, setSubmitting] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (!open) {
      setFile(null)
      setName("")
      setCategory("")
      setSubmitting(false)
    }
  }, [open])

  useEffect(() => {
    if (kind === "gif") setUploadKind("gif")
    else if (kind === "sticker") setUploadKind("sticker")
  }, [kind])

  const handleFile = (f: File | null) => {
    setFile(f)
    if (f && (f.type === "image/gif" || kind === "gif")) setUploadKind("gif")
    if (!name && f) {
      const base = f.name.replace(/\.[^.]+$/, "")
      setName(base.slice(0, 40))
    }
  }

  const submit = async () => {
    if (!file) {
      toast("یک فایل انتخاب کنید", "error")
      return
    }
    if (!name.trim()) {
      toast("نام استیکر الزامی است", "error")
      return
    }
    setSubmitting(true)
    try {
      const fd = new FormData()
      fd.append("file", file)
      fd.append("name", name.trim())
      fd.append("kind", uploadKind)
      if (category.trim()) fd.append("category", category.trim())
      await api<{ sticker: Sticker }>("/api/chat/stickers/upload", {
        method: "POST",
        body: fd,
      })
      toast("استیکر با موفقیت آپلود شد", "success")
      onUploaded()
      onOpenChange(false)
    } catch (e: any) {
      toast(e.message || "خطا در آپلود استیکر", "error")
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>آپلود استیکر / گیف</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label>فایل (PNG/JPG/GIF/WebP)</Label>
            <input
              ref={fileRef}
              type="file"
              accept="image/png,image/jpeg,image/gif,image/webp"
              className="hidden"
              onChange={(e) => handleFile(e.target.files?.[0] || null)}
            />
            <Button
              type="button"
              variant="outline"
              className="w-full justify-start text-muted-foreground"
              onClick={() => fileRef.current?.click()}
            >
              <Upload className="w-4 h-4 ml-2" />
              {file ? file.name : "انتخاب فایل…"}
            </Button>
            {file && (
              <div className="aspect-square w-24 mx-auto rounded-lg overflow-hidden bg-muted/30 flex items-center justify-center">
                <img
                  src={URL.createObjectURL(file)}
                  alt="preview"
                  className="w-full h-full object-contain"
                />
              </div>
            )}
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="st-name">نام</Label>
            <Input
              id="st-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="مثلاً خنده"
              maxLength={40}
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1.5">
              <Label htmlFor="st-kind">نوع</Label>
              <select
                id="st-kind"
                value={uploadKind}
                onChange={(e) => setUploadKind(e.target.value as "sticker" | "gif")}
                className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm"
              >
                <option value="sticker">استیکر</option>
                <option value="gif">گیف</option>
              </select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="st-cat">دسته</Label>
              <Input
                id="st-cat"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                placeholder="احساسات"
                maxLength={30}
                list="st-cat-list"
              />
              <datalist id="st-cat-list">
                {DEFAULT_CATEGORIES.map((c) => (
                  <option key={c} value={c} />
                ))}
              </datalist>
            </div>
          </div>
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={submitting}>
            انصراف
          </Button>
          <Button onClick={submit} disabled={submitting} className="gradient-karol">
            {submitting ? <Loader2 className="w-4 h-4 animate-spin ml-1" /> : <Plus className="w-4 h-4 ml-1" />}
            آپلود
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

export function StickerPicker({ onPick }: { onPick: (url: string) => void }) {
  const { user, toast } = useApp()
  const [open, setOpen] = useState(false)
  const [tab, setTab] = useState<TabKind>("sticker")
  const [packs, setPacks] = useState<StickerPack[]>([])
  const [popular, setPopular] = useState<Sticker[]>([])
  const [loading, setLoading] = useState(false)
  const [activePack, setActivePack] = useState<string | null>(null)
  const [query, setQuery] = useState("")
  const [activeCategory, setActiveCategory] = useState<string | null>(null)
  const [uploadOpen, setUploadOpen] = useState(false)
  const [refreshKey, setRefreshKey] = useState(0)

  useEffect(() => {
    if (!open) return
    let active = true
    const load = async () => {
      setLoading(true)
      try {
        if (tab === "popular") {
          const d = await api<{ stickers: Sticker[] }>("/api/chat/stickers?popular=true")
          if (!active) return
          setPopular(d.stickers || [])
        } else {
          const params = new URLSearchParams()
          if (tab === "gif") params.set("kind", "gif")
          if (tab === "sticker") params.set("kind", "sticker")
          if (tab === "mine") {
            // mine = user packs only (filter client-side from full list)
          }
          const d = await api<{ packs: StickerPack[]; stickers: Sticker[] }>(
            `/api/chat/stickers${params.toString() ? `?${params.toString()}` : ""}`,
          )
          if (!active) return
          const filteredPacks =
            tab === "mine"
              ? (d.packs || []).filter((p) => !p.isOfficial)
              : (d.packs || [])
          setPacks(filteredPacks)
          setActivePack(filteredPacks[0]?.id || null)
        }
      } catch {
        if (active) {
          setPacks([])
          setPopular([])
        }
      } finally {
        if (active) setLoading(false)
      }
    }
    load()
    return () => {
      active = false
    }
  }, [open, tab, refreshKey])

  useEffect(() => {
    setQuery("")
    setActiveCategory(null)
  }, [tab])

  const categories = useMemo(() => {
    const set = new Set<string>()
    const src = tab === "popular" ? popular : packs.flatMap((p) => p.stickers)
    for (const s of src) {
      if (s.category) set.add(s.category)
    }
    return Array.from(set)
  }, [packs, popular, tab])

  const visibleStickers = useMemo(() => {
    if (tab === "popular") return popular
    const pack = packs.find((p) => p.id === activePack)
    if (!pack) return []
    return pack.stickers
  }, [tab, popular, packs, activePack])

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    return visibleStickers.filter((s) => {
      if (q && !(s.name || "").toLowerCase().includes(q)) return false
      if (activeCategory && s.category !== activeCategory) return false
      return true
    })
  }, [visibleStickers, query, activeCategory])

  const handleDelete = async (id: string) => {
    try {
      await api(`/api/chat/stickers/${id}`, { method: "DELETE" })
      toast("استیکر حذف شد", "success")
      setRefreshKey((k) => k + 1)
    } catch (e: any) {
      toast(e.message || "خطا در حذف", "error")
    }
  }

  const canDeleteSticker = (s: Sticker) => {
    if (!user) return false
    if (s.isOfficial) return false
    return true
  }

  return (
    <>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            type="button"
            size="icon"
            variant="ghost"
            className="h-9 w-9 rounded-full text-muted-foreground hover:text-primary shrink-0"
            title="استیکر"
          >
            <StickerIcon className="w-[18px] h-[18px]" />
          </Button>
        </PopoverTrigger>
        <PopoverContent
          side="top"
          align="end"
          className="w-[340px] p-0"
          onOpenAutoFocus={(e) => e.preventDefault()}
        >
          <div className="flex flex-col h-[360px]">
            <div className="flex items-center gap-1 px-2 pt-2 pb-1.5 border-b border-border/60">
              {TABS.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  className={cn(
                    "flex-1 px-1.5 py-1 rounded-md text-[11px] font-medium transition-colors",
                    tab === t.id
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:bg-accent",
                  )}
                >
                  {t.label}
                </button>
              ))}
            </div>

            <div className="px-2 py-1.5 border-b border-border/60">
              <div className="relative">
                <Search className="absolute right-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                <Input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="جستجوی استیکر…"
                  className="h-8 pr-7 text-xs"
                />
              </div>
              {categories.length > 0 && (
                <div className="flex items-center gap-1 mt-1.5 overflow-x-auto no-scrollbar">
                  <button
                    onClick={() => setActiveCategory(null)}
                    className={cn(
                      "px-2 py-0.5 rounded-full text-[10px] whitespace-nowrap transition-colors",
                      !activeCategory
                        ? "bg-primary/15 text-primary"
                        : "text-muted-foreground hover:bg-accent",
                    )}
                  >
                    همه
                  </button>
                  {categories.map((c) => (
                    <button
                      key={c}
                      onClick={() => setActiveCategory(c === activeCategory ? null : c)}
                      className={cn(
                        "px-2 py-0.5 rounded-full text-[10px] whitespace-nowrap transition-colors",
                        activeCategory === c
                          ? "bg-primary/15 text-primary"
                          : "text-muted-foreground hover:bg-accent",
                      )}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {tab !== "popular" && packs.length > 0 && (
              <div className="flex items-center gap-1 px-2 py-1 border-b border-border/60 overflow-x-auto no-scrollbar">
                {packs.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setActivePack(p.id)}
                    className={cn(
                      "px-2 py-0.5 rounded text-[10px] font-medium whitespace-nowrap transition-colors flex items-center gap-1",
                      activePack === p.id
                        ? "bg-primary text-primary-foreground"
                        : "text-muted-foreground hover:bg-accent",
                    )}
                  >
                    {p.isOfficial && <Sparkles className="w-2.5 h-2.5" />}
                    {p.name}
                  </button>
                ))}
              </div>
            )}

            <div className="flex-1 overflow-y-auto thin-scrollbar p-2">
              {loading ? (
                <div className="grid grid-cols-4 gap-1.5">
                  {Array.from({ length: 8 }).map((_, i) => (
                    <Skeleton key={i} className="aspect-square rounded-lg" />
                  ))}
                </div>
              ) : filtered.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center px-4 gap-2">
                  <div className="w-10 h-10 rounded-xl bg-muted/40 flex items-center justify-center">
                    {tab === "mine" ? (
                      <ImageIcon className="w-5 h-5 text-muted-foreground" />
                    ) : (
                      <StickerIcon className="w-5 h-5 text-muted-foreground" />
                    )}
                  </div>
                  <p className="text-[11px] text-muted-foreground">
                    {tab === "mine"
                      ? "هنوز استیکری نساخته‌اید."
                      : tab === "popular"
                        ? "هنوز استیکر محبوبی وجود ندارد."
                        : "نتیجه‌ای یافت نشد."}
                  </p>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 text-[11px] mt-1"
                    onClick={() => setUploadOpen(true)}
                  >
                    <Plus className="w-3 h-3 ml-1" />
                    آپلود استیکر
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-4 gap-1.5">
                  {filtered.map((s) => (
                    <StickerTile
                      key={s.id}
                      s={s}
                      onPick={(url) => {
                        onPick(url)
                        setOpen(false)
                      }}
                      onDelete={handleDelete}
                      canDelete={canDeleteSticker(s)}
                    />
                  ))}
                </div>
              )}
            </div>

            <div className="border-t border-border/60 px-2 py-1.5">
              <Button
                variant="outline"
                size="sm"
                className="w-full h-8 text-[11px] justify-center"
                onClick={() => setUploadOpen(true)}
              >
                <Plus className="w-3.5 h-3.5 ml-1" />
                آپلود استیکر/گیف
              </Button>
            </div>
          </div>
        </PopoverContent>
      </Popover>

      <UploadDialog
        open={uploadOpen}
        onOpenChange={setUploadOpen}
        kind={tab}
        onUploaded={() => setRefreshKey((k) => k + 1)}
      />
    </>
  )
}
