export type ChatRoom = {
  id: string
  name: string
  description: string | null
  type: string
  roomKind: string
  iconUrl: string | null
  ownerId: string
  order: number
  memberCount: number
  isMember: boolean
  isOwner?: boolean
  memberRole: string | null
  accessible: boolean
}

export type ChatUser = {
  id: string
  username: string
  displayName: string | null
  avatarUrl: string | null
  animatedAvatarUrl?: string | null
  isVip: boolean
  isAdmin?: boolean
  profileEffect?: string | null
  nameColor?: string | null
}

export type ChatMessage = {
  id: string
  roomId: string
  userId: string | null
  username: string
  content: string | null
  type: "text" | "image" | "video" | "voice" | "gif" | "sticker"
  mediaUrl: string | null
  mediaMeta: string | null
  replyToId: string | null
  forwardedFromId: string | null
  forwardedFromName: string | null
  createdAt: string
  deletedAt: string | null
  user: ChatUser | null
  pending?: boolean
}

export type ChatSettings = {
  maxMessageLength: number
  allowVoice: boolean
  allowStickers: boolean
  allowGifs: boolean
  allowImages: boolean
  allowVideos: boolean
}

export type PresenceUser = {
  userId: string
  username: string
  displayName?: string | null
  avatarUrl?: string | null
  isVip?: boolean
}

export type Sticker = {
  id: string
  url: string
  name: string | null
  kind?: string
  category?: string | null
  usageCount?: number
  isOfficial?: boolean
  packId?: string
}
export type StickerPack = {
  id: string
  name: string
  coverUrl: string | null
  isOfficial?: boolean
  stickers: Sticker[]
}

export const DEFAULT_CHAT_SETTINGS: ChatSettings = {
  maxMessageLength: 2000,
  allowVoice: true,
  allowStickers: true,
  allowGifs: true,
  allowImages: true,
  allowVideos: true,
}
