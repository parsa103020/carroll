"use client"

import { useState, useEffect } from "react"
import { useApp } from "@/lib/store"
import { api } from "@/lib/format"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { MessageCircle, Music, Video, Film, ShoppingBag, Crown, Sparkles, Loader2, AtSign, Lock } from "lucide-react"

const FEATURES = [
  { icon: Sparkles, title: "کهکشان کارول", desc: "کشف محتوای زنده‌ی پلتفرم در یک نقشه‌ی کیهانی تعاملی — اختصاصی کارول" },
  { icon: MessageCircle, title: "کارول چت", desc: "گفتگوی زنده با ویس، استیکر، گیف و تصویر" },
  { icon: Music, title: "کارول موزیک", desc: "جستجو و پخش موسیقی بدون نیاز به اینترنت خارجی" },
  { icon: Video, title: "کارول ویدیوز", desc: "آپلود و تماشای ویدیوهای کاربری" },
  { icon: Film, title: "کارول ریلز", desc: "ویدیوهای کوتاه عمودی با تجربه‌ای روان" },
  { icon: Crown, title: "بخش VIP", desc: "دسترسی ویژه برای اعضای ممتاز کارول" },
]

export default function AuthScreen() {
  const { refreshUser, toast } = useApp()
  const [mode, setMode] = useState<"login" | "register">("login")
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const t = (localStorage.getItem("karol-theme") as any) || "purple"
    document.documentElement.setAttribute("data-theme", t)
  }, [])

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!username.trim() || !password) return
    setLoading(true)
    try {
      await api("/api/auth", { method: "POST", json: { action: mode, username: username.trim(), password } })
      await refreshUser()
      toast(mode === "login" ? "خوش آمدید!" : "ثبت‌نام موفق بود!", "success")
    } catch (err: any) {
      toast(err.message || "خطا در ورود", "error")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-base">
      <div className="relative hidden lg:flex lg:w-1/2 flex-col justify-between p-10 overflow-hidden bg-deep">
        <div className="absolute inset-0">
          <img src="/hero.png" alt="" className="w-full h-full object-cover opacity-60" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#02060a] via-[#060d11]/85 to-[#060d11]/50" />
        </div>
        <div className="relative z-10 flex items-center gap-3">
          <img src="/logo.svg" alt="Karol" className="w-12 h-12" />
          <div>
            <h1 className="text-2xl font-bold text-primary-c">کارول</h1>
            <p className="text-secondary-c text-sm">پلتفرم اجتماعی یکپارچه</p>
          </div>
        </div>
        <div className="relative z-10 space-y-6">
          <h2 className="text-4xl font-black text-primary-c leading-tight">
            وقتی اینترنت قطع است،
            <br />
            <span className="text-gradient-karol">کارول وصل می‌ماند.</span>
          </h2>
          <p className="text-secondary-c text-lg max-w-md leading-relaxed">
            چت، موسیقی، ویدیو، ریلز، فروشگاه و بخش وی‌آی‌پی — همه در یک پلتفرم، ساخته‌شده برای جامعه‌ی ما.
          </p>
          <div className="grid grid-cols-2 gap-3 max-w-lg">
            {FEATURES.map((f) => (
              <div key={f.title} className="rounded-xl p-4 bg-white/[0.04] backdrop-blur border border-white/[0.06]">
                <f.icon className="w-6 h-6 text-accent-soft mb-2" />
                <div className="text-primary-c font-semibold text-sm">{f.title}</div>
                <div className="text-secondary-c/70 text-xs mt-1 leading-relaxed">{f.desc}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="relative z-10 text-secondary-c/60 text-xs">
          ساخته‌شده برای دوران قطعی — کارول
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-6 bg-base">
        <div className="w-full max-w-md animate-fade-in">
          <div className="lg:hidden flex items-center justify-center gap-3 mb-8">
            <img src="/logo.svg" alt="Karol" className="w-14 h-14" />
            <div>
              <h1 className="text-2xl font-black text-gradient-karol">کارول</h1>
              <p className="text-muted-c text-xs">پلتفرم اجتماعی یکپارچه</p>
            </div>
          </div>

          <Card className="border-hair shadow-soft bg-surface">
            <CardContent className="pt-6">
              <Tabs value={mode} onValueChange={(v) => setMode(v as any)}>
                <TabsList className="grid w-full grid-cols-2 mb-6">
                  <TabsTrigger value="login">ورود</TabsTrigger>
                  <TabsTrigger value="register">ثبت‌نام</TabsTrigger>
                </TabsList>
                <TabsContent value="login">
                  <form onSubmit={submit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="u">نام کاربری</Label>
                      <div className="relative">
                        <AtSign className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-c" />
                        <Input id="u" className="pr-9" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="نام کاربری" autoComplete="username" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="p">رمز عبور</Label>
                      <div className="relative">
                        <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-c" />
                        <Input id="p" type="password" className="pr-9" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••" autoComplete="current-password" />
                      </div>
                    </div>
                    <Button type="submit" className="w-full gradient-karol text-white" disabled={loading}>
                      {loading && <Loader2 className="w-4 h-4 ml-2 animate-spin" />}
                      ورود به کارول
                    </Button>
                  </form>
                </TabsContent>
                <TabsContent value="register">
                  <form onSubmit={submit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="ru">نام کاربری</Label>
                      <div className="relative">
                        <AtSign className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-c" />
                        <Input id="ru" className="pr-9" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="مثلاً ali_93" autoComplete="username" />
                      </div>
                      <p className="text-xs text-muted-c">۳ تا ۲۴ نویسه؛ حروف انگلیسی، عدد، نقطه، خط‌تیره</p>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="rp">رمز عبور</Label>
                      <div className="relative">
                        <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-c" />
                        <Input id="rp" type="password" className="pr-9" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="حداقل ۶ نویسه" autoComplete="new-password" />
                      </div>
                    </div>
                    <Button type="submit" className="w-full gradient-karol text-white" disabled={loading}>
                      {loading && <Loader2 className="w-4 h-4 ml-2 animate-spin" />}
                      ساخت حساب کاربری
                    </Button>
                  </form>
                </TabsContent>
              </Tabs>
              <div className="mt-6 pt-4 border-t border-hair flex items-center gap-2 justify-center text-xs text-muted-c">
                <Sparkles className="w-3.5 h-3.5 text-warning" />
                <span>با ورود، قوانین کارول را می‌پذیرید</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
