"use client"

import { useEffect, useState } from "react"
import { useApp } from "@/lib/store"
import { api, timeAgo, formatNumber } from "@/lib/format"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Heart, MessageCircle, Share2, ImagePlus, Send, Sparkles, TrendingUp, Crown, Coins, MessageSquare, Film, Music } from "lucide-react"
import { cn } from "@/lib/utils"
import { UserAvatar } from "@/components/karol/UserAvatar"
import { UserName } from "@/components/karol/UserName"

interface FeedPostT {
  id: string
  content: string | null
  mediaUrls: string[]
  createdAt: string
  likes: number
  comments: number
  liked: boolean
  owner: {
    id: string
    username: string
    displayName: string | null
    avatarUrl: string | null
    animatedAvatarUrl?: string | null
    isVip: boolean
    profileEffect?: string | null
    nameColor?: string | null
  }
}

export default function FeedSection() {
  const { user, setSection, toast } = useApp()
  const [posts, setPosts] = useState<FeedPostT[]>([])
  const [loading, setLoading] = useState(true)
  const [composing, setComposing] = useState(false)
  const [text, setText] = useState("")
  const [posting, setPosting] = useState(false)

  async function load() {
    setLoading(true)
    try {
      const d = await api<{ posts: FeedPostT[] }>("/api/feed")
      setPosts(d.posts)
    } catch {
    } finally {
      setLoading(false)
    }
  }
  useEffect(() => { load() }, [])

  async function publish() {
    if (!text.trim() && !media.length) return
    setPosting(true)
    try {
      await api("/api/feed", { method: "POST", json: { content: text, mediaUrls: media } })
      setText("")
      setMedia([])
      setComposing(false)
      toast("پست منتشر شد", "success")
      load()
    } catch (e: any) {
      toast(e.message, "error")
    } finally {
      setPosting(false)
    }
  }

  const [media, setMedia] = useState<string[]>([])

  async function onPickFiles(files: FileList | null) {
    if (!files) return
    const urls: string[] = []
    for (const f of Array.from(files).slice(0, 4)) {
      const fd = new FormData()
      fd.append("file", f)
      fd.append("category", "drive")
      try {
        const r = await api<{ url: string }>("/api/upload", { method: "POST", body: fd })
        urls.push(r.url)
      } catch (e: any) {
        toast(e.message, "error")
      }
    }
    setMedia((m) => [...m, ...urls].slice(0, 4))
  }

  async function toggleLike(id: string) {
    setPosts((p) =>
      p.map((x) => (x.id === id ? { ...x, liked: !x.liked, likes: x.likes + (x.liked ? -1 : 1) } : x)),
    )
    try {
      await api(`/api/feed/${id}/like`, { method: "POST" })
    } catch {}
  }

  return (
    <div className="min-h-full">
      <div className="max-w-2xl mx-auto px-3 sm:px-4 py-4 sm:py-6 space-y-4">
        {/* Composer */}
        <Card className="shadow-soft">
          <CardContent className="p-4">
            <div className="flex gap-3">
              <UserAvatar
                user={{
                  avatarUrl: user?.avatarUrl || null,
                  animatedAvatarUrl: user?.animatedAvatarUrl || null,
                  isVip: user?.isVip,
                  profileEffect: user?.profileEffect,
                  displayName: user?.displayName || null,
                  username: user?.username,
                }}
                size="md"
              />
              <div className="flex-1">
                <textarea
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  onFocus={() => setComposing(true)}
                  placeholder="چه خبر، کارولی؟"
                  rows={composing ? 3 : 1}
                  className="w-full resize-none bg-transparent outline-none text-sm placeholder:text-muted-foreground transition-all"
                />
                {(composing || media.length > 0) && (
                  <>
                    {media.length > 0 && (
                      <div className="grid grid-cols-2 gap-2 mb-3">
                        {media.map((u, i) => (
                          <div key={i} className="relative aspect-square rounded-lg overflow-hidden bg-muted">
                            <img src={u} alt="" className="w-full h-full object-cover" />
                            <button
                              onClick={() => setMedia((m) => m.filter((_, j) => j !== i))}
                              className="absolute top-1 left-1 w-6 h-6 rounded-full bg-black/60 text-white text-xs"
                            >
                              ×
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                    <div className="flex items-center justify-between gap-2 pt-2 border-t border-border/50">
                      <label className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground cursor-pointer">
                        <ImagePlus className="w-4 h-4" />
                        <span>تصویر</span>
                        <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => onPickFiles(e.target.files)} />
                      </label>
                      <div className="flex gap-2">
                        <Button variant="ghost" size="sm" onClick={() => { setComposing(false); setText(""); setMedia([]) }}>لغو</Button>
                        <Button size="sm" className="gradient-karol text-white" disabled={posting || (!text.trim() && !media.length)} onClick={publish}>
                          {posting ? "…" : "انتشار"}
                        </Button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick links */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { icon: MessageSquare, label: "رفتن به چت", to: "chat" as const, color: "text-emerald-500" },
            { icon: Music, label: "موزیک", to: "music" as const, color: "text-amber-500" },
            { icon: Film, label: "ریلز", to: "reels" as const, color: "text-rose-500" },
            { icon: Crown, label: user?.isVip ? "بخش VIP" : "گرفتن VIP", to: "vip" as const, color: "text-gold" },
          ].map((q) => (
            <button key={q.to} onClick={() => setSection(q.to)} className="flex items-center gap-2 p-3 rounded-xl bg-card border border-border/60 hover:border-primary/40 hover:shadow-soft transition-all text-right">
              <q.icon className={cn("w-5 h-5 shrink-0", q.color)} />
              <span className="text-sm font-medium truncate">{q.label}</span>
            </button>
          ))}
        </div>

        {/* Stats banner */}
        <Card className="overflow-hidden border-0">
          <div className="gradient-karol p-4 text-white">
            <div className="flex items-center gap-2 mb-1">
              <Sparkles className="w-4 h-4" />
              <span className="text-sm font-semibold">کارول‌کوین شما</span>
            </div>
            <div className="flex items-end justify-between">
              <div className="text-3xl font-black tabular-nums">{user?.coins.toLocaleString("fa-IR") || "۰"}</div>
              <Button size="sm" variant="secondary" onClick={() => setSection("wallet")} className="bg-white/20 text-white hover:bg-white/30">
                <Coins className="w-4 h-4 ml-1" /> شارژ
              </Button>
            </div>
          </div>
        </Card>

        {/* Feed */}
        {loading ? (
          <div className="space-y-3">
            {[...Array(3)].map((_, i) => (
              <Card key={i}><CardContent className="p-4 space-y-3">
                <div className="flex gap-3"><Skeleton className="w-10 h-10 rounded-full" /><div className="flex-1 space-y-2"><Skeleton className="h-3 w-32" /><Skeleton className="h-3 w-20" /></div></div>
                <Skeleton className="h-16 w-full" />
              </CardContent></Card>
            ))}
          </div>
        ) : posts.length === 0 ? (
          <Card><CardContent className="p-10 text-center">
            <TrendingUp className="w-10 h-10 mx-auto mb-3 text-muted-foreground/50" />
            <p className="text-sm text-muted-foreground">هنوز پستی وجود ندارد. اولین نفر باشید!</p>
          </CardContent></Card>
        ) : (
          posts.map((p) => (
            <Card key={p.id} className="shadow-soft overflow-hidden">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-3">
                  <UserAvatar
                    user={{
                      avatarUrl: p.owner.avatarUrl || null,
                      animatedAvatarUrl: p.owner.animatedAvatarUrl || null,
                      isVip: p.owner.isVip,
                      profileEffect: p.owner.profileEffect,
                      displayName: p.owner.displayName,
                      username: p.owner.username,
                      nameColor: p.owner.nameColor,
                    }}
                    size="md"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <UserName
                        user={{
                          displayName: p.owner.displayName,
                          username: p.owner.username,
                          isVip: p.owner.isVip,
                          profileEffect: p.owner.profileEffect,
                          nameColor: p.owner.nameColor,
                        }}
                        className="text-sm"
                      />
                    </div>
                    <div className="text-xs text-muted-foreground">@{p.owner.username} · {timeAgo(p.createdAt)}</div>
                  </div>
                </div>
                {p.content && <p className="text-sm leading-relaxed mb-3 whitespace-pre-wrap break-words">{p.content}</p>}
                {p.mediaUrls.length > 0 && (
                  <div className={cn("grid gap-1 mb-3", p.mediaUrls.length === 1 ? "grid-cols-1" : "grid-cols-2")}>
                    {p.mediaUrls.map((u, i) => (
                      <div key={i} className="rounded-lg overflow-hidden bg-muted">
                        <img src={u} alt="" className="w-full max-h-96 object-cover" />
                      </div>
                    ))}
                  </div>
                )}
                <div className="flex items-center gap-4 text-muted-foreground">
                  <button onClick={() => toggleLike(p.id)} className={cn("flex items-center gap-1.5 text-sm hover:text-rose-500 transition-colors", p.liked && "text-rose-500")}>
                    <Heart className={cn("w-4 h-4", p.liked && "fill-current")} />
                    {formatNumber(p.likes)}
                  </button>
                  <button className="flex items-center gap-1.5 text-sm hover:text-primary transition-colors">
                    <MessageCircle className="w-4 h-4" />
                    {formatNumber(p.comments)}
                  </button>
                  <button className="flex items-center gap-1.5 text-sm hover:text-primary transition-colors mr-auto">
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}
