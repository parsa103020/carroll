"use client"

import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import { useApp } from "@/lib/store"
import {
  api,
  formatBytes,
  formatNumber,
  faDigits,
  formatDate,
} from "@/lib/format"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Slider } from "@/components/ui/slider"
import { Input } from "@/components/ui/input"
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  Shield,
  HardDrive,
  Clock,
  Coins,
  Zap,
  Download,
  Copy,
  Check,
  Server,
  AlertTriangle,
  Inbox,
  Loader2,
  Eye,
  Wallet,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface Package {
  id: string
  name: string
  volumeBytes: string
  priceCoins: number
  durationDays: number
  stockAvailable: number
}

interface MyPurchase {
  id: string
  packageId: string
  configId: string
  pricePaid: number
  volumeBytes: string
  expiresAt: string
  createdAt: string
  packageName: string
  durationDays: number
  configText?: string
}

const MB = 1024 * 1024

function pkgVolumeMB(p: Package): number {
  return Math.round(Number(p.volumeBytes) / MB)
}

function isExpired(p: { expiresAt: string }): boolean {
  return new Date(p.expiresAt).getTime() < Date.now()
}

export default function ConfigsSection() {
  const { user, setSection, refreshUser, toast } = useApp()
  const [tab, setTab] = useState<"shop" | "mine">("shop")

  const [packages, setPackages] = useState<Package[]>([])
  const [loadingPkgs, setLoadingPkgs] = useState(true)
  const [selectedMB, setSelectedMB] = useState<number>(10)
  const [inputMB, setInputMB] = useState<string>("10")
  const [inputFocused, setInputFocused] = useState(false)

  const [mine, setMine] = useState<MyPurchase[]>([])
  const [loadingMine, setLoadingMine] = useState(true)
  const [nextCursor, setNextCursor] = useState<string | null>(null)
  const [loadingMore, setLoadingMore] = useState(false)

  const [confirmPkg, setConfirmPkg] = useState<Package | null>(null)
  const [buying, setBuying] = useState(false)
  const [result, setResult] = useState<MyPurchase | null>(null)
  const [viewing, setViewing] = useState<MyPurchase | null>(null)
  const [viewingText, setViewingText] = useState<string | null>(null)
  const [viewLoading, setViewLoading] = useState(false)
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const copyTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const loadPackages = useCallback(async () => {
    setLoadingPkgs(true)
    try {
      const r = await api<{ packages: Package[] }>("/api/configs/packages")
      setPackages(r.packages)
      if (r.packages.length > 0) {
        const firstMB = pkgVolumeMB(r.packages[0])
        setSelectedMB(firstMB)
        setInputMB(String(firstMB))
      }
    } catch (e: any) {
      toast(e.message || "خطا در بارگذاری بسته‌ها", "error")
    } finally {
      setLoadingPkgs(false)
    }
  }, [toast])

  const loadMine = useCallback(async () => {
    setLoadingMine(true)
    try {
      const r = await api<{ purchases: MyPurchase[]; nextCursor: string | null }>(
        "/api/configs/my?limit=20",
      )
      setMine(r.purchases)
      setNextCursor(r.nextCursor)
    } catch (e: any) {
      toast(e.message || "خطا در بارگذاری کانفیگ‌ها", "error")
    } finally {
      setLoadingMine(false)
    }
  }, [toast])

  useEffect(() => {
    loadPackages()
    loadMine()
  }, [loadPackages, loadMine])

  useEffect(() => {
    return () => {
      if (copyTimer.current) clearTimeout(copyTimer.current)
    }
  }, [])

  const minMB = useMemo(() => {
    if (packages.length === 0) return 10
    return Math.min(...packages.map(pkgVolumeMB))
  }, [packages])

  const maxMB = useMemo(() => {
    if (packages.length === 0) return 5120
    return Math.max(...packages.map(pkgVolumeMB))
  }, [packages])

  const targetPackage = useMemo<Package | null>(() => {
    if (packages.length === 0) return null
    const selectedBytes = BigInt(selectedMB) * BigInt(MB)
    const ceiling = packages.find((p) => BigInt(p.volumeBytes) >= selectedBytes)
    if (ceiling) return ceiling
    return packages[packages.length - 1]
  }, [packages, selectedMB])

  const targetIdx = useMemo(() => {
    if (!targetPackage) return -1
    return packages.findIndex((p) => p.id === targetPackage.id)
  }, [packages, targetPackage])

  function onSliderChange(values: number[]) {
    const v = values[0]
    if (typeof v !== "number") return
    const clamped = Math.max(minMB, Math.min(maxMB, Math.round(v)))
    setSelectedMB(clamped)
    if (!inputFocused) setInputMB(String(clamped))
  }

  function onInputChange(e: React.ChangeEvent<HTMLInputElement>) {
    const raw = e.target.value.replace(/[^0-9]/g, "")
    setInputMB(raw)
    const n = parseInt(raw, 10)
    if (Number.isFinite(n) && n > 0) {
      const clamped = Math.max(minMB, Math.min(maxMB, n))
      setSelectedMB(clamped)
    }
  }

  function snapInputToNearest() {
    setInputFocused(false)
    const n = parseInt(inputMB, 10)
    if (!Number.isFinite(n) || n <= 0) {
      setInputMB(String(selectedMB))
      return
    }
    const clamped = Math.max(minMB, Math.min(maxMB, n))
    let nearest = packages[0]
    let bestDiff = Infinity
    for (const p of packages) {
      const diff = Math.abs(pkgVolumeMB(p) - clamped)
      if (diff < bestDiff) {
        bestDiff = diff
        nearest = p
      }
    }
    const nearestMB = pkgVolumeMB(nearest)
    setSelectedMB(nearestMB)
    setInputMB(String(nearestMB))
  }

  function openBuy(pkg: Package) {
    if (!user) return
    if ((user.coins ?? 0) < pkg.priceCoins) {
      toast("کارول‌کوین کافی ندارید", "error")
      return
    }
    if (pkg.stockAvailable <= 0) {
      toast("موجودی این بسته تمام شده است", "error")
      return
    }
    setConfirmPkg(pkg)
  }

  async function confirmBuy() {
    if (!confirmPkg) return
    setBuying(true)
    try {
      const r = await api<{ purchase: MyPurchase; configText: string }>(
        "/api/configs/purchase",
        {
          method: "POST",
          json: { packageId: confirmPkg.id },
        },
      )
      setConfirmPkg(null)
      setResult(r.purchase)
      refreshUser()
      loadMine()
      loadPackages()
      toast("کانفیگ با موفقیت خریداری شد", "success")
    } catch (e: any) {
      toast(e.message || "خطا در خرید کانفیگ", "error")
    } finally {
      setBuying(false)
    }
  }

  async function openView(p: MyPurchase) {
    setViewing(p)
    setViewingText(null)
    setViewLoading(true)
    try {
      const r = await api<{ purchase: MyPurchase }>(`/api/configs/my/${p.id}`)
      setViewingText(r.purchase.configText || null)
    } catch (e: any) {
      toast(e.message || "خطا در بارگذاری کانفیگ", "error")
    } finally {
      setViewLoading(false)
    }
  }

  async function copyText(text: string, id: string) {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedId(id)
      if (copyTimer.current) clearTimeout(copyTimer.current)
      copyTimer.current = setTimeout(() => setCopiedId(null), 1800)
      toast("کانفیگ کپی شد", "success")
    } catch {
      toast("کپی ناموفق بود", "error")
    }
  }

  async function loadMore() {
    if (!nextCursor || loadingMore) return
    setLoadingMore(true)
    try {
      const r = await api<{ purchases: MyPurchase[]; nextCursor: string | null }>(
        `/api/configs/my?limit=20&cursor=${encodeURIComponent(nextCursor)}`,
      )
      setMine((prev) => [...prev, ...r.purchases])
      setNextCursor(r.nextCursor)
    } catch (e: any) {
      toast(e.message || "خطا در بارگذاری بیشتر", "error")
    } finally {
      setLoadingMore(false)
    }
  }

  return (
    <div className="min-h-full p-3 sm:p-4 lg:p-6 max-w-5xl mx-auto w-full">
      <div className="mb-5 sm:mb-6 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-accent-15 flex items-center justify-center">
            <Shield className="w-5 h-5 text-accent-soft" />
          </div>
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-primary-c flex items-center gap-2">
              کانفیگ V2Ray
            </h2>
            <p className="text-xs text-muted-c">
              اشتراک V2Ray شخصی، امن و سریع
            </p>
          </div>
        </div>
        <button
          onClick={() => setSection("wallet")}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-warning-15 hover:bg-warning-15/70 transition-colors"
        >
          <Coins className="w-4 h-4 text-warning" />
          <span className="text-[13px] font-bold text-warning tabular-nums">
            {faDigits(formatNumber(user?.coins ?? 0))}
          </span>
        </button>
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as "shop" | "mine")}>
        <TabsList className="grid w-full grid-cols-2 max-w-sm mb-5">
          <TabsTrigger value="shop">خرید کانفیگ</TabsTrigger>
          <TabsTrigger value="mine">کانفیگ‌های من</TabsTrigger>
        </TabsList>

        <TabsContent value="shop" className="space-y-5 sm:space-y-6 outline-none">
          {loadingPkgs ? (
            <Skeleton className="h-44 w-full rounded-2xl" />
          ) : packages.length === 0 ? (
            <EmptyState
              icon={Inbox}
              title="بسته‌ای موجود نیست"
              desc="در حال حاضر بسته کانفیگی برای فروش وجود ندارد."
            />
          ) : (
            <>
              <VolumeSelector
                minMB={minMB}
                maxMB={maxMB}
                selectedMB={selectedMB}
                inputMB={inputMB}
                targetPackage={targetPackage}
                targetIdx={targetIdx}
                onSliderChange={onSliderChange}
                onInputChange={onInputChange}
                onInputFocus={() => setInputFocused(true)}
                onInputBlur={snapInputToNearest}
                onInputEnter={(e) => {
                  if (e.key === "Enter") {
                    e.currentTarget.blur()
                  }
                }}
                onBuy={() => targetPackage && openBuy(targetPackage)}
                canAfford={
                  !!user && user.coins >= (targetPackage?.priceCoins ?? 0)
                }
              />

              <div>
                <div className="flex items-center gap-2 mb-3 px-1">
                  <Server className="w-4 h-4 text-accent-soft" />
                  <h3 className="text-sm font-bold text-primary-c">
                    بسته‌های آماده
                  </h3>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                  {packages.map((p) => (
                    <PackageCard
                      key={p.id}
                      pkg={p}
                      active={targetPackage?.id === p.id}
                      onSelect={() => {
                        const mb = pkgVolumeMB(p)
                        setSelectedMB(mb)
                        setInputMB(String(mb))
                      }}
                      onBuy={() => openBuy(p)}
                      canAfford={!!user && user.coins >= p.priceCoins}
                    />
                  ))}
                </div>
              </div>

              <div className="rounded-2xl border border-hair bg-surface p-4 sm:p-5">
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-accent-15 flex items-center justify-center shrink-0">
                    <Zap className="w-4 h-4 text-accent-soft" />
                  </div>
                  <div className="text-[13px] text-secondary-c leading-relaxed space-y-1">
                    <p className="text-primary-c font-semibold text-sm">
                      راهنمای خرید
                    </p>
                    <p>
                      حجم انتخابی شما به نزدیک‌ترین بسته موجود گرد می‌شود. کانفیگ
                      پس از خرید بلافاصله نمایش داده می‌شود و تا پایان اعتبار بسته
                      قابل استفاده است.
                    </p>
                  </div>
                </div>
              </div>
            </>
          )}
        </TabsContent>

        <TabsContent value="mine" className="outline-none">
          {loadingMine ? (
            <div className="space-y-3">
              {[0, 1, 2].map((i) => (
                <Skeleton key={i} className="h-24 w-full rounded-2xl" />
              ))}
            </div>
          ) : mine.length === 0 ? (
            <EmptyState
              icon={Download}
              title="هنوز کانفیگی نخریده‌اید"
              desc="از تب «خرید کانفیگ» اولین اشتراک V2Ray خود را تهیه کنید."
              action={
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setTab("shop")}
                  className="mt-3"
                >
                  رفتن به فروشگاه
                </Button>
              }
            />
          ) : (
            <div className="space-y-3">
              {mine.map((p) => {
                const expired = isExpired(p)
                return (
                  <div
                    key={p.id}
                    className={cn(
                      "rounded-2xl border border-hair bg-surface p-4 flex flex-wrap items-center gap-3 sm:gap-4 transition-opacity",
                      expired && "opacity-55",
                    )}
                  >
                    <div className="w-11 h-11 rounded-xl bg-accent-15 flex items-center justify-center shrink-0">
                      <HardDrive className="w-5 h-5 text-accent-soft" />
                    </div>
                    <div className="flex-1 min-w-[140px]">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-bold text-primary-c">
                          {p.packageName}
                        </span>
                        <Badge
                          variant="outline"
                          className="bg-accent-10 text-accent-soft border-hair gap-1"
                        >
                          <Clock className="w-3 h-3" />
                          {faDigits(p.durationDays)} روز
                        </Badge>
                        {expired ? (
                          <Badge className="bg-danger-15 text-danger border border-danger/20 gap-1">
                            <AlertTriangle className="w-3 h-3" />
                            منقضی
                          </Badge>
                        ) : (
                          <Badge className="bg-success-15 text-success border border-success/20 gap-1">
                            <Check className="w-3 h-3" />
                            فعال
                          </Badge>
                        )}
                      </div>
                      <div className="text-[12px] text-muted-c mt-1">
                        انقضا: {faDigits(formatDate(p.expiresAt))} · هزینه{" "}
                        {faDigits(formatNumber(p.pricePaid))} کارول‌کوین
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => openView(p)}
                      className="gap-1.5"
                    >
                      <Eye className="w-4 h-4" />
                      مشاهده کانفیگ
                    </Button>
                  </div>
                )
              })}
              {nextCursor && (
                <div className="flex justify-center pt-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={loadMore}
                    disabled={loadingMore}
                  >
                    {loadingMore ? (
                      <Loader2 className="w-4 h-4 animate-spin ml-1" />
                    ) : null}
                    بارگذاری بیشتر
                  </Button>
                </div>
              )}
            </div>
          )}
        </TabsContent>
      </Tabs>

      <AlertDialog open={!!confirmPkg} onOpenChange={(o) => !buying && !o && setConfirmPkg(null)}>
        <AlertDialogContent className="max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-primary-c">
              تأیید خرید کانفیگ
            </AlertDialogTitle>
            <AlertDialogDescription className="text-secondary-c">
              {confirmPkg ? (
                <>
                  خرید کانفیگ{" "}
                  <span className="font-bold text-primary-c">
                    {confirmPkg.name}
                  </span>{" "}
                  با{" "}
                  <span className="font-bold text-warning">
                    {faDigits(formatNumber(confirmPkg.priceCoins))} کارول‌کوین
                  </span>
                  ؟ کانفیگ بلافاصله پس از تأیید صادر می‌شود.
                </>
              ) : null}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={buying}>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault()
                confirmBuy()
              }}
              disabled={buying}
              className="gradient-karol text-primary-foreground"
            >
              {buying ? (
                <Loader2 className="w-4 h-4 animate-spin ml-1.5" />
              ) : (
                <Coins className="w-4 h-4 ml-1.5" />
              )}
              خرید کانفیگ
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={!!result} onOpenChange={(o) => !o && setResult(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-primary-c flex items-center gap-2">
              <Check className="w-5 h-5 text-success" />
              کانفیگ صادر شد
            </DialogTitle>
            <DialogDescription className="text-secondary-c">
              {result
                ? `این کانفیگ تا ${faDigits(formatDate(result.expiresAt))} معتبر است`
                : null}
            </DialogDescription>
          </DialogHeader>
          {result?.configText ? (
            <div className="space-y-3">
              <div className="rounded-xl border border-hair bg-base p-3 max-h-52 overflow-y-auto thin-scrollbar">
                <pre className="text-[11.5px] leading-relaxed text-accent-soft whitespace-pre-wrap break-all font-mono">
                  {result.configText}
                </pre>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Button
                  className="flex-1 gap-1.5 gradient-karol text-primary-foreground"
                  onClick={() => result.configText && copyText(result.configText, "result")}
                >
                  {copiedId === "result" ? (
                    <Check className="w-4 h-4" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                  کپی کانفیگ
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setResult(null)
                    setTab("mine")
                  }}
                >
                  کانفیگ‌های من
                </Button>
              </div>
              <p className="text-[11px] text-muted-c leading-relaxed">
                کانفیگ را در برنامه V2Ray خود وارد کنید. این کانفیگ فقط برای شما
                صادر شده و تا پایان اعتبار قابل استفاده است.
              </p>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>

      <Dialog open={!!viewing} onOpenChange={(o) => !o && (setViewing(null), setViewingText(null))}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-primary-c flex items-center gap-2">
              <Eye className="w-5 h-5 text-accent-soft" />
              {viewing?.packageName ?? "کانفیگ"}
            </DialogTitle>
            <DialogDescription className="text-secondary-c">
              {viewing
                ? `حجم ${formatBytes(viewing.volumeBytes)} · انقضا ${faDigits(formatDate(viewing.expiresAt))}`
                : null}
            </DialogDescription>
          </DialogHeader>
          {viewLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-5 h-5 animate-spin text-accent-soft" />
            </div>
          ) : viewingText ? (
            <div className="space-y-3">
              <div className="rounded-xl border border-hair bg-base p-3 max-h-52 overflow-y-auto thin-scrollbar">
                <pre className="text-[11.5px] leading-relaxed text-accent-soft whitespace-pre-wrap break-all font-mono">
                  {viewingText}
                </pre>
              </div>
              <Button
                className="w-full gap-1.5 gradient-karol text-primary-foreground"
                onClick={() => viewing && copyText(viewingText, "view")}
              >
                {copiedId === "view" ? (
                  <Check className="w-4 h-4" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
                کپی کانفیگ
              </Button>
            </div>
          ) : (
            <p className="text-sm text-muted-c py-6 text-center">
              بارگذاری کانفیگ ناموفق بود.
            </p>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function VolumeSelector({
  minMB,
  maxMB,
  selectedMB,
  inputMB,
  targetPackage,
  targetIdx,
  onSliderChange,
  onInputChange,
  onInputFocus,
  onInputBlur,
  onInputEnter,
  onBuy,
  canAfford,
}: {
  minMB: number
  maxMB: number
  selectedMB: number
  inputMB: string
  targetPackage: Package | null
  targetIdx: number
  onSliderChange: (v: number[]) => void
  onInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void
  onInputFocus: () => void
  onInputBlur: () => void
  onInputEnter: (e: React.KeyboardEvent<HTMLInputElement>) => void
  onBuy: () => void
  canAfford: boolean
}) {
  const selectedBytes = BigInt(selectedMB) * BigInt(MB)
  return (
    <div className="rounded-2xl border border-hair bg-surface p-4 sm:p-6">
      <div className="flex items-center gap-2 mb-1">
        <HardDrive className="w-4 h-4 text-accent-soft" />
        <h3 className="text-sm font-bold text-primary-c">انتخاب حجم</h3>
      </div>
      <p className="text-[12px] text-muted-c mb-4">
        حجم دلخواه را با نوار لغزان انتخاب یا به مگابایت وارد کنید.
      </p>

      <div className="flex items-end justify-between gap-3 mb-4">
        <div>
          <div className="text-[11px] text-muted-c mb-1">حجم انتخاب‌شده</div>
          <div className="text-2xl sm:text-3xl font-black text-gradient-karol tabular-nums">
            {faDigits(formatBytes(selectedBytes.toString()))}
          </div>
        </div>
        <div className="text-left">
          <div className="text-[11px] text-muted-c mb-1">قیمت بسته</div>
          <div className="flex items-center gap-1.5 text-xl sm:text-2xl font-black text-warning tabular-nums">
            <Coins className="w-4 h-4 sm:w-5 sm:h-5" />
            {targetPackage
              ? faDigits(formatNumber(targetPackage.priceCoins))
              : "—"}
          </div>
        </div>
      </div>

      <div className="mb-2">
        <Slider
          value={[selectedMB]}
          min={minMB}
          max={maxMB}
          step={10}
          onValueChange={onSliderChange}
          className="py-2"
        />
        <div className="flex justify-between text-[10px] text-muted-c mt-1 tabular-nums">
          <span>{faDigits(minMB)} مگ</span>
          <span>{faDigits(maxMB)} مگ</span>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2 mt-4">
        <div className="flex items-center gap-1.5 text-[11px] text-muted-c">
          <span>ورودی دستی:</span>
        </div>
        <div className="relative">
          <Input
            value={inputMB}
            onChange={onInputChange}
            onFocus={onInputFocus}
            onBlur={onInputBlur}
            onKeyDown={onInputEnter}
            inputMode="numeric"
            className="w-28 h-9 text-center tabular-nums pr-10 text-[13px]"
            aria-label="حجم به مگابایت"
          />
          <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[11px] text-muted-c pointer-events-none">
            مگ
          </span>
        </div>
        {targetPackage && (
          <Badge className="bg-accent-15 text-accent-soft border border-hair gap-1 text-[11px]">
            <Server className="w-3 h-3" />
            بسته: {targetPackage.name}
          </Badge>
        )}
        <div className="flex-1" />
        <Button
          onClick={onBuy}
          disabled={!targetPackage || (targetPackage && targetPackage.stockAvailable <= 0)}
          className="gap-1.5 gradient-karol text-primary-foreground shadow-soft"
        >
          <Zap className="w-4 h-4" />
          خرید کانفیگ
        </Button>
      </div>

      {!canAfford && targetPackage ? (
        <div className="mt-3 text-[12px] text-danger flex items-center gap-1.5">
          <AlertTriangle className="w-3.5 h-3.5" />
          کارول‌کوین کافی ندارید — برای شارژ به کیف پول بروید.
        </div>
      ) : null}
      {targetPackage && targetPackage.stockAvailable <= 0 ? (
        <div className="mt-3 text-[12px] text-danger flex items-center gap-1.5">
          <AlertTriangle className="w-3.5 h-3.5" />
          موجودی این بسته تمام شده است.
        </div>
      ) : null}

      {targetIdx >= 0 && (
        <div className="mt-4 pt-4 border-t border-hair flex flex-wrap items-center gap-2">
          <span className="text-[11px] text-muted-c">بسته انتخابی:</span>
          <div className="flex flex-wrap gap-1.5">
            {[0, 1, 2, 3, 4, 5].map((i) => (
              <span
                key={i}
                className={cn(
                  "w-2 h-2 rounded-full transition-all",
                  i === targetIdx
                    ? "bg-accent shadow-glow"
                    : i < targetIdx
                      ? "bg-accent/30"
                      : "bg-white/10",
                )}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

function PackageCard({
  pkg,
  active,
  onSelect,
  onBuy,
  canAfford,
}: {
  pkg: Package
  active: boolean
  onSelect: () => void
  onBuy: () => void
  canAfford: boolean
}) {
  const volMB = pkgVolumeMB(pkg)
  const outOfStock = pkg.stockAvailable <= 0
  return (
    <button
      onClick={onSelect}
      className={cn(
        "text-right rounded-2xl border p-4 sm:p-5 transition-all relative overflow-hidden group",
        active
          ? "border-accent-soft bg-accent-10 shadow-glow"
          : "border-hair bg-surface hover:border-accent-soft/50 hover:bg-surface-2",
      )}
    >
      <div className="flex items-center justify-between mb-3">
        <div className="w-10 h-10 rounded-xl bg-accent-15 flex items-center justify-center">
          <HardDrive className="w-5 h-5 text-accent-soft" />
        </div>
        {active ? (
          <Badge className="bg-accent text-primary-foreground gap-1">
            <Check className="w-3 h-3" />
            انتخاب‌شده
          </Badge>
        ) : outOfStock ? (
          <Badge className="bg-danger-15 text-danger border border-danger/20">
            ناموجود
          </Badge>
        ) : (
          <Badge variant="outline" className="bg-surface-2 text-muted-c border-hair">
            موجود: {faDigits(pkg.stockAvailable)}
          </Badge>
        )}
      </div>

      <div className="text-lg font-black text-primary-c">{pkg.name}</div>
      <div className="text-[11px] text-muted-c mt-0.5">
        {faDigits(volMB)} مگابایت · اعتبار {faDigits(pkg.durationDays)} روز
      </div>

      <div className="mt-4 flex items-end justify-between">
        <div className="flex items-center gap-1.5">
          <Coins className="w-4 h-4 text-warning" />
          <span className="text-lg font-black text-warning tabular-nums">
            {faDigits(formatNumber(pkg.priceCoins))}
          </span>
        </div>
        <span
          role="button"
          tabIndex={0}
          onClick={(e) => {
            e.stopPropagation()
            onBuy()
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault()
              e.stopPropagation()
              onBuy()
            }
          }}
          className={cn(
            "inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-[12px] font-bold transition-all",
            outOfStock
              ? "bg-white/5 text-muted-c cursor-not-allowed"
              : canAfford
                ? "gradient-karol text-primary-foreground cursor-pointer"
                : "bg-danger-15 text-danger cursor-pointer",
          )}
        >
          <Zap className="w-3.5 h-3.5" />
          خرید
        </span>
      </div>
    </button>
  )
}

function EmptyState({
  icon: Icon,
  title,
  desc,
  action,
}: {
  icon: React.ComponentType<{ className?: string }>
  title: string
  desc: string
  action?: React.ReactNode
}) {
  return (
    <div className="rounded-2xl border border-dashed border-hair bg-surface/50 p-10 text-center">
      <div className="mx-auto w-14 h-14 rounded-2xl bg-accent-15 flex items-center justify-center mb-3">
        <Icon className="w-6 h-6 text-accent-soft" />
      </div>
      <p className="text-sm font-bold text-primary-c">{title}</p>
      <p className="text-[12px] text-muted-c mt-1 leading-relaxed max-w-sm mx-auto">
        {desc}
      </p>
      {action}
    </div>
  )
}
