"use client"

import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import { useApp } from "@/lib/store"
import { api, formatBytes, timeAgo, faDigits } from "@/lib/format"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Progress } from "@/components/ui/progress"
import { Dialog, DialogContent, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  HardDrive,
  Upload as UploadIcon,
  Search,
  Image as ImageIcon,
  Film,
  Music as MusicIcon,
  FileText,
  Play,
  MoreVertical,
  Link2,
  Globe,
  Lock,
  Trash2,
  ChevronLeft,
  ChevronRight,
  X,
  Loader2,
  File as FileIcon,
  Download,
  Sparkles,
} from "lucide-react"

interface DriveFile {
  id: string
  name: string
  url: string
  size: string
  mime: string
  category: string
  isPublic: boolean
  createdAt: string
}

interface QuotaStats {
  used: string
  limit: string
  remaining: string
  resetAt: string
}

interface UploadTask {
  id: string
  file: File
  progress: number
  status: "uploading" | "done" | "error"
  error?: string
}

const TABS: { key: string; label: string }[] = [
  { key: "all", label: "همه" },
  { key: "image", label: "تصاویر" },
  { key: "video", label: "ویدیو" },
  { key: "audio", label: "صوت" },
  { key: "gif", label: "گیف" },
  { key: "file", label: "فایل‌ها" },
]

function uploadWithProgress(
  url: string,
  fd: FormData,
  onProgress: (pct: number) => void,
): Promise<any> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest()
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100))
    }
    xhr.onload = () => {
      try {
        const r = JSON.parse(xhr.responseText || "{}")
        if (xhr.status >= 200 && xhr.status < 300) resolve(r)
        else reject(new Error(r.error || `خطا ${xhr.status}`))
      } catch {
        reject(new Error(`خطا ${xhr.status}`))
      }
    }
    xhr.onerror = () => reject(new Error("خطای شبکه"))
    xhr.open("POST", url)
    xhr.send(fd)
  })
}

function fileExt(name: string): string {
  const i = name.lastIndexOf(".")
  return i >= 0 ? name.slice(i + 1).toUpperCase() : "FILE"
}

export default function DriveSection() {
  const { toast } = useApp()

  const [files, setFiles] = useState<DriveFile[]>([])
  const [loading, setLoading] = useState(true)
  const [loadingMore, setLoadingMore] = useState(false)
  const [nextCursor, setNextCursor] = useState<string | null>(null)
  const [tab, setTab] = useState("all")
  const [search, setSearch] = useState("")
  const [quota, setQuota] = useState<QuotaStats | null>(null)

  const [uploading, setUploading] = useState<UploadTask[]>([])
  const [dragOver, setDragOver] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null)
  const [videoOpen, setVideoOpen] = useState<DriveFile | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<DriveFile | null>(null)
  const [deleting, setDeleting] = useState(false)

  const loadFiles = useCallback(async (reset = true) => {
    if (reset) {
      setLoading(true)
    } else {
      setLoadingMore(true)
    }
    try {
      const params = new URLSearchParams()
      if (tab !== "all") params.set("category", tab)
      const r = await api<{ files: DriveFile[]; nextCursor: string | null }>(
        `/api/drive/files?${params.toString()}`,
      )
      if (reset) {
        setFiles(r.files)
      } else {
        setFiles((prev) => [...prev, ...r.files])
      }
      setNextCursor(r.nextCursor)
    } catch (e: any) {
      toast(e.message || "خطا در بارگذاری فایل‌ها", "error")
    } finally {
      setLoading(false)
      setLoadingMore(false)
    }
  }, [tab, toast])

  const loadQuota = useCallback(async () => {
    try {
      const r = await api<QuotaStats>("/api/drive/stats")
      setQuota(r)
    } catch {
      // ignore
    }
  }, [])

  useEffect(() => {
    loadFiles(true)
  }, [loadFiles])

  useEffect(() => {
    loadQuota()
  }, [loadQuota])

  const filtered = useMemo(() => {
    if (!search.trim()) return files
    const q = search.trim().toLowerCase()
    return files.filter((f) => f.name.toLowerCase().includes(q))
  }, [files, search])

  const mediaItems = useMemo(() => filtered.filter((f) => f.category === "image" || f.category === "gif"), [filtered])

  const startUpload = useCallback(
    async (fileList: FileList | File[]) => {
      const list = Array.from(fileList)
      if (!list.length) return

      const tasks: UploadTask[] = list.map((f, i) => ({
        id: `${Date.now()}-${i}-${f.name}`,
        file: f,
        progress: 0,
        status: "uploading",
      }))
      setUploading((prev) => [...prev, ...tasks])

      for (const task of tasks) {
        const fd = new FormData()
        fd.append("file", task.file)
        fd.append("category", "drive")
        try {
          await uploadWithProgress("/api/upload", fd, (pct) => {
            setUploading((prev) =>
              prev.map((t) => (t.id === task.id ? { ...t, progress: pct } : t)),
            )
          })
          setUploading((prev) =>
            prev.map((t) => (t.id === task.id ? { ...t, status: "done", progress: 100 } : t)),
          )
        } catch (e: any) {
          setUploading((prev) =>
            prev.map((t) =>
              t.id === task.id ? { ...t, status: "error", error: e.message } : t,
            ),
          )
          toast(e.message || `آپلود ${task.file.name} ناموفق بود`, "error")
        }
      }

      await loadFiles(true)
      await loadQuota()
      setUploading((prev) => prev.filter((t) => t.status === "uploading"))
      toast("آپلود کامل شد", "success")
    },
    [loadFiles, loadQuota, toast],
  )

  const onFilePick = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.length) startUpload(e.target.files)
    e.target.value = ""
  }

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(false)
    if (e.dataTransfer.files?.length) startUpload(e.dataTransfer.files)
  }

  const loadMore = async () => {
    if (!nextCursor || loadingMore) return
    setLoadingMore(true)
    try {
      const params = new URLSearchParams()
      if (tab !== "all") params.set("category", tab)
      params.set("cursor", nextCursor)
      const r = await api<{ files: DriveFile[]; nextCursor: string | null }>(
        `/api/drive/files?${params.toString()}`,
      )
      setFiles((prev) => [...prev, ...r.files])
      setNextCursor(r.nextCursor)
    } catch (e: any) {
      toast(e.message || "خطا", "error")
    } finally {
      setLoadingMore(false)
    }
  }

  const copyLink = async (f: DriveFile) => {
    try {
      await navigator.clipboard.writeText(window.location.origin + f.url)
      toast("لینک کپی شد", "success")
    } catch {
      toast("کپی لینک ناموفق بود", "error")
    }
  }

  const togglePublic = async (f: DriveFile) => {
    try {
      await api(`/api/drive/files/${f.id}`, {
        method: "PATCH",
        json: { isPublic: !f.isPublic },
      })
      setFiles((prev) =>
        prev.map((x) => (x.id === f.id ? { ...x, isPublic: !f.isPublic } : x)),
      )
      toast(f.isPublic ? "فایل خصوصی شد" : "فایل عمومی شد", "success")
    } catch (e: any) {
      toast(e.message || "خطا", "error")
    }
  }

  const confirmDelete = async () => {
    if (!deleteTarget) return
    setDeleting(true)
    try {
      await api(`/api/drive/files/${deleteTarget.id}`, { method: "DELETE" })
      setFiles((prev) => prev.filter((x) => x.id !== deleteTarget.id))
      toast("فایل حذف شد", "success")
      setDeleteTarget(null)
    } catch (e: any) {
      toast(e.message || "خطا در حذف", "error")
    } finally {
      setDeleting(false)
    }
  }

  const usedPct = quota
    ? Math.min(100, (Number(quota.used) / Math.max(1, Number(quota.limit))) * 100)
    : 0

  return (
    <div className="min-h-full">
      <div className="mx-auto max-w-7xl px-3 py-4 sm:px-5 sm:py-6 space-y-4">
        <QuotaHeader quota={quota} usedPct={usedPct} />

        <UploadZone
          dragOver={dragOver}
          setDragOver={setDragOver}
          onDrop={onDrop}
          onPick={() => fileInputRef.current?.click()}
          uploading={uploading}
        />
        <input
          ref={fileInputRef}
          type="file"
          multiple
          className="hidden"
          onChange={onFilePick}
        />

        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-1 overflow-x-auto no-scrollbar -mx-1 px-1">
            {TABS.map((t) => (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                className={cn(
                  "shrink-0 rounded-full px-3.5 py-1.5 text-xs font-medium transition-colors",
                  tab === t.key
                    ? "bg-primary text-primary-foreground shadow-soft"
                    : "bg-card text-muted-foreground hover:text-foreground border border-border",
                )}
              >
                {t.label}
              </button>
            ))}
          </div>
          <div className="relative sm:w-64">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="جستجوی فایل…"
              className="pr-9 h-9 text-sm"
            />
            {search && (
              <button
                onClick={() => setSearch("")}
                className="absolute left-2 top-1/2 -translate-y-1/2 p-1 rounded-md hover:bg-accent"
              >
                <X className="h-3.5 w-3.5 text-muted-foreground" />
              </button>
            )}
          </div>
        </div>

        {loading ? (
          <SkeletonGrid />
        ) : filtered.length === 0 ? (
          <EmptyState />
        ) : (
          <Gallery
            files={filtered}
            onOpenImage={(f) => {
              const idx = mediaItems.findIndex((m) => m.id === f.id)
              if (idx >= 0) setLightboxIndex(idx)
            }}
            onOpenVideo={(f) => setVideoOpen(f)}
            onCopy={copyLink}
            onTogglePublic={togglePublic}
            onDelete={setDeleteTarget}
          />
        )}

        {nextCursor && !loading && (
          <div className="flex justify-center pt-2">
            <Button
              variant="outline"
              onClick={loadMore}
              disabled={loadingMore}
            >
              {loadingMore ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                "بارگذاری بیشتر"
              )}
            </Button>
          </div>
        )}
      </div>

      <Lightbox
        items={mediaItems}
        index={lightboxIndex}
        onClose={() => setLightboxIndex(null)}
        onPrev={() =>
          setLightboxIndex((i) =>
            i === null ? null : (i - 1 + mediaItems.length) % mediaItems.length,
          )
        }
        onNext={() =>
          setLightboxIndex((i) =>
            i === null ? null : (i + 1) % mediaItems.length,
          )
        }
      />

      <VideoDialog file={videoOpen} onClose={() => setVideoOpen(null)} />

      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(o) => !o && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف فایل</AlertDialogTitle>
            <AlertDialogDescription>
              آیا از حذف «{deleteTarget?.name}» مطمئن هستید؟ این عمل قابل بازگشت نیست.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault()
                confirmDelete()
              }}
              disabled={deleting}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              {deleting ? <Loader2 className="h-4 w-4 animate-spin" /> : "حذف"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

function QuotaHeader({ quota, usedPct }: { quota: QuotaStats | null; usedPct: number }) {
  return (
    <div className="glass rounded-2xl p-4 sm:p-5 border border-border shadow-soft">
      <div className="flex items-center gap-3 mb-3">
        <div className="h-10 w-10 rounded-xl gradient-karol flex items-center justify-center shrink-0">
          <HardDrive className="h-5 w-5 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <h2 className="text-sm font-semibold truncate">سهمیه آپلود روزانه</h2>
          <p className="text-xs text-muted-foreground truncate">
            هر روز ساعت ۰۰:۰۰ به‌روزرسانی می‌شود
          </p>
        </div>
      </div>
      <div className="space-y-2">
        <Progress value={usedPct} className="h-2.5" />
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>
            {quota
              ? `${formatBytes(quota.used)} از ${formatBytes(quota.limit)}`
              : "در حال بارگذاری…"}
          </span>
          <span className="text-gold font-medium">
            {quota ? `${formatBytes(quota.remaining)} باقی‌مانده` : ""}
          </span>
        </div>
      </div>
    </div>
  )
}

function UploadZone({
  dragOver,
  setDragOver,
  onDrop,
  onPick,
  uploading,
}: {
  dragOver: boolean
  setDragOver: (b: boolean) => void
  onDrop: (e: React.DragEvent) => void
  onPick: () => void
  uploading: UploadTask[]
}) {
  return (
    <div className="space-y-3">
      <div
        onClick={onPick}
        onDragOver={(e) => {
          e.preventDefault()
          setDragOver(true)
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={onDrop}
        className={cn(
          "rounded-2xl border-2 border-dashed p-6 sm:p-8 cursor-pointer transition-colors text-center",
          dragOver
            ? "border-primary bg-primary/5"
            : "border-border hover:border-primary/50 bg-card/40",
        )}
      >
        <div className="mx-auto mb-3 h-12 w-12 rounded-xl gradient-karol flex items-center justify-center">
          <UploadIcon className="h-6 w-6 text-white" />
        </div>
        <p className="text-sm font-medium">فایل‌ها را اینجا رها کنید یا کلیک کنید</p>
        <p className="text-xs text-muted-foreground mt-1">
          چندین فایل به‌طور همزمان پشتیبانی می‌شود — تصویر، ویدیو، صوت، گیف و…
        </p>
        <Button size="sm" className="mt-4" onClick={(e) => { e.stopPropagation(); onPick() }}>
          <UploadIcon className="h-4 w-4" />
          انتخاب فایل
        </Button>
      </div>

      {uploading.length > 0 && (
        <div className="space-y-2">
          {uploading.map((t) => (
            <div
              key={t.id}
              className="rounded-xl border border-border bg-card/60 p-3 flex items-center gap-3"
            >
              <div className="h-8 w-8 rounded-lg bg-muted flex items-center justify-center shrink-0">
                {t.status === "error" ? (
                  <X className="h-4 w-4 text-destructive" />
                ) : t.status === "done" ? (
                  <Sparkles className="h-4 w-4 text-emerald-500" />
                ) : (
                  <Loader2 className="h-4 w-4 animate-spin text-primary" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-xs font-medium truncate">{t.file.name}</p>
                  <span className="text-[10px] text-muted-foreground shrink-0">
                    {t.status === "error"
                      ? "خطا"
                      : t.status === "done"
                        ? "تکمیل شد"
                        : `${faDigits(t.progress)}٪`}
                  </span>
                </div>
                <Progress value={t.progress} className="h-1.5 mt-1.5" />
              </div>
              <span className="text-[10px] text-muted-foreground shrink-0 hidden sm:inline">
                {formatBytes(t.file.size)}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function Gallery({
  files,
  onOpenImage,
  onOpenVideo,
  onCopy,
  onTogglePublic,
  onDelete,
}: {
  files: DriveFile[]
  onOpenImage: (f: DriveFile) => void
  onOpenVideo: (f: DriveFile) => void
  onCopy: (f: DriveFile) => void
  onTogglePublic: (f: DriveFile) => void
  onDelete: (f: DriveFile) => void
}) {
  const media = files.filter((f) => f.category === "image" || f.category === "gif" || f.category === "video")
  const rows = files.filter((f) => f.category === "audio" || f.category === "file")

  return (
    <div className="space-y-5">
      {media.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2.5 sm:gap-3">
          {media.map((f) => (
            <MediaCard
              key={f.id}
              file={f}
              onOpenImage={onOpenImage}
              onOpenVideo={onOpenVideo}
              onCopy={onCopy}
              onTogglePublic={onTogglePublic}
              onDelete={onDelete}
            />
          ))}
        </div>
      )}

      {rows.length > 0 && (
        <div className="space-y-2">
          {rows.map((f) => (
            <RowItem
              key={f.id}
              file={f}
              onCopy={onCopy}
              onTogglePublic={onTogglePublic}
              onDelete={onDelete}
            />
          ))}
        </div>
      )}
    </div>
  )
}

function MediaCard({
  file,
  onOpenImage,
  onOpenVideo,
  onCopy,
  onTogglePublic,
  onDelete,
}: {
  file: DriveFile
  onOpenImage: (f: DriveFile) => void
  onOpenVideo: (f: DriveFile) => void
  onCopy: (f: DriveFile) => void
  onTogglePublic: (f: DriveFile) => void
  onDelete: (f: DriveFile) => void
}) {
  const isVideo = file.category === "video"
  return (
    <div className="group relative aspect-square rounded-xl overflow-hidden border border-border bg-card">
      {isVideo ? (
        <button
          onClick={() => onOpenVideo(file)}
          className="absolute inset-0 w-full h-full"
          aria-label={`پخش ${file.name}`}
        >
          <video
            src={file.url}
            className="w-full h-full object-cover"
            preload="metadata"
            muted
          />
          <div className="absolute inset-0 flex items-center justify-center bg-black/30 group-hover:bg-black/40 transition-colors">
            <span className="h-10 w-10 rounded-full bg-white/90 flex items-center justify-center shadow-soft">
              <Play className="h-5 w-5 text-black fill-black mr-0.5" />
            </span>
          </div>
        </button>
      ) : (
        <button
          onClick={() => onOpenImage(file)}
          className="absolute inset-0 w-full h-full"
          aria-label={file.name}
        >
          { }
          <img
            src={file.url}
            alt={file.name}
            loading="lazy"
            className="w-full h-full object-cover transition-transform group-hover:scale-105"
          />
        </button>
      )}

      <div className="absolute top-1.5 left-1.5 flex items-center gap-1">
        {file.isPublic && (
          <Badge className="h-5 px-1.5 text-[10px] bg-gold text-gold-foreground gap-0.5">
            <Globe className="h-2.5 w-2.5" />
            عمومی
          </Badge>
        )}
      </div>

      <div className="absolute top-1.5 right-1.5">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              className="h-7 w-7 rounded-lg bg-black/50 backdrop-blur text-white flex items-center justify-center hover:bg-black/70 transition-colors"
              aria-label="منو"
            >
              <MoreVertical className="h-3.5 w-3.5" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-44">
            <DropdownMenuItem onClick={() => onCopy(file)}>
              <Link2 className="h-4 w-4" />
              کپی لینک
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onTogglePublic(file)}>
              {file.isPublic ? (
                <>
                  <Lock className="h-4 w-4" />
                  خصوصی کردن
                </>
              ) : (
                <>
                  <Globe className="h-4 w-4" />
                  عمومی کردن
                </>
              )}
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <a href={file.url} download={file.name} className="flex items-center">
                <Download className="h-4 w-4" />
                دانلود
              </a>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={() => onDelete(file)}
              className="text-destructive focus:text-destructive"
            >
              <Trash2 className="h-4 w-4" />
              حذف
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="absolute bottom-0 inset-x-0 p-2 bg-gradient-to-t from-black/80 to-transparent">
        <p className="text-[11px] text-white font-medium truncate">{file.name}</p>
        <p className="text-[10px] text-white/70">
          {formatBytes(file.size)} · {timeAgo(file.createdAt)}
        </p>
      </div>
    </div>
  )
}

function RowItem({
  file,
  onCopy,
  onTogglePublic,
  onDelete,
}: {
  file: DriveFile
  onCopy: (f: DriveFile) => void
  onTogglePublic: (f: DriveFile) => void
  onDelete: (f: DriveFile) => void
}) {
  const isAudio = file.category === "audio"
  return (
    <div className="rounded-xl border border-border bg-card p-3 flex items-center gap-3">
      <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center shrink-0">
        {isAudio ? (
          <MusicIcon className="h-5 w-5 text-amber-500" />
        ) : (
          <FileIcon className="h-5 w-5 text-emerald-500" />
        )}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <p className="text-sm font-medium truncate">{file.name}</p>
          {file.isPublic && (
            <Badge className="h-4 px-1.5 text-[9px] bg-gold text-gold-foreground gap-0.5 shrink-0">
              <Globe className="h-2.5 w-2.5" />
              عمومی
            </Badge>
          )}
        </div>
        <p className="text-xs text-muted-foreground">
          {formatBytes(file.size)} · {timeAgo(file.createdAt)} · {fileExt(file.name)}
        </p>
        {isAudio && (
          <audio
            controls
            preload="metadata"
            src={file.url}
            className="w-full mt-2 h-8"
          />
        )}
      </div>
      <div className="flex items-center gap-1 shrink-0">
        <a
          href={file.url}
          download={file.name}
          className="h-8 w-8 rounded-lg hover:bg-accent flex items-center justify-center"
          aria-label="دانلود"
        >
          <Download className="h-4 w-4 text-muted-foreground" />
        </a>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              className="h-8 w-8 rounded-lg hover:bg-accent flex items-center justify-center"
              aria-label="منو"
            >
              <MoreVertical className="h-4 w-4 text-muted-foreground" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-44">
            <DropdownMenuItem onClick={() => onCopy(file)}>
              <Link2 className="h-4 w-4" />
              کپی لینک
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onTogglePublic(file)}>
              {file.isPublic ? (
                <>
                  <Lock className="h-4 w-4" />
                  خصوصی کردن
                </>
              ) : (
                <>
                  <Globe className="h-4 w-4" />
                  عمومی کردن
                </>
              )}
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={() => onDelete(file)}
              className="text-destructive focus:text-destructive"
            >
              <Trash2 className="h-4 w-4" />
              حذف
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  )
}

function Lightbox({
  items,
  index,
  onClose,
  onPrev,
  onNext,
}: {
  items: DriveFile[]
  index: number | null
  onClose: () => void
  onPrev: () => void
  onNext: () => void
}) {
  useEffect(() => {
    if (index === null) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose()
      else if (e.key === "ArrowLeft") onNext()
      else if (e.key === "ArrowRight") onPrev()
    }
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [index, onClose, onPrev, onNext])

  if (index === null || !items[index]) return null
  const f = items[index]

  return (
    <Dialog open={index !== null} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-4xl p-0 overflow-hidden bg-black/95 border-border">
        <DialogTitle className="sr-only">{f.name}</DialogTitle>
        <div className="relative flex items-center justify-center">
          {items.length > 1 && (
            <button
              onClick={onPrev}
              className="absolute right-2 z-10 h-10 w-10 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center"
              aria-label="قبلی"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          )}
          { }
          <img
            src={f.url}
            alt={f.name}
            className="max-h-[80vh] w-auto max-w-full object-contain"
          />
          {items.length > 1 && (
            <button
              onClick={onNext}
              className="absolute left-2 z-10 h-10 w-10 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center"
              aria-label="بعدی"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
          )}
          <button
            onClick={onClose}
            className="absolute top-2 left-2 z-10 h-9 w-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center"
            aria-label="بستن"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="px-4 py-3 bg-black/80 text-white border-t border-white/10">
          <div className="flex items-center justify-between gap-3">
            <p className="text-sm font-medium truncate">{f.name}</p>
            <div className="flex items-center gap-2 shrink-0">
              <a
                href={f.url}
                download={f.name}
                className="text-xs px-2 py-1 rounded-md bg-white/10 hover:bg-white/20 flex items-center gap-1"
              >
                <Download className="h-3.5 w-3.5" />
                دانلود
              </a>
              <span className="text-xs text-white/60">
                {formatBytes(f.size)} · {faDigits(index + 1)} از {faDigits(items.length)}
              </span>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

function VideoDialog({ file, onClose }: { file: DriveFile | null; onClose: () => void }) {
  return (
    <Dialog open={!!file} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-3xl p-0 overflow-hidden bg-black/95 border-border">
        <DialogTitle className="sr-only">{file?.name}</DialogTitle>
        {file && (
          <video
            src={file.url}
            controls
            autoPlay
            className="w-full max-h-[80vh] bg-black"
          />
        )}
        {file && (
          <div className="px-4 py-3 bg-black/80 text-white border-t border-white/10 flex items-center justify-between gap-3">
            <p className="text-sm font-medium truncate">{file.name}</p>
            <a
              href={file.url}
              download={file.name}
              className="text-xs px-2 py-1 rounded-md bg-white/10 hover:bg-white/20 flex items-center gap-1 shrink-0"
            >
              <Download className="h-3.5 w-3.5" />
              دانلود
            </a>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

function EmptyState() {
  return (
    <div className="text-center py-16">
      <div className="mx-auto mb-4 h-16 w-16 rounded-2xl bg-muted flex items-center justify-center">
        <HardDrive className="h-8 w-8 text-muted-foreground" />
      </div>
      <p className="text-sm font-medium mb-1">هنوز فایلی آپلود نکرده‌اید</p>
      <p className="text-xs text-muted-foreground">
        فایل‌های خود را بکشید و رها کنید یا از دکمه بالا استفاده کنید
      </p>
    </div>
  )
}

function SkeletonGrid() {
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2.5 sm:gap-3">
        {Array.from({ length: 12 }).map((_, i) => (
          <Skeleton key={i} className="aspect-square rounded-xl" />
        ))}
      </div>
    </div>
  )
}
