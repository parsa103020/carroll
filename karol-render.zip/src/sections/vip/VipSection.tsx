"use client"

import { useEffect, useState } from "react"
import { useApp } from "@/lib/store"
import { api, formatNumber, faDigits, formatDate, formatBytes } from "@/lib/format"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Crown,
  Sparkles,
  MessageCircle,
  HardDrive,
  Shield,
  Headphones,
  Zap,
  Check,
  ArrowLeft,
  Coins,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface VipStatus {
  isVip: boolean
  vipExpiresAt: string | null
  bonusUploadBytes: string
  dailyUploadLimitBytes: string
  pricePerMonth: string
}

const PERKS = [
  {
    icon: MessageCircle,
    title: "چت اختصاصی VIP",
    desc: "دسترسی به اتاق گفتگوی ویژه اعضای وی‌آی‌پی",
  },
  {
    icon: HardDrive,
    title: "آپلود بیشتر",
    desc: "افزایش سهمیه روزانه آپلود با خرید اشتراک",
  },
  {
    icon: Crown,
    title: "نشان VIP",
    desc: "نشان طلایی کنار نام شما در همه بخش‌ها",
  },
  {
    icon: Headphones,
    title: "پشتیبانی اولویت‌دار",
    desc: "پاسخ سریع‌تر به تیکت‌ها و درخواست‌ها",
  },
  {
    icon: Zap,
    title: "دسترسی زودهنگام",
    desc: "امکانات جدید قبل از عموم کاربران",
  },
  {
    icon: Shield,
    title: "آرشیو محتوا",
    desc: "دسترسی به محتوای آرشیوی کارول",
  },
]

export default function VipSection() {
  const { user, setSection, toast } = useApp()
  const [status, setStatus] = useState<VipStatus | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      try {
        const r = await api<VipStatus>("/api/vip/status")
        if (!cancelled) setStatus(r)
      } catch (e: any) {
        if (!cancelled) toast(e.message || "خطا در بارگذاری وضعیت VIP", "error")
      } finally {
        if (!cancelled) setLoading(false)
      }
    })()
    return () => {
      cancelled = true
    }
  }, [toast])

  if (loading || !status) {
    return (
      <div className="min-h-full flex items-center justify-center p-10">
        <div className="text-center">
          <Crown className="w-10 h-10 mx-auto mb-3 text-gold animate-karol-pulse" />
          <p className="text-sm text-muted-foreground">در حال بارگذاری بخش VIP…</p>
        </div>
      </div>
    )
  }

  const isVip = status.isVip && status.vipExpiresAt && new Date(status.vipExpiresAt) > new Date()

  if (isVip) {
    const expires = new Date(status.vipExpiresAt!)
    const daysLeft = Math.max(0, Math.ceil((expires.getTime() - Date.now()) / 86400000))
    return (
      <div className="min-h-full p-3 sm:p-4 lg:p-6 max-w-4xl mx-auto w-full">
        <div className="relative overflow-hidden rounded-2xl gradient-gold p-6 sm:p-8 shadow-soft mb-5">
          <div className="absolute -left-16 -top-16 w-56 h-56 rounded-full bg-white/20 blur-3xl" />
          <div className="absolute -right-12 -bottom-12 w-48 h-48 rounded-full bg-black/10 blur-2xl" />
          <Sparkles className="absolute top-4 left-4 w-5 h-5 text-gold-foreground/40" />
          <Sparkles className="absolute bottom-6 right-8 w-4 h-4 text-gold-foreground/30" />
          <div className="relative text-center">
            <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-white/25 backdrop-blur flex items-center justify-center">
              <Crown className="w-10 h-10 text-gold-foreground" />
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-gold-foreground mb-1">
              شما عضو VIP هستید
            </h2>
            <p className="text-sm text-gold-foreground/80 mb-4">
              از مزایای ویژه کارول لذت می‌برید
            </p>
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur rounded-full px-4 py-2 text-gold-foreground">
              <ClockIcon />
              <span className="text-xs sm:text-sm font-medium">
                انقضا: {formatDate(expires)} ({faDigits(daysLeft)} روز مانده)
              </span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-5">
          <StatCard
            label="سهمیه آپلود روزانه"
            value={formatBytes(BigInt(status.dailyUploadLimitBytes))}
            icon={HardDrive}
          />
          <StatCard
            label="پاداش آپلود VIP"
            value={`+${formatBytes(BigInt(status.bonusUploadBytes))}`}
            icon={Sparkles}
          />
        </div>

        <div className="rounded-2xl border border-border bg-card p-4 sm:p-5">
          <h3 className="font-bold mb-3 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-gold" />
            مزایای فعال شما
          </h3>
          <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {PERKS.map((p) => (
              <li key={p.title} className="flex items-start gap-2 p-2 rounded-lg hover:bg-accent/40">
                <div className="w-7 h-7 rounded-lg bg-gold/10 flex items-center justify-center shrink-0">
                  <Check className="w-4 h-4 text-gold" />
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-medium">{p.title}</div>
                  <div className="text-[11px] text-muted-foreground">{p.desc}</div>
                </div>
              </li>
            ))}
          </ul>
        </div>

        <div className="mt-5 flex justify-center">
          <Button variant="outline" onClick={() => setSection("shop")}>
            <Crown className="w-4 h-4 ml-1 text-gold" /> تمدید اشتراک
          </Button>
        </div>
      </div>
    )
  }

  const price = parseInt(status.pricePerMonth, 10) || 0

  return (
    <div className="min-h-full p-3 sm:p-4 lg:p-6 max-w-4xl mx-auto w-full">
      <div className="mb-4 sm:mb-6 flex items-center gap-2">
        <Crown className="w-5 h-5 text-gold" />
        <h2 className="text-lg sm:text-xl font-bold">بخش VIP کارول</h2>
      </div>

      <div className="relative overflow-hidden rounded-2xl gradient-gold p-6 sm:p-8 shadow-soft mb-5">
        <div className="absolute -left-16 -top-16 w-56 h-56 rounded-full bg-white/20 blur-3xl" />
        <div className="absolute -right-12 -bottom-12 w-48 h-48 rounded-full bg-black/10 blur-2xl" />
        <div className="relative text-center">
          <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-white/25 backdrop-blur flex items-center justify-center">
            <Crown className="w-10 h-10 text-gold-foreground" />
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-gold-foreground mb-1">
            اشتراک VIP کارول
          </h2>
          <p className="text-sm text-gold-foreground/80 mb-5 max-w-md mx-auto">
            با عضویت VIP از تمام امکانات ویژه کارول استفاده کنید و تجربه‌ای متفاوت داشته باشید.
          </p>
          <div className="inline-flex flex-col items-center gap-1 bg-white/20 backdrop-blur rounded-2xl px-6 py-3">
            <span className="text-[11px] text-gold-foreground/80">قیمت ماهانه</span>
            <div className="flex items-baseline gap-1">
              <span className="text-3xl font-black text-gold-foreground tabular-nums">
                {faDigits(formatNumber(price))}
              </span>
              <span className="text-xs text-gold-foreground/80">تومان</span>
            </div>
          </div>
          <div className="mt-5">
            <Button
              size="lg"
              onClick={() => setSection("shop")}
              className="bg-gold-foreground text-gold hover:bg-gold-foreground/90 font-bold"
            >
              <Crown className="w-5 h-5 ml-1" /> خرید اشتراک VIP
            </Button>
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-border bg-card p-4 sm:p-5 mb-5">
        <h3 className="font-bold mb-3 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-gold" />
          VIP چیست؟
        </h3>
        <p className="text-sm text-muted-foreground leading-relaxed">
          اشتراک VIP کارول به شما اجازه می‌دهد از امکانات ویژه‌ای که برای کاربران عادی در دسترس نیست
          بهره‌مند شوید. از چت اختصاصی VIP گرفته تا افزایش سهمیه آپلود و پشتیبانی اولویت‌دار؛ همه
          چیزی که برای تجربه‌ای حرفه‌ای نیاز دارید.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {PERKS.map((p) => (
          <div
            key={p.title}
            className="rounded-2xl border border-border bg-card p-4 hover:border-gold/40 hover:shadow-soft transition-all"
          >
            <div className="w-10 h-10 rounded-xl bg-gold/10 flex items-center justify-center mb-3">
              <p.icon className="w-5 h-5 text-gold" />
            </div>
            <h4 className="font-bold text-sm mb-1">{p.title}</h4>
            <p className="text-xs text-muted-foreground leading-relaxed">{p.desc}</p>
          </div>
        ))}
      </div>

      <div className="mt-6 rounded-2xl border border-dashed border-gold/40 bg-gold/5 p-4 flex flex-col sm:flex-row items-center gap-3">
        <div className="w-12 h-12 rounded-full bg-gold/15 flex items-center justify-center shrink-0">
          <Coins className="w-6 h-6 text-gold" />
        </div>
        <div className="flex-1 text-center sm:text-right">
          <div className="font-bold text-sm">آیا موجودی کافی دارید؟</div>
          <div className="text-xs text-muted-foreground">
            برای خرید VIP ابتدا مبلغ را کارت‌به‌کارت کرده و رسید را در فروشگاه بارگذاری کنید.
          </div>
        </div>
        <Button variant="outline" onClick={() => setSection("shop")} className="border-gold/40 text-gold hover:bg-gold/10">
          رفتن به فروشگاه
          <ArrowLeft className="w-4 h-4 mr-1" />
        </Button>
      </div>
    </div>
  )
}

function StatCard({
  label,
  value,
  icon: Icon,
}: {
  label: string
  value: string
  icon: React.ComponentType<{ className?: string }>
}) {
  return (
    <div className="rounded-2xl border border-border bg-card p-4 flex items-center gap-3">
      <div className="w-11 h-11 rounded-xl bg-gold/10 flex items-center justify-center shrink-0">
        <Icon className="w-5 h-5 text-gold" />
      </div>
      <div className="min-w-0">
        <div className="text-[11px] text-muted-foreground">{label}</div>
        <div className="font-bold text-sm tabular-nums truncate">{value}</div>
      </div>
    </div>
  )
}

function ClockIcon() {
  return (
    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" strokeLinecap="round" />
    </svg>
  )
}
