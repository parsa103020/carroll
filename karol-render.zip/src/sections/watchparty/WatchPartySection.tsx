"use client"

import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import { io, type Socket } from "socket.io-client"
import { getSocketUrl } from "@/lib/socket-client"
import { useApp, isAppAdmin } from "@/lib/store"
import { api, faDigits, timeAgo } from "@/lib/format"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  Play,
  Pause,
  Plus,
  Users,
  Crown,
  Trash2,
  Loader2,
  MonitorPlay,
  Send,
  ArrowRight,
  Mic,
  MicOff,
  Headphones,
  PhoneOff,
  AlertTriangle,
  Tv,
  MessageSquare,
  Volume2,
  Eye,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { useVoiceRoom, type VoiceMember } from "@/sections/voice/useVoiceRoom"

interface WatchRoom {
  id: string
  name: string
  ownerId: string
  ownerName: string
  ownerAvatar: string | null
  videoUrl: string
  videoTitle: string | null
  videoType: string
  isPlaying: boolean
  currentTime: number
  hostControlOnly?: boolean
  createdAt: string
  messageCount: number
  isOwner: boolean
  canManage: boolean
}

interface WatchMessage {
  id: string
  userId: string | null
  username: string
  content: string
  createdAt: string
}

interface WatchUser {
  id: string
  username: string
  displayName?: string | null
  avatarUrl?: string | null
}

export default function WatchPartySection() {
  const { user, toast } = useApp()
  const [rooms, setRooms] = useState<WatchRoom[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedRoom, setSelectedRoom] = useState<WatchRoom | null>(null)

  async function fetchRooms() {
    try {
      const d = await api<{ rooms: WatchRoom[] }>("/api/watchparty/rooms")
      setRooms(d.rooms)
    } catch {
      toast("خطا در بارگذاری اتاق‌ها", "error")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchRooms()
  }, [])

  if (selectedRoom) {
    return <RoomView room={selectedRoom} onBack={() => { setSelectedRoom(null); fetchRooms() }} />
  }

  return (
    <div className="h-[calc(100vh-3.5rem-4rem)] lg:h-[calc(100vh-3.5rem)] flex flex-col bg-base">
      <div className="px-4 sm:px-6 py-4 border-b border-hair">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div>
            <h1 className="text-xl font-black text-primary-c flex items-center gap-2">
              <MonitorPlay className="w-5 h-5 text-accent" />
              تماشای گروهی
            </h1>
            <p className="text-xs text-muted-c mt-0.5">ویدیو را با دوستان هم‌زمان تماشا کنید و حرف بزنید</p>
          </div>
          <CreateRoomDialog onCreated={fetchRooms} />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto thin-scrollbar p-4 sm:p-6">
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-40 w-full rounded-2xl" />
            ))}
          </div>
        ) : rooms.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="w-16 h-16 rounded-2xl bg-accent-15 flex items-center justify-center mb-4">
              <Tv className="w-8 h-8 text-accent" />
            </div>
            <p className="text-primary-c font-semibold mb-1">هنوز اتاقی ساخته نشده است</p>
            <p className="text-xs text-muted-c">یک ویدیو انتخاب کنید و تماشای گروهی را شروع کنید</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {rooms.map((r) => (
              <RoomCard key={r.id} room={r} onJoin={() => setSelectedRoom(r)} onDeleted={fetchRooms} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

function CreateRoomDialog({ onCreated }: { onCreated: () => void }) {
  const { toast } = useApp()
  const [open, setOpen] = useState(false)
  const [name, setName] = useState("")
  const [videoUrl, setVideoUrl] = useState("")
  const [videoTitle, setVideoTitle] = useState("")
  const [hostControlOnly, setHostControlOnly] = useState(true)
  const [submitting, setSubmitting] = useState(false)

  async function submit() {
    if (!name.trim()) return toast("نام اتاق را وارد کنید", "error")
    if (!videoUrl.trim()) return toast("آدرس ویدیو را وارد کنید", "error")
    setSubmitting(true)
    try {
      await api("/api/watchparty/rooms", {
        method: "POST",
        json: { name, videoUrl, videoTitle: videoTitle || undefined, hostControlOnly },
      })
      toast("اتاق ساخته شد", "success")
      setOpen(false)
      setName("")
      setVideoUrl("")
      setVideoTitle("")
      setHostControlOnly(true)
      onCreated()
    } catch (e: any) {
      toast(e.message || "خطا در ساخت اتاق", "error")
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2 gradient-karol text-white border-0">
          <Plus className="w-4 h-4" />
          اتاق جدید
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>ساخت اتاق تماشای گروهی</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="wr-name">نام اتاق</Label>
            <Input
              id="wr-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="مثلاً: شب فیلم کلاسیک"
              maxLength={60}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="wr-url">آدرس ویدیو</Label>
            <Input
              id="wr-url"
              value={videoUrl}
              onChange={(e) => setVideoUrl(e.target.value)}
              placeholder="https://example.com/video.mp4"
              dir="ltr"
            />
            <p className="text-[11px] text-muted-c">
              لینک مستقیم ویدیو را وارد کنید. فرمت‌های پشتیبانی‌شده: mp4، webm، m3u8، mov. mkv هم با احتیاط پخش می‌شود (فقط اگر کدک H264 باشد).
            </p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="wr-title">عنوان ویدیو (اختیاری)</Label>
            <Input
              id="wr-title"
              value={videoTitle}
              onChange={(e) => setVideoTitle(e.target.value)}
              placeholder="مثلاً: فیلم مستند طبیعت"
              maxLength={200}
            />
          </div>
          <label className="flex items-start gap-2 cursor-pointer p-3 rounded-lg border border-hair bg-surface-2">
            <input
              type="checkbox"
              checked={hostControlOnly}
              onChange={(e) => setHostControlOnly(e.target.checked)}
              className="mt-0.5 accent-[var(--accent)]"
            />
            <div>
              <div className="text-xs font-semibold text-primary-c">فقط میزبان کنترل کند</div>
              <div className="text-[10px] text-muted-c mt-0.5">
                اگر فعال باشد، بیننده‌ها نمی‌توانند ویدیو را پلی/پاز/جابجا کنند — فقط تماشا می‌کنند.
              </div>
            </div>
          </label>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>انصراف</Button>
          <Button
            onClick={submit}
            disabled={submitting}
            className="gradient-karol text-white border-0"
          >
            {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : "ساخت اتاق"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

function RoomCard({
  room,
  onJoin,
  onDeleted,
}: {
  room: WatchRoom
  onJoin: () => void
  onDeleted: () => void
}) {
  const { toast } = useApp()
  const [confirmOpen, setConfirmOpen] = useState(false)
  const [deleting, setDeleting] = useState(false)

  async function del() {
    setDeleting(true)
    try {
      await api(`/api/watchparty/rooms/${room.id}`, { method: "DELETE" })
      toast("اتاق حذف شد", "success")
      setConfirmOpen(false)
      onDeleted()
    } catch (e: any) {
      toast(e.message || "خطا در حذف", "error")
    } finally {
      setDeleting(false)
    }
  }

  return (
    <div className="bg-surface rounded-2xl border border-hair overflow-hidden hover:border-accent/30 transition-colors">
      <div className="aspect-video bg-black relative">
        <video
          src={room.videoUrl}
          className="w-full h-full object-cover opacity-70"
          preload="metadata"
          muted
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-3 gap-2">
          <Badge className="bg-black/60 text-white border-0 backdrop-blur gap-1">
            <MonitorPlay className="w-3 h-3" />
            {room.videoType.toUpperCase()}
          </Badge>
          {room.hostControlOnly !== false && (
            <Badge className="bg-gold/20 text-gold border-0 backdrop-blur gap-1">
              <Crown className="w-3 h-3" />
              فقط میزبان
            </Badge>
          )}
        </div>
      </div>
      <div className="p-4 space-y-3">
        <div>
          <h3 className="font-bold text-primary-c truncate">{room.name}</h3>
          {room.videoTitle && <p className="text-xs text-muted-c truncate mt-0.5">{room.videoTitle}</p>}
        </div>
        <div className="flex items-center justify-between text-[11px] text-muted-c">
          <span className="truncate">ساخته‌شده توسط {room.ownerName}</span>
          <span className="flex items-center gap-1 shrink-0">
            <MessageSquare className="w-3.5 h-3.5" />
            {faDigits(room.messageCount)}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={onJoin} className="flex-1 gap-2 gradient-karol text-white border-0">
            <Tv className="w-4 h-4" />
            ورود به اتاق
          </Button>
          {room.canManage && (
            <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
              <Button
                variant="ghost"
                size="icon"
                className="text-danger hover:text-danger hover:bg-danger-15"
                onClick={() => setConfirmOpen(true)}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>حذف اتاق؟</AlertDialogTitle>
                  <AlertDialogDescription>
                    این اتاق برای همیشه حذف می‌شود. این عمل قابل بازگشت نیست.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>انصراف</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={del}
                    disabled={deleting}
                    className="bg-danger text-white hover:bg-danger/90"
                  >
                    {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : "حذف"}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>
      </div>
    </div>
  )
}

function RoomView({ room, onBack }: { room: WatchRoom; onBack: () => void }) {
  const { user, toast } = useApp()
  const videoRef = useRef<HTMLVideoElement | null>(null)
  const socketRef = useRef<Socket | null>(null)
  const isHostRef = useRef(room.isOwner)
  const isApplyingRemoteRef = useRef(false)
  const lastSyncRef = useRef<number>(0)
  const syncIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const [hostControlOnly, setHostControlOnly] = useState<boolean>(
    room.hostControlOnly !== false,
  )

  const hostControlled =
    hostControlOnly && !room.isOwner
  const canControlVideo = room.isOwner || !hostControlled

  const isMkv = (room.videoType || "").toLowerCase() === "mkv"

  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [videoError, setVideoError] = useState<string | null>(null)
  const [messages, setMessages] = useState<WatchMessage[]>([])
  const [participants, setParticipants] = useState<WatchUser[]>([])
  const [chatInput, setChatInput] = useState("")
  const [chatSending, setChatSending] = useState(false)
  const [showChatMobile, setShowChatMobile] = useState(false)

  const [voiceOpen, setVoiceOpen] = useState(false)

  const messagesEndRef = useRef<HTMLDivElement | null>(null)
  const chatListRef = useRef<HTMLDivElement | null>(null)

  const auth = useMemo(
    () => ({
      userId: user?.id || "",
      username: user?.username || "",
      displayName: user?.displayName,
      avatarUrl: user?.avatarUrl,
    }),
    [user],
  )

  const [iceServers, setIceServers] = useState<RTCIceServer[]>([])
  useEffect(() => {
    api<{ iceServers: RTCIceServer[] }>("/api/voice/ice")
      .then((d) => setIceServers(d.iceServers || []))
      .catch(() => {})
  }, [])

  const voice = useVoiceRoom({ enabled: voiceOpen, auth, iceServers })
  const voiceRoomId = useMemo(() => `watch-${room.id}`, [room.id])

  useEffect(() => {
    if (voiceOpen) {
      voice.joinRoom(voiceRoomId)
    } else if (voice.inRoom) {
      voice.leaveRoom()
    }
  }, [voiceOpen])

  async function fetchMessages() {
    try {
      const d = await api<{ messages: WatchMessage[] }>(`/api/watchparty/rooms/${room.id}/messages`)
      setMessages(d.messages)
    } catch {}
  }

  const sendChat = useCallback(async (content: string) => {
    if (!content.trim() || !socketRef.current?.connected) return
    setChatSending(true)
    try {
      const msg = await api<{ message: WatchMessage }>(`/api/watchparty/rooms/${room.id}/messages`, {
        method: "POST",
        json: { content },
      })
      setMessages((prev) => {
        if (prev.some((m) => m.id === msg.message.id)) return prev
        return [...prev, msg.message]
      })
      socketRef.current?.emit("watch:chat", {
        roomId: room.id,
        user: {
          id: user!.id,
          username: user!.username,
          displayName: user!.displayName,
          avatarUrl: user!.avatarUrl,
        },
        content: msg.message.content,
        createdAt: msg.message.createdAt,
      })
      setChatInput("")
    } catch (e: any) {
      toast(e.message || "خطا در ارسال پیام", "error")
    } finally {
      setChatSending(false)
    }
  }, [room.id, toast, user])

  const syncVideo = useCallback((time: number, playing: boolean) => {
    const v = videoRef.current
    if (!v) return
    isApplyingRemoteRef.current = true
    const drift = Math.abs(v.currentTime - time)
    if (drift > 0.5) {
      try { v.currentTime = time } catch {}
    }
    if (playing && v.paused) {
      v.play().catch(() => {}).finally(() => {
        setTimeout(() => { isApplyingRemoteRef.current = false }, 200)
      })
    } else if (!playing && !v.paused) {
      v.pause()
      setTimeout(() => { isApplyingRemoteRef.current = false }, 200)
    } else {
      isApplyingRemoteRef.current = false
    }
  }, [])

  useEffect(() => {
    fetchMessages()
    const s = io(getSocketUrl(), {
      transports: ["websocket", "polling"],
      auth: {
        userId: user!.id,
        username: user!.username,
        displayName: user!.displayName,
        avatarUrl: user!.avatarUrl,
      },
      reconnection: true,
      reconnectionAttempts: 10,
      reconnectionDelay: 1500,
    })
    socketRef.current = s

    s.on("connect", () => {
      s.emit("watch:join", {
        roomId: room.id,
        user: {
          id: user!.id,
          username: user!.username,
          displayName: user!.displayName,
          avatarUrl: user!.avatarUrl,
        },
        state: room.isOwner
          ? { isPlaying: false, currentTime: 0, videoUrl: room.videoUrl, videoTitle: room.videoTitle }
          : undefined,
      })
    })

    s.on("watch:state", (data: { isPlaying: boolean; currentTime: number; hostSocketId: string | null }) => {
      if (!room.isOwner && data.hostSocketId && data.hostSocketId !== s.id) {
        isHostRef.current = false
      }
      const v = videoRef.current
      if (v) {
        if (data.currentTime > 0) {
          try { v.currentTime = data.currentTime } catch {}
        }
        if (data.isPlaying) v.play().catch(() => {})
      }
    })

    s.on("watch:play", ({ time }: { time: number }) => {
      syncVideo(time, true)
      setIsPlaying(true)
    })
    s.on("watch:pause", ({ time }: { time: number }) => {
      syncVideo(time, false)
      setIsPlaying(false)
    })
    s.on("watch:seek", ({ time }: { time: number }) => {
      const v = videoRef.current
      if (v) {
        isApplyingRemoteRef.current = true
        try { v.currentTime = time } catch {}
        setTimeout(() => { isApplyingRemoteRef.current = false }, 200)
      }
    })
    s.on("watch:time-sync", ({ time }: { time: number }) => {
      const v = videoRef.current
      if (!v) return
      const drift = Math.abs(v.currentTime - time)
      if (drift > 1.5) {
        isApplyingRemoteRef.current = true
        try { v.currentTime = time } catch {}
        setTimeout(() => { isApplyingRemoteRef.current = false }, 200)
      }
    })
    s.on("watch:sync", ({ isPlaying, currentTime }: { isPlaying: boolean; currentTime: number }) => {
      syncVideo(currentTime, isPlaying)
      setIsPlaying(isPlaying)
    })
    s.on("watch:sync-request", ({ target }: { roomId: string; target: string }) => {
      if (!isHostRef.current) return
      const v = videoRef.current
      s.emit("watch:sync", {
        roomId: room.id,
        isPlaying: !v?.paused,
        currentTime: v?.currentTime || 0,
        target,
      })
    })
    s.on("watch:user-joined", ({ user: u }: { roomId: string; user: WatchUser }) => {
      setParticipants((prev) => (prev.some((p) => p.id === u.id) ? prev : [...prev, u]))
    })
    s.on("watch:user-left", ({ socketId }: { roomId: string; socketId: string }) => {
      void socketId
    })
    s.on("watch:chat", (msg: { user: WatchUser; content: string; timestamp: string }) => {
      const newMsg: WatchMessage = {
        id: `${msg.timestamp}-${msg.user.id}-${Math.random()}`,
        userId: msg.user.id,
        username: msg.user.displayName || msg.user.username,
        content: msg.content,
        createdAt: msg.timestamp,
      }
      setMessages((prev) => {
        if (prev.some((m) => m.id === newMsg.id)) return prev
        if (prev.length && prev[prev.length - 1].userId === msg.user.id && prev[prev.length - 1].content === msg.content) {
          const last = prev[prev.length - 1]
          if (Math.abs(new Date(last.createdAt).getTime() - new Date(newMsg.createdAt).getTime()) < 1500) return prev
        }
        return [...prev, newMsg]
      })
    })

    return () => {
      s.emit("watch:leave", { roomId: room.id })
      s.removeAllListeners()
      s.disconnect()
      socketRef.current = null
    }
  }, [room.id, room.isOwner, room.videoUrl, room.videoTitle, syncVideo, user])

  useEffect(() => {
    if (isHostRef.current && socketRef.current?.connected) {
      if (syncIntervalRef.current) clearInterval(syncIntervalRef.current)
      syncIntervalRef.current = setInterval(() => {
        const v = videoRef.current
        if (!v) return
        const now = Date.now()
        if (now - lastSyncRef.current < 4000) return
        lastSyncRef.current = now
        socketRef.current?.emit("watch:time-update", { roomId: room.id, time: v.currentTime })
      }, 5000)
    }
    return () => {
      if (syncIntervalRef.current) {
        clearInterval(syncIntervalRef.current)
        syncIntervalRef.current = null
      }
    }
  }, [room.id])

  useEffect(() => {
    if (chatListRef.current) {
      chatListRef.current.scrollTop = chatListRef.current.scrollHeight
    }
  }, [messages])

  function onPlayClick() {
    const v = videoRef.current
    if (!v) return
    if (!canControlVideo) return
    if (v.paused) {
      v.play().catch(() => {})
      socketRef.current?.emit("watch:play", { roomId: room.id, time: v.currentTime })
    } else {
      v.pause()
      socketRef.current?.emit("watch:pause", { roomId: room.id, time: v.currentTime })
    }
  }

  function onSeek(e: React.SyntheticEvent<HTMLVideoElement>) {
    const v = e.currentTarget
    setCurrentTime(v.currentTime)
    if (isApplyingRemoteRef.current) return
    if (!canControlVideo) return
    socketRef.current?.emit("watch:seek", { roomId: room.id, time: v.currentTime })
  }

  function onPlayEvt() {
    setIsPlaying(true)
  }
  function onPauseEvt() {
    setIsPlaying(false)
  }
  function onTimeEvt(e: React.SyntheticEvent<HTMLVideoElement>) {
    setCurrentTime(e.currentTarget.currentTime)
  }
  function onLoaded(e: React.SyntheticEvent<HTMLVideoElement>) {
    setDuration(e.currentTarget.duration || 0)
  }
  function onError() {
    setVideoError(
      isMkv
        ? "ویدیو بارگذاری نشد. فایل MKV ممکن است در مرورگر پخش نشود — در صورت مشکل، آن را به MP4 تبدیل کنید. ممکن است CORS هم مانع پخش شده باشد."
        : "ویدیو بارگذاری نشد. ممکن است آدرس اشتباه باشد یا CORS مانع پخش شده باشد.",
    )
  }

  async function toggleHostControl() {
    const next = !hostControlOnly
    setHostControlOnly(next)
    try {
      await api(`/api/watchparty/rooms/${room.id}`, {
        method: "PATCH",
        json: { hostControlOnly: next },
      })
      toast(next ? "حالت فقط میزبان فعال شد" : "همه می‌توانند ویدیو را کنترل کنند", "success")
    } catch (e: any) {
      setHostControlOnly(!next)
      toast(e.message || "خطا در تغییر حالت", "error")
    }
  }

  function formatTime(t: number) {
    if (!Number.isFinite(t)) return "۰۰:۰۰"
    const m = Math.floor(t / 60)
    const s = Math.floor(t % 60)
    return `${faDigits(String(m).padStart(2, "0"))}:${faDigits(String(s).padStart(2, "0"))}`
  }

  return (
    <div className="h-[calc(100vh-3.5rem-4rem)] lg:h-[calc(100vh-3.5rem)] flex flex-col bg-base">
      <div className="px-4 sm:px-6 py-3 border-b border-hair flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={onBack}
            className="flex items-center justify-center w-9 h-9 rounded-full hover:bg-white/[0.05]"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
          <div className="min-w-0">
            <h2 className="font-bold text-primary-c truncate flex items-center gap-2">
              <Tv className="w-4 h-4 text-accent shrink-0" />
              {room.name}
            </h2>
            {room.videoTitle && <p className="text-xs text-muted-c truncate">{room.videoTitle}</p>}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="border-hair text-muted-c gap-1">
            <Users className="w-3 h-3" />
            {faDigits(participants.length + 1)}
          </Badge>
          {room.isOwner ? (
            <>
              <Badge className="bg-gold/15 text-gold border-0 gap-1">
                <Crown className="w-3 h-3" /> شما میزبان هستید
              </Badge>
              <button
                type="button"
                onClick={toggleHostControl}
                className={cn(
                  "text-[10px] px-2 py-1 rounded-full border transition-colors",
                  hostControlOnly
                    ? "border-gold/40 bg-gold/10 text-gold"
                    : "border-hair text-muted-c hover:text-primary-c",
                )}
                title="تغییر حالت کنترل ویدیو"
              >
                {hostControlOnly ? "فقط میزبان" : "همه کنترل می‌کنند"}
              </button>
            </>
          ) : hostControlled ? (
            <Badge variant="outline" className="border-accent-soft/40 text-accent-soft gap-1">
              <Eye className="w-3 h-3" /> در حال تماشا
            </Badge>
          ) : null}
        </div>
      </div>

      <div className="flex-1 min-h-0 flex flex-col lg:flex-row">
        <div className="flex-1 min-h-0 flex flex-col bg-black">
          <div className="relative flex-1 min-h-0 bg-black flex items-center justify-center">
            <video
              ref={videoRef}
              src={room.videoUrl}
              controls={canControlVideo}
              playsInline
              className="w-full h-full max-h-full"
              onPlay={onPlayEvt}
              onPause={onPauseEvt}
              onSeeked={onSeek}
              onTimeUpdate={onTimeEvt}
              onLoadedMetadata={onLoaded}
              onError={onError}
            />
            {isMkv && !videoError && (
              <div className="absolute top-3 left-1/2 -translate-x-1/2 z-10 bg-warning-15 border border-warning/40 text-warning text-[11px] px-3 py-1.5 rounded-full backdrop-blur-sm flex items-center gap-1.5 max-w-[90%]">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">فایل MKV ممکن است در مرورگر پخش نشود — در صورت مشکل، به MP4 تبدیل کنید.</span>
              </div>
            )}
            {!canControlVideo && !videoError && (
              <div className="absolute top-3 right-3 z-10 bg-black/60 text-white text-[10px] px-2.5 py-1 rounded-full backdrop-blur-sm flex items-center gap-1 border border-white/10">
                <Eye className="w-3 h-3" />
                فقط میزبان کنترل می‌کند
              </div>
            )}
            {videoError && (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 bg-black/80">
                <AlertTriangle className="w-10 h-10 text-warning mb-3" />
                <p className="text-white font-semibold mb-1">ویدیو پخش نشد</p>
                <p className="text-xs text-white/70 max-w-md">{videoError}</p>
              </div>
            )}
          </div>

          <div className="bg-surface border-t border-hair p-3 flex items-center gap-3">
            <Button
              onClick={onPlayClick}
              size="icon"
              disabled={!canControlVideo}
              className="rounded-full h-10 w-10 gradient-karol text-white border-0 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </Button>
            <div className="text-xs text-muted-c tabular-nums">
              {formatTime(currentTime)} / {formatTime(duration)}
            </div>
            <div className="flex-1" />
            {voiceOpen ? (
              <>
                <VoiceMicToggle voice={voice} />
                <Button
                  onClick={() => setVoiceOpen(false)}
                  variant="ghost"
                  className="text-danger hover:text-danger hover:bg-danger-15 gap-2"
                >
                  <PhoneOff className="w-4 h-4" />
                  <span className="hidden sm:inline">خروج از ویس</span>
                </Button>
              </>
            ) : (
              <Button
                onClick={() => setVoiceOpen(true)}
                variant="outline"
                className="border-hair gap-2"
              >
                <Headphones className="w-4 h-4" />
                <span className="hidden sm:inline">ورود به ویس روم</span>
                <span className="sm:hidden">ویس</span>
              </Button>
            )}
            <Button
              onClick={() => setShowChatMobile((s) => !s)}
              variant="outline"
              size="icon"
              className="lg:hidden border-hair"
            >
              <MessageSquare className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <aside
          className={cn(
            "lg:w-80 xl:w-96 border-l border-hair bg-surface flex flex-col min-h-0",
            showChatMobile ? "flex absolute inset-y-0 right-0 left-0 z-30" : "hidden lg:flex",
          )}
        >
          <div className="px-3 py-2 border-b border-hair flex items-center justify-between">
            <span className="text-xs font-bold text-primary-c flex items-center gap-1.5">
              <MessageSquare className="w-3.5 h-3.5 text-accent" />
              چت اتاق
            </span>
            <button
              onClick={() => setShowChatMobile(false)}
              className="lg:hidden text-muted-c text-xs"
            >
              بستن
            </button>
          </div>
          <div
            ref={chatListRef}
            className="flex-1 overflow-y-auto thin-scrollbar p-3 space-y-2 min-h-0"
          >
            {messages.length === 0 ? (
              <div className="text-center text-xs text-muted-c py-8">
                هنوز پیامی ارسال نشده است
              </div>
            ) : (
              messages.map((m) => {
                const mine = m.userId === user?.id
                return (
                  <div key={m.id} className={cn("flex flex-col gap-0.5", mine ? "items-end" : "items-start")}>
                    <div className="flex items-center gap-1.5 text-[10px] text-muted-c px-1">
                      <span className="font-semibold">{mine ? "شما" : m.username}</span>
                      <span>{timeAgo(m.createdAt)}</span>
                    </div>
                    <div
                      className={cn(
                        "max-w-[85%] px-3 py-1.5 rounded-2xl text-sm",
                        mine
                          ? "bg-accent-15 text-accent-soft rounded-bl-md"
                          : "bg-surface-2 text-primary-c rounded-br-md",
                      )}
                    >
                      {m.content}
                    </div>
                  </div>
                )
              })
            )}
            <div ref={messagesEndRef} />
          </div>
          <div className="p-2 border-t border-hair flex items-center gap-2">
            <Input
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault()
                  sendChat(chatInput)
                }
              }}
              placeholder="پیام بنویسید..."
              className="bg-surface-2 border-hair"
              maxLength={500}
            />
            <Button
              size="icon"
              onClick={() => sendChat(chatInput)}
              disabled={chatSending || !chatInput.trim()}
              className="gradient-karol text-white border-0 shrink-0"
            >
              {chatSending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            </Button>
          </div>
        </aside>
      </div>

      {voice.inRoom && voice.remoteStreams.size > 0 && (
        <div className="sr-only" aria-hidden>
          {Array.from(voice.remoteStreams.entries()).map(([socketId, stream]) => (
            <audio
              key={socketId}
              autoPlay
              ref={(el) => {
                if (el && el.srcObject !== stream) el.srcObject = stream
              }}
            />
          ))}
        </div>
      )}
    </div>
  )
}

function VoiceMicToggle({ voice }: { voice: ReturnType<typeof useVoiceRoom> }) {
  if (!voice.inRoom) {
    return (
      <div className="flex items-center gap-1.5 text-xs text-muted-c px-2">
        <Loader2 className="w-3.5 h-3.5 animate-spin" />
        <span className="hidden sm:inline">در حال ورود...</span>
      </div>
    )
  }
  return (
    <button
      onClick={voice.toggleMute}
      className={cn(
        "h-10 w-10 rounded-full flex items-center justify-center transition-colors",
        voice.isMuted ? "bg-danger text-white" : "bg-success/20 text-success",
      )}
      title={voice.isMuted ? "روشن کردن میکروفون" : "خاموش کردن میکروفون"}
    >
      {voice.isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
    </button>
  )
}
