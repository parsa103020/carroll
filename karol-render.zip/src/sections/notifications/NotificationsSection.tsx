"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import { useApp, type SectionId } from "@/lib/store"
import { api, timeAgo } from "@/lib/format"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Coins,
  Crown,
  Ticket,
  Bell,
  Heart,
  AtSign,
  CheckCheck,
  BellOff,
  Loader2,
} from "lucide-react"

interface NotificationT {
  id: string
  type: string
  title: string
  body: string | null
  link: string | null
  read: boolean
  createdAt: string
}

const TYPE_ICON: Record<string, React.ComponentType<{ className?: string }>> = {
  order: Coins,
  vip: Crown,
  ticket: Ticket,
  system: Bell,
  like: Heart,
  mention: AtSign,
}

const TYPE_COLOR: Record<string, string> = {
  order: "bg-gold/15 text-gold",
  vip: "bg-gold/15 text-gold",
  ticket: "bg-primary/15 text-primary",
  system: "bg-primary/15 text-primary",
  like: "bg-rose-500/15 text-rose-500",
  mention: "bg-primary/15 text-primary",
}

function iconFor(type: string) {
  return TYPE_ICON[type] || Bell
}
function colorFor(type: string) {
  return TYPE_COLOR[type] || "bg-primary/15 text-primary"
}

const SECTION_LINKS = new Set<SectionId>([
  "feed",
  "chat",
  "music",
  "videos",
  "reels",
  "drive",
  "shop",
  "vip",
  "wallet",
  "tickets",
  "profile",
  "admin",
])

export default function NotificationsSection() {
  const { toast, setSection } = useApp()
  const [filter, setFilter] = useState<"all" | "unread">("all")
  const [items, setItems] = useState<NotificationT[]>([])
  const [loading, setLoading] = useState(true)
  const [markingAll, setMarkingAll] = useState(false)
  const [next, setNext] = useState<string | null>(null)
  const [loadingMore, setLoadingMore] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const d = await api<{ notifications: NotificationT[]; nextCursor: string | null }>(
        `/api/notifications?filter=${filter}`,
      )
      setItems(d.notifications)
      setNext(d.nextCursor)
    } catch (e: any) {
      toast(e.message || "خطا در بارگذاری اعلان‌ها", "error")
    } finally {
      setLoading(false)
    }
  }, [filter, toast])

  useEffect(() => {
    load()
  }, [load])

  const loadMore = useCallback(async () => {
    if (!next || loadingMore) return
    setLoadingMore(true)
    try {
      const d = await api<{ notifications: NotificationT[]; nextCursor: string | null }>(
        `/api/notifications?filter=${filter}&cursor=${next}`,
      )
      setItems((prev) => [...prev, ...d.notifications])
      setNext(d.nextCursor)
    } catch (e: any) {
      toast(e.message || "خطا", "error")
    } finally {
      setLoadingMore(false)
    }
  }, [next, filter, loadingMore, toast])

  const markRead = useCallback(async (id: string) => {
    setItems((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)))
    try {
      await api("/api/notifications/read", { method: "POST", json: { id } })
    } catch {
      // rollback silently on next load
    }
  }, [])

  const markAllRead = useCallback(async () => {
    setMarkingAll(true)
    const prev = items
    setItems((p) => p.map((n) => ({ ...n, read: true })))
    try {
      await api("/api/notifications/read", { method: "POST", json: { all: true } })
      toast("همه اعلان‌ها خوانده شدند", "success")
    } catch (e: any) {
      setItems(prev)
      toast(e.message || "خطا", "error")
    } finally {
      setMarkingAll(false)
    }
  }, [items, toast])

  function handleClick(n: NotificationT) {
    if (!n.read) markRead(n.id)
    if (n.link && SECTION_LINKS.has(n.link as SectionId)) {
      setSection(n.link as SectionId)
    }
  }

  const unreadCount = items.filter((n) => !n.read).length

  return (
    <div className="min-h-full overflow-y-auto thin-scrollbar">
      <div className="max-w-3xl mx-auto p-3 sm:p-6">
        <div className="flex items-center justify-between gap-3 mb-4">
          <div>
            <h1 className="text-lg sm:text-xl font-bold flex items-center gap-2">
              <Bell className="w-5 h-5 text-primary" />
              اعلان‌ها
              {unreadCount > 0 && (
                <span className="text-[11px] font-bold bg-primary text-primary-foreground rounded-full px-2 py-0.5 tabular-nums">
                  {unreadCount.toLocaleString("fa-IR")}
                </span>
              )}
            </h1>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex rounded-lg bg-muted p-0.5 text-xs">
              <button
                onClick={() => setFilter("all")}
                className={cn(
                  "px-3 py-1.5 rounded-md font-medium transition-colors",
                  filter === "all" ? "bg-background shadow-soft" : "text-muted-foreground",
                )}
              >
                همه
              </button>
              <button
                onClick={() => setFilter("unread")}
                className={cn(
                  "px-3 py-1.5 rounded-md font-medium transition-colors",
                  filter === "unread" ? "bg-background shadow-soft" : "text-muted-foreground",
                )}
              >
                خوانده‌نشده
              </button>
            </div>
            {unreadCount > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={markAllRead}
                disabled={markingAll}
                className="gap-1.5 shrink-0"
              >
                {markingAll ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCheck className="w-4 h-4" />}
                <span className="hidden sm:inline">خواندن همه</span>
              </Button>
            )}
          </div>
        </div>

        {loading ? (
          <div className="space-y-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-20 w-full rounded-xl" />
            ))}
          </div>
        ) : items.length === 0 ? (
          <EmptyState filter={filter} />
        ) : (
          <div ref={containerRef} className="space-y-2">
            {items.map((n) => {
              const Icon = iconFor(n.type)
              const hasLink = n.link && SECTION_LINKS.has(n.link as SectionId)
              return (
                <button
                  key={n.id}
                  onClick={() => handleClick(n)}
                  className={cn(
                    "w-full text-right p-3 sm:p-4 rounded-xl border transition-colors flex gap-3 group",
                    n.read
                      ? "border-border/60 bg-card hover:bg-accent"
                      : "border-primary/30 bg-primary/5 hover:bg-primary/10",
                    hasLink && "cursor-pointer",
                  )}
                >
                  <div className={cn("w-10 h-10 rounded-xl shrink-0 flex items-center justify-center", colorFor(n.type))}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className={cn("text-sm truncate", !n.read && "font-bold")}>{n.title}</span>
                      {!n.read && <span className="w-2 h-2 rounded-full bg-primary shrink-0" />}
                    </div>
                    {n.body && (
                      <p className="text-[13px] text-muted-foreground line-clamp-2 mt-0.5 leading-relaxed">{n.body}</p>
                    )}
                    <div className="text-[11px] text-muted-foreground/80 mt-1">{timeAgo(n.createdAt)}</div>
                  </div>
                </button>
              )
            })}
            {next && (
              <Button variant="ghost" size="sm" onClick={loadMore} disabled={loadingMore} className="w-full gap-1.5">
                {loadingMore && <Loader2 className="w-4 h-4 animate-spin" />}
                بارگذاری بیشتر
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

function EmptyState({ filter }: { filter: "all" | "unread" }) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-16 px-4 rounded-xl border border-dashed border-border/60">
      <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center mb-4">
        <BellOff className="w-7 h-7 text-muted-foreground" />
      </div>
      <p className="text-sm text-muted-foreground">
        {filter === "unread" ? "اعلان خوانده‌نشده‌ای وجود ندارد" : "اعلانی وجود ندارد"}
      </p>
    </div>
  )
}
