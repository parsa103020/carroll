"use client"

import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import { useApp, isAppAdmin } from "@/lib/store"
import { api, timeAgo, formatNumber, faDigits } from "@/lib/format"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog"
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu"
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Heart, MessageCircle, Share2, MoreHorizontal, Crown, Music2, Play, Pause,
  Volume2, VolumeX, Plus, Film, Send, Loader2, Trash2, Flag, Link2, X, Upload, Sparkles,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface ReelOwner {
  id: string
  username: string
  displayName: string | null
  avatarUrl: string | null
  isVip: boolean
}

interface ReelT {
  id: string
  videoUrl: string
  posterUrl: string | null
  caption: string | null
  musicTitle: string | null
  views: number
  createdAt: string
  likes: number
  comments: number
  liked: boolean
  owner: ReelOwner
}

interface ReelCommentT {
  id: string
  content: string
  createdAt: string
  user: ReelOwner
}

const PAGE_SIZE = 10

export default function ReelsSection() {
  const { user, toast } = useApp()
  const [reels, setReels] = useState<ReelT[]>([])
  const [loading, setLoading] = useState(true)
  const [loadingMore, setLoadingMore] = useState(false)
  const [nextCursor, setNextCursor] = useState<string | null>(null)
  const [activeId, setActiveId] = useState<string | null>(null)
  const [globalMuted, setGlobalMuted] = useState(true)
  const [uploadOpen, setUploadOpen] = useState(false)
  const [commentsReel, setCommentsReel] = useState<ReelT | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<ReelT | null>(null)
  const viewedRef = useRef<Set<string>>(new Set())
  const containerRef = useRef<HTMLDivElement>(null)

  const loadFeed = useCallback(async () => {
    setLoading(true)
    try {
      const d = await api<{ reels: ReelT[]; nextCursor: string | null }>("/api/reels")
      setReels(d.reels)
      setNextCursor(d.nextCursor)
      if (d.reels[0]) setActiveId(d.reels[0].id)
    } catch (e: any) {
      toast(e.message, "error")
    } finally {
      setLoading(false)
    }
  }, [toast])

  useEffect(() => {
    loadFeed()
  }, [loadFeed])

  const loadMore = useCallback(async () => {
    if (!nextCursor || loadingMore) return
    setLoadingMore(true)
    try {
      const d = await api<{ reels: ReelT[]; nextCursor: string | null }>(`/api/reels?cursor=${encodeURIComponent(nextCursor)}`)
      setReels((prev) => [...prev, ...d.reels])
      setNextCursor(d.nextCursor)
    } catch {
    } finally {
      setLoadingMore(false)
    }
  }, [nextCursor, loadingMore])

  const onToggleLike = useCallback(async (id: string) => {
    setReels((prev) => prev.map((r) => r.id === id ? { ...r, liked: !r.liked, likes: r.likes + (r.liked ? -1 : 1) } : r))
    try {
      await api(`/api/reels/${id}/like`, { method: "POST" })
    } catch {
      setReels((prev) => prev.map((r) => r.id === id ? { ...r, liked: !r.liked, likes: r.likes + (r.liked ? -1 : 1) } : r))
    }
  }, [])

  const onShare = useCallback(async (reel: ReelT) => {
    const url = `${window.location.origin}/?reel=${reel.id}`
    try {
      if (navigator.share) {
        await navigator.share({ title: "ریلز کارول", url })
      } else {
        await navigator.clipboard.writeText(url)
        toast("لینک کپی شد", "success")
      }
    } catch {
      try {
        await navigator.clipboard.writeText(url)
        toast("لینک کپی شد", "success")
      } catch {
        toast("کپی لینک ناموفق بود", "error")
      }
    }
  }, [toast])

  const incrementView = useCallback(async (id: string) => {
    if (viewedRef.current.has(id)) return
    viewedRef.current.add(id)
    try {
      await api<{ views: number }>(`/api/reels/${id}/view`, { method: "POST" })
      setReels((prev) => prev.map((r) => r.id === id ? { ...r, views: r.views + 1 } : r))
    } catch {
      viewedRef.current.delete(id)
    }
  }, [])

  const onDelete = useCallback(async (id: string) => {
    try {
      await api(`/api/reels/${id}`, { method: "DELETE" })
      setReels((prev) => prev.filter((r) => r.id !== id))
      toast("ریلز حذف شد", "success")
    } catch (e: any) {
      toast(e.message, "error")
    }
  }, [toast])

  const onUploadSuccess = useCallback((reel: ReelT) => {
    setReels((prev) => [reel, ...prev])
    setActiveId(reel.id)
    setTimeout(() => {
      const el = document.getElementById(`reel-${reel.id}`)
      el?.scrollIntoView({ behavior: "smooth", block: "start" })
    }, 80)
  }, [])

  const onCommentsChanged = useCallback((reelId: string, delta: number) => {
    setReels((prev) => prev.map((r) => r.id === reelId ? { ...r, comments: Math.max(0, r.comments + delta) } : r))
  }, [])

  return (
    <div className="relative h-full bg-black">
      <div
        ref={containerRef}
        className="h-[calc(100vh-3.5rem-4rem)] lg:h-[calc(100vh-3.5rem)] overflow-y-scroll snap-y snap-mandatory no-scrollbar bg-black"
      >
        {loading ? (
          <ReelsSkeleton />
        ) : reels.length === 0 ? (
          <EmptyState onUpload={() => setUploadOpen(true)} canUpload={!!user} />
        ) : (
          reels.map((reel, idx) => (
            <ReelCard
              key={reel.id}
              reel={reel}
              isActive={activeId === reel.id}
              index={idx}
              total={reels.length}
              muted={globalMuted}
              onToggleMute={() => setGlobalMuted((m) => !m)}
              onActive={(id) => setActiveId(id)}
              onViewed={incrementView}
              onLike={onToggleLike}
              onComment={() => setCommentsReel(reel)}
              onShare={() => onShare(reel)}
              onDelete={user && (reel.owner.id === user.id || isAppAdmin(user)) ? () => setDeleteTarget(reel) : undefined}
              onNearEnd={idx === reels.length - 2 ? loadMore : undefined}
              currentUserId={user?.id}
              isAdmin={!!user && isAppAdmin(user)}
            />
          ))
        )}
      </div>

      {!loading && user && (
        <button
          onClick={() => setUploadOpen(true)}
          aria-label="ساخت ریلز"
          className="fixed lg:absolute bottom-24 lg:bottom-6 left-4 z-30 w-14 h-14 rounded-full gradient-karol text-white shadow-soft flex items-center justify-center hover:scale-105 active:scale-95 transition-transform"
        >
          <Plus className="w-7 h-7" />
        </button>
      )}

      <UploadReelDialog
        open={uploadOpen}
        onOpenChange={setUploadOpen}
        onSuccess={onUploadSuccess}
      />

      <CommentsSheet
        reel={commentsReel}
        onOpenChange={(o) => !o && setCommentsReel(null)}
        onChanged={(delta) => commentsReel && onCommentsChanged(commentsReel.id, delta)}
      />

      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف ریلز؟</AlertDialogTitle>
            <AlertDialogDescription>
              این ریلز برای همیشه حذف می‌شود و قابل بازگردانی نیست.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={() => deleteTarget && onDelete(deleteTarget.id)}
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

function ReelsSkeleton() {
  return (
    <div className="h-full w-full flex items-center justify-center snap-start">
      <div className="flex flex-col items-center gap-3 text-white/70">
        <div className="w-12 h-12 rounded-xl gradient-karol animate-karol-pulse" />
        <p className="text-sm">در حال بارگذاری ریلز…</p>
      </div>
    </div>
  )
}

function EmptyState({ onUpload, canUpload }: { onUpload: () => void; canUpload: boolean }) {
  return (
    <div className="h-full w-full flex items-center justify-center snap-start p-6">
      <div className="text-center max-w-sm">
        <div className="w-20 h-20 mx-auto mb-4 rounded-2xl gradient-karol flex items-center justify-center shadow-soft">
          <Film className="w-10 h-10 text-white" />
        </div>
        <h3 className="text-white text-lg font-bold mb-2">هنوز ریلزی وجود ندارد</h3>
        <p className="text-white/60 text-sm mb-5">اولین ریلز را بسازید و لحظات خود را به اشتراک بگذارید!</p>
        {canUpload && (
          <Button onClick={onUpload} className="gradient-karol text-white gap-2">
            <Plus className="w-4 h-4" /> ساخت ریلز جدید
          </Button>
        )}
      </div>
    </div>
  )
}

interface ReelCardProps {
  reel: ReelT
  isActive: boolean
  index: number
  total: number
  muted: boolean
  onToggleMute: () => void
  onActive: (id: string) => void
  onViewed: (id: string) => void
  onLike: (id: string) => void
  onComment: () => void
  onShare: () => void
  onDelete?: () => void
  onNearEnd?: () => void
  currentUserId?: string
  isAdmin: boolean
}

function ReelCard({
  reel, isActive, muted, onToggleMute, onActive, onViewed, onLike, onComment, onShare, onDelete, onNearEnd,
}: ReelCardProps) {
  const cardRef = useRef<HTMLDivElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const [nearby, setNearby] = useState(false)
  const [playing, setPlaying] = useState(false)
  const [buffering, setBuffering] = useState(false)
  const [showPlayHint, setShowPlayHint] = useState(false)
  const [captionExpanded, setCaptionExpanded] = useState(false)
  const [heartBurst, setHeartBurst] = useState(false)

  useEffect(() => {
    const el = cardRef.current
    if (!el) return
    const obs = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting && e.intersectionRatio >= 0.6) {
            onActive(reel.id)
            onViewed(reel.id)
            onNearEnd?.()
          }
          setNearby(e.intersectionRatio > 0.05)
        }
      },
      { threshold: [0, 0.05, 0.6, 1], root: el.parentElement },
    )
    obs.observe(el)
    return () => obs.disconnect()
  }, [reel.id, onActive, onViewed, onNearEnd])

  useEffect(() => {
    const v = videoRef.current
    if (!v) return
    if (isActive) {
      v.muted = muted
      const p = v.play()
      if (p && typeof p.then === "function") {
        p.catch(() => { /* autoplay blocked; user can tap to play */ })
      }
    } else {
      v.pause()
      v.currentTime = 0
    }
  }, [isActive, muted])

  useEffect(() => {
    if (videoRef.current) videoRef.current.muted = muted
  }, [muted])

  const togglePlay = useCallback(() => {
    const v = videoRef.current
    if (!v) return
    if (v.paused) {
      const p = v.play()
      if (p && typeof p.then === "function") {
        p.then(() => setPlaying(true)).catch(() => {})
      } else {
        setPlaying(true)
      }
    } else {
      v.pause()
      setPlaying(false)
    }
    setShowPlayHint(true)
    window.setTimeout(() => setShowPlayHint(false), 600)
  }, [])

  const doubleTap = useCallback(() => {
    if (!reel.liked) onLike(reel.id)
    setHeartBurst(true)
    window.setTimeout(() => setHeartBurst(false), 800)
  }, [reel.liked, reel.id, onLike])

  const lastTap = useRef(0)
  const onTap = useCallback(() => {
    const now = Date.now()
    if (now - lastTap.current < 280) {
      doubleTap()
      lastTap.current = 0
    } else {
      lastTap.current = now
      window.setTimeout(() => {
        if (lastTap.current && Date.now() - lastTap.current >= 280) {
          togglePlay()
          lastTap.current = 0
        }
      }, 290)
    }
  }, [doubleTap, togglePlay])

  const ownerInitial = (reel.owner.displayName?.[0] || reel.owner.username[0] || "?").toUpperCase()

  return (
    <section
      id={`reel-${reel.id}`}
      ref={cardRef}
      className="relative h-full w-full snap-start snap-always overflow-hidden bg-black flex items-center justify-center"
    >
      {(nearby || isActive) && (
        <video
          ref={videoRef}
          src={reel.videoUrl}
          poster={reel.posterUrl || undefined}
          playsInline
          loop
          muted={muted}
          preload={isActive ? "auto" : "metadata"}
          onWaiting={() => setBuffering(true)}
          onPlaying={() => { setBuffering(false); setPlaying(true) }}
          onPause={() => setPlaying(false)}
          onCanPlay={() => setBuffering(false)}
          onClick={onTap}
          className="absolute inset-0 w-full h-full object-cover bg-black cursor-pointer"
        />
      )}

      {!nearby && !isActive && (
        <div className="absolute inset-0 bg-black flex items-center justify-center">
          {reel.posterUrl ? (
            <img src={reel.posterUrl} alt="" className="w-full h-full object-cover" />
          ) : (
            <Film className="w-12 h-12 text-white/20" />
          )}
        </div>
      )}

      <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-black/70 via-transparent to-black/30" />

      {buffering && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <Loader2 className="w-10 h-10 text-white/80 animate-spin" />
        </div>
      )}

      {showPlayHint && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-20 h-20 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center">
            {playing ? <Pause className="w-9 h-9 text-white" /> : <Play className="w-9 h-9 text-white mr-1" />}
          </div>
        </div>
      )}

      {heartBurst && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <Heart className="w-28 h-28 text-rose-500 fill-rose-500 animate-[karol-pulse_0.8s_ease-out]" style={{ transform: "scale(1.4)" }} />
        </div>
      )}

      <button
        onClick={onToggleMute}
        className="absolute top-3 right-3 z-20 w-9 h-9 rounded-full bg-black/40 backdrop-blur-sm text-white flex items-center justify-center pointer-events-auto hover:bg-black/60 transition-colors"
        aria-label={muted ? "فعال‌سازی صدا" : "بی‌صدا"}
      >
        {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
      </button>

      <div className="absolute bottom-0 left-0 right-0 p-4 pb-6 pointer-events-none">
        <div className="max-w-[calc(100%-4.5rem)]">
          <div className="flex items-center gap-2 mb-2">
            <Avatar className="w-9 h-9 border-2 border-white/40 shrink-0">
              <AvatarImage src={reel.owner.avatarUrl || undefined} />
              <AvatarFallback className="bg-primary/30 text-white text-xs font-bold">
                {ownerInitial}
              </AvatarFallback>
            </Avatar>
            <div className="min-w-0">
              <div className="flex items-center gap-1">
                <span className="text-white text-sm font-bold truncate drop-shadow">
                  {reel.owner.displayName || reel.owner.username}
                </span>
                {reel.owner.isVip && <Crown className="w-3.5 h-3.5 text-gold shrink-0" />}
              </div>
              <div className="text-white/70 text-xs">@{reel.owner.username}</div>
            </div>
          </div>

          {reel.caption && (
            <button
              onClick={() => setCaptionExpanded((v) => !v)}
              className="pointer-events-auto block text-right mb-2"
            >
              <p className={cn(
                "text-white text-sm leading-relaxed drop-shadow whitespace-pre-wrap break-words",
                !captionExpanded && "line-clamp-2",
              )}>
                {reel.caption}
              </p>
              {reel.caption.length > 100 && (
                <span className="text-white/60 text-xs">
                  {captionExpanded ? "بستن" : "بیشتر…"}
                </span>
              )}
            </button>
          )}

          {reel.musicTitle && (
            <div className="flex items-center gap-1.5 text-white/90 text-xs">
              <Music2 className="w-3.5 h-3.5 shrink-0 animate-pulse" />
              <span className="truncate">{reel.musicTitle}</span>
            </div>
          )}
        </div>
      </div>

      <div className="absolute bottom-6 left-2 sm:left-4 z-20 flex flex-col items-center gap-4 pointer-events-auto">
        <ActionBtn onClick={() => onLike(reel.id)} label={formatNumber(reel.likes)}>
          <Heart className={cn("w-7 h-7 transition-transform", reel.liked ? "text-rose-500 fill-rose-500 scale-110" : "text-white")} />
        </ActionBtn>
        <ActionBtn onClick={onComment} label={formatNumber(reel.comments)}>
          <MessageCircle className="w-7 h-7 text-white" />
        </ActionBtn>
        <ActionBtn onClick={onShare} label="اشتراک">
          <Share2 className="w-7 h-7 text-white" />
        </ActionBtn>
        {onDelete && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex flex-col items-center gap-1 group" aria-label="بیشتر">
                <span className="w-11 h-11 rounded-full bg-black/30 backdrop-blur-sm flex items-center justify-center group-hover:bg-black/50 transition-colors">
                  <MoreHorizontal className="w-6 h-6 text-white" />
                </span>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent side="left" align="end" className="min-w-[10rem]">
              <DropdownMenuItem onClick={onShare} className="gap-2">
                <Link2 className="w-4 h-4" /> کپی لینک
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => {}} className="gap-2 text-amber-600 focus:text-amber-600">
                <Flag className="w-4 h-4" /> گزارش
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={onDelete} className="gap-2 text-destructive focus:text-destructive">
                <Trash2 className="w-4 h-4" /> حذف ریلز
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>

      <div className="absolute top-3 left-3 z-10 pointer-events-none">
        <span className="text-white/70 text-xs px-2 py-1 rounded-full bg-black/30 backdrop-blur-sm">
          {faDigits(formatNumber(reel.views))} بازدید
        </span>
      </div>
    </section>
  )
}

function ActionBtn({ children, onClick, label }: { children: React.ReactNode; onClick: () => void; label: string }) {
  return (
    <button onClick={onClick} className="flex flex-col items-center gap-1 group" aria-label={label}>
      <span className="w-11 h-11 rounded-full bg-black/30 backdrop-blur-sm flex items-center justify-center group-hover:bg-black/50 group-active:scale-90 transition-all">
        {children}
      </span>
      <span className="text-white text-xs font-medium drop-shadow">{label}</span>
    </button>
  )
}

interface UploadState {
  file: File | null
  caption: string
  musicTitle: string
  uploading: boolean
  progress: number
}

function UploadReelDialog({
  open, onOpenChange, onSuccess,
}: {
  open: boolean
  onOpenChange: (o: boolean) => void
  onSuccess: (reel: ReelT) => void
}) {
  const { toast } = useApp()
  const [state, setState] = useState<UploadState>({
    file: null, caption: "", musicTitle: "", uploading: false, progress: 0,
  })
  const [maxBytes, setMaxBytes] = useState<number>(100 * 1024 * 1024)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const xhrRef = useRef<XMLHttpRequest | null>(null)

  useEffect(() => {
    if (!open) return
    api<{ settings: Record<string, string> }>("/api/settings").then((d) => {
      const v = parseInt(d.settings["reel.maxBytes"] || "0", 10)
      if (Number.isFinite(v) && v > 0) setMaxBytes(v)
    }).catch(() => {})
  }, [open])

  useEffect(() => {
    if (!open) {
      setState({ file: null, caption: "", musicTitle: "", uploading: false, progress: 0 })
      xhrRef.current?.abort()
    }
  }, [open])

  function pickFile() {
    fileInputRef.current?.click()
  }

  function onFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0]
    if (!f) return
    if (!f.type.startsWith("video/")) {
      toast("فقط ویدیو قابل آپلود است", "error")
      return
    }
    if (f.size > maxBytes) {
      toast(`حجم ویدیو بیش از حد مجاز است (${(maxBytes / 1024 / 1024).toFixed(0)} مگابایت)`, "error")
      return
    }
    setState((s) => ({ ...s, file: f }))
  }

  async function upload() {
    if (!state.file) {
      toast("ابتدا یک ویدیو انتخاب کنید", "error")
      return
    }
    setState((s) => ({ ...s, uploading: true, progress: 0 }))

    try {
      const videoUrl = await new Promise<string>((resolve, reject) => {
        const fd = new FormData()
        fd.append("file", state.file!)
        fd.append("category", "reel")
        const xhr = new XMLHttpRequest()
        xhrRef.current = xhr
        xhr.open("POST", "/api/upload")
        xhr.upload.onprogress = (e) => {
          if (e.lengthComputable) {
            const pct = Math.round((e.loaded / e.total) * 100)
            setState((s) => ({ ...s, progress: pct }))
          }
        }
        xhr.onload = () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            try {
              const data = JSON.parse(xhr.responseText)
              resolve(data.url)
            } catch {
              reject(new Error("پاسخ نامعتبر سرور"))
            }
          } else {
            try {
              const data = JSON.parse(xhr.responseText)
              reject(new Error(data.error || `خطای ${xhr.status}`))
            } catch {
              reject(new Error(`خطای ${xhr.status}`))
            }
          }
        }
        xhr.onerror = () => reject(new Error("خطای شبکه"))
        xhr.send(fd)
      })

      const { reel } = await api<{ reel: ReelT }>("/api/reels", {
        method: "POST",
        json: {
          videoUrl,
          caption: state.caption.trim() || undefined,
          musicTitle: state.musicTitle.trim() || undefined,
        },
      })
      toast("ریلز منتشر شد!", "success")
      onSuccess(reel)
      onOpenChange(false)
    } catch (e: any) {
      toast(e.message, "error")
    } finally {
      setState((s) => ({ ...s, uploading: false, progress: 0 }))
    }
  }

  function cancelUpload() {
    xhrRef.current?.abort()
    setState((s) => ({ ...s, uploading: false, progress: 0 }))
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !state.uploading && onOpenChange(o)}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-gold" />
            ساخت ریلز جدید
          </DialogTitle>
          <DialogDescription>
            یک ویدیوی کوتاه انتخاب کنید و منتشر کنید.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <input
            ref={fileInputRef}
            type="file"
            accept="video/*"
            className="hidden"
            onChange={onFileChange}
          />

          {!state.file ? (
            <button
              onClick={pickFile}
              className="w-full border-2 border-dashed border-border rounded-xl p-8 hover:border-primary/40 hover:bg-primary/5 transition-colors flex flex-col items-center gap-2 text-center"
            >
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Upload className="w-6 h-6 text-primary" />
              </div>
              <span className="text-sm font-medium">انتخاب ویدیو</span>
              <span className="text-xs text-muted-foreground">
                حداکثر {(maxBytes / 1024 / 1024).toFixed(0)} مگابایت
              </span>
            </button>
          ) : (
            <div className="space-y-3">
              <div className="relative rounded-xl overflow-hidden bg-black aspect-[9/16] max-h-64 mx-auto">
                <video
                  src={URL.createObjectURL(state.file)}
                  controls
                  playsInline
                  className="w-full h-full object-contain"
                />
                {!state.uploading && (
                  <button
                    onClick={() => setState((s) => ({ ...s, file: null }))}
                    className="absolute top-2 right-2 w-7 h-7 rounded-full bg-black/60 text-white flex items-center justify-center"
                    aria-label="حذف ویدیو"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
              <div className="text-xs text-muted-foreground truncate flex items-center gap-1.5">
                <Film className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{state.file.name}</span>
                <span className="text-muted-foreground/70">· {(state.file.size / 1024 / 1024).toFixed(1)} مگابایت</span>
              </div>
            </div>
          )}

          {state.file && (
            <>
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-muted-foreground">توضیحات (اختیاری)</label>
                <textarea
                  value={state.caption}
                  onChange={(e) => setState((s) => ({ ...s, caption: e.target.value }))}
                  placeholder="چه خبر؟"
                  rows={3}
                  maxLength={1000}
                  className="w-full resize-none rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                  <Music2 className="w-3.5 h-3.5" /> نام موسیقی (اختیاری)
                </label>
                <input
                  type="text"
                  value={state.musicTitle}
                  onChange={(e) => setState((s) => ({ ...s, musicTitle: e.target.value }))}
                  placeholder="مثلاً: آهنگ تازه"
                  maxLength={200}
                  className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
                />
              </div>
            </>
          )}

          {state.uploading && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">در حال آپلود…</span>
                <span className="font-bold text-primary">{faDigits(state.progress)}٪</span>
              </div>
              <div className="h-2 rounded-full bg-muted overflow-hidden">
                <div
                  className="h-full gradient-karol transition-all duration-200"
                  style={{ width: `${state.progress}%` }}
                />
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          {state.uploading ? (
            <Button variant="outline" onClick={cancelUpload} className="gap-2">
              <X className="w-4 h-4" /> لغو
            </Button>
          ) : (
            <>
              <Button variant="outline" onClick={() => onOpenChange(false)}>انصراف</Button>
              <Button
                className="gradient-karol text-white gap-2"
                disabled={!state.file}
                onClick={upload}
              >
                <Send className="w-4 h-4" /> انتشار
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

function CommentsSheet({
  reel, onOpenChange, onChanged,
}: {
  reel: ReelT | null
  onOpenChange: (o: boolean) => void
  onChanged: (delta: number) => void
}) {
  const { user } = useApp()
  const [comments, setComments] = useState<ReelCommentT[]>([])
  const [loading, setLoading] = useState(false)
  const [text, setText] = useState("")
  const [posting, setPosting] = useState(false)
  const listRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!reel) {
      setComments([])
      setText("")
      return
    }
    let cancelled = false
    setLoading(true)
    api<{ comments: ReelCommentT[] }>(`/api/reels/${reel.id}/comments`)
      .then((d) => { if (!cancelled) setComments(d.comments) })
      .catch(() => {})
      .finally(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [reel])

  async function postComment() {
    if (!reel || !text.trim() || !user) return
    setPosting(true)
    try {
      const { comment } = await api<{ comment: ReelCommentT }>(`/api/reels/${reel.id}/comments`, {
        method: "POST",
        json: { content: text.trim() },
      })
      setComments((prev) => [comment, ...prev])
      setText("")
      onChanged(1)
    } catch (e: any) {
    } finally {
      setPosting(false)
    }
  }

  return (
    <Sheet open={!!reel} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className="h-[70vh] p-0 flex flex-col">
        <SheetHeader className="px-4 py-3 border-b border-border/60">
          <SheetTitle className="text-base">نظرات ({faDigits(formatNumber(reel?.comments || 0))})</SheetTitle>
        </SheetHeader>

        <div ref={listRef} className="flex-1 overflow-y-auto thin-scrollbar px-4 py-3 space-y-3">
          {loading ? (
            [...Array(4)].map((_, i) => (
              <div key={i} className="flex gap-2">
                <Skeleton className="w-8 h-8 rounded-full" />
                <div className="flex-1 space-y-1.5">
                  <Skeleton className="h-3 w-20" />
                  <Skeleton className="h-4 w-3/4" />
                </div>
              </div>
            ))
          ) : comments.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground text-sm">
              <MessageCircle className="w-8 h-8 mx-auto mb-2 text-muted-foreground/40" />
              هنوز نظری ثبت نشده. اولین نظر را شما بدهید!
            </div>
          ) : (
            comments.map((c) => (
              <div key={c.id} className="flex gap-2.5">
                <Avatar className="w-8 h-8 shrink-0">
                  <AvatarImage src={c.user.avatarUrl || undefined} />
                  <AvatarFallback className="bg-primary/15 text-primary text-[10px] font-bold">
                    {(c.user.displayName?.[0] || c.user.username[0] || "?").toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-semibold">{c.user.displayName || c.user.username}</span>
                    {c.user.isVip && <Crown className="w-3 h-3 text-gold" />}
                    <span className="text-[10px] text-muted-foreground">{timeAgo(c.createdAt)}</span>
                  </div>
                  <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">{c.content}</p>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="border-t border-border/60 p-3 flex gap-2 items-end bg-background">
          <Avatar className="w-8 h-8 shrink-0">
            <AvatarImage src={user?.avatarUrl || undefined} />
            <AvatarFallback className="bg-primary/15 text-primary text-[10px] font-bold">
              {(user?.displayName?.[0] || user?.username?.[0] || "?").toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault()
                postComment()
              }
            }}
            placeholder="نظر شما…"
            rows={1}
            maxLength={1000}
            className="flex-1 resize-none max-h-24 rounded-2xl border border-input bg-muted/40 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
          />
          <Button
            size="icon"
            className="gradient-karol text-white rounded-full shrink-0"
            disabled={!text.trim() || posting}
            onClick={postComment}
            aria-label="ارسال نظر"
          >
            {posting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  )
}
