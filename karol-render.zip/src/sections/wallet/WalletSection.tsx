"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import { useApp } from "@/lib/store"
import { api, formatNumber, faDigits, timeAgo } from "@/lib/format"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import {
  Coins,
  Wallet as WalletIcon,
  Crown,
  ShoppingBag,
  History,
  TrendingUp,
  TrendingDown,
  Gift,
  ArrowUpLeft,
  ArrowDownRight,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface Tx {
  id: string
  amount: number
  balanceAfter: number
  type: string
  description: string
  referenceId: string | null
  createdAt: string
}

const TYPE_META: Record<string, {
  label: string
  icon: React.ComponentType<{ className?: string }>
  tone: "up" | "down" | "gold"
}> = {
  purchase: { label: "خرید", icon: TrendingUp, tone: "up" },
  reward: { label: "پاداش", icon: Gift, tone: "gold" },
  spend: { label: "خرج", icon: TrendingDown, tone: "down" },
  admin: { label: "توسط مدیر", icon: Coins, tone: "gold" },
  refund: { label: "بازگشت", icon: ArrowUpLeft, tone: "up" },
}

function toneClasses(tone: "up" | "down" | "gold") {
  if (tone === "up") return "text-emerald-500 bg-emerald-500/10"
  if (tone === "down") return "text-rose-500 bg-rose-500/10"
  return "text-gold bg-gold/10"
}

function signAmount(amount: number) {
  const fa = formatNumber(Math.abs(amount))
  return amount > 0 ? `+${fa}` : amount < 0 ? `−${fa}` : fa
}

export default function WalletSection() {
  const { user, setSection, refreshUser, toast } = useApp()
  const [loading, setLoading] = useState(true)
  const [list, setList] = useState<Tx[]>([])
  const [cursor, setCursor] = useState<string | null>(null)
  const [hasMore, setHasMore] = useState(false)
  const [loadingMore, setLoadingMore] = useState(false)
  const sentinelRef = useRef<HTMLDivElement | null>(null)

  const loadFirst = useCallback(async () => {
    setLoading(true)
    try {
      const r = await api<{ transactions: Tx[]; nextCursor: string | null }>("/api/coins/transactions?limit=50")
      setList(r.transactions)
      setCursor(r.nextCursor)
      setHasMore(!!r.nextCursor)
    } catch (e: any) {
      toast(e.message || "خطا در بارگذاری تراکنش‌ها", "error")
    } finally {
      setLoading(false)
    }
  }, [toast])

  useEffect(() => {
    loadFirst()
    refreshUser()
  }, [loadFirst, refreshUser])

  const loadMore = useCallback(async () => {
    if (!cursor || loadingMore) return
    setLoadingMore(true)
    try {
      const r = await api<{ transactions: Tx[]; nextCursor: string | null }>(
        `/api/coins/transactions?limit=50&cursor=${encodeURIComponent(cursor)}`,
      )
      setList((prev) => [...prev, ...r.transactions])
      setCursor(r.nextCursor)
      setHasMore(!!r.nextCursor)
    } catch (e: any) {
      toast(e.message || "خطا در بارگذاری بیشتر", "error")
    } finally {
      setLoadingMore(false)
    }
  }, [cursor, loadingMore, toast])

  useEffect(() => {
    if (!hasMore || loading) return
    const el = sentinelRef.current
    if (!el) return
    const obs = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) loadMore()
      },
      { rootMargin: "200px" },
    )
    obs.observe(el)
    return () => obs.disconnect()
  }, [hasMore, loading, loadMore])

  const coins = user?.coins ?? 0

  return (
    <div className="min-h-full p-3 sm:p-4 lg:p-6 max-w-4xl mx-auto w-full">
      <div className="mb-4 sm:mb-6 flex items-center gap-2">
        <WalletIcon className="w-5 h-5 text-primary" />
        <h2 className="text-lg sm:text-xl font-bold">کیف پول</h2>
      </div>

      <div className="relative overflow-hidden rounded-2xl gradient-gold p-5 sm:p-6 shadow-soft mb-4">
        <div className="absolute -left-12 -top-12 w-44 h-44 rounded-full bg-white/15 blur-2xl" />
        <div className="absolute -right-10 -bottom-10 w-40 h-40 rounded-full bg-black/10 blur-2xl" />
        <div className="relative">
          <div className="flex items-center gap-2 text-gold-foreground/80">
            <Coins className="w-4 h-4" />
            <span className="text-sm font-medium">موجودی فعلی</span>
          </div>
          <div className="mt-2 flex items-end gap-2">
            <span className="text-4xl sm:text-5xl font-black text-gold-foreground tabular-nums tracking-tight">
              {faDigits(formatNumber(coins))}
            </span>
            <span className="mb-1 text-sm font-bold text-gold-foreground/80">کارول‌کوین</span>
          </div>
          <div className="mt-5 flex flex-wrap gap-2">
            <Button
              onClick={() => setSection("shop")}
              className="bg-gold-foreground text-gold hover:bg-gold-foreground/90 font-bold"
            >
              <Coins className="w-4 h-4 ml-1" /> شارژ کیف پول
            </Button>
            <Button
              variant="secondary"
              onClick={() => setSection("vip")}
              className="glass border border-gold/40 bg-white/20 text-gold-foreground hover:bg-white/30 font-medium"
            >
              <Crown className="w-4 h-4 ml-1" /> خرید VIP
            </Button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2 sm:gap-3 mb-5">
        <QuickAction
          icon={ShoppingBag}
          label="خرید کوین"
          onClick={() => setSection("shop")}
          tone="primary"
        />
        <QuickAction
          icon={Crown}
          label="خرید VIP"
          onClick={() => setSection("vip")}
          tone="gold"
        />
        <QuickAction
          icon={History}
          label="تاریخچه"
          onClick={() => {
            const el = document.getElementById("tx-list")
            el?.scrollIntoView({ behavior: "smooth", block: "start" })
          }}
          tone="muted"
        />
      </div>

      <div id="tx-list" className="rounded-2xl border border-border bg-card overflow-hidden shadow-soft">
        <div className="px-4 py-3 border-b border-border flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-muted-foreground" />
            <h3 className="font-bold">تاریخچه تراکنش‌ها</h3>
          </div>
          <Badge variant="secondary" className="tabular-nums">
            {faDigits(formatNumber(list.length))} مورد
          </Badge>
        </div>

        {loading ? (
          <div className="p-4 space-y-2">
            {[0, 1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-14 rounded-xl" />
            ))}
          </div>
        ) : list.length === 0 ? (
          <div className="p-10 text-center">
            <div className="w-14 h-14 mx-auto mb-3 rounded-full bg-muted flex items-center justify-center">
              <Coins className="w-6 h-6 text-muted-foreground" />
            </div>
            <p className="text-sm text-muted-foreground mb-1">هنوز تراکنشی ثبت نشده است</p>
            <p className="text-xs text-muted-foreground/70">با شارژ کیف پول یا دریافت پاداش، تراکنش‌های شما اینجا نمایش داده می‌شوند.</p>
          </div>
        ) : (
          <ul className="divide-y divide-border">
            {list.map((tx) => {
              const meta = TYPE_META[tx.type] || TYPE_META.spend
              const Icon = meta.icon
              const isCredit = tx.amount > 0
              return (
                <li key={tx.id} className="px-3 sm:px-4 py-3 flex items-center gap-3 hover:bg-accent/40 transition-colors">
                  <div
                    className={cn(
                      "w-10 h-10 rounded-xl flex items-center justify-center shrink-0",
                      toneClasses(meta.tone),
                    )}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm truncate">
                        {tx.description || meta.label}
                      </span>
                      <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4 font-medium">
                        {meta.label}
                      </Badge>
                    </div>
                    <div className="text-[11px] text-muted-foreground mt-0.5 flex items-center gap-2">
                      <span>{timeAgo(tx.createdAt)}</span>
                      <span className="opacity-50">•</span>
                      <span className="tabular-nums">
                        موجودی پس از تراکنش: {faDigits(formatNumber(tx.balanceAfter))}
                      </span>
                    </div>
                  </div>
                  <div
                    className={cn(
                      "flex flex-col items-end gap-0.5 shrink-0",
                      isCredit ? "text-emerald-500" : tx.amount < 0 ? "text-rose-500" : "text-muted-foreground",
                    )}
                  >
                    <span className="font-bold tabular-nums text-sm flex items-center gap-1">
                      {isCredit ? (
                        <ArrowUpLeft className="w-3.5 h-3.5" />
                      ) : tx.amount < 0 ? (
                        <ArrowDownRight className="w-3.5 h-3.5" />
                      ) : null}
                      {signAmount(tx.amount)}
                    </span>
                    <span className="text-[10px] opacity-70">کوین</span>
                  </div>
                </li>
              )
            })}
          </ul>
        )}

        {hasMore && (
          <div ref={sentinelRef} className="p-3 flex justify-center">
            {loadingMore ? (
              <Skeleton className="h-10 w-32 rounded-lg" />
            ) : (
              <Button variant="ghost" size="sm" onClick={loadMore}>
                بارگذاری بیشتر
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

function QuickAction({
  icon: Icon,
  label,
  onClick,
  tone,
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  onClick: () => void
  tone: "primary" | "gold" | "muted"
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "rounded-xl border p-3 sm:p-4 flex flex-col items-center gap-1.5 text-xs sm:text-sm font-medium transition-all hover:shadow-soft active:scale-95",
        tone === "primary" && "bg-primary/5 border-primary/30 text-primary hover:bg-primary/10",
        tone === "gold" && "bg-gold/10 border-gold/40 text-gold hover:bg-gold/20",
        tone === "muted" && "bg-card border-border text-muted-foreground hover:bg-accent",
      )}
    >
      <Icon className="w-5 h-5" />
      <span>{label}</span>
    </button>
  )
}
