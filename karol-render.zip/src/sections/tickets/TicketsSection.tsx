"use client"

import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import { useApp, isAppAdmin } from "@/lib/store"
import { api, timeAgo, formatDate, formatTime, faDigits } from "@/lib/format"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  Ticket as TicketIcon,
  MessageSquare,
  Send,
  Plus,
  Clock,
  CheckCircle,
  AlertCircle,
  ArrowRight,
  Trash2,
  Headphones,
  Loader2,
  Search,
  Filter,
  Paperclip,
  Inbox,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface Owner {
  id: string
  username: string
  displayName: string | null
  avatarUrl: string | null
  isVip: boolean
}

interface TicketListItem {
  id: string
  subject: string
  category: string
  status: "open" | "pending" | "closed"
  priority: string
  assignedTo: string | null
  userId: string
  createdAt: string
  updatedAt: string
  closedAt: string | null
  owner: Owner | null
  messagesCount: number
  lastMessage: {
    id: string
    content: string
    isAdmin: boolean
    createdAt: string
    userId: string
  } | null
}

interface TicketMessageT {
  id: string
  content: string
  isAdmin: boolean
  attachments: string[]
  createdAt: string
  userId: string
  user: Owner | null
}

interface TicketFull {
  id: string
  subject: string
  category: string
  status: "open" | "pending" | "closed"
  priority: string
  assignedTo: string | null
  userId: string
  createdAt: string
  updatedAt: string
  closedAt: string | null
  owner: (Owner & { roles?: string }) | null
  messages: TicketMessageT[]
}

const CATEGORY_LABEL: Record<string, string> = {
  tech: "پشتیبانی فنی",
  report: "گزارش کاربر",
  payment: "پرداخت",
  vip: "VIP",
  other: "دیگر",
  general: "عمومی",
}

const PRIORITY_LABEL: Record<string, string> = {
  low: "کم",
  normal: "معمولی",
  high: "فوری",
}

const STATUS_LABEL: Record<string, string> = {
  open: "باز",
  pending: "در انتظار",
  closed: "بسته",
}

function statusBadge(status: string) {
  if (status === "open")
    return (
      <Badge className="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/30">
        <span className="size-1.5 rounded-full bg-emerald-500" />
        {STATUS_LABEL.open}
      </Badge>
    )
  if (status === "pending")
    return (
      <Badge className="bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/30">
        <Clock className="size-3" />
        {STATUS_LABEL.pending}
      </Badge>
    )
  return (
    <Badge variant="secondary" className="text-muted-foreground">
      <CheckCircle className="size-3" />
      {STATUS_LABEL.closed}
    </Badge>
  )
}

function priorityBadge(priority: string) {
  if (priority === "high")
    return (
      <Badge className="bg-rose-500/15 text-rose-600 dark:text-rose-400 border-rose-500/30">
        {PRIORITY_LABEL.high}
      </Badge>
    )
  if (priority === "low")
    return <Badge variant="outline" className="text-muted-foreground">{PRIORITY_LABEL.low}</Badge>
  return (
    <Badge className="bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/30">
      {PRIORITY_LABEL.normal}
    </Badge>
  )
}

function categoryBadge(category: string) {
  return (
    <Badge variant="outline" className="text-muted-foreground">
      {CATEGORY_LABEL[category] || category}
    </Badge>
  )
}

function initialsOf(name: string | null, username: string) {
  const src = (name || username || "").trim()
  if (!src) return "؟"
  const parts = src.split(/\s+/).filter(Boolean)
  if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase()
  return src.slice(0, 2).toUpperCase()
}

function readUpToKey(ticketId: string) {
  return `karol:ticket:${ticketId}:readUpTo`
}

function getReadUpTo(ticketId: string): number {
  if (typeof window === "undefined") return 0
  const v = window.localStorage.getItem(readUpToKey(ticketId))
  return v ? Number(v) : 0
}

function setReadUpTo(ticketId: string, ts: number) {
  if (typeof window === "undefined") return
  window.localStorage.setItem(readUpToKey(ticketId), String(ts))
}

export default function TicketsSection() {
  const { user, toast } = useApp()
  const admin = isAppAdmin(user)

  const [tickets, setTickets] = useState<TicketListItem[]>([])
  const [loading, setLoading] = useState(true)
  const [isAdminMode, setIsAdminMode] = useState(false)
  const [filterStatus, setFilterStatus] = useState<string>("all")
  const [filterCategory, setFilterCategory] = useState<string>("all")
  const [search, setSearch] = useState("")
  const [debouncedSearch, setDebouncedSearch] = useState("")

  const [selected, setSelected] = useState<TicketFull | null>(null)
  const [loadingDetail, setLoadingDetail] = useState(false)
  const [draft, setDraft] = useState("")
  const [sending, setSending] = useState(false)
  const [creating, setCreating] = useState(false)
  const [newOpen, setNewOpen] = useState(false)
  const [closeTarget, setCloseTarget] = useState<TicketFull | TicketListItem | null>(null)

  const [newForm, setNewForm] = useState({
    subject: "",
    category: "tech",
    priority: "normal",
    message: "",
  })

  const messagesEndRef = useRef<HTMLDivElement | null>(null)
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const listRef = useRef<HTMLDivElement | null>(null)

  // Debounced search
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search), 350)
    return () => clearTimeout(t)
  }, [search])

  const fetchList = useCallback(async () => {
    try {
      const params = new URLSearchParams()
      if (admin) {
        if (filterStatus !== "all") params.set("status", filterStatus)
        if (filterCategory !== "all") params.set("category", filterCategory)
        if (debouncedSearch) params.set("q", debouncedSearch)
      }
      const q = params.toString()
      const data = await api<{ tickets: TicketListItem[]; isAdmin: boolean }>(
        `/api/tickets${q ? `?${q}` : ""}`,
      )
      setTickets(data.tickets)
      setIsAdminMode(data.isAdmin)
    } catch (e: any) {
      toast(e.message || "خطا در بارگذاری تیکت‌ها", "error")
    } finally {
      setLoading(false)
    }
  }, [admin, filterStatus, filterCategory, debouncedSearch, toast])

  useEffect(() => {
    fetchList()
  }, [fetchList])

  // Polling for new messages in detail view
  useEffect(() => {
    if (!selected) {
      if (pollRef.current) {
        clearInterval(pollRef.current)
        pollRef.current = null
      }
      return
    }
    const tick = async () => {
      try {
        const last = selected.messages[selected.messages.length - 1]
        const since = last ? last.createdAt : selected.createdAt
        const data = await api<{ messages: TicketMessageT[] }>(
          `/api/tickets/${selected.id}/messages?since=${encodeURIComponent(since)}`,
        )
        if (data.messages.length > 0) {
          setSelected((prev) =>
            prev && prev.id === selected.id
              ? { ...prev, messages: [...prev.messages, ...data.messages] }
              : prev,
          )
        }
      } catch {
        // silent
      }
    }
    pollRef.current = setInterval(tick, 5000)
    return () => {
      if (pollRef.current) {
        clearInterval(pollRef.current)
        pollRef.current = null
      }
    }
  }, [selected?.id])  

  // Mark read when opening / when new messages arrive
  useEffect(() => {
    if (!selected) return
    const last = selected.messages[selected.messages.length - 1]
    if (last) {
      const ts = new Date(last.createdAt).getTime()
      if (ts > getReadUpTo(selected.id)) setReadUpTo(selected.id, ts)
    } else {
      setReadUpTo(selected.id, Date.now())
    }
  }, [selected?.id, selected?.messages.length])  

  // Auto scroll
  useEffect(() => {
    if (selected) {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth", block: "end" })
    }
  }, [selected?.messages.length, selected?.id])

  const openTicket = useCallback(
    async (id: string) => {
      setLoadingDetail(true)
      setSelected(null)
      try {
        const data = await api<{ ticket: TicketFull; isAdmin: boolean }>(
          `/api/tickets/${id}`,
        )
        setSelected(data.ticket)
        setIsAdminMode(data.isAdmin)
      } catch (e: any) {
        toast(e.message || "خطا در بارگذاری تیکت", "error")
      } finally {
        setLoadingDetail(false)
      }
    },
    [toast],
  )

  const handleSend = useCallback(async () => {
    if (!selected) return
    const content = draft.trim()
    if (!content) return
    if (selected.status === "closed" && !admin) {
      toast("این تیکت بسته شده است", "error")
      return
    }
    setSending(true)
    const tempId = `temp-${Date.now()}`
    const optimistic: TicketMessageT = {
      id: tempId,
      content,
      isAdmin: admin,
      attachments: [],
      createdAt: new Date().toISOString(),
      userId: user!.id,
      user: {
        id: user!.id,
        username: user!.username,
        displayName: user!.displayName,
        avatarUrl: user!.avatarUrl,
        isVip: user!.isVip,
      },
    }
    setSelected((prev) =>
      prev ? { ...prev, messages: [...prev.messages, optimistic] } : prev,
    )
    setDraft("")
    try {
      const data = await api<{ message: TicketMessageT }>(
        `/api/tickets/${selected.id}/messages`,
        { method: "POST", json: { content } },
      )
      setSelected((prev) =>
        prev
          ? {
              ...prev,
              messages: prev.messages.map((m) =>
                m.id === tempId ? data.message : m,
              ),
            }
          : prev,
      )
      // refresh list silently
      fetchList()
    } catch (e: any) {
      toast(e.message || "ارسال ناموفق", "error")
      setSelected((prev) =>
        prev ? { ...prev, messages: prev.messages.filter((m) => m.id !== tempId) } : prev,
      )
      setDraft(content)
    } finally {
      setSending(false)
    }
  }, [draft, selected, admin, user, toast, fetchList])

  const handleCreate = useCallback(async () => {
    const subject = newForm.subject.trim()
    const message = newForm.message.trim()
    if (subject.length < 3) {
      toast("موضوع باید حداقل ۳ نویسه باشد", "error")
      return
    }
    if (message.length < 1) {
      toast("پیام اولیه الزامی است", "error")
      return
    }
    setCreating(true)
    try {
      const data = await api<{ ticket: TicketListItem }>(`/api/tickets`, {
        method: "POST",
        json: {
          subject,
          category: newForm.category,
          priority: newForm.priority,
          message,
        },
      })
      setTickets((prev) => [data.ticket, ...prev])
      setNewOpen(false)
      setNewForm({ subject: "", category: "tech", priority: "normal", message: "" })
      toast("تیکت ایجاد شد", "success")
      openTicket(data.ticket.id)
    } catch (e: any) {
      toast(e.message || "ایجاد تیکت ناموفق", "error")
    } finally {
      setCreating(false)
    }
  }, [newForm, toast, openTicket])

  const patchTicket = useCallback(
    async (patch: Record<string, any>) => {
      if (!selected) return
      try {
        const data = await api<{ ticket: TicketFull }>(
          `/api/tickets/${selected.id}`,
          { method: "PATCH", json: patch },
        )
        setSelected(data.ticket)
        setTickets((prev) =>
          prev.map((t) =>
            t.id === data.ticket.id
              ? {
                  ...t,
                  status: data.ticket.status,
                  priority: data.ticket.priority,
                  assignedTo: data.ticket.assignedTo,
                  category: data.ticket.category,
                  updatedAt: data.ticket.updatedAt,
                }
              : t,
          ),
        )
        toast("به‌روزرسانی شد", "success")
      } catch (e: any) {
        toast(e.message || "خطا در به‌روزرسانی", "error")
      }
    },
    [selected, toast],
  )

  const handleClose = useCallback(async () => {
    if (!closeTarget) return
    try {
      await api(`/api/tickets/${closeTarget.id}`, { method: "DELETE" })
      setTickets((prev) =>
        prev.map((t) =>
          t.id === closeTarget.id
            ? { ...t, status: "closed" as const, closedAt: new Date().toISOString() }
            : t,
        ),
      )
      if (selected && selected.id === closeTarget.id) {
        setSelected({
          ...selected,
          status: "closed",
          closedAt: new Date().toISOString(),
        })
      }
      toast("تیکت بسته شد", "success")
    } catch (e: any) {
      toast(e.message || "خطا در بستن تیکت", "error")
    } finally {
      setCloseTarget(null)
    }
  }, [closeTarget, selected, toast])

  // ============ Detail View ============
  if (loadingDetail) {
    return (
      <div className="p-4 sm:p-6 max-w-3xl mx-auto">
        <Skeleton className="h-10 w-32 mb-4" />
        <Skeleton className="h-32 w-full mb-4" />
        <Skeleton className="h-64 w-full" />
      </div>
    )
  }

  if (selected) {
    const last = selected.messages[selected.messages.length - 1]
    const isClosed = selected.status === "closed"
    return (
      <div className="flex flex-col h-[calc(100vh-3.5rem-4rem)] lg:h-[calc(100vh-3.5rem)]">
        {/* Header */}
        <div className="px-4 sm:px-6 py-3 border-b border-border bg-background/80 backdrop-blur sticky top-0 z-10">
          <div className="max-w-3xl mx-auto">
            <div className="flex items-start gap-3">
              <Button
                variant="ghost"
                size="icon"
                className="shrink-0 size-9"
                onClick={() => setSelected(null)}
                aria-label="بازگشت"
              >
                <ArrowRight className="size-5" />
              </Button>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="font-bold text-base sm:text-lg truncate">
                    {selected.subject}
                  </h2>
                  {statusBadge(selected.status)}
                  {priorityBadge(selected.priority)}
                  {categoryBadge(selected.category)}
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1 flex-wrap">
                  <span className="flex items-center gap-1">
                    <Clock className="size-3" />
                    {formatDate(selected.createdAt)}
                  </span>
                  <span>•</span>
                  <span>{faDigits(selected.messages.length)} پیام</span>
                  {selected.assignedTo && (
                    <>
                      <span>•</span>
                      <span>مسئول: {selected.assignedTo}</span>
                    </>
                  )}
                  {admin && selected.owner && (
                    <>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <Avatar className="size-4">
                          <AvatarImage src={selected.owner.avatarUrl || undefined} />
                          <AvatarFallback className="text-[8px]">
                            {initialsOf(selected.owner.displayName, selected.owner.username)}
                          </AvatarFallback>
                        </Avatar>
                        {selected.owner.displayName || selected.owner.username}
                      </span>
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* Admin actions */}
            {admin && (
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <Select
                  value={selected.status}
                  onValueChange={(v) => patchTicket({ status: v })}
                >
                  <SelectTrigger className="h-8 w-28 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="open">باز</SelectItem>
                    <SelectItem value="pending">در انتظار</SelectItem>
                    <SelectItem value="closed">بسته</SelectItem>
                  </SelectContent>
                </Select>
                <Select
                  value={selected.priority}
                  onValueChange={(v) => patchTicket({ priority: v })}
                >
                  <SelectTrigger className="h-8 w-28 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">کم</SelectItem>
                    <SelectItem value="normal">معمولی</SelectItem>
                    <SelectItem value="high">فوری</SelectItem>
                  </SelectContent>
                </Select>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-8 text-xs"
                  onClick={() => patchTicket({ assignedTo: user?.username || "admin" })}
                  disabled={selected.assignedTo === (user?.username || "admin")}
                >
                  <Headphones className="size-3.5" />
                  {selected.assignedTo === (user?.username || "admin")
                    ? "پاسخگو شما هستید"
                    : "پاسخگویی"}
                </Button>
                {selected.status !== "closed" && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 text-xs text-rose-600 hover:text-rose-700"
                    onClick={() => setCloseTarget(selected)}
                  >
                    <Trash2 className="size-3.5" />
                    بستن تیکت
                  </Button>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Messages */}
        <div
          ref={listRef}
          className="flex-1 overflow-y-auto thin-scrollbar px-4 sm:px-6 py-4"
        >
          <div className="max-w-3xl mx-auto flex flex-col gap-3">
            {selected.messages.length === 0 && (
              <div className="text-center py-12 text-muted-foreground">
                <Inbox className="size-10 mx-auto mb-3 opacity-50" />
                <p className="text-sm">هنوز پیامی در این تیکت وجود ندارد.</p>
              </div>
            )}
            {selected.messages.map((m) => {
              const mine = m.userId === user?.id
              return (
                <div
                  key={m.id}
                  className={cn(
                    "flex flex-col gap-1",
                    mine ? "items-start" : "items-end",
                  )}
                >
                  {!mine && (
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground px-1">
                      <Avatar className="size-5">
                        <AvatarImage src={m.user?.avatarUrl || undefined} />
                        <AvatarFallback className="text-[9px] bg-amber-500/15 text-amber-600 dark:text-amber-400">
                          {m.isAdmin ? (
                            <Headphones className="size-3" />
                          ) : (
                            initialsOf(m.user?.displayName || null, m.user?.username || "")
                          )}
                        </AvatarFallback>
                      </Avatar>
                      <span className="font-medium">
                        {m.isAdmin ? "پشتیبانی کارول" : m.user?.displayName || m.user?.username}
                      </span>
                      {m.isAdmin && (
                        <Badge className="bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/30 text-[10px] px-1.5 py-0">
                          تیم پشتیبانی
                        </Badge>
                      )}
                    </div>
                  )}
                  <div
                    className={cn(
                      "max-w-[85%] sm:max-w-[75%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed break-words shadow-soft",
                      mine
                        ? "bg-primary text-primary-foreground rounded-bl-md"
                        : m.isAdmin
                          ? "bg-amber-500/15 text-foreground border border-amber-500/30 rounded-br-md"
                          : "bg-muted text-foreground rounded-br-md",
                    )}
                  >
                    <p className="whitespace-pre-wrap">{m.content}</p>
                    {m.attachments.length > 0 && (
                      <div className="mt-2 flex flex-col gap-1">
                        {m.attachments.map((url, i) => (
                          <a
                            key={i}
                            href={url}
                            target="_blank"
                            rel="noreferrer"
                            className={cn(
                              "inline-flex items-center gap-1.5 text-xs underline",
                              mine ? "text-primary-foreground/90" : "text-amber-600 dark:text-amber-400",
                            )}
                          >
                            <Paperclip className="size-3" />
                            {url.split("/").pop() || "پیوست"}
                          </a>
                        ))}
                      </div>
                    )}
                  </div>
                  <span className="text-[10px] text-muted-foreground px-1">
                    {formatTime(m.createdAt)}
                  </span>
                </div>
              )
            })}
            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Reply box */}
        <div className="border-t border-border bg-background/80 backdrop-blur px-4 sm:px-6 py-3">
          <div className="max-w-3xl mx-auto">
            {isClosed && !admin ? (
              <div className="flex items-center gap-2 text-sm text-muted-foreground py-2">
                <CheckCircle className="size-4" />
                این تیکت بسته شده است. در صورت نیاز تیکت جدید بسازید.
              </div>
            ) : (
              <div className="flex items-end gap-2">
                <Textarea
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault()
                      handleSend()
                    }
                  }}
                  placeholder={admin ? "پاسخ به کاربر..." : "پیام خود را بنویسید..."}
                  className="min-h-[44px] max-h-32 resize-none"
                  rows={1}
                  disabled={sending}
                />
                <Button
                  size="icon"
                  className="size-11 shrink-0 gradient-karol text-white shadow-soft"
                  onClick={handleSend}
                  disabled={sending || !draft.trim()}
                  aria-label="ارسال"
                >
                  {sending ? <Loader2 className="size-5 animate-spin" /> : <Send className="size-5" />}
                </Button>
              </div>
            )}
            {last && (
              <p className="text-[10px] text-muted-foreground mt-1.5 text-center">
                آخرین به‌روزرسانی {timeAgo(last.createdAt)} • به‌روزرسانی خودکار هر ۵ ثانیه
              </p>
            )}
          </div>
        </div>
      </div>
    )
  }

  // ============ List View ============
  return (
    <div className="p-4 sm:p-6 max-w-3xl mx-auto">
      <div className="flex items-center justify-between gap-3 mb-5">
        <div className="flex items-center gap-3">
          <div className="size-10 rounded-xl gradient-karol flex items-center justify-center shadow-soft">
            <TicketIcon className="size-5 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-lg sm:text-xl">تیکت‌ها</h1>
            <p className="text-xs text-muted-foreground">
              {admin ? "مدیریت تیکت‌های کاربران" : "پشتیبانی و ارتباط با تیم کارول"}
            </p>
          </div>
        </div>
        <Button
          onClick={() => setNewOpen(true)}
          className="gradient-karol text-white shadow-soft shrink-0"
          size="sm"
        >
          <Plus className="size-4" />
          <span className="hidden sm:inline">تیکت جدید</span>
        </Button>
      </div>

      {/* Filters (admin only) */}
      {admin && (
        <div className="flex flex-wrap items-center gap-2 mb-4">
          <div className="relative flex-1 min-w-[180px]">
            <Search className="size-4 absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="جستجوی موضوع یا کاربر..."
              className="pr-9 h-9"
            />
          </div>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="h-9 w-32">
              <Filter className="size-3.5" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">همه وضعیت‌ها</SelectItem>
              <SelectItem value="open">باز</SelectItem>
              <SelectItem value="pending">در انتظار</SelectItem>
              <SelectItem value="closed">بسته</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterCategory} onValueChange={setFilterCategory}>
            <SelectTrigger className="h-9 w-36">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">همه دسته‌ها</SelectItem>
              {Object.entries(CATEGORY_LABEL).map(([k, v]) => (
                <SelectItem key={k} value={k}>
                  {v}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {/* List */}
      {loading ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-24 w-full rounded-xl" />
          ))}
        </div>
      ) : tickets.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="py-12 flex flex-col items-center text-center">
            <div className="size-14 rounded-2xl gradient-karol flex items-center justify-center mb-4 opacity-80">
              <TicketIcon className="size-7 text-white" />
            </div>
            <h3 className="font-semibold text-base mb-1">
              {admin ? "هیچ تیکتی وجود ندارد" : "هنوز تیکتی نساخته‌اید"}
            </h3>
            <p className="text-sm text-muted-foreground max-w-sm mb-4">
              {admin
                ? "تیکت‌های کاربران در اینجا نمایش داده می‌شوند."
                : "سوال، مشکل یا پیشنهادی دارید؟ اولین تیکت خود را بسازید تا تیم پشتیبانی پاسخ دهد."}
            </p>
            {!admin && (
              <Button onClick={() => setNewOpen(true)} className="gradient-karol text-white shadow-soft">
                <Plus className="size-4" />
                ساخت تیکت
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2.5">
          {tickets.map((t) => {
            const unread =
              t.lastMessage &&
              t.lastMessage.isAdmin &&
              !admin &&
              new Date(t.lastMessage.createdAt).getTime() > getReadUpTo(t.id)
            return (
              <button
                key={t.id}
                onClick={() => openTicket(t.id)}
                className="w-full text-right group"
              >
                <Card className="hover:border-primary/40 hover:shadow-soft transition-all overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div className="relative shrink-0">
                        <div className="size-10 rounded-xl bg-muted flex items-center justify-center">
                          <MessageSquare className="size-5 text-muted-foreground" />
                        </div>
                        {unread && (
                          <span className="absolute -top-1 -right-1 size-3 rounded-full bg-emerald-500 ring-2 ring-background" />
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-semibold text-sm truncate flex-1 min-w-0">
                            {t.subject}
                          </h3>
                          {statusBadge(t.status)}
                          {priorityBadge(t.priority)}
                        </div>
                        <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                          {categoryBadge(t.category)}
                          <span className="text-xs text-muted-foreground">
                            {faDigits(t.messagesCount)} پیام
                          </span>
                          {admin && t.owner && (
                            <span className="text-xs text-muted-foreground flex items-center gap-1">
                              <Avatar className="size-4">
                                <AvatarImage src={t.owner.avatarUrl || undefined} />
                                <AvatarFallback className="text-[8px]">
                                  {initialsOf(t.owner.displayName, t.owner.username)}
                                </AvatarFallback>
                              </Avatar>
                              {t.owner.displayName || t.owner.username}
                            </span>
                          )}
                          {admin && t.assignedTo && (
                            <span className="text-xs text-amber-600 dark:text-amber-400 flex items-center gap-1">
                              <Headphones className="size-3" />
                              {t.assignedTo}
                            </span>
                          )}
                        </div>
                        {t.lastMessage && (
                          <p
                            className={cn(
                              "text-xs mt-2 truncate",
                              unread ? "text-foreground font-medium" : "text-muted-foreground",
                            )}
                          >
                            <span className="text-muted-foreground">
                              {t.lastMessage.isAdmin ? "پشتیبانی: " : "شما: "}
                            </span>
                            {t.lastMessage.content}
                          </p>
                        )}
                      </div>
                      <div className="shrink-0 text-left">
                        <p className="text-[10px] text-muted-foreground whitespace-nowrap">
                          {timeAgo(t.updatedAt)}
                        </p>
                        {t.status !== "closed" && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 mt-1 text-xs text-rose-600 hover:text-rose-700 hover:bg-rose-500/10 px-2"
                            onClick={(e) => {
                              e.stopPropagation()
                              setCloseTarget(t)
                            }}
                          >
                            بستن
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </button>
            )
          })}
        </div>
      )}

      {/* New ticket dialog */}
      <Dialog open={newOpen} onOpenChange={setNewOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <TicketIcon className="size-5 text-primary" />
              تیکت جدید
            </DialogTitle>
            <DialogDescription>
              پیام شما به تیم پشتیبانی کارول ارسال می‌شود.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5">
              <Label htmlFor="t-subject">موضوع</Label>
              <Input
                id="t-subject"
                value={newForm.subject}
                onChange={(e) => setNewForm({ ...newForm, subject: e.target.value })}
                placeholder="مثال: مشکل در پرداخت"
                maxLength={200}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>دسته‌بندی</Label>
                <Select
                  value={newForm.category}
                  onValueChange={(v) => setNewForm({ ...newForm, category: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(CATEGORY_LABEL).map(([k, v]) => (
                      <SelectItem key={k} value={k}>
                        {v}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>اولویت</Label>
                <Select
                  value={newForm.priority}
                  onValueChange={(v) => setNewForm({ ...newForm, priority: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">کم</SelectItem>
                    <SelectItem value="normal">معمولی</SelectItem>
                    <SelectItem value="high">فوری</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="t-message">پیام</Label>
              <Textarea
                id="t-message"
                value={newForm.message}
                onChange={(e) => setNewForm({ ...newForm, message: e.target.value })}
                placeholder="مشکل یا درخواست خود را به طور کامل توضیح دهید..."
                rows={5}
                maxLength={5000}
              />
              <p className="text-[10px] text-muted-foreground text-left">
                {faDigits(newForm.message.length)} / {faDigits(5000)}
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setNewOpen(false)} disabled={creating}>
              انصراف
            </Button>
            <Button
              onClick={handleCreate}
              disabled={creating || newForm.subject.trim().length < 3 || !newForm.message.trim()}
              className="gradient-karol text-white shadow-soft"
            >
              {creating ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
              ارسال تیکت
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Close confirmation */}
      <AlertDialog
        open={!!closeTarget}
        onOpenChange={(o) => !o && setCloseTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertCircle className="size-5 text-amber-500" />
              بستن تیکت
            </AlertDialogTitle>
            <AlertDialogDescription>
              آیا از بستن این تیکت مطمئن هستید؟
              {admin && " در صورت نیاز می‌توانید مجدداً آن را باز کنید."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleClose}
              className="bg-rose-600 hover:bg-rose-700 text-white"
            >
              بستن تیکت
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
