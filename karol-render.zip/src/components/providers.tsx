"use client"

import { QueryClient, QueryClientProvider } from "@tanstack/react-query"
import { useState, useEffect, useCallback } from "react"

export type KarolTheme = "aurora" | "sunset" | "ocean" | "forest" | "coral" | "light"

export const THEMES: { value: KarolTheme; label: string; swatch: string }[] = [
  { value: "aurora", label: "شفق", swatch: "#2dd4bf" },
  { value: "sunset", label: "غروب", swatch: "#fb7185" },
  { value: "ocean", label: "اقیانوس", swatch: "#38bdf8" },
  { value: "forest", label: "جنگل", swatch: "#a3e635" },
  { value: "coral", label: "مرجانی", swatch: "#f472b6" },
  { value: "light", label: "روشن", swatch: "#f5fbfa" },
]

export function Providers({ children }: { children: React.ReactNode }) {
  const [qc] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: { staleTime: 30_000, refetchOnWindowFocus: false, retry: 1 },
        },
      }),
  )

  const applyTheme = useCallback((theme: KarolTheme) => {
    document.documentElement.setAttribute("data-theme", theme)
    const meta = document.querySelector('meta[name="theme-color"]')
    const colors: Record<KarolTheme, string> = {
      aurora: "#060d11",
      sunset: "#1a0a0f",
      ocean: "#06121f",
      forest: "#0a1208",
      coral: "#1a0a14",
      light: "#f5fbfa",
    }
    if (meta) meta.setAttribute("content", colors[theme])
  }, [])

  useEffect(() => {
    const stored = (localStorage.getItem("karol-theme") as KarolTheme) || "aurora"
    applyTheme(stored)
    const handler = (e: Event) => {
      const t = (e as CustomEvent<KarolTheme>).detail
      applyTheme(t)
    }
    window.addEventListener("karol-theme-change", handler as EventListener)
    return () => window.removeEventListener("karol-theme-change", handler as EventListener)
  }, [applyTheme])

  return <QueryClientProvider client={qc}>{children}</QueryClientProvider>
}

export function setTheme(theme: KarolTheme) {
  localStorage.setItem("karol-theme", theme)
  window.dispatchEvent(new CustomEvent("karol-theme-change", { detail: theme }))
}

export function getTheme(): KarolTheme {
  return (localStorage.getItem("karol-theme") as KarolTheme) || "aurora"
}
