"use client"

import { Crown } from "lucide-react"
import { cn } from "@/lib/utils"
import type { ProfileEffect } from "./UserAvatar"

export interface UserNameUser {
  displayName?: string | null
  username?: string
  isVip?: boolean
  profileEffect?: ProfileEffect | null
  nameColor?: string | null
}

interface UserNameProps {
  user: UserNameUser
  className?: string
  showCrown?: boolean
  as?: "span" | "div"
}

export function UserName({
  user,
  className,
  showCrown = true,
  as = "span",
}: UserNameProps) {
  const effect = (user.profileEffect || "none") as ProfileEffect
  const isVip = !!user.isVip
  const name = user.displayName || user.username || "کاربر"
  const Comp: any = as

  let style: React.CSSProperties = {}
  let textClass = ""

  if (isVip && effect === "rainbow") {
    textClass = "karol-rainbow-text"
  } else if (isVip && user.nameColor) {
    style = { color: user.nameColor }
  }

  return (
    <Comp
      className={cn("inline-flex items-center gap-1 font-semibold", textClass, className)}
      style={style}
    >
      <span className="truncate">{name}</span>
      {showCrown && isVip && (
        <Crown className="w-3 h-3 text-gold shrink-0" aria-label="VIP" />
      )}
    </Comp>
  )
}
