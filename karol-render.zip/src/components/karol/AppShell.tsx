"use client"

import { useState } from "react"
import { useApp, isAppAdmin, type SectionId } from "@/lib/store"
import { THEMES, type KarolTheme } from "@/components/providers"
import { api } from "@/lib/format"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Home,
  MessageCircle,
  Music,
  Video,
  Film,
  HardDrive,
  ShoppingBag,
  Crown,
  Wallet,
  Ticket,
  User,
  Shield,
  Bell,
  Menu,
  Palette,
  LogOut,
  Coins,
  Check,
  Sparkles,
  Orbit,
  Mic,
  Clapperboard,
  Server,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface NavItem {
  id: SectionId
  label: string
  icon: React.ComponentType<{ className?: string }>
  group: "main" | "media" | "account" | "admin"
  vipOnly?: boolean
  adminOnly?: boolean
}

const NAV: NavItem[] = [
  { id: "feed", label: "خانه", icon: Home, group: "main" },
  { id: "galaxy", label: "کهکشان کارول", icon: Orbit, group: "main" },
  { id: "chat", label: "کارول چت", icon: MessageCircle, group: "main" },
  { id: "voice", label: "ویس چت", icon: Mic, group: "main" },
  { id: "watchparty", label: "تماشای گروهی", icon: Clapperboard, group: "main" },
  { id: "music", label: "موزیک", icon: Music, group: "media" },
  { id: "videos", label: "ویدیوها", icon: Video, group: "media" },
  { id: "reels", label: "ریلز", icon: Film, group: "media" },
  { id: "drive", label: "آپلود سنتر", icon: HardDrive, group: "media" },
  { id: "shop", label: "فروشگاه", icon: ShoppingBag, group: "main" },
  { id: "configs", label: "کانفیگ V2Ray", icon: Server, group: "main" },
  { id: "vip", label: "بخش VIP", icon: Crown, group: "main", vipOnly: false },
  { id: "wallet", label: "کیف پول", icon: Wallet, group: "account" },
  { id: "tickets", label: "تیکت‌ها", icon: Ticket, group: "account" },
  { id: "notifications", label: "اعلان‌ها", icon: Bell, group: "account" },
  { id: "profile", label: "پروفایل", icon: User, group: "account" },
  { id: "admin", label: "پنل مدیریت", icon: Shield, group: "admin", adminOnly: true },
]

const GROUP_LABELS: Record<string, string> = {
  main: "اصلی",
  media: "رسانه",
  account: "حساب کاربری",
  admin: "مدیریت",
}

const THEME_OPTIONS = THEMES

function NavList({ onNavigate }: { onNavigate?: () => void }) {
  const { user, section, setSection } = useApp()
  if (!user) return null
  const items = NAV.filter((n) => {
    if (n.adminOnly && !isAppAdmin(user)) return false
    return true
  })
  const groups: Record<string, NavItem[]> = {}
  for (const it of items) (groups[it.group] ||= []).push(it)

  return (
    <nav className="flex flex-col gap-4 p-2">
      {Object.entries(groups).map(([g, arr]) => (
        <div key={g} className="space-y-0.5">
          <div className="px-3 pt-2 pb-1 text-[10px] font-bold text-muted-c/80 uppercase tracking-wider">
            {GROUP_LABELS[g]}
          </div>
          {arr.map((it) => {
            const active = section === it.id
            return (
              <button
                key={it.id}
                onClick={() => {
                  setSection(it.id)
                  onNavigate?.()
                }}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-[13.5px] font-medium transition-all relative",
                  active
                    ? "bg-accent-15 text-accent-soft"
                    : "text-secondary-c hover:bg-white/[0.04] hover:text-primary-c",
                )}
              >
                <it.icon className={cn("w-[18px] h-[18px] shrink-0", active && "text-accent-soft")} />
                <span className="flex-1 text-right">{it.label}</span>
                {it.id === "vip" && user.isVip && (
                  <Crown className="w-3.5 h-3.5 text-gold" />
                )}
                {it.id === "vip" && !user.isVip && (
                  <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-warning-15 text-warning font-bold">VIP</span>
                )}
              </button>
            )
          })}
        </div>
      ))}
    </nav>
  )
}

function CoinPill() {
  const { user, setSection } = useApp()
  if (!user) return null
  return (
    <button
      onClick={() => setSection("wallet")}
      className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-warning-15 hover:bg-warning-15/70 transition-colors"
    >
      <Coins className="w-4 h-4 text-warning" />
      <span className="text-[13px] font-bold text-warning tabular-nums">
        {user.coins.toLocaleString("fa-IR")}
      </span>
    </button>
  )
}

function ThemeSwitcher() {
  const { theme, setTheme } = useApp()
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="h-9 w-9 rounded-full">
          <Palette className="w-4 h-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <DropdownMenuLabel>پوسته کارول</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {THEME_OPTIONS.map((t) => (
          <DropdownMenuItem key={t.value} onClick={() => setTheme(t.value)} className="gap-2">
            <span
              className="w-4 h-4 rounded-full border border-border/40 shrink-0"
              style={{ background: t.swatch }}
            />
            <span className="flex-1">{t.label}</span>
            {theme === t.value && <Check className="w-3.5 h-3.5 text-accent" />}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

function UserMenu() {
  const { user, setSection, toast } = useApp()
  if (!user) return null
  async function logout() {
    try {
      await api("/api/auth", { method: "POST", json: { action: "logout" } })
      window.location.reload()
    } catch {
      toast("خطا در خروج", "error")
    }
  }
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="flex items-center gap-2 rounded-full pr-1 pl-3 py-1 hover:bg-white/[0.04] transition-colors">
          <Avatar className="w-8 h-8 border border-hair">
            <AvatarImage src={user.avatarUrl || undefined} />
            <AvatarFallback className="bg-accent-15 text-accent-soft text-xs font-bold">
              {user.displayName?.[0]?.toUpperCase() || user.username[0]?.toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <span className="hidden sm:block text-[13px] font-medium max-w-[120px] truncate text-primary-c">{user.displayName || user.username}</span>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <div className="px-2 py-1.5">
          <div className="text-sm font-semibold truncate text-primary-c">{user.displayName || user.username}</div>
          <div className="text-xs text-muted-c">@{user.username}</div>
          {user.isVip && (
            <Badge className="mt-1 bg-gold text-gold-foreground gap-1">
              <Crown className="w-3 h-3" /> عضو VIP
            </Badge>
          )}
        </div>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => setSection("profile")}>
          <User className="w-4 h-4 ml-2" /> پروفایل من
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => setSection("wallet")}>
          <Wallet className="w-4 h-4 ml-2" /> کیف پول
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => setSection("tickets")}>
          <Ticket className="w-4 h-4 ml-2" /> تیکت‌ها
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={logout} className="text-destructive focus:text-destructive">
          <LogOut className="w-4 h-4 ml-2" /> خروج از حساب
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const { section, setSection } = useApp()
  const [mobileOpen, setMobileOpen] = useState(false)

  const currentLabel = NAV.find((n) => n.id === section)?.label || "کارول"

  return (
    <div className="min-h-screen flex flex-col bg-base">
      <header className="sticky top-0 z-40 border-b border-hair glass">
        <div className="flex h-14 items-center gap-2 px-3 sm:px-4">
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden h-9 w-9">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72 p-0 bg-surface border-hair">
              <div className="h-14 flex items-center gap-2 px-4 border-b border-hair">
                <img src="/logo.svg" alt="" className="w-8 h-8" />
                <span className="font-black text-gradient-karol text-lg">کارول</span>
              </div>
              <div className="overflow-y-auto thin-scrollbar h-[calc(100vh-3.5rem)]">
                <NavList onNavigate={() => setMobileOpen(false)} />
              </div>
            </SheetContent>
          </Sheet>

          <div className="flex items-center gap-2 lg:hidden">
            <img src="/logo.svg" alt="" className="w-7 h-7" />
            <span className="font-black text-gradient-karol">کارول</span>
          </div>

          <div className="hidden lg:flex items-center gap-2">
            <h1 className="text-base font-bold text-primary-c">{currentLabel}</h1>
          </div>

          <div className="flex-1" />

          <div className="flex items-center gap-1.5 sm:gap-2">
            <CoinPill />
            <Button variant="ghost" size="icon" className="h-9 w-9 rounded-full" onClick={() => setSection("notifications")}>
              <Bell className="w-4 h-4" />
            </Button>
            <ThemeSwitcher />
            <UserMenu />
          </div>
        </div>
      </header>

      <div className="flex-1 flex">
        <aside className="hidden lg:flex w-64 shrink-0 border-l border-hair flex-col bg-surface">
          <div className="h-14 flex items-center gap-2 px-4 border-b border-hair">
            <img src="/logo.svg" alt="" className="w-8 h-8" />
            <span className="font-black text-gradient-karol text-lg">کارول</span>
          </div>
          <div className="overflow-y-auto thin-scrollbar flex-1">
            <NavList />
          </div>
          <div className="p-3 border-t border-hair text-[10px] text-muted-c text-center">
            نسخه ۱.۰ — کارول
          </div>
        </aside>

        <main className="flex-1 min-w-0 flex flex-col">
          <div className="flex-1 min-h-0">{children}</div>
        </main>
      </div>

      <nav className="lg:hidden sticky bottom-0 z-40 border-t border-hair glass grid grid-cols-6 h-16">
        {([
          { id: "feed" as const, icon: Home, label: "خانه" },
          { id: "chat" as const, icon: MessageCircle, label: "چت" },
          { id: "voice" as const, icon: Mic, label: "ویس" },
          { id: "watchparty" as const, icon: Clapperboard, label: "تماشا" },
          { id: "music" as const, icon: Music, label: "موزیک" },
          { id: "configs" as const, icon: Server, label: "کانفیگ" },
        ]).map((it) => {
          const active = section === it.id
          return (
            <button
              key={it.id}
              onClick={() => setSection(it.id)}
              className={cn(
                "flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium transition-colors",
                active ? "text-accent-soft" : "text-muted-c",
              )}
            >
              <it.icon className="w-5 h-5" />
              {it.label}
            </button>
          )
        })}
      </nav>
    </div>
  )
}
