"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { cn } from "@/lib/utils"

export type ProfileEffect = "none" | "rgb" | "rainbow" | "pulse" | "gold" | string

export interface UserAvatarUser {
  avatarUrl?: string | null
  animatedAvatarUrl?: string | null
  isVip?: boolean
  profileEffect?: ProfileEffect | null
  displayName?: string | null
  username?: string
}

interface UserAvatarProps {
  user: UserAvatarUser
  size?: "xs" | "sm" | "md" | "lg" | "xl"
  className?: string
  rounded?: string
}

const SIZES: Record<NonNullable<UserAvatarProps["size"]>, string> = {
  xs: "w-8 h-8",
  sm: "w-9 h-9",
  md: "w-10 h-10",
  lg: "w-12 h-12",
  xl: "w-24 h-24",
}

const TEXT_SIZES: Record<NonNullable<UserAvatarProps["size"]>, string> = {
  xs: "text-[11px]",
  sm: "text-xs",
  md: "text-sm",
  lg: "text-base",
  xl: "text-3xl",
}

export function UserAvatar({ user, size = "md", className, rounded }: UserAvatarProps) {
  const effect = (user.profileEffect || "none") as ProfileEffect
  const isVip = !!user.isVip
  const showEffect = isVip && effect !== "none"

  const sizeCls = SIZES[size]
  const textCls = TEXT_SIZES[size]
  const radiusCls = rounded ?? (size === "xl" ? "rounded-2xl" : "rounded-full")

  const ringClass = showEffect
    ? effect === "rgb"
      ? "karol-rgb-ring"
      : effect === "pulse"
        ? "karol-pulse-glow"
        : effect === "gold"
          ? "karol-gold-ring"
          : ""
    : ""

  const animatedUrl = user.animatedAvatarUrl || null
  const staticUrl = user.avatarUrl || null
  const useAnimated = isVip && animatedUrl
  const imgSrc = useAnimated ? animatedUrl! : staticUrl

  const initials =
    (user.displayName || user.username || "?")?.[0]?.toUpperCase() || "?"

  return (
    <div className={cn("relative inline-block", sizeCls, className)}>
      <Avatar
        className={cn(
          sizeCls,
          radiusCls,
          "border-2 border-background shrink-0",
          ringClass,
        )}
      >
        {imgSrc ? (
          <AvatarImage src={imgSrc} alt={user.displayName || user.username || ""} />
        ) : null}
        <AvatarFallback
          className={cn(
            radiusCls,
            "bg-primary/15 text-primary font-black",
            textCls,
          )}
        >
          {initials}
        </AvatarFallback>
      </Avatar>
    </div>
  )
}
